=== Woo Telegram Alert ===
Contributors: borbila
Tags: woocommerce, telegram, orders, notifications, hpos
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 4.5.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Send WooCommerce checkout and manual status notifications to Telegram with custom templates, multiple chat IDs, and status filters.

== Description ==

Woo Telegram Alert connects WooCommerce to Telegram. It sends one Telegram notification after checkout reaches the thank-you page, and it can also notify when an admin manually changes an order to an enabled status. The plugin includes a custom message template, placeholder replacement, multiple comma-separated chat IDs, duplicate prevention, and HPOS compatibility declaration.

== Features ==

* Telegram Bot Token and Chat ID settings.
* Borbila license activation for WooCommerce alert features.
* Multiple Telegram chat IDs separated by comma.
* AJAX Test Message button.
* WooCommerce order notifications based on selected order statuses.
* Custom new order message template.
* Placeholder replacement system.
* Duplicate prevention for checkout order alerts.
* WooCommerce inactive safety notice.
* HPOS compatibility declaration.

== Requirements ==

* WordPress 5.8 or newer.
* PHP 7.4 or newer.
* WooCommerce for order notifications.
* A Telegram bot token from BotFather.
* A Telegram chat ID, group ID, or channel ID.

The settings page and Test Message feature can open without WooCommerce. WooCommerce is required only for order notifications.

== Installation ==

1. Upload the `woo-telegram-alert` folder to `/wp-content/plugins/`.
2. Go to WordPress Admin > Plugins.
3. Activate `Woo Telegram Alert`.
4. Go to WordPress Admin > Telegram Alert.
5. Enter your Telegram Bot Token.
6. Enter one or more Telegram Chat IDs.
7. Enable the WooCommerce alert types you want.
8. Save settings.
9. Send a test message.

== Create a Telegram Bot ==

1. Open Telegram and search for `@BotFather`.
2. Start a chat with BotFather.
3. Send `/newbot`.
4. Follow the prompts to choose a bot name and username.
5. Copy the bot token BotFather gives you.
6. Paste the token into WordPress Admin > Telegram Alert > Telegram Bot Token.

== Get a Chat ID ==

1. Send any message to your Telegram bot.
2. Open this URL in a browser, replacing `BOT_TOKEN` with your real token:
   `https://api.telegram.org/botBOT_TOKEN/getUpdates`
3. Find the `chat` object in the response.
4. Copy the `id` value.
5. Paste it into the Telegram Chat ID field.

For a group or channel, add the bot first, send a message in that group or channel, then check `getUpdates`.

== Multiple Chat IDs ==

Use comma-separated chat IDs to send the same alert to multiple Telegram users, groups, or channels.

Example:

`123456789,-1001234567890`

The plugin ignores empty comma values. If at least one chat ID succeeds and another fails, the notification is treated as partially sent.

== Configure WooCommerce Order Notifications ==

1. Install and activate WooCommerce.
2. Go to WordPress Admin > Telegram Alert.
3. Open WooCommerce Alerts.
4. Turn on the order statuses you want to notify for.
5. Save settings.
6. Place a WooCommerce checkout test order.

Telegram messages are sent only when checkout reaches the thank-you page or an admin manually changes an order status, and the current status matches an enabled status. For example, if you only want successful order notifications, keep `Completed` enabled and turn the other status filters off.

After a successful alert, the plugin saves order meta to prevent duplicate notifications for the same checkout order.

== Customize Message Template ==

Go to WordPress Admin > Telegram Alert > Message Template. Edit the template and save settings.

Allowed Telegram HTML tags:

`b`, `strong`, `i`, `em`, `code`, `pre`, `a`

Unsafe HTML is removed before sending to Telegram.

Use Reset to Default Template to restore the built-in template.

== Supported Placeholders ==

`{order_id}`
`{order_date}`
`{customer_name}`
`{billing_first_name}`
`{billing_last_name}`
`{billing_phone}`
`{billing_email}`
`{billing_address}`
`{shipping_address}`
`{order_items}`
`{payment_method}`
`{subtotal}`
`{shipping_total}`
`{discount_total}`
`{order_total}`
`{order_status}`
`{currency}`
`{site_name}`
`{admin_order_url}`

Manual status change alerts also support:

`{old_status}`
`{new_status}`

== FAQ ==

= Does the plugin work without WooCommerce? =

The settings page opens safely without WooCommerce. Order notifications require WooCommerce.

= Does this support WooCommerce HPOS? =

Yes. The plugin declares compatibility with WooCommerce custom order tables when the WooCommerce FeaturesUtil class is available and uses order object meta methods.

= Can I send alerts to multiple Telegram groups? =

Yes. Add comma-separated chat IDs in the Chat ID field.

= Can I use custom HTML in templates? =

Only Telegram-supported HTML tags are allowed: `b`, `strong`, `i`, `em`, `code`, `pre`, and `a`.

= Are settings deleted on deactivation? =

No. Settings are preserved on deactivation.

= Does the plugin create custom database tables? =

No. Settings are stored in WordPress options, and duplicate prevention uses WooCommerce order meta.

== Changelog ==

= 4.5.0 =
* Fixed Telegram Bot Token, Chat ID, status, and message-template saving on restrictive hosting environments.
* Added AJAX settings saving with an encoded normal-form fallback when admin AJAX is blocked.
* Added non-JavaScript fallback actions for license activation and deactivation.
* Switched Borbila licensing to the canonical JSON REST API URL with normalized domain handling.
* Added daily license validation while preserving the last valid state during connection failures.
* Added instant master license activation without storing the clear-text master key.

= 4.4.4 =
* Added a Telegram getUpdates helper link below the Chat ID field.

= 4.4.3 =
* Updated the Video Guide embed URL.

= 4.4.2 =
* Improved locked order status toggle styling and forced inactive-license toggles to render off.

= 4.4.1 =
* Moved the inactive-license lock icon inside the disabled order status toggle.

= 4.4.0 =
* Kept disabled order status toggles visible beside lock icons when the license is inactive.

= 4.3.9 =
* Made order status notifications default to off on new installs.
* Replaced inactive-license order status toggles with lock icons and a license activation message.

= 4.3.8 =
* Removed the message template textarea label from the admin UI.

= 4.3.7 =
* Removed the Telegram Bot Token helper text from the admin UI.

= 4.3.6 =
* Removed the template helper text from the Message Template tab.

= 4.3.5 =
* Added temporary success/error messages after license activate and deactivate actions.

= 4.3.4 =
* Restored the header connection and license status badges.

= 4.3.3 =
* Removed selected header badges, license helper text, license response bar, and footer helper copy from the admin UI.

= 4.3.2 =
* Removed the Debug Logs tab, debug toggle, clear logs action, and stored log output.

= 4.3.1 =
* Moved the License Key tab to the bottom of the dashboard sidebar.

= 4.3.0 =
* Added Borbila license activation tab.
* Locked automatic WooCommerce Telegram alerts behind an active Borbila license.
* Kept Telegram settings and Test Message available without a license.

= 4.2.4 =
* Reduced Telegram request timeout to avoid long waits if the Telegram API is slow.

= 4.2.3 =
* Changed the Video Guide embed to click-to-load so YouTube does not slow the admin dashboard load.

= 4.2.2 =
* Moved the settings saved notice from the header to the save footer area.

= 4.2.1 =
* Added linked Borbila author credit to the admin dashboard footer.

= 4.2.0 =
* Updated plugin author metadata to Borbila with the Borbila website link.
* Added a Settings shortcut on the WordPress Plugins screen.

= 4.1.9 =
* Updated Borbila header links to circular social icon buttons.

= 4.1.8 =
* Added Borbila branding and social links to the admin header.

= 4.1.7 =
* Added a Video Guide tab with an embedded YouTube setup guide.

= 4.1.6 =
* Changed manual status change notifications to use a compact status-update message.
* Kept checkout order notifications on the full custom order template.

= 4.1.5 =
* Added admin-only manual status change notifications.
* Manual status changes use the normal order message template.
* Frontend checkout automatic status changes remain ignored.

= 4.1.4 =
* Removed the order status change notification hook and status-change message.
* Removed the deferred alert queue.
* Checkout now sends one immediate order alert from the thank-you page using the current order status.

= 4.1.3 =
* Added a short deferred alert queue to avoid duplicate Pending to Processing messages during checkout.
* Telegram alerts now use the settled order status after WooCommerce finishes automatic status changes.

= 4.1.2 =
* Removed separate New Order Alert and Status Change Alert toggles from the admin UI.
* Made order status toggles the only WooCommerce notification controls.
* Kept internal options enabled for backward compatibility.
* Prevented duplicate alerts when a new order is created directly in an enabled status.

= 4.1.1 =
* Applied order status filters to New Order Alert as well as Status Change Alert.
* Clarified the WooCommerce Alerts settings text.

= 4.1.0 =
* Moved WooCommerce Alerts to the first settings tab.
* Added per-status notification filters for order status alerts.
* Removed the global enable toggle; active plugins are enabled by default.

= 4.0.0 =
* Added better Telegram API error handling.
* Added invalid JSON handling.
* Added partial multiple-chat delivery handling.
* Added final admin UI polish.
* Added final production readme.

= 3.0.0 =
* Added custom new order message template.
* Added placeholder replacement system.
* Added order status-change Telegram alerts.
* Added multiple comma-separated Chat ID support.
* Added Reset to Default Template button.
* Added billing and shipping address placeholders.

= 2.0.0 =
* Added WooCommerce new order Telegram alerts.
* Added Enable New Order Alert setting.
* Added WooCommerce inactive admin notice and settings warning card.
* Added duplicate prevention with order meta.
* Added WooCommerce HPOS compatibility declaration.

= 1.0.0 =
* Initial release.
* Added plugin bootstrap and constants.
* Added admin settings page.
* Added Telegram Bot Token and Chat ID settings.
* Added AJAX-powered Test Message feature.
