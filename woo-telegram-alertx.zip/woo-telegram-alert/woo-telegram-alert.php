<?php
/**
 * Plugin Name: Woo Telegram Alert
 * Plugin URI: https://borbila.com/
 * Description: Send automatic Telegram notifications for WooCommerce orders.
 * Version: 4.5.0
 * Author: Borbila
 * Author URI: https://borbila.com/
 * Text Domain: woo-telegram-alert
 *
 * @package Woo_Telegram_Alert
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WTA_VERSION' ) ) {
	define( 'WTA_VERSION', '4.5.0' );
}

if ( ! defined( 'WTA_PLUGIN_FILE' ) ) {
	define( 'WTA_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'WTA_PLUGIN_DIR' ) ) {
	define( 'WTA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'WTA_PLUGIN_URL' ) ) {
	define( 'WTA_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! defined( 'WTA_MASKED_TOKEN_VALUE' ) ) {
	define( 'WTA_MASKED_TOKEN_VALUE', '••••••••••••••••••••••••' );
}

require_once WTA_PLUGIN_DIR . 'includes/class-wta-logger.php';
require_once WTA_PLUGIN_DIR . 'includes/class-wta-license.php';
require_once WTA_PLUGIN_DIR . 'includes/class-wta-telegram.php';
require_once WTA_PLUGIN_DIR . 'includes/class-wta-woocommerce.php';
require_once WTA_PLUGIN_DIR . 'includes/class-wta-admin.php';
require_once WTA_PLUGIN_DIR . 'includes/class-wta-plugin.php';

register_activation_hook( __FILE__, array( 'WTA_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WTA_Plugin', 'deactivate' ) );

/**
 * Declare WooCommerce feature compatibility.
 *
 * @return void
 */
function wta_declare_woocommerce_compatibility() {
	if ( class_exists( 'Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
			'custom_order_tables',
			WTA_PLUGIN_FILE,
			true
		);
	}
}
add_action( 'before_woocommerce_init', 'wta_declare_woocommerce_compatibility' );

/**
 * Initialize Woo Telegram Alert.
 *
 * @return void
 */
function wta_initialize_plugin() {
	WTA_Plugin::instance();
}
add_action( 'plugins_loaded', 'wta_initialize_plugin' );
