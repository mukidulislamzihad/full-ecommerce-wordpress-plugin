<?php
/**
 * Telegram Bot API client.
 *
 * @package Woo_Telegram_Alert
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sends messages through the Telegram Bot API.
 */
class WTA_Telegram {

	/**
	 * Telegram bot token.
	 *
	 * @var string
	 */
	private $bot_token = '';

	/**
	 * Telegram chat ID.
	 *
	 * @var string
	 */
	private $chat_ids = '';

	/**
	 * Class constructor.
	 *
	 * @param string $bot_token Telegram bot token.
	 * @param string $chat_ids  Telegram chat ID or comma-separated chat IDs.
	 */
	public function __construct( $bot_token = '', $chat_ids = '' ) {
		$this->bot_token = trim( (string) $bot_token );
		$this->chat_ids  = trim( (string) $chat_ids );
	}

	/**
	 * Send a Telegram message.
	 *
	 * @param string $text Message text.
	 * @return true|array|WP_Error
	 */
	public function send_message( $text ) {
		$text = trim( wp_kses( (string) $text, self::get_allowed_html() ) );

		if ( '' === $this->bot_token ) {
			WTA_Logger::add_log( 'error', __( 'Missing bot token.', 'woo-telegram-alert' ) );

			return new WP_Error(
				'wta_missing_bot_token',
				esc_html__( 'Telegram Bot Token is required.', 'woo-telegram-alert' )
			);
		}

		$chat_ids = $this->get_chat_ids();

		if ( empty( $chat_ids ) ) {
			WTA_Logger::add_log( 'error', __( 'Missing chat ID.', 'woo-telegram-alert' ) );

			return new WP_Error(
				'wta_missing_chat_id',
				esc_html__( 'Telegram Chat ID is required.', 'woo-telegram-alert' )
			);
		}

		if ( '' === trim( (string) $text ) ) {
			return new WP_Error(
				'wta_empty_message',
				esc_html__( 'Message text is required.', 'woo-telegram-alert' )
			);
		}

		$sent_count = 0;
		$errors     = array();

		foreach ( $chat_ids as $chat_id ) {
			$result = $this->send_single_message( $chat_id, $text );

			if ( true === $result ) {
				++$sent_count;
				continue;
			}

			if ( is_wp_error( $result ) ) {
				$errors[] = $result->get_error_message();
			}
		}

		if ( $sent_count > 0 ) {
			if ( ! empty( $errors ) ) {
				$message = sprintf(
					/* translators: 1: successful chat count, 2: failed chat count. */
					__( 'Telegram message partially sent. Successful chats: %1$d. Failed chats: %2$d.', 'woo-telegram-alert' ),
					$sent_count,
					count( $errors )
				);

				WTA_Logger::add_log( 'error', $message . ' ' . implode( ' ', array_unique( $errors ) ) );

				return array(
					'partial'      => true,
					'sent_count'   => $sent_count,
					'failed_count' => count( $errors ),
					'message'      => $message,
				);
			}

			return true;
		}

		$error_message = ! empty( $errors )
			? implode( ' ', array_unique( $errors ) )
			: esc_html__( 'Telegram message could not be sent to any chat ID.', 'woo-telegram-alert' );

		WTA_Logger::add_log(
			'error',
			sprintf(
				/* translators: %s: Telegram error message. */
				__( 'Telegram message failed for all chat IDs. %s', 'woo-telegram-alert' ),
				$error_message
			)
		);

		return new WP_Error(
			'wta_all_telegram_requests_failed',
			$error_message
		);
	}

	/**
	 * Send a Telegram message to one chat ID.
	 *
	 * @param string $chat_id Telegram chat ID.
	 * @param string $text    Message text.
	 * @return true|WP_Error
	 */
	private function send_single_message( $chat_id, $text ) {
		$endpoint = esc_url_raw( 'https://api.telegram.org/bot' . $this->bot_token . '/sendMessage' );
		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => 8,
				'body'    => array(
					'chat_id'                  => $chat_id,
					'text'                     => $text,
					'parse_mode'               => 'HTML',
					'disable_web_page_preview' => true,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			$request_error = $this->redact_sensitive_data( $response->get_error_message() );

			WTA_Logger::add_log(
				'error',
				sprintf(
					/* translators: %s: request error message. */
					__( 'Telegram request failed: %s', 'woo-telegram-alert' ),
					$request_error
				)
			);

			return new WP_Error(
				'wta_request_failed',
				sprintf(
					/* translators: %s: request error message. */
					esc_html__( 'Telegram request failed: %s', 'woo-telegram-alert' ),
					$request_error
				)
			);
		}

		$status_code = (int) wp_remote_retrieve_response_code( $response );
		$body        = wp_remote_retrieve_body( $response );
		$data        = json_decode( $body, true );

		if ( JSON_ERROR_NONE !== json_last_error() ) {
			$message = esc_html__( 'Telegram API returned an invalid JSON response.', 'woo-telegram-alert' );

			WTA_Logger::add_log( 'error', $message );

			return new WP_Error(
				'wta_invalid_json_response',
				$message
			);
		}

		if ( 200 !== $status_code || ! is_array( $data ) || empty( $data['ok'] ) ) {
			$message = $this->get_api_error_message( $data, $status_code );

			WTA_Logger::add_log( 'error', $message );

			return new WP_Error(
				'wta_telegram_api_error',
				$message
			);
		}

		return true;
	}

	/**
	 * Parse comma-separated Telegram chat IDs.
	 *
	 * @return array
	 */
	private function get_chat_ids() {
		$chat_ids = array_map( 'trim', explode( ',', $this->chat_ids ) );
		$chat_ids = array_filter(
			$chat_ids,
			static function ( $chat_id ) {
				return '' !== $chat_id;
			}
		);

		return array_values( array_unique( $chat_ids ) );
	}

	/**
	 * Escape dynamic text for Telegram HTML messages.
	 *
	 * @param mixed $text Text to escape.
	 * @return string
	 */
	public static function escape_html( $text ) {
		return htmlspecialchars(
			wp_check_invalid_utf8( (string) $text ),
			ENT_QUOTES | ENT_SUBSTITUTE,
			'UTF-8',
			false
		);
	}

	/**
	 * Allowed Telegram HTML tags.
	 *
	 * @return array
	 */
	public static function get_allowed_html() {
		return array(
			'b'      => array(),
			'strong' => array(),
			'i'      => array(),
			'em'     => array(),
			'code'   => array(),
			'pre'    => array(),
			'a'      => array(
				'href' => array(),
			),
		);
	}

	/**
	 * Redact the bot token from messages returned to admins.
	 *
	 * @param string $message Error message.
	 * @return string
	 */
	private function redact_sensitive_data( $message ) {
		$message = (string) $message;

		if ( '' !== $this->bot_token ) {
			$message = str_replace( $this->bot_token, '[redacted-token]', $message );
		}

		$message = preg_replace( '/\b\d{6,}:[A-Za-z0-9_-]{20,}\b/', '[redacted-token]', $message );

		return $message;
	}

	/**
	 * Build a safe Telegram API error message.
	 *
	 * @param array|null $data        Decoded Telegram response.
	 * @param int        $status_code HTTP status code.
	 * @return string
	 */
	private function get_api_error_message( $data, $status_code ) {
		if ( is_array( $data ) && ! empty( $data['description'] ) ) {
			return sprintf(
				/* translators: %s: Telegram API error description. */
				esc_html__( 'Telegram API error: %s', 'woo-telegram-alert' ),
				sanitize_text_field( $data['description'] )
			);
		}

		return sprintf(
			/* translators: %d: HTTP response code. */
			esc_html__( 'Telegram API request failed with HTTP status %d.', 'woo-telegram-alert' ),
			$status_code
		);
	}
}
