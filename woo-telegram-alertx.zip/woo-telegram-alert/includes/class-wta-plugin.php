<?php
/**
 * Main plugin class.
 *
 * @package Woo_Telegram_Alert
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bootstraps the Woo Telegram Alert plugin.
 */
class WTA_Plugin {

	/**
	 * Plugin instance.
	 *
	 * @var WTA_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Admin instance.
	 *
	 * @var WTA_Admin|null
	 */
	private $admin = null;

	/**
	 * WooCommerce integration instance.
	 *
	 * @var WTA_WooCommerce|null
	 */
	private $woocommerce = null;

	/**
	 * Return the plugin singleton.
	 *
	 * @return WTA_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Plugin constructor.
	 */
	private function __construct() {
		add_action( 'init', array( $this, 'load_textdomain' ) );
		WTA_License::register_hooks();

		$this->maybe_upgrade_settings();

		if ( is_admin() ) {
			add_filter( 'plugin_action_links_' . plugin_basename( WTA_PLUGIN_FILE ), array( $this, 'add_plugin_action_links' ) );

			$this->admin = new WTA_Admin();
		}

		if ( self::is_woocommerce_active() ) {
			$this->woocommerce = new WTA_WooCommerce();
		}
	}

	/**
	 * Set default options on activation.
	 *
	 * @return void
	 */
	public static function activate() {
		WTA_License::maybe_add_default();
		WTA_License::ensure_validation_schedule();

		$existing = get_option( 'wta_settings', array() );

		if ( ! is_array( $existing ) || empty( $existing ) ) {
			update_option( 'wta_settings', self::get_default_settings() );
			return;
		}

		$settings = wp_parse_args( $existing, self::get_default_settings() );
		$settings['enabled'] = 'yes';
		$settings['new_order_alert'] = 'yes';
		$settings['status_alert_statuses'] = self::normalize_status_alert_statuses( $settings['status_alert_statuses'] );

		if ( empty( $settings['message_template'] ) ) {
			$settings['message_template'] = self::get_default_message_template();
		}

		update_option( 'wta_settings', $settings );
	}

	/**
	 * Keep settings during deactivation.
	 *
	 * @return void
	 */
	public static function deactivate() {
		WTA_License::unschedule_validation();
		// Settings and license data are intentionally preserved.
	}

	/**
	 * Load translations.
	 *
	 * @return void
	 */
	public function load_textdomain() {
		load_plugin_textdomain(
			'woo-telegram-alert',
			false,
			dirname( plugin_basename( WTA_PLUGIN_FILE ) ) . '/languages'
		);
	}

	/**
	 * Add quick links on the WordPress Plugins screen.
	 *
	 * @param array $actions Existing plugin action links.
	 * @return array
	 */
	public function add_plugin_action_links( $actions ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return $actions;
		}

		$settings_link = sprintf(
			'<a href="%1$s">%2$s</a>',
			esc_url( admin_url( 'admin.php?page=woo-telegram-alert' ) ),
			esc_html__( 'Settings', 'woo-telegram-alert' )
		);

		return array_merge(
			array(
				'settings' => $settings_link,
			),
			$actions
		);
	}

	/**
	 * Default plugin settings.
	 *
	 * @return array
	 */
	public static function get_default_settings() {
		return array(
			'enabled'               => 'yes',
			'new_order_alert'       => 'yes',
			'status_alert_statuses' => self::get_default_status_alert_statuses(),
			'bot_token'             => '',
			'chat_id'               => '',
			'message_template'      => self::get_default_message_template(),
		);
	}

	/**
	 * Get order statuses available for status alert filtering.
	 *
	 * @return array
	 */
	public static function get_order_status_options() {
		if ( function_exists( 'wc_get_order_statuses' ) ) {
			$woocommerce_statuses = wc_get_order_statuses();
			$statuses             = array();

			foreach ( $woocommerce_statuses as $status_key => $status_label ) {
				$status_key = sanitize_key( preg_replace( '/^wc-/', '', (string) $status_key ) );

				if ( '' === $status_key ) {
					continue;
				}

				$statuses[ $status_key ] = wp_strip_all_tags( (string) $status_label );
			}

			if ( ! empty( $statuses ) ) {
				return $statuses;
			}
		}

		return array(
			'pending'        => __( 'Pending payment', 'woo-telegram-alert' ),
			'processing'     => __( 'Processing', 'woo-telegram-alert' ),
			'on-hold'        => __( 'On hold', 'woo-telegram-alert' ),
			'completed'      => __( 'Completed', 'woo-telegram-alert' ),
			'cancelled'      => __( 'Cancelled', 'woo-telegram-alert' ),
			'refunded'       => __( 'Refunded', 'woo-telegram-alert' ),
			'failed'         => __( 'Failed', 'woo-telegram-alert' ),
			'checkout-draft' => __( 'Draft', 'woo-telegram-alert' ),
		);
	}

	/**
	 * Default status alert toggle values.
	 *
	 * @return array
	 */
	public static function get_default_status_alert_statuses() {
		return array();
	}

	/**
	 * Normalize saved status alert toggle values.
	 *
	 * @param mixed $statuses Saved statuses.
	 * @return array
	 */
	public static function normalize_status_alert_statuses( $statuses ) {
		if ( ! is_array( $statuses ) ) {
			return array();
		}

		$available  = self::get_order_status_options();
		$normalized = array();

		foreach ( $statuses as $status_key => $enabled ) {
			if ( is_int( $status_key ) ) {
				$status_key = $enabled;
				$enabled    = 'yes';
			}

			$status_key = sanitize_key( $status_key );

			if ( '' === $status_key || ! array_key_exists( $status_key, $available ) ) {
				continue;
			}

			if ( 'yes' === $enabled ) {
				$normalized[ $status_key ] = 'yes';
			}
		}

		return $normalized;
	}

	/**
	 * Default custom message template.
	 *
	 * @return string
	 */
	public static function get_default_message_template() {
		return "🔔 <b>New Order Received</b> 🔔\n\n"
			. "🆔 <b>Order ID:</b> #{order_id}\n"
			. "📅 <b>Date:</b> {order_date}\n\n"
			. "👤 <b>Customer:</b>\n"
			. "{customer_name}\n"
			. "📞 <b>Phone:</b> {billing_phone}\n"
			. "📧 <b>Email:</b> {billing_email}\n\n"
			. "📍 <b>Billing Address:</b>\n"
			. "{billing_address}\n\n"
			. "📦 <b>Order Items:</b>\n"
			. "{order_items}\n\n"
			. "💳 <b>Payment Method:</b>\n"
			. "{payment_method}\n\n"
			. "💰 <b>Order Summary:</b>\n"
			. "Subtotal: {subtotal}\n"
			. "Shipping: {shipping_total}\n"
			. "Discount: {discount_total}\n"
			. "Total: {order_total}\n\n"
			. "📌 <b>Status:</b> {order_status}\n\n"
			. "🌐 <b>Website:</b> {site_name}";
	}

	/**
	 * Get normalized plugin settings.
	 *
	 * @return array
	 */
	public static function get_settings() {
		$settings = get_option( 'wta_settings', array() );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$settings = wp_parse_args( $settings, self::get_default_settings() );
		$template = wp_kses_post( $settings['message_template'] );

		if ( '' === trim( $template ) ) {
			$template = self::get_default_message_template();
		}

		return array(
			'enabled'               => 'yes',
			'new_order_alert'       => 'yes',
			'status_alert_statuses' => self::normalize_status_alert_statuses( $settings['status_alert_statuses'] ),
			'bot_token'             => sanitize_text_field( $settings['bot_token'] ),
			'chat_id'               => sanitize_text_field( $settings['chat_id'] ),
			'message_template'      => $template,
		);
	}

	/**
	 * Check whether WooCommerce is active and loaded.
	 *
	 * @return bool
	 */
	public static function is_woocommerce_active() {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Merge newly introduced settings into existing installations.
	 *
	 * @return void
	 */
	private function maybe_upgrade_settings() {
		WTA_License::maybe_add_default();

		$settings = get_option( 'wta_settings', array() );

		if ( ! is_array( $settings ) ) {
			update_option( 'wta_settings', self::get_default_settings() );
			return;
		}

		$merged_settings = wp_parse_args( $settings, self::get_default_settings() );
		$merged_settings['enabled'] = 'yes';
		$merged_settings['new_order_alert'] = 'yes';
		$merged_settings['status_alert_statuses'] = self::normalize_status_alert_statuses( $merged_settings['status_alert_statuses'] );
		unset( $merged_settings['debug_log'] );

		if ( empty( $merged_settings['message_template'] ) ) {
			$merged_settings['message_template'] = self::get_default_message_template();
		}

		delete_option( 'wta_logs' );

		if ( $merged_settings !== $settings ) {
			update_option( 'wta_settings', $merged_settings );
		}
	}
}
