<?php
/**
 * Borbila license client.
 *
 * @package Woo_Telegram_Alert
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles local license state and Borbila license API requests.
 */
class WTA_License {

	/** License option key. */
	const OPTION_NAME = 'wta_license';

	/** Borbila license template ID. */
	const TEMPLATE_ID = 'woo-telegram-alert';

	/** Borbila REST API base URL. */
	const API_BASE_URL = 'https://borbila.com/wp-json/borbila-license/v1';

	/** Daily validation cron hook. */
	const CRON_HOOK = 'wta_license_daily_validation';

	/** Local value used instead of storing the clear-text master key. */
	const MASTER_SENTINEL = 'WTA-MASTER-ACTIVE';

	/** SHA-256 of the normalized master key. */
	const MASTER_KEY_HASH = 'cd9fecc95a533bfd7ed1b62a34a6105f4cb74e5495c20c986a1a7121c9a8f484';

	/**
	 * Register recurring license validation hooks.
	 *
	 * @return void
	 */
	public static function register_hooks() {
		add_action( 'admin_init', array( __CLASS__, 'ensure_validation_schedule' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'validate_stored_license' ) );
	}

	/**
	 * Ensure a single daily validation event exists.
	 *
	 * @return void
	 */
	public static function ensure_validation_schedule() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
	}

	/**
	 * Remove the validation event when the plugin is deactivated.
	 *
	 * @return void
	 */
	public static function unschedule_validation() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	/**
	 * Return default license data.
	 *
	 * @return array
	 */
	public static function get_default_license() {
		return array(
			'license_key'      => '',
			'template_id'      => self::TEMPLATE_ID,
			'source'           => '',
			'status'           => 'inactive',
			'message'          => '',
			'activated_domain' => '',
			'last_checked'     => '',
		);
	}

	/**
	 * Create or upgrade the local license option.
	 *
	 * @return void
	 */
	public static function maybe_add_default() {
		$stored = get_option( self::OPTION_NAME, null );

		if ( ! is_array( $stored ) ) {
			update_option( self::OPTION_NAME, self::get_default_license(), false );
			return;
		}

		$merged = wp_parse_args( $stored, self::get_default_license() );

		if ( $merged !== $stored ) {
			update_option( self::OPTION_NAME, $merged, false );
		}
	}

	/**
	 * Get normalized license data.
	 *
	 * @return array
	 */
	public static function get_license() {
		$license = get_option( self::OPTION_NAME, array() );
		$license = is_array( $license ) ? wp_parse_args( $license, self::get_default_license() ) : self::get_default_license();
		$key     = self::sanitize_license_key( $license['license_key'] );
		$source  = sanitize_key( $license['source'] );
		$status  = sanitize_key( $license['status'] );

		if ( ! in_array( $source, array( 'master', 'server' ), true ) ) {
			$source = '' !== $key && self::MASTER_SENTINEL !== $key ? 'server' : '';
		}

		if ( '' === $status ) {
			$status = 'inactive';
		}

		return array(
			'license_key'      => $key,
			'template_id'      => self::TEMPLATE_ID,
			'source'           => $source,
			'status'           => $status,
			'message'          => sanitize_text_field( $license['message'] ),
			'activated_domain' => self::normalize_domain( $license['activated_domain'] ),
			'last_checked'     => sanitize_text_field( $license['last_checked'] ),
		);
	}

	/**
	 * Check whether the local Borbila license is active.
	 *
	 * @return bool
	 */
	public static function is_active() {
		$license = self::get_license();

		if ( 'active' !== $license['status'] ) {
			return false;
		}

		if ( 'master' === $license['source'] ) {
			return self::MASTER_SENTINEL === $license['license_key'];
		}

		return 'server' === $license['source'] && '' !== $license['license_key'];
	}

	/**
	 * Return a masked version of a saved license key.
	 *
	 * @param string $license_key License key.
	 * @return string
	 */
	public static function mask_license_key( $license_key ) {
		$license_key = self::sanitize_license_key( $license_key );

		if ( '' === $license_key ) {
			return '';
		}

		if ( self::MASTER_SENTINEL === $license_key ) {
			return 'Master license · ••••1426';
		}

		$parts = array_values( array_filter( explode( '-', $license_key ), 'strlen' ) );

		if ( count( $parts ) >= 2 ) {
			return $parts[0] . '-••••-••••-' . $parts[ count( $parts ) - 1 ];
		}

		$prefix = substr( $license_key, 0, min( 4, strlen( $license_key ) ) );
		$suffix = strlen( $license_key ) > 4 ? substr( $license_key, -4 ) : '';

		return $prefix . '-••••••••' . ( '' !== $suffix ? '-' . $suffix : '' );
	}

	/**
	 * Activate a server license or the local master license.
	 *
	 * @param string $submitted_key Submitted license key or masked value.
	 * @return array
	 */
	public static function activate_license( $submitted_key ) {
		$current       = self::get_license();
		$submitted_key = trim( sanitize_text_field( (string) $submitted_key ) );
		$license_key   = false !== strpos( $submitted_key, '•' ) ? $current['license_key'] : self::sanitize_license_key( $submitted_key );

		if ( '' === $license_key ) {
			return self::activation_error( __( 'License key is required.', 'woo-telegram-alert' ) );
		}

		if ( self::MASTER_SENTINEL === $license_key && 'master' === $current['source'] ) {
			self::activate_master_license();

			return array(
				'success' => true,
				'message' => __( 'Master license is valid.', 'woo-telegram-alert' ),
				'license' => self::get_license(),
			);
		}

		if ( self::is_master_license_key( $license_key ) ) {
			self::activate_master_license();

			return array(
				'success' => true,
				'message' => __( 'Master license activated instantly.', 'woo-telegram-alert' ),
				'license' => self::get_license(),
			);
		}

		if ( self::MASTER_SENTINEL === $license_key ) {
			return self::activation_error( __( 'Enter a valid Borbila license key.', 'woo-telegram-alert' ) );
		}

		$result = self::request( 'activate', $license_key );

		if ( $result['success'] ) {
			self::save_license(
				array(
					'license_key'      => $license_key,
					'source'           => 'server',
					'status'           => 'active',
					'message'          => $result['message'],
					'activated_domain' => self::get_domain(),
					'last_checked'     => current_time( 'mysql' ),
				)
			);

			return array(
				'success' => true,
				'message' => '' !== $result['message'] ? $result['message'] : __( 'License activated successfully.', 'woo-telegram-alert' ),
				'license' => self::get_license(),
			);
		}

		if ( $result['connection_error'] && self::is_active() ) {
			self::save_license(
				array(
					'message'      => $result['message'],
					'last_checked' => current_time( 'mysql' ),
				)
			);
		} else {
			self::save_license(
				array(
					'license_key'      => $license_key,
					'source'           => 'server',
					'status'           => $result['connection_error'] ? 'inactive' : 'invalid',
					'message'          => $result['message'],
					'activated_domain' => '',
					'last_checked'     => current_time( 'mysql' ),
				)
			);
		}

		return array(
			'success' => false,
			'message' => $result['message'],
			'license' => self::get_license(),
		);
	}

	/**
	 * Deactivate the current license.
	 *
	 * @return array
	 */
	public static function deactivate_license() {
		$license = self::get_license();

		if ( 'master' === $license['source'] ) {
			self::clear_license( __( 'Master license deactivated.', 'woo-telegram-alert' ) );

			return array(
				'success' => true,
				'message' => __( 'Master license deactivated.', 'woo-telegram-alert' ),
				'license' => self::get_license(),
			);
		}

		if ( '' === $license['license_key'] ) {
			self::clear_license( __( 'License removed successfully.', 'woo-telegram-alert' ) );

			return array(
				'success' => true,
				'message' => __( 'License removed successfully.', 'woo-telegram-alert' ),
				'license' => self::get_license(),
			);
		}

		$result = self::request( 'deactivate', $license['license_key'] );

		if ( $result['connection_error'] ) {
			return array(
				'success' => false,
				'message' => $result['message'],
				'license' => self::get_license(),
			);
		}

		$message = $result['success']
			? __( 'License deactivated successfully.', 'woo-telegram-alert' )
			: __( 'License was removed from this website.', 'woo-telegram-alert' );

		self::clear_license( $message );

		return array(
			'success' => true,
			'message' => $message,
			'license' => self::get_license(),
		);
	}

	/**
	 * Validate the stored license without disabling it on connection failures.
	 *
	 * @return void
	 */
	public static function validate_stored_license() {
		$license = self::get_license();

		if ( 'master' === $license['source'] ) {
			self::activate_master_license();
			return;
		}

		if ( '' === $license['license_key'] ) {
			return;
		}

		$result = self::request( 'check', $license['license_key'] );

		if ( $result['connection_error'] ) {
			self::save_license(
				array(
					'message'      => $result['message'],
					'last_checked' => current_time( 'mysql' ),
				)
			);
			return;
		}

		self::save_license(
			array(
				'source'           => 'server',
				'status'           => $result['success'] ? 'active' : 'invalid',
				'message'          => $result['message'],
				'activated_domain' => $result['success'] ? self::get_domain() : '',
				'last_checked'     => current_time( 'mysql' ),
			)
		);
	}

	/**
	 * Get the normalized current domain.
	 *
	 * @return string
	 */
	public static function get_domain() {
		return self::normalize_domain( home_url() );
	}

	/**
	 * Send a JSON POST request to the Borbila API.
	 *
	 * @param string $action      API action.
	 * @param string $license_key License key.
	 * @return array
	 */
	private static function request( $action, $license_key ) {
		if ( ! in_array( $action, array( 'activate', 'check', 'deactivate' ), true ) ) {
			return array(
				'success'          => false,
				'connection_error' => false,
				'message'          => __( 'Invalid license action.', 'woo-telegram-alert' ),
			);
		}

		$response = wp_remote_post(
			trailingslashit( self::API_BASE_URL ) . $action,
			array(
				'timeout'     => 20,
				'redirection' => 3,
				'sslverify'   => true,
				'headers'     => array(
					'Accept'       => 'application/json',
					'Content-Type' => 'application/json',
				),
				'body'        => wp_json_encode(
					array(
						'license_key' => self::sanitize_license_key( $license_key ),
						'template_id' => self::TEMPLATE_ID,
						'domain'      => self::get_domain(),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success'          => false,
				'connection_error' => true,
				'message'          => __( 'Could not connect to the Borbila license server. Please try again.', 'woo-telegram-alert' ),
			);
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $data ) || ! array_key_exists( 'success', $data ) ) {
			return array(
				'success'          => false,
				'connection_error' => true,
				'message'          => __( 'The license server returned an invalid response. Please try again.', 'woo-telegram-alert' ),
			);
		}

		$success = self::value_is_true( $data['success'] );
		$message = isset( $data['message'] ) && is_scalar( $data['message'] )
			? sanitize_text_field( (string) $data['message'] )
			: ( $success ? __( 'License verified.', 'woo-telegram-alert' ) : __( 'License validation failed.', 'woo-telegram-alert' ) );

		return array(
			'success'          => $success,
			'connection_error' => false,
			'message'          => $message,
		);
	}

	/**
	 * Return a consistent activation error payload.
	 *
	 * @param string $message Error message.
	 * @return array
	 */
	private static function activation_error( $message ) {
		return array(
			'success' => false,
			'message' => $message,
			'license' => self::get_license(),
		);
	}

	/**
	 * Activate the master key without storing its clear-text value.
	 *
	 * @return void
	 */
	private static function activate_master_license() {
		self::save_license(
			array(
				'license_key'      => self::MASTER_SENTINEL,
				'source'           => 'master',
				'status'           => 'active',
				'message'          => __( 'Master license valid.', 'woo-telegram-alert' ),
				'activated_domain' => self::get_domain(),
				'last_checked'     => current_time( 'mysql' ),
			)
		);
	}

	/**
	 * Clear local license data.
	 *
	 * @param string $message Status message.
	 * @return void
	 */
	private static function clear_license( $message ) {
		self::save_license(
			array(
				'license_key'      => '',
				'source'           => '',
				'status'           => 'inactive',
				'message'          => $message,
				'activated_domain' => '',
				'last_checked'     => current_time( 'mysql' ),
			)
		);
	}

	/**
	 * Save normalized license values with autoload disabled for new options.
	 *
	 * @param array $license License values.
	 * @return void
	 */
	private static function save_license( $license ) {
		$current = self::get_license();
		$license = wp_parse_args( $license, $current );
		$source  = sanitize_key( $license['source'] );

		update_option(
			self::OPTION_NAME,
			array(
				'license_key'      => self::sanitize_license_key( $license['license_key'] ),
				'template_id'      => self::TEMPLATE_ID,
				'source'           => in_array( $source, array( 'master', 'server' ), true ) ? $source : '',
				'status'           => sanitize_key( $license['status'] ),
				'message'          => sanitize_text_field( $license['message'] ),
				'activated_domain' => self::normalize_domain( $license['activated_domain'] ),
				'last_checked'     => sanitize_text_field( $license['last_checked'] ),
			),
			false
		);
	}

	/**
	 * Check the normalized master key hash.
	 *
	 * @param string $license_key License key.
	 * @return bool
	 */
	private static function is_master_license_key( $license_key ) {
		return hash_equals( self::MASTER_KEY_HASH, hash( 'sha256', self::sanitize_license_key( $license_key ) ) );
	}

	/**
	 * Sanitize a license key consistently with the server.
	 *
	 * @param string $license_key License key.
	 * @return string
	 */
	private static function sanitize_license_key( $license_key ) {
		$license_key = strtoupper( trim( sanitize_text_field( (string) $license_key ) ) );
		$license_key = preg_replace( '/[^A-Z0-9\-]/', '', $license_key );

		return substr( (string) $license_key, 0, 64 );
	}

	/**
	 * Normalize a URL or host to the domain format expected by the API.
	 *
	 * @param string $value URL or domain.
	 * @return string
	 */
	private static function normalize_domain( $value ) {
		$value  = strtolower( trim( (string) $value ) );
		$parsed = false !== strpos( $value, '://' ) ? $value : 'https://' . ltrim( $value, '/' );
		$domain = wp_parse_url( $parsed, PHP_URL_HOST );

		if ( ! is_string( $domain ) || '' === $domain ) {
			$domain = preg_replace( '#^https?://#i', '', $value );
			$domain = strtok( (string) $domain, '/:' );
		}

		$domain = preg_replace( '/^www\./i', '', strtolower( trim( (string) $domain ) ) );

		return sanitize_text_field( (string) $domain );
	}

	/**
	 * Interpret a flexible API boolean safely.
	 *
	 * @param mixed $value Response value.
	 * @return bool
	 */
	private static function value_is_true( $value ) {
		if ( true === $value || 1 === $value ) {
			return true;
		}

		return in_array( strtolower( trim( (string) $value ) ), array( '1', 'true', 'yes' ), true );
	}
}
