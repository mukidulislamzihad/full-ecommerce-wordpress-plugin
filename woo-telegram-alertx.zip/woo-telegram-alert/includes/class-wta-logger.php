<?php
/**
 * Compatibility logger.
 *
 * @package Woo_Telegram_Alert
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps older internal log calls harmless after the log UI was removed.
 */
class WTA_Logger {

	/**
	 * Legacy logs option key.
	 *
	 * @var string
	 */
	const OPTION_NAME = 'wta_logs';

	/**
	 * Ignore log entries.
	 *
	 * @param string $type    Log type.
	 * @param string $message Log message.
	 * @return void
	 */
	public static function add_log( $type, $message ) {
		return;
	}

	/**
	 * Return an empty legacy log list.
	 *
	 * @return array
	 */
	public static function get_logs() {
		return array();
	}

	/**
	 * Remove legacy stored logs.
	 *
	 * @return void
	 */
	public static function clear_logs() {
		delete_option( self::OPTION_NAME );
	}
}
