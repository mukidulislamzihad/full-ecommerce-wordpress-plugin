<?php
/**
 * WooCommerce order alert integration.
 *
 * @package Woo_Telegram_Alert
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sends Telegram alerts for WooCommerce orders.
 */
class WTA_WooCommerce {

	/**
	 * Meta key used to prevent duplicate new order alerts.
	 *
	 * @var string
	 */
	const NEW_ORDER_ALERT_SENT_META = '_wta_new_order_alert_sent';

	/**
	 * Class constructor.
	 */
	public function __construct() {
		add_action( 'woocommerce_thankyou', array( $this, 'send_new_order_alert' ), 10, 1 );
		add_action( 'woocommerce_order_status_changed', array( $this, 'send_manual_status_change_alert' ), 20, 4 );
	}

	/**
	 * Send a Telegram alert once after checkout reaches the thank-you page.
	 *
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public function send_new_order_alert( $order_id ) {
		if ( ! WTA_License::is_active() ) {
			return;
		}

		$order_id = absint( $order_id );
		$settings = WTA_Plugin::get_settings();
		$order    = $this->get_order( $order_id );

		if ( ! $this->should_send_alert( $settings, 'new_order_alert' ) ) {
			return;
		}

		if ( ! $order ) {
			WTA_Logger::add_log( 'error', __( 'New order alert failed: invalid order ID.', 'woo-telegram-alert' ) );
			return;
		}

		$current_status = sanitize_key( $order->get_status() );

		if ( '' === $current_status ) {
			WTA_Logger::add_log( 'error', __( 'New order alert failed: invalid order status.', 'woo-telegram-alert' ) );
			return;
		}

		if ( ! $this->is_order_status_enabled( $settings, $current_status ) ) {
			WTA_Logger::add_log(
				'info',
				sprintf(
					/* translators: 1: order ID, 2: status label. */
					__( 'New order alert skipped for order #%1$d. Status disabled: %2$s.', 'woo-telegram-alert' ),
					$order->get_id(),
					$this->get_status_label( $current_status )
				)
			);
			return;
		}

		if ( 'yes' === $order->get_meta( self::NEW_ORDER_ALERT_SENT_META, true ) ) {
			WTA_Logger::add_log(
				'info',
				sprintf(
					/* translators: %d: order ID. */
					__( 'Duplicate new order alert skipped for order #%d.', 'woo-telegram-alert' ),
					$order->get_id()
				)
			);
			return;
		}

		$message  = $this->build_order_message( $order, $settings['message_template'] );
		$telegram = new WTA_Telegram( $settings['bot_token'], $settings['chat_id'] );
		$result   = $telegram->send_message( $message );

		if ( is_wp_error( $result ) ) {
			WTA_Logger::add_log(
				'error',
				sprintf(
					/* translators: 1: order ID, 2: error message. */
					__( 'New order alert failed for order #%1$d. %2$s', 'woo-telegram-alert' ),
					$order->get_id(),
					$result->get_error_message()
				)
			);
			return;
		}

		$order->update_meta_data( self::NEW_ORDER_ALERT_SENT_META, 'yes' );
		$order->save();

		WTA_Logger::add_log(
			'success',
			sprintf(
				/* translators: 1: order ID, 2: status label. */
				__( 'New order alert sent for order #%1$d. Status: %2$s.', 'woo-telegram-alert' ),
				$order->get_id(),
				$this->get_status_label( $current_status )
			)
		);
	}

	/**
	 * Send a Telegram alert when an admin manually changes an order status.
	 *
	 * @param int    $order_id   Order ID.
	 * @param string $old_status Old order status.
	 * @param string $new_status New order status.
	 * @param mixed  $order      WooCommerce order object.
	 * @return void
	 */
	public function send_manual_status_change_alert( $order_id, $old_status, $new_status, $order = null ) {
		$order_id = absint( $order_id );

		if ( ! $this->is_manual_admin_status_change( $order_id ) ) {
			return;
		}

		if ( ! WTA_License::is_active() ) {
			return;
		}

		$settings = WTA_Plugin::get_settings();
		$order    = $this->get_order( $order_id, $order );

		if ( ! $this->should_send_alert( $settings, 'new_order_alert' ) ) {
			return;
		}

		if ( ! $order ) {
			WTA_Logger::add_log( 'error', __( 'Manual status alert failed: invalid order ID.', 'woo-telegram-alert' ) );
			return;
		}

		$current_status = sanitize_key( $new_status );

		if ( '' === $current_status ) {
			$current_status = sanitize_key( $order->get_status() );
		}

		if ( '' === $current_status ) {
			WTA_Logger::add_log( 'error', __( 'Manual status alert failed: invalid order status.', 'woo-telegram-alert' ) );
			return;
		}

		if ( ! $this->is_order_status_enabled( $settings, $current_status ) ) {
			WTA_Logger::add_log(
				'info',
				sprintf(
					/* translators: 1: order ID, 2: status label. */
					__( 'Manual status alert skipped for order #%1$d. Status disabled: %2$s.', 'woo-telegram-alert' ),
					$order->get_id(),
					$this->get_status_label( $current_status )
				)
			);
			return;
		}

		$message  = $this->build_order_message(
			$order,
			$this->get_status_change_template(),
			array(
				'old_status' => $this->get_status_label( $old_status ),
				'new_status' => $this->get_status_label( $current_status ),
			)
		);
		$telegram = new WTA_Telegram( $settings['bot_token'], $settings['chat_id'] );
		$result   = $telegram->send_message( $message );

		if ( is_wp_error( $result ) ) {
			WTA_Logger::add_log(
				'error',
				sprintf(
					/* translators: 1: order ID, 2: error message. */
					__( 'Manual status alert failed for order #%1$d. %2$s', 'woo-telegram-alert' ),
					$order->get_id(),
					$result->get_error_message()
				)
			);
			return;
		}

		WTA_Logger::add_log(
			'success',
			sprintf(
				/* translators: 1: order ID, 2: status label. */
				__( 'Manual status alert sent for order #%1$d. Status: %2$s.', 'woo-telegram-alert' ),
				$order->get_id(),
				$this->get_status_label( $current_status )
			)
		);
	}

	/**
	 * Build an order message from a template.
	 *
	 * @param WC_Order $order    WooCommerce order.
	 * @param string   $template Message template.
	 * @param array    $extra    Extra placeholder values.
	 * @return string
	 */
	public function build_order_message( $order, $template, $extra = array() ) {
		if ( ! is_a( $order, 'WC_Order' ) ) {
			return '';
		}

		if ( '' === trim( (string) $template ) ) {
			$template = WTA_Plugin::get_default_message_template();
		}

		$template     = $this->convert_breaks_to_new_lines( (string) $template );
		$placeholders = $this->get_order_placeholders( $order, $extra );
		$message      = strtr( $template, $placeholders );

		$message = $this->convert_breaks_to_new_lines( $message );
		$message = wp_kses( $message, WTA_Telegram::get_allowed_html() );

		return trim( $message );
	}

	/**
	 * Check whether a configured alert type is allowed to send.
	 *
	 * @param array  $settings  Plugin settings.
	 * @param string $alert_key Alert setting key.
	 * @return bool
	 */
	private function should_send_alert( $settings, $alert_key ) {
		if (
			WTA_Plugin::is_woocommerce_active()
			&& ! empty( $settings[ $alert_key ] )
			&& 'yes' === $settings['enabled']
			&& 'yes' === $settings[ $alert_key ]
		) {
			if ( '' === $settings['bot_token'] ) {
				WTA_Logger::add_log(
					'error',
					sprintf(
						/* translators: %s: alert label. */
						__( '%s skipped: missing bot token.', 'woo-telegram-alert' ),
						$this->get_alert_label( $alert_key )
					)
				);
			}

			if ( '' === $settings['chat_id'] ) {
				WTA_Logger::add_log(
					'error',
					sprintf(
						/* translators: %s: alert label. */
						__( '%s skipped: missing chat ID.', 'woo-telegram-alert' ),
						$this->get_alert_label( $alert_key )
					)
				);
			}
		}

		return (
			WTA_Plugin::is_woocommerce_active()
			&& ! empty( $settings[ $alert_key ] )
			&& 'yes' === $settings['enabled']
			&& 'yes' === $settings[ $alert_key ]
			&& '' !== $settings['bot_token']
			&& '' !== $settings['chat_id']
		);
	}

	/**
	 * Get a readable alert label for logs.
	 *
	 * @param string $alert_key Alert setting key.
	 * @return string
	 */
	private function get_alert_label( $alert_key ) {
		return __( 'New order alert', 'woo-telegram-alert' );
	}

	/**
	 * Check whether alerts are enabled for a specific target status.
	 *
	 * @param array  $settings Plugin settings.
	 * @param string $status   New order status.
	 * @return bool
	 */
	private function is_order_status_enabled( $settings, $status ) {
		$status = sanitize_key( $status );

		if ( '' === $status ) {
			return false;
		}

		$enabled_statuses = isset( $settings['status_alert_statuses'] ) && is_array( $settings['status_alert_statuses'] )
			? $settings['status_alert_statuses']
			: array();

		return isset( $enabled_statuses[ $status ] ) && 'yes' === $enabled_statuses[ $status ];
	}

	/**
	 * Determine whether the status change came from a logged-in admin action.
	 *
	 * @param int $order_id Order ID.
	 * @return bool
	 */
	private function is_manual_admin_status_change( $order_id ) {
		if ( ! is_admin() || ! is_user_logged_in() ) {
			return false;
		}

		return current_user_can( 'edit_shop_orders' ) || current_user_can( 'manage_woocommerce' ) || current_user_can( 'edit_shop_order', $order_id );
	}

	/**
	 * Get a WooCommerce order object safely.
	 *
	 * @param int   $order_id Order ID.
	 * @param mixed $order    Possible WooCommerce order object.
	 * @return WC_Order|null
	 */
	private function get_order( $order_id, $order = null ) {
		$order_id = absint( $order_id );

		if ( ! $order_id ) {
			return null;
		}

		if ( is_a( $order, 'WC_Order' ) ) {
			return $order;
		}

		if ( ! function_exists( 'wc_get_order' ) ) {
			return null;
		}

		$order = wc_get_order( $order_id );

		return is_a( $order, 'WC_Order' ) ? $order : null;
	}

	/**
	 * Build the placeholder map for an order.
	 *
	 * @param WC_Order $order WooCommerce order.
	 * @param array    $extra Extra placeholder values.
	 * @return array
	 */
	private function get_order_placeholders( $order, $extra = array() ) {
		$status      = $order->get_status();
		$admin_url   = $this->get_admin_order_url( $order );
		$old_status  = isset( $extra['old_status'] ) ? $extra['old_status'] : '';
		$new_status  = isset( $extra['new_status'] ) ? $extra['new_status'] : '';
		$placeholder = array(
			'{order_id}'           => $order->get_id(),
			'{order_date}'         => $this->get_order_date( $order ),
			'{customer_name}'      => $this->get_customer_name( $order ),
			'{billing_first_name}' => $this->fallback( $order->get_billing_first_name() ),
			'{billing_last_name}'  => $this->fallback( $order->get_billing_last_name() ),
			'{billing_phone}'      => $this->fallback( $order->get_billing_phone() ),
			'{billing_email}'      => $this->fallback( $order->get_billing_email() ),
			'{billing_address}'    => $this->format_address( $order->get_formatted_billing_address() ),
			'{shipping_address}'   => $this->format_address( $order->get_formatted_shipping_address() ),
			'{order_items}'        => $this->get_order_items_text( $order ),
			'{payment_method}'     => $this->fallback( $order->get_payment_method_title() ),
			'{subtotal}'           => $this->format_price( $order->get_subtotal(), $order ),
			'{shipping_total}'     => $this->format_price( $order->get_shipping_total(), $order ),
			'{discount_total}'     => $this->format_price( $order->get_discount_total(), $order ),
			'{order_total}'        => $this->format_price( $order->get_total(), $order ),
			'{order_status}'       => $this->get_status_label( $status ),
			'{currency}'           => $this->fallback( $order->get_currency() ),
			'{site_name}'          => $this->fallback( wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ),
			'{admin_order_url}'    => $admin_url,
			'{old_status}'         => $this->fallback( $old_status ),
			'{new_status}'         => $this->fallback( $new_status ),
		);

		foreach ( $placeholder as $key => $value ) {
			$placeholder[ $key ] = WTA_Telegram::escape_html( $value );
		}

		return $placeholder;
	}

	/**
	 * Status change alert template.
	 *
	 * @return string
	 */
	private function get_status_change_template() {
		return "🔄 <b>Order Status Updated</b>\n\n"
			. "🆔 <b>Order ID:</b> #{order_id}\n"
			. "Previous Status: {old_status}\n"
			. "New Status: {new_status}\n\n"
			. "👤 <b>Customer:</b> {customer_name}\n"
			. "📞 <b>Phone:</b> {billing_phone}\n"
			. "💰 <b>Total:</b> {order_total}\n\n"
			. "🌐 <b>Website:</b> {site_name}";
	}

	/**
	 * Get the order creation date.
	 *
	 * @param WC_Order $order WooCommerce order.
	 * @return string
	 */
	private function get_order_date( $order ) {
		$date = $order->get_date_created();

		if ( is_object( $date ) && method_exists( $date, 'date_i18n' ) ) {
			return $date->date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
		}

		return __( 'Not available', 'woo-telegram-alert' );
	}

	/**
	 * Get a safe customer name.
	 *
	 * @param WC_Order $order WooCommerce order.
	 * @return string
	 */
	private function get_customer_name( $order ) {
		$name = trim( (string) $order->get_formatted_billing_full_name() );

		if ( '' === $name ) {
			$name = trim( (string) $order->get_formatted_shipping_full_name() );
		}

		return $this->fallback( $name );
	}

	/**
	 * Format an address as plain multiline text.
	 *
	 * @param string $address Address HTML.
	 * @return string
	 */
	private function format_address( $address ) {
		$address = $this->convert_breaks_to_new_lines( (string) $address );
		$address = wp_strip_all_tags( $address );
		$address = html_entity_decode( $address, ENT_QUOTES, get_bloginfo( 'charset' ) );
		$address = preg_replace( "/[ \t]+\n/", "\n", $address );
		$address = preg_replace( "/\n{3,}/", "\n\n", $address );

		return $this->fallback( $address );
	}

	/**
	 * Build formatted order item lines.
	 *
	 * @param WC_Order $order WooCommerce order.
	 * @return string
	 */
	private function get_order_items_text( $order ) {
		$items = $order->get_items();

		if ( empty( $items ) ) {
			return __( 'No items found.', 'woo-telegram-alert' );
		}

		$lines = array();

		foreach ( $items as $item ) {
			$name = method_exists( $item, 'get_name' ) ? trim( (string) $item->get_name() ) : '';

			if ( '' === $name ) {
				$name = __( 'Deleted product', 'woo-telegram-alert' );
			}

			$quantity = method_exists( $item, 'get_quantity' ) ? $this->format_quantity( $item->get_quantity() ) : '0';
			$total    = method_exists( $item, 'get_total' ) ? $this->format_price( $item->get_total(), $order ) : $this->format_price( 0, $order );

			$lines[] = sprintf(
				'%1$s × %2$s — %3$s',
				$name,
				$quantity,
				$total
			);
		}

		return implode( "\n", $lines );
	}

	/**
	 * Get a readable order status label.
	 *
	 * @param string $status Order status slug.
	 * @return string
	 */
	private function get_status_label( $status ) {
		$status = sanitize_key( $status );

		if ( '' === $status ) {
			return $this->fallback( '' );
		}

		if ( function_exists( 'wc_get_order_status_name' ) ) {
			return wc_get_order_status_name( $status );
		}

		return $this->fallback( ucwords( str_replace( '-', ' ', (string) $status ) ) );
	}

	/**
	 * Get the HPOS-compatible admin order URL.
	 *
	 * @param WC_Order $order WooCommerce order.
	 * @return string
	 */
	private function get_admin_order_url( $order ) {
		if ( method_exists( $order, 'get_edit_order_url' ) ) {
			return $order->get_edit_order_url();
		}

		return admin_url( 'post.php?post=' . absint( $order->get_id() ) . '&action=edit' );
	}

	/**
	 * Format a WooCommerce price as plain text.
	 *
	 * @param float|int|string $amount Amount.
	 * @param WC_Order         $order  WooCommerce order.
	 * @return string
	 */
	private function format_price( $amount, $order ) {
		if ( function_exists( 'wc_price' ) ) {
			$formatted = wc_price(
				(float) $amount,
				array(
					'currency' => $order->get_currency(),
				)
			);
			$formatted = wp_strip_all_tags( $formatted );
			$formatted = html_entity_decode( $formatted, ENT_QUOTES, get_bloginfo( 'charset' ) );

			return trim( $formatted );
		}

		return number_format_i18n( (float) $amount, 2 );
	}

	/**
	 * Format an item quantity.
	 *
	 * @param float|int|string $quantity Item quantity.
	 * @return string
	 */
	private function format_quantity( $quantity ) {
		$quantity = (float) $quantity;

		if ( floor( $quantity ) === $quantity ) {
			return (string) absint( $quantity );
		}

		return rtrim( rtrim( number_format_i18n( $quantity, 2 ), '0' ), '.' );
	}

	/**
	 * Convert HTML line breaks to new lines.
	 *
	 * @param string $text Text.
	 * @return string
	 */
	private function convert_breaks_to_new_lines( $text ) {
		return preg_replace( '/<br\s*\/?>/i', "\n", (string) $text );
	}

	/**
	 * Return a fallback value when text is empty.
	 *
	 * @param mixed  $value    Value to check.
	 * @param string $fallback Fallback text.
	 * @return string
	 */
	private function fallback( $value, $fallback = '' ) {
		$value = trim( (string) $value );

		if ( '' !== $value ) {
			return $value;
		}

		return '' !== $fallback ? $fallback : __( 'Not provided', 'woo-telegram-alert' );
	}
}
