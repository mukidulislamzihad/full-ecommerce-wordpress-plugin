<?php
/**
 * Admin settings screen and AJAX handlers.
 *
 * @package Woo_Telegram_Alert
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles the Woo Telegram Alert admin area.
 */
class WTA_Admin {

	/**
	 * Settings option key.
	 *
	 * @var string
	 */
	private $option_name = 'wta_settings';

	/**
	 * Admin menu slug.
	 *
	 * @var string
	 */
	private $menu_slug = 'woo-telegram-alert';

	/**
	 * Class constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_notices', array( $this, 'maybe_show_woocommerce_notice' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_post_wta_save_settings', array( $this, 'save_settings' ) );
		add_action( 'admin_post_wta_license_action', array( $this, 'handle_license_action' ) );
		add_action( 'wp_ajax_wta_save_settings_ajax', array( $this, 'save_settings_ajax' ) );
		add_action( 'wp_ajax_wta_send_test_message', array( $this, 'send_test_message' ) );
		add_action( 'wp_ajax_wta_reset_message_template', array( $this, 'reset_message_template' ) );
		add_action( 'wp_ajax_wta_activate_license', array( $this, 'activate_license' ) );
		add_action( 'wp_ajax_wta_deactivate_license', array( $this, 'deactivate_license' ) );
	}

	/**
	 * Register the top-level admin menu page.
	 *
	 * @return void
	 */
	public function register_menu() {
		add_menu_page(
			esc_html__( 'Woo Telegram Alert', 'woo-telegram-alert' ),
			esc_html__( 'Telegram Alert', 'woo-telegram-alert' ),
			'manage_options',
			$this->menu_slug,
			array( $this, 'render_settings_page' ),
			'dashicons-bell',
			56
		);
	}

	/**
	 * Enqueue admin-only assets.
	 *
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		if ( 'toplevel_page_' . $this->menu_slug !== $hook ) {
			return;
		}

		$css_file    = WTA_PLUGIN_DIR . 'assets/admin.css';
		$css_version = WTA_VERSION . ( file_exists( $css_file ) ? '-' . filemtime( $css_file ) : '' );
		$js_file     = WTA_PLUGIN_DIR . 'assets/admin.js';
		$js_version  = WTA_VERSION . ( file_exists( $js_file ) ? '-' . filemtime( $js_file ) : '' );

		wp_enqueue_style(
			'wta-admin',
			WTA_PLUGIN_URL . 'assets/admin.css',
			array(),
			$css_version
		);

		wp_enqueue_script(
			'wta-admin',
			WTA_PLUGIN_URL . 'assets/admin.js',
			array( 'jquery' ),
			$js_version,
			true
		);

		wp_localize_script(
			'wta-admin',
			'wtaAdmin',
			array(
				'ajaxUrl'         => admin_url( 'admin-ajax.php' ),
				'settingsNonce'   => wp_create_nonce( 'wta_save_settings_ajax_nonce' ),
				'testNonce'       => wp_create_nonce( 'wta_test_message_nonce' ),
				'resetNonce'      => wp_create_nonce( 'wta_reset_template_nonce' ),
				'licenseNonce'    => wp_create_nonce( 'wta_license_nonce' ),
				'maskedToken'     => WTA_MASKED_TOKEN_VALUE,
				'strings' => array(
					'saving'        => esc_html__( 'Saving...', 'woo-telegram-alert' ),
					'save'          => esc_html__( 'Save Changes', 'woo-telegram-alert' ),
					'saved'         => esc_html__( 'Settings saved successfully.', 'woo-telegram-alert' ),
					'sending'       => esc_html__( 'Sending...', 'woo-telegram-alert' ),
					'default'       => esc_html__( 'Send Test Message', 'woo-telegram-alert' ),
					'resetting'     => esc_html__( 'Resetting...', 'woo-telegram-alert' ),
					'resetDefault'  => esc_html__( 'Reset to Default Template', 'woo-telegram-alert' ),
					'activating'    => esc_html__( 'Activating...', 'woo-telegram-alert' ),
					'activate'      => esc_html__( 'Activate License', 'woo-telegram-alert' ),
					'deactivating'  => esc_html__( 'Deactivating...', 'woo-telegram-alert' ),
					'deactivate'    => esc_html__( 'Deactivate License', 'woo-telegram-alert' ),
					'licenseRequired' => esc_html__( 'Please activate your license to enable automatic WooCommerce Telegram alerts.', 'woo-telegram-alert' ),
					'error'         => esc_html__( 'Something went wrong. Please try again.', 'woo-telegram-alert' ),
				),
			)
		);
	}

	/**
	 * Show a WooCommerce dependency notice when WooCommerce is inactive.
	 *
	 * @return void
	 */
	public function maybe_show_woocommerce_notice() {
		if ( ! current_user_can( 'manage_options' ) || WTA_Plugin::is_woocommerce_active() ) {
			return;
		}

		?>
		<div class="notice notice-warning">
			<p>
				<?php echo esc_html__( 'Woo Telegram Alert requires WooCommerce to send order notifications. Please install and activate WooCommerce.', 'woo-telegram-alert' ); ?>
			</p>
		</div>
		<?php

		WTA_Logger::add_log( 'info', __( 'WooCommerce inactive notice shown.', 'woo-telegram-alert' ) );
	}

	/**
	 * Save settings from the admin form.
	 *
	 * @return void
	 */
	public function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to save these settings.', 'woo-telegram-alert' ) );
		}

		check_admin_referer( 'wta_save_settings', 'wta_settings_nonce' );
		$result     = $this->save_settings_from_request();
		$notice_key = is_wp_error( $result ) ? 'wta_settings_error' : 'wta_settings_updated';

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'        => $this->menu_slug,
					$notice_key   => '1',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Save settings over AJAX with a normal form fallback in the browser.
	 *
	 * @return void
	 */
	public function save_settings_ajax() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => esc_html__( 'You do not have permission to save these settings.', 'woo-telegram-alert' ) ),
				403
			);
		}

		if ( ! check_ajax_referer( 'wta_save_settings_ajax_nonce', 'nonce', false ) ) {
			wp_send_json_error(
				array( 'message' => esc_html__( 'Security check failed. Please refresh the page and try again.', 'woo-telegram-alert' ) ),
				403
			);
		}

		$result = $this->save_settings_from_request();

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 500 );
		}

		wp_send_json_success(
			array(
				'message'   => esc_html__( 'Settings saved successfully.', 'woo-telegram-alert' ),
				'has_token' => ! empty( $result['bot_token'] ),
			)
		);
	}

	/**
	 * Build, sanitize, persist, and verify submitted settings.
	 *
	 * @return array|WP_Error
	 */
	private function save_settings_from_request() {
		$existing_settings = WTA_Plugin::get_settings();
		$submitted_token   = sanitize_text_field( $this->get_posted_value( 'wta_bot_token' ) );
		$bot_token         = $existing_settings['bot_token'];

		if ( '' !== $submitted_token && WTA_MASKED_TOKEN_VALUE !== $submitted_token ) {
			$bot_token = $submitted_token;
		}

		$status_options        = WTA_Plugin::get_order_status_options();
		$submitted_statuses    = isset( $_POST['wta_status_alert_statuses'] )
			? wp_unslash( $_POST['wta_status_alert_statuses'] )
			: array();
		$submitted_statuses    = is_array( $submitted_statuses ) ? array_filter( $submitted_statuses, 'is_scalar' ) : array();
		$submitted_statuses    = array_map( 'sanitize_key', $submitted_statuses );
		$status_alert_statuses = array();
		$allowed_statuses      = array_keys( $status_options );
		$submitted_statuses    = array_intersect( $submitted_statuses, $allowed_statuses );

		foreach ( $submitted_statuses as $status_key ) {
			$status_alert_statuses[ $status_key ] = 'yes';
		}

		if ( ! WTA_License::is_active() ) {
			$status_alert_statuses = $existing_settings['status_alert_statuses'];
		}

		$message_template = wp_kses_post( $this->get_posted_value( 'wta_message_template' ) );

		if ( '' === trim( $message_template ) ) {
			$message_template = WTA_Plugin::get_default_message_template();
		}

		$settings = array(
			'enabled'               => 'yes',
			'new_order_alert'       => 'yes',
			'status_alert_statuses' => $status_alert_statuses,
			'bot_token'             => $bot_token,
			'chat_id'               => sanitize_text_field( $this->get_posted_value( 'wta_chat_id' ) ),
			'message_template'      => $message_template,
		);

		update_option( $this->option_name, $settings, false );
		$saved = get_option( $this->option_name, array() );

		if ( ! is_array( $saved ) ) {
			return new WP_Error( 'wta_settings_not_saved', esc_html__( 'Settings could not be saved. Please check the database or object-cache configuration.', 'woo-telegram-alert' ) );
		}

		foreach ( $settings as $key => $value ) {
			if ( ! array_key_exists( $key, $saved ) || $saved[ $key ] !== $value ) {
				return new WP_Error( 'wta_settings_not_verified', esc_html__( 'Settings were not stored correctly. Please clear the website cache and try again.', 'woo-telegram-alert' ) );
			}
		}

		return $settings;
	}

	/**
	 * Read a normal or base64-encoded POST value.
	 *
	 * Encoded fields avoid false positives from restrictive hosting firewalls.
	 *
	 * @param string $key Field key.
	 * @return string
	 */
	private function get_posted_value( $key ) {
		$key         = sanitize_key( $key );
		$encoding    = isset( $_POST['wta_payload_encoding'] ) ? sanitize_key( wp_unslash( $_POST['wta_payload_encoding'] ) ) : '';
		$encoded_key = $key . '_encoded';

		if ( 'base64' === $encoding && isset( $_POST[ $encoded_key ] ) && is_scalar( $_POST[ $encoded_key ] ) ) {
			$decoded = base64_decode( (string) wp_unslash( $_POST[ $encoded_key ] ), true );

			if ( false !== $decoded ) {
				return $decoded;
			}
		}

		return isset( $_POST[ $key ] ) && is_scalar( $_POST[ $key ] ) ? (string) wp_unslash( $_POST[ $key ] ) : '';
	}

	/**
	 * Check whether a normal or encoded field was submitted.
	 *
	 * @param string $key Field key.
	 * @return bool
	 */
	private function has_posted_value( $key ) {
		$key = sanitize_key( $key );

		return isset( $_POST[ $key ] ) || isset( $_POST[ $key . '_encoded' ] );
	}

	/**
	 * Render the plugin settings page.
	 *
	 * @return void
	 */
	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'woo-telegram-alert' ) );
		}

		$settings                    = WTA_Plugin::get_settings();
		$status_options              = WTA_Plugin::get_order_status_options();
		$status_alert_statuses       = $settings['status_alert_statuses'];
		$bot_has_value               = ! empty( $settings['bot_token'] );
		$bot_token_field_value       = $bot_has_value ? WTA_MASKED_TOKEN_VALUE : '';
		$is_connected                = $bot_has_value && ! empty( $settings['chat_id'] );
		$woocommerce_active          = WTA_Plugin::is_woocommerce_active();
		$license                     = WTA_License::get_license();
		$license_active              = WTA_License::is_active();
		$license_key_field_value     = WTA_License::mask_license_key( $license['license_key'] );
		$updated                     = isset( $_GET['wta_settings_updated'] ) ? sanitize_text_field( wp_unslash( $_GET['wta_settings_updated'] ) ) : '';
		$save_error                  = isset( $_GET['wta_settings_error'] ) ? sanitize_text_field( wp_unslash( $_GET['wta_settings_error'] ) ) : '';
		$license_notice              = $this->pop_license_notice();
		$placeholders                = $this->get_template_placeholders();
		?>
		<div class="wrap wta-admin-wrap">
			<div class="wta-header">
				<div class="wta-header-main">
					<div class="wta-plugin-icon">
						<span class="dashicons dashicons-bell" aria-hidden="true"></span>
					</div>
					<div>
						<p class="wta-eyebrow"><?php echo esc_html__( 'Telegram notifications', 'woo-telegram-alert' ); ?></p>
						<h1><?php echo esc_html__( 'Woo Telegram Alert', 'woo-telegram-alert' ); ?></h1>
						<p><?php echo esc_html__( 'Instant WooCommerce order alerts on Telegram.', 'woo-telegram-alert' ); ?></p>
					</div>
				</div>
				<div class="wta-header-aside">
					<div class="wta-badge-group">
						<span class="wta-badge <?php echo esc_attr( $is_connected ? 'is-connected' : 'is-not-connected' ); ?>">
							<?php echo $is_connected ? esc_html__( 'Connected', 'woo-telegram-alert' ) : esc_html__( 'Not Connected', 'woo-telegram-alert' ); ?>
						</span>
						<span class="wta-badge <?php echo esc_attr( $license_active ? 'is-license-active' : 'is-license-inactive' ); ?>" id="wta-header-license-badge">
							<?php echo $license_active ? esc_html__( 'License: Active', 'woo-telegram-alert' ) : esc_html__( 'License: Inactive', 'woo-telegram-alert' ); ?>
						</span>
					</div>
					<div class="wta-brand-links" aria-label="<?php echo esc_attr__( 'Borbila links', 'woo-telegram-alert' ); ?>">
						<a class="is-facebook" href="https://www.facebook.com/borbilax" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr__( 'Borbila Facebook', 'woo-telegram-alert' ); ?>">
							<svg aria-hidden="true" focusable="false" viewBox="0 0 24 24">
								<path d="M14.2 8.1h2.4V4.2c-.4-.1-1.9-.2-3.6-.2-3.5 0-5.8 2.1-5.8 6v3.3H3.4v4.4h3.8V24h4.7v-6.3h3.8l.6-4.4h-4.4v-2.9c0-1.3.3-2.3 2.3-2.3Z"></path>
							</svg>
						</a>
						<a class="is-youtube" href="https://www.youtube.com/@borbila" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr__( 'Borbila YouTube', 'woo-telegram-alert' ); ?>">
							<svg aria-hidden="true" focusable="false" viewBox="0 0 24 24">
								<path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.6 3.6 12 3.6 12 3.6s-7.6 0-9.4.5A3 3 0 0 0 .5 6.2 31.6 31.6 0 0 0 0 12a31.6 31.6 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.8.5 9.4.5 9.4.5s7.6 0 9.4-.5a3 3 0 0 0 2.1-2.1A31.6 31.6 0 0 0 24 12a31.6 31.6 0 0 0-.5-5.8ZM9.6 15.5v-7l6.3 3.5-6.3 3.5Z"></path>
							</svg>
						</a>
						<a class="is-website" href="https://borbila.com/" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr__( 'Borbila website', 'woo-telegram-alert' ); ?>">
							<svg aria-hidden="true" focusable="false" viewBox="0 0 24 24">
								<path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm6.9 9h-3.1a15.5 15.5 0 0 0-1.3-5.1A8.1 8.1 0 0 1 18.9 11ZM12 4c.6.8 1.5 2.9 1.7 7H10.3c.2-4.1 1.1-6.2 1.7-7ZM4.3 13h3.1c.1 1.9.5 3.7 1.2 5.1A8.1 8.1 0 0 1 4.3 13Zm3.1-2H4.3a8.1 8.1 0 0 1 4.3-5.1A15.5 15.5 0 0 0 7.4 11ZM12 20c-.6-.8-1.5-2.9-1.7-7h3.4c-.2 4.1-1.1 6.2-1.7 7Zm3.4-1.9c.7-1.4 1.1-3.2 1.2-5.1h3.1a8.1 8.1 0 0 1-4.3 5.1Z"></path>
							</svg>
						</a>
					</div>
				</div>
			</div>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wta-settings-form">
				<input type="hidden" name="action" value="wta_save_settings">
				<?php wp_nonce_field( 'wta_save_settings', 'wta_settings_nonce' ); ?>

				<div class="wta-settings-shell">
					<nav class="wta-sidebar" role="tablist" aria-label="<?php echo esc_attr__( 'Woo Telegram Alert settings tabs', 'woo-telegram-alert' ); ?>">
						<button type="button" class="wta-tab wta-tab-active" data-tab="woocommerce" role="tab" aria-controls="wta-panel-woocommerce" aria-selected="true">
							<span class="dashicons dashicons-cart" aria-hidden="true"></span>
							<?php echo esc_html__( 'Order Status', 'woo-telegram-alert' ); ?>
						</button>
						<button type="button" class="wta-tab" data-tab="telegram" role="tab" aria-controls="wta-panel-telegram" aria-selected="false">
							<span class="dashicons dashicons-email-alt2" aria-hidden="true"></span>
							<?php echo esc_html__( 'Telegram Bot', 'woo-telegram-alert' ); ?>
						</button>
						<button type="button" class="wta-tab" data-tab="template" role="tab" aria-controls="wta-panel-template" aria-selected="false">
							<span class="dashicons dashicons-editor-code" aria-hidden="true"></span>
							<?php echo esc_html__( 'Message Template', 'woo-telegram-alert' ); ?>
						</button>
						<button type="button" class="wta-tab" data-tab="video" role="tab" aria-controls="wta-panel-video" aria-selected="false">
							<span class="dashicons dashicons-video-alt3" aria-hidden="true"></span>
							<?php echo esc_html__( 'Video Guide', 'woo-telegram-alert' ); ?>
						</button>
						<button type="button" class="wta-tab" data-tab="license" role="tab" aria-controls="wta-panel-license" aria-selected="false">
							<span class="dashicons dashicons-admin-network" aria-hidden="true"></span>
							<?php echo esc_html__( 'License Key', 'woo-telegram-alert' ); ?>
						</button>
					</nav>

					<div class="wta-content">
						<section class="wta-panel" data-panel="telegram" id="wta-panel-telegram" role="tabpanel">
							<div class="wta-panel-header">
								<div>
									<h2><?php echo esc_html__( 'Telegram Connection', 'woo-telegram-alert' ); ?></h2>
									<p><?php echo esc_html__( 'Connect your Telegram bot and chat destination.', 'woo-telegram-alert' ); ?></p>
								</div>
								<span class="wta-badge <?php echo esc_attr( $is_connected ? 'is-connected' : 'is-not-connected' ); ?>">
									<?php echo $is_connected ? esc_html__( 'Connected', 'woo-telegram-alert' ) : esc_html__( 'Not Connected', 'woo-telegram-alert' ); ?>
								</span>
							</div>

							<div class="wta-panel-card">
								<div class="wta-field">
									<label for="wta-bot-token"><?php echo esc_html__( 'Telegram Bot Token', 'woo-telegram-alert' ); ?></label>
									<input
										type="password"
										id="wta-bot-token"
										name="wta_bot_token"
										value="<?php echo esc_attr( $bot_token_field_value ); ?>"
										placeholder="<?php echo esc_attr__( 'Enter Telegram Bot Token', 'woo-telegram-alert' ); ?>"
										autocomplete="new-password"
									>
								</div>

								<div class="wta-field">
									<label for="wta-chat-id"><?php echo esc_html__( 'Telegram Chat ID', 'woo-telegram-alert' ); ?></label>
									<input
										type="text"
										id="wta-chat-id"
										name="wta_chat_id"
										value="<?php echo esc_attr( $settings['chat_id'] ); ?>"
										placeholder="<?php echo esc_attr__( '123456789,-1001234567890', 'woo-telegram-alert' ); ?>"
									>
									<p class="description">
										<?php echo esc_html__( 'Use comma-separated chat IDs for multiple Telegram groups/users.', 'woo-telegram-alert' ); ?>
									</p>
									<p class="description">
										<?php echo esc_html__( 'Find Chat ID:', 'woo-telegram-alert' ); ?>
										<a href="https://api.telegram.org/botYOUR_NEW_TOKEN/getUpdates" target="_blank" rel="noopener noreferrer">
											<?php echo esc_html( 'https://api.telegram.org/botYOUR_NEW_TOKEN/getUpdates' ); ?>
										</a>
									</p>
								</div>

								<div class="wta-quick-action">
									<button type="button" class="button wta-button-secondary" id="wta-send-test-message">
										<?php echo esc_html__( 'Send Test Message', 'woo-telegram-alert' ); ?>
									</button>
									<div id="wta-test-result" class="wta-test-result" role="status" aria-live="polite"></div>
								</div>
							</div>
						</section>

						<section class="wta-panel" data-panel="license" id="wta-panel-license" role="tabpanel">
							<div class="wta-panel-header">
								<div>
									<h2><?php echo esc_html__( 'Borbila License', 'woo-telegram-alert' ); ?></h2>
									<p><?php echo esc_html__( 'Activate your license to enable automatic WooCommerce Telegram alerts.', 'woo-telegram-alert' ); ?></p>
								</div>
								<span class="wta-badge <?php echo esc_attr( $license_active ? 'is-license-active' : 'is-license-inactive' ); ?>" id="wta-license-status-badge">
									<?php echo $license_active ? esc_html__( 'Active', 'woo-telegram-alert' ) : esc_html__( 'Inactive', 'woo-telegram-alert' ); ?>
								</span>
							</div>

							<div class="wta-panel-card wta-license-card">
								<div class="wta-field">
									<label for="wta-license-key"><?php echo esc_html__( 'License Key', 'woo-telegram-alert' ); ?></label>
									<input
										type="password"
										id="wta-license-key"
										name="wta_license_key"
										form="wta-license-form"
										value="<?php echo esc_attr( $license_key_field_value ); ?>"
										placeholder="<?php echo esc_attr__( 'Enter Borbila license key', 'woo-telegram-alert' ); ?>"
										autocomplete="new-password"
									>
								</div>

								<div class="wta-license-actions">
									<button type="submit" name="license_operation" value="activate" form="wta-license-form" class="button button-primary wta-button-primary" id="wta-activate-license">
										<?php echo esc_html__( 'Activate License', 'woo-telegram-alert' ); ?>
									</button>
									<button type="submit" name="license_operation" value="deactivate" form="wta-license-form" class="button wta-button-secondary" id="wta-deactivate-license">
										<?php echo esc_html__( 'Deactivate License', 'woo-telegram-alert' ); ?>
									</button>
								</div>

								<div id="wta-license-result" class="wta-test-result <?php echo ! empty( $license_notice ) ? 'is-visible ' . ( ! empty( $license_notice['success'] ) ? 'is-success' : 'is-error' ) : ''; ?>" role="status" aria-live="polite">
									<?php echo ! empty( $license_notice['message'] ) ? esc_html( $license_notice['message'] ) : ''; ?>
								</div>

								<div class="wta-license-meta">
									<div>
										<strong><?php echo esc_html__( 'Template ID', 'woo-telegram-alert' ); ?></strong>
										<span id="wta-license-template-id"><?php echo esc_html( WTA_License::TEMPLATE_ID ); ?></span>
									</div>
									<div>
										<strong><?php echo esc_html__( 'Activated Domain', 'woo-telegram-alert' ); ?></strong>
										<span id="wta-license-domain"><?php echo '' !== $license['activated_domain'] ? esc_html( $license['activated_domain'] ) : esc_html__( 'Not activated', 'woo-telegram-alert' ); ?></span>
									</div>
									<div>
										<strong><?php echo esc_html__( 'Last Checked', 'woo-telegram-alert' ); ?></strong>
										<span id="wta-license-last-checked"><?php echo '' !== $license['last_checked'] ? esc_html( $license['last_checked'] ) : esc_html__( 'Never', 'woo-telegram-alert' ); ?></span>
									</div>
								</div>
							</div>
						</section>

						<section class="wta-panel wta-panel-active" data-panel="woocommerce" id="wta-panel-woocommerce" role="tabpanel">
							<div class="wta-panel-header">
								<div>
									<h2><?php echo esc_html__( 'Order Status Notifications', 'woo-telegram-alert' ); ?></h2>
									<p><?php echo esc_html__( 'Choose which order statuses should send Telegram messages.', 'woo-telegram-alert' ); ?></p>
								</div>
							</div>

							<?php if ( ! $woocommerce_active ) : ?>
								<div class="wta-warning-box">
									<span class="dashicons dashicons-warning" aria-hidden="true"></span>
									<p><?php echo esc_html__( 'Woo Telegram Alert requires WooCommerce to send order notifications. Please install and activate WooCommerce.', 'woo-telegram-alert' ); ?></p>
								</div>
							<?php endif; ?>

							<div class="wta-warning-box <?php echo $license_active ? esc_attr( 'is-hidden' ) : ''; ?>" id="wta-license-lock-warning">
								<span class="dashicons dashicons-lock" aria-hidden="true"></span>
								<p><?php echo esc_html__( 'Please activate your license to enable automatic WooCommerce Telegram alerts.', 'woo-telegram-alert' ); ?></p>
							</div>
							<div id="wta-status-lock-result" class="wta-test-result" role="status" aria-live="polite"></div>

							<div class="wta-panel-card">
								<div class="wta-status-options">
									<div class="wta-status-grid">
										<?php foreach ( $status_options as $status_key => $status_label ) : ?>
											<?php
											$status_key = sanitize_key( $status_key );
											$field_id   = 'wta-status-alert-' . $status_key;
											?>
											<label
												class="wta-toggle-row wta-status-toggle <?php echo ! $license_active ? esc_attr( 'is-license-locked' ) : ''; ?>"
												for="<?php echo esc_attr( $field_id ); ?>"
												<?php echo ! $license_active ? 'data-license-locked="yes"' : ''; ?>
											>
												<span>
													<strong><?php echo esc_html( $status_label ); ?></strong>
													<small>
														<?php
														printf(
															/* translators: %s: WooCommerce order status label. */
															esc_html__( 'Allow notifications when order status is %s.', 'woo-telegram-alert' ),
															esc_html( $status_label )
														);
														?>
													</small>
												</span>
												<input
													type="checkbox"
													id="<?php echo esc_attr( $field_id ); ?>"
													name="wta_status_alert_statuses[]"
													value="<?php echo esc_attr( $status_key ); ?>"
													<?php checked( $license_active && isset( $status_alert_statuses[ $status_key ] ) && 'yes' === $status_alert_statuses[ $status_key ] ); ?>
													<?php disabled( ! $license_active ); ?>
												>
												<span class="wta-toggle" aria-hidden="true">
													<span class="wta-status-lock dashicons dashicons-lock"></span>
												</span>
											</label>
										<?php endforeach; ?>
									</div>
								</div>
							</div>
						</section>

						<section class="wta-panel" data-panel="template" id="wta-panel-template" role="tabpanel">
							<div class="wta-panel-header">
								<div>
									<h2><?php echo esc_html__( 'Message Template', 'woo-telegram-alert' ); ?></h2>
									<p><?php echo esc_html__( 'Customize the new order alert message sent to Telegram.', 'woo-telegram-alert' ); ?></p>
								</div>
							</div>

							<div class="wta-template-layout">
								<div class="wta-panel-card">
									<div class="wta-field">
										<textarea id="wta-message-template" name="wta_message_template" rows="14"><?php echo esc_textarea( $settings['message_template'] ); ?></textarea>
									</div>
									<button type="button" class="button wta-button-secondary" id="wta-reset-template">
										<?php echo esc_html__( 'Reset to Default Template', 'woo-telegram-alert' ); ?>
									</button>
									<div id="wta-template-result" class="wta-test-result" role="status" aria-live="polite"></div>
								</div>

								<div class="wta-placeholder-panel">
									<h3><?php echo esc_html__( 'Available Placeholders', 'woo-telegram-alert' ); ?></h3>
									<div class="wta-placeholder-list">
										<?php foreach ( $placeholders as $placeholder ) : ?>
											<button type="button" class="wta-placeholder-pill" data-placeholder="<?php echo esc_attr( $placeholder ); ?>">
												<?php echo esc_html( $placeholder ); ?>
											</button>
										<?php endforeach; ?>
									</div>
								</div>
							</div>
						</section>

						<section class="wta-panel" data-panel="video" id="wta-panel-video" role="tabpanel">
							<div class="wta-panel-header">
								<div>
									<h2><?php echo esc_html__( 'Video Guide', 'woo-telegram-alert' ); ?></h2>
									<p><?php echo esc_html__( 'Watch the setup guide for Woo Telegram Alert.', 'woo-telegram-alert' ); ?></p>
								</div>
							</div>

							<div class="wta-panel-card wta-video-card">
								<div class="wta-video-frame" data-video-src="https://www.youtube.com/embed/lQcqgcoi2dM?rel=0&autoplay=1">
									<button type="button" class="wta-video-loader">
										<span class="dashicons dashicons-controls-play" aria-hidden="true"></span>
										<strong><?php echo esc_html__( 'Play Video Guide', 'woo-telegram-alert' ); ?></strong>
										<small><?php echo esc_html__( 'YouTube loads only after clicking play.', 'woo-telegram-alert' ); ?></small>
									</button>
								</div>
							</div>
						</section>

					</div>

					<div class="wta-settings-footer">
						<div class="wta-footer-actions">
							<button type="submit" class="button button-primary wta-button-primary" id="wta-save-settings">
								<?php echo esc_html__( 'Save Changes', 'woo-telegram-alert' ); ?>
							</button>
							<div id="wta-save-result" class="wta-footer-notice <?php echo '1' === $updated ? 'is-success' : ( '1' === $save_error ? 'is-error' : 'is-hidden' ); ?>" role="status" aria-live="polite">
								<span class="dashicons <?php echo '1' === $save_error ? 'dashicons-warning' : 'dashicons-yes-alt'; ?>" aria-hidden="true"></span>
								<span><?php echo '1' === $save_error ? esc_html__( 'Settings could not be saved. Please try again or check the website firewall.', 'woo-telegram-alert' ) : esc_html__( 'Settings saved successfully.', 'woo-telegram-alert' ); ?></span>
							</div>
						</div>
						<div class="wta-footer-author">
							<?php echo esc_html__( 'Author', 'woo-telegram-alert' ); ?>
							<a href="https://borbila.com/" target="_blank" rel="noopener noreferrer">
								<?php echo esc_html__( 'Borbila', 'woo-telegram-alert' ); ?>
							</a>
						</div>
					</div>
				</div>
			</form>
			<form id="wta-license-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wta-hidden-form">
				<input type="hidden" name="action" value="wta_license_action">
				<?php wp_nonce_field( 'wta_license_action', 'wta_license_action_nonce' ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Send a Telegram test message over AJAX.
	 *
	 * @return void
	 */
	public function send_test_message() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'You do not have permission to send test messages.', 'woo-telegram-alert' ),
				),
				403
			);
		}

		$nonce_valid = check_ajax_referer( 'wta_test_message_nonce', 'nonce', false );

		if ( ! $nonce_valid ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Security check failed. Please refresh the page and try again.', 'woo-telegram-alert' ),
				),
				403
			);
		}

		$settings        = WTA_Plugin::get_settings();
		$submitted_token = sanitize_text_field( $this->get_posted_value( 'wta_bot_token' ) );

		if ( '' !== $submitted_token && WTA_MASKED_TOKEN_VALUE !== $submitted_token ) {
			$settings['bot_token'] = $submitted_token;
		}

		if ( $this->has_posted_value( 'wta_chat_id' ) ) {
			$settings['chat_id'] = sanitize_text_field( $this->get_posted_value( 'wta_chat_id' ) );
		}

		$site     = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$time     = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
		$message  = "✅ <b>Woo Telegram Alert Test Message</b>\n\n";
		$message .= "Your Telegram alert system is connected successfully.\n\n";
		$message .= 'Website: ' . esc_html( $site ) . "\n";
		$message .= 'Time: ' . esc_html( $time );

		$telegram = new WTA_Telegram( $settings['bot_token'], $settings['chat_id'] );
		$result   = $telegram->send_message( $message );

		if ( is_wp_error( $result ) ) {
			WTA_Logger::add_log(
				'error',
				sprintf(
					/* translators: %s: error message. */
					__( 'Test message failed. %s', 'woo-telegram-alert' ),
					$result->get_error_message()
				)
			);

			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
				)
			);
		}

		$success_message = is_array( $result ) && ! empty( $result['message'] )
			? $result['message']
			: esc_html__( 'Test message sent successfully.', 'woo-telegram-alert' );

		WTA_Logger::add_log( 'success', $success_message );

		wp_send_json_success(
			array(
				'message' => $success_message,
			)
		);
	}

	/**
	 * Reset the custom message template to the default template.
	 *
	 * @return void
	 */
	public function reset_message_template() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'You do not have permission to reset this template.', 'woo-telegram-alert' ),
				),
				403
			);
		}

		$nonce_valid = check_ajax_referer( 'wta_reset_template_nonce', 'nonce', false );

		if ( ! $nonce_valid ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Security check failed. Please refresh the page and try again.', 'woo-telegram-alert' ),
				),
				403
			);
		}

		$settings                     = get_option( $this->option_name, array() );
		$settings                     = is_array( $settings ) ? wp_parse_args( $settings, WTA_Plugin::get_default_settings() ) : WTA_Plugin::get_default_settings();
		$settings['message_template'] = WTA_Plugin::get_default_message_template();

		update_option( $this->option_name, $settings );
		WTA_Logger::add_log( 'info', __( 'Message template reset to default.', 'woo-telegram-alert' ) );

		wp_send_json_success(
			array(
				'message'  => esc_html__( 'Message template reset to the default template.', 'woo-telegram-alert' ),
				'template' => $settings['message_template'],
			)
		);
	}

	/**
	 * Handle non-JavaScript license activate/deactivate requests.
	 *
	 * @return void
	 */
	public function handle_license_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage this license.', 'woo-telegram-alert' ) );
		}

		check_admin_referer( 'wta_license_action', 'wta_license_action_nonce' );

		$operation = isset( $_POST['license_operation'] ) ? sanitize_key( wp_unslash( $_POST['license_operation'] ) ) : '';

		if ( 'activate' === $operation ) {
			$result = WTA_License::activate_license( $this->get_posted_value( 'wta_license_key' ) );
		} elseif ( 'deactivate' === $operation ) {
			$result = WTA_License::deactivate_license();
		} else {
			$result = array(
				'success' => false,
				'message' => __( 'Invalid license action.', 'woo-telegram-alert' ),
			);
		}

		$this->set_license_notice( ! empty( $result['success'] ), isset( $result['message'] ) ? $result['message'] : __( 'License action failed.', 'woo-telegram-alert' ) );

		wp_safe_redirect( admin_url( 'admin.php?page=' . $this->menu_slug ) . '#license' );
		exit;
	}

	/**
	 * Activate a Borbila license over AJAX.
	 *
	 * @return void
	 */
	public function activate_license() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'You do not have permission to activate this license.', 'woo-telegram-alert' ),
				),
				403
			);
		}

		$nonce_valid = check_ajax_referer( 'wta_license_nonce', 'nonce', false );

		if ( ! $nonce_valid ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Security check failed. Please refresh the page and try again.', 'woo-telegram-alert' ),
				),
				403
			);
		}

		$license_key = $this->get_posted_value( 'wta_license_key' );

		if ( '' === $license_key && isset( $_POST['license_key'] ) && is_scalar( $_POST['license_key'] ) ) {
			$license_key = sanitize_text_field( wp_unslash( $_POST['license_key'] ) );
		}

		$result      = WTA_License::activate_license( $license_key );
		$message     = ! empty( $result['message'] ) ? sanitize_text_field( $result['message'] ) : esc_html__( 'License activation failed.', 'woo-telegram-alert' );
		$license     = isset( $result['license'] ) && is_array( $result['license'] ) ? $result['license'] : WTA_License::get_license();
		$data        = array(
			'message' => $message,
			'license' => $this->get_public_license_data( $license ),
		);

		if ( ! empty( $result['success'] ) ) {
			WTA_Logger::add_log( 'success', __( 'Borbila license activated.', 'woo-telegram-alert' ) );
			wp_send_json_success( $data );
		}

		WTA_Logger::add_log( 'error', __( 'Borbila license activation failed.', 'woo-telegram-alert' ) );
		wp_send_json_error( $data );
	}

	/**
	 * Deactivate a Borbila license locally over AJAX.
	 *
	 * @return void
	 */
	public function deactivate_license() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'You do not have permission to deactivate this license.', 'woo-telegram-alert' ),
				),
				403
			);
		}

		$nonce_valid = check_ajax_referer( 'wta_license_nonce', 'nonce', false );

		if ( ! $nonce_valid ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Security check failed. Please refresh the page and try again.', 'woo-telegram-alert' ),
				),
				403
			);
		}

		$result  = WTA_License::deactivate_license();
		$message = ! empty( $result['message'] ) ? sanitize_text_field( $result['message'] ) : esc_html__( 'License deactivation failed.', 'woo-telegram-alert' );
		$license = isset( $result['license'] ) && is_array( $result['license'] ) ? $result['license'] : WTA_License::get_license();
		$data    = array(
			'message' => $message,
			'license' => $this->get_public_license_data( $license ),
		);

		if ( ! empty( $result['success'] ) ) {
			WTA_Logger::add_log( 'info', __( 'Borbila license deactivated.', 'woo-telegram-alert' ) );
			wp_send_json_success( $data );
		}

		WTA_Logger::add_log( 'error', __( 'Borbila license deactivation failed.', 'woo-telegram-alert' ) );
		wp_send_json_error( $data );
	}

	/**
	 * Supported template placeholders.
	 *
	 * @return array
	 */
	private function get_template_placeholders() {
		return array(
			'{order_id}',
			'{order_date}',
			'{customer_name}',
			'{billing_first_name}',
			'{billing_last_name}',
			'{billing_phone}',
			'{billing_email}',
			'{billing_address}',
			'{shipping_address}',
			'{order_items}',
			'{payment_method}',
			'{subtotal}',
			'{shipping_total}',
			'{discount_total}',
			'{order_total}',
			'{order_status}',
			'{currency}',
			'{site_name}',
			'{admin_order_url}',
			'{old_status}',
			'{new_status}',
		);
	}

	/**
	 * Get license data safe for HTML and AJAX responses.
	 *
	 * @param array $license License data.
	 * @return array
	 */
	private function get_public_license_data( $license ) {
		$license = is_array( $license ) ? wp_parse_args( $license, WTA_License::get_default_license() ) : WTA_License::get_license();
		$status    = sanitize_key( $license['status'] );
		$is_active = WTA_License::is_active();

		return array(
			'status'           => $status,
			'is_active'        => $is_active,
			'status_label'     => $is_active ? esc_html__( 'Active', 'woo-telegram-alert' ) : esc_html__( 'Inactive', 'woo-telegram-alert' ),
			'header_label'     => $is_active ? esc_html__( 'License: Active', 'woo-telegram-alert' ) : esc_html__( 'License: Inactive', 'woo-telegram-alert' ),
			'masked_key'       => WTA_License::mask_license_key( $license['license_key'] ),
			'template_id'      => WTA_License::TEMPLATE_ID,
			'activated_domain' => '' !== $license['activated_domain'] ? sanitize_text_field( $license['activated_domain'] ) : esc_html__( 'Not activated', 'woo-telegram-alert' ),
			'last_checked'     => '' !== $license['last_checked'] ? sanitize_text_field( $license['last_checked'] ) : esc_html__( 'Never', 'woo-telegram-alert' ),
		);
	}

	/**
	 * Store a short-lived license result for the non-JavaScript fallback.
	 *
	 * @param bool   $success Success state.
	 * @param string $message User-facing message.
	 * @return void
	 */
	private function set_license_notice( $success, $message ) {
		set_transient(
			'wta_license_notice_' . get_current_user_id(),
			array(
				'success' => (bool) $success,
				'message' => sanitize_text_field( $message ),
			),
			MINUTE_IN_SECONDS
		);
	}

	/**
	 * Read and clear the current user's fallback license result.
	 *
	 * @return array
	 */
	private function pop_license_notice() {
		$key    = 'wta_license_notice_' . get_current_user_id();
		$notice = get_transient( $key );

		if ( false !== $notice ) {
			delete_transient( $key );
		}

		return is_array( $notice ) ? $notice : array();
	}
}
