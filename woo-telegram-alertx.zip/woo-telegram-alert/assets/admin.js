( function ( $ ) {
	'use strict';

	var tabStorageKey = 'wtaActiveTabV3';
	var defaultTab = 'woocommerce';
	var allowedTabs = [ 'woocommerce', 'telegram', 'license', 'template', 'video' ];
	var nativeSettingsSubmit = false;

	function encodeBase64( value ) {
		try {
			return window.btoa( window.unescape( window.encodeURIComponent( String( value || '' ) ) ) );
		} catch ( error ) {
			return window.btoa( String( value || '' ) );
		}
	}

	function showSaveResult( type, message ) {
		var $result = $( '#wta-save-result' );
		var $icon = $result.find( '.dashicons' );

		$result
			.removeClass( 'is-hidden is-success is-error' )
			.addClass( 'is-' + type );

		$icon
			.removeClass( 'dashicons-yes-alt dashicons-warning' )
			.addClass( 'success' === type ? 'dashicons-yes-alt' : 'dashicons-warning' );

		$result.find( 'span' ).last().text( message );
	}

	function getSelectedStatuses() {
		var statuses = [];

		$( 'input[name="wta_status_alert_statuses[]"]:checked:not(:disabled)' ).each( function () {
			statuses.push( $( this ).val() );
		} );

		return statuses;
	}

	function getEncodedSettingsData() {
		return {
			action: 'wta_save_settings_ajax',
			nonce: wtaAdmin.settingsNonce,
			wta_payload_encoding: 'base64',
			wta_bot_token_encoded: encodeBase64( $( '#wta-bot-token' ).val() ),
			wta_chat_id_encoded: encodeBase64( $( '#wta-chat-id' ).val() ),
			wta_message_template_encoded: encodeBase64( $( '#wta-message-template' ).val() ),
			wta_status_alert_statuses: getSelectedStatuses()
		};
	}

	function submitNativeSettingsForm( $form ) {
		var encodedFields = {
			wta_payload_encoding: 'base64',
			wta_bot_token_encoded: encodeBase64( $( '#wta-bot-token' ).val() ),
			wta_chat_id_encoded: encodeBase64( $( '#wta-chat-id' ).val() ),
			wta_message_template_encoded: encodeBase64( $( '#wta-message-template' ).val() )
		};

		nativeSettingsSubmit = true;
		$form.find( '.wta-encoded-payload' ).remove();

		$.each( encodedFields, function ( name, value ) {
			$( '<input>', {
				type: 'hidden',
				name: name,
				value: value,
				'class': 'wta-encoded-payload'
			} ).appendTo( $form );
		} );

		$( '#wta-bot-token, #wta-chat-id, #wta-message-template' ).removeAttr( 'name' );
		$form.get( 0 ).submit();
	}

	function submitNativeLicenseForm( operation ) {
		var $form = $( '#wta-license-form' );

		$form.find( '.wta-license-fallback-field' ).remove();
		$( '#wta-license-key' ).removeAttr( 'name' );
		$( '<input>', {
			type: 'hidden',
			name: 'wta_payload_encoding',
			value: 'base64',
			'class': 'wta-license-fallback-field'
		} ).appendTo( $form );
		$( '<input>', {
			type: 'hidden',
			name: 'wta_license_key_encoded',
			value: encodeBase64( $( '#wta-license-key' ).val() ),
			'class': 'wta-license-fallback-field'
		} ).appendTo( $form );
		$( '<input>', {
			type: 'hidden',
			name: 'license_operation',
			value: operation,
			'class': 'wta-license-fallback-field'
		} ).appendTo( $form );
		$form.get( 0 ).submit();
	}

	function showResult( selector, type, message ) {
		var $result = $( selector );

		$result
			.removeClass( 'is-success is-error' )
			.addClass( 'is-visible is-' + type )
			.text( message );
	}

	function showTemporaryResult( selector, type, message ) {
		showResult( selector, type, message );

		window.setTimeout( function () {
			$( selector )
				.removeClass( 'is-visible is-success is-error' )
				.text( '' );
		}, 3500 );
	}

	function insertAtCursor( textarea, text ) {
		var start;
		var end;
		var value;

		if ( ! textarea ) {
			return;
		}

		textarea.focus();

		if ( typeof textarea.selectionStart === 'number' ) {
			start = textarea.selectionStart;
			end = textarea.selectionEnd;
			value = textarea.value;

			textarea.value = value.substring( 0, start ) + text + value.substring( end );
			textarea.selectionStart = textarea.selectionEnd = start + text.length;
			return;
		}

		textarea.value += text;
	}

	function normalizeTab( tab ) {
		return allowedTabs.indexOf( tab ) !== -1 ? tab : defaultTab;
	}

	function getStoredTab() {
		try {
			return window.localStorage.getItem( tabStorageKey );
		} catch ( error ) {
			return '';
		}
	}

	function storeTab( tab ) {
		try {
			window.localStorage.setItem( tabStorageKey, tab );
		} catch ( error ) {
			return;
		}
	}

	function getInitialTab() {
		var hash = window.location.hash ? window.location.hash.replace( '#', '' ) : '';

		return normalizeTab( hash || getStoredTab() || defaultTab );
	}

	function activateTab( tab, updateHash ) {
		var activeTab = normalizeTab( tab );

		$( '.wta-tab' )
			.removeClass( 'wta-tab-active' )
			.attr( 'aria-selected', 'false' );

		$( '.wta-tab[data-tab="' + activeTab + '"]' )
			.addClass( 'wta-tab-active' )
			.attr( 'aria-selected', 'true' );

		$( '.wta-panel' )
			.removeClass( 'wta-panel-active' )
			.attr( 'aria-hidden', 'true' );

		$( '.wta-panel[data-panel="' + activeTab + '"]' )
			.addClass( 'wta-panel-active' )
			.attr( 'aria-hidden', 'false' );

		storeTab( activeTab );

		if ( updateHash && window.history && window.history.replaceState ) {
			window.history.replaceState( null, '', '#' + activeTab );
		}
	}

	function updateLicenseUi( license ) {
		var isActive = license && license.is_active;
		var statusLabel = license && license.status_label ? license.status_label : 'Inactive';
		var headerLabel = license && license.header_label ? license.header_label : 'License: Inactive';
		var maskedKey = license && license.masked_key ? license.masked_key : '';
		var domain = license && license.activated_domain ? license.activated_domain : 'Not activated';
		var lastChecked = license && license.last_checked ? license.last_checked : 'Never';

		$( '#wta-license-status-badge' )
			.removeClass( 'is-license-active is-license-inactive' )
			.addClass( isActive ? 'is-license-active' : 'is-license-inactive' )
			.text( statusLabel );

		$( '#wta-header-license-badge' )
			.removeClass( 'is-license-active is-license-inactive' )
			.addClass( isActive ? 'is-license-active' : 'is-license-inactive' )
			.text( headerLabel );

		$( '#wta-license-key' ).val( maskedKey );
		$( '#wta-license-domain' ).text( domain );
		$( '#wta-license-last-checked' ).text( lastChecked );
		$( '#wta-license-lock-warning' ).toggleClass( 'is-hidden', !! isActive );

		$( '.wta-status-toggle' )
			.toggleClass( 'is-license-locked', ! isActive )
			.attr( 'data-license-locked', isActive ? null : 'yes' )
				.find( 'input' )
				.prop( 'disabled', ! isActive );

		if ( ! isActive ) {
			$( '.wta-status-toggle input' ).prop( 'checked', false );
		}
	}

	$( function () {
		activateTab( getInitialTab(), false );

		$( '.wta-tab' ).on( 'click', function () {
			activateTab( $( this ).data( 'tab' ), true );
		} );

		$( window ).on( 'hashchange', function () {
			activateTab( getInitialTab(), false );
		} );

		$( '.wta-status-toggle' ).on( 'click', function ( event ) {
			if ( ! $( this ).hasClass( 'is-license-locked' ) ) {
				return;
			}

			event.preventDefault();
			showTemporaryResult( '#wta-status-lock-result', 'error', wtaAdmin.strings.licenseRequired );
		} );

		$( '.wta-settings-form' ).on( 'submit', function ( event ) {
			var $form = $( this );
			var $button = $( '#wta-save-settings' );

			if ( nativeSettingsSubmit || ! wtaAdmin.ajaxUrl || ! wtaAdmin.settingsNonce ) {
				return;
			}

			event.preventDefault();
			$button.prop( 'disabled', true ).text( wtaAdmin.strings.saving );
			$( '#wta-save-result' ).addClass( 'is-hidden' );

			$.ajax( {
				url: wtaAdmin.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: getEncodedSettingsData()
			} )
				.done( function ( response ) {
					var message = response && response.data && response.data.message
						? response.data.message
						: wtaAdmin.strings.error;

					if ( response && response.success ) {
						if ( response.data && response.data.has_token ) {
							$( '#wta-bot-token' ).val( wtaAdmin.maskedToken );
						}

						showSaveResult( 'success', message );
						return;
					}

					showSaveResult( 'error', message );
				} )
				.fail( function ( xhr ) {
					var message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message
						? xhr.responseJSON.data.message
						: '';

					if ( message ) {
						showSaveResult( 'error', message );
						return;
					}

					submitNativeSettingsForm( $form );
				} )
				.always( function () {
					if ( ! nativeSettingsSubmit ) {
						$button.prop( 'disabled', false ).text( wtaAdmin.strings.save );
					}
				} );
		} );

		$( '#wta-send-test-message' ).on( 'click', function () {
			var $button = $( this );

			$button.prop( 'disabled', true ).text( wtaAdmin.strings.sending );
			$( '#wta-test-result' ).removeClass( 'is-visible is-success is-error' ).text( '' );

			$.ajax( {
				url: wtaAdmin.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'wta_send_test_message',
					nonce: wtaAdmin.testNonce,
					wta_payload_encoding: 'base64',
					wta_bot_token_encoded: encodeBase64( $( '#wta-bot-token' ).val() ),
					wta_chat_id_encoded: encodeBase64( $( '#wta-chat-id' ).val() )
				}
			} )
				.done( function ( response ) {
					var message = response && response.data && response.data.message
						? response.data.message
						: wtaAdmin.strings.error;

					if ( response && response.success ) {
						showResult( '#wta-test-result', 'success', message );
						return;
					}

					showResult( '#wta-test-result', 'error', message );
				} )
				.fail( function () {
					showResult( '#wta-test-result', 'error', wtaAdmin.strings.error );
				} )
				.always( function () {
					$button.prop( 'disabled', false ).text( wtaAdmin.strings.default );
				} );
		} );

		$( '#wta-reset-template' ).on( 'click', function () {
			var $button = $( this );

			$button.prop( 'disabled', true ).text( wtaAdmin.strings.resetting );
			$( '#wta-template-result' ).removeClass( 'is-visible is-success is-error' ).text( '' );

			$.ajax( {
				url: wtaAdmin.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'wta_reset_message_template',
					nonce: wtaAdmin.resetNonce
				}
			} )
				.done( function ( response ) {
					var message = response && response.data && response.data.message
						? response.data.message
						: wtaAdmin.strings.error;

					if ( response && response.success ) {
						if ( response.data && response.data.template ) {
							$( '#wta-message-template' ).val( response.data.template );
						}

						showResult( '#wta-template-result', 'success', message );
						return;
					}

					showResult( '#wta-template-result', 'error', message );
				} )
				.fail( function () {
					showResult( '#wta-template-result', 'error', wtaAdmin.strings.error );
				} )
				.always( function () {
					$button.prop( 'disabled', false ).text( wtaAdmin.strings.resetDefault );
				} );
		} );

		$( '#wta-activate-license' ).on( 'click', function ( event ) {
			var $button = $( this );
			var $deactivateButton = $( '#wta-deactivate-license' );

			event.preventDefault();

			$button.prop( 'disabled', true ).text( wtaAdmin.strings.activating );
			$deactivateButton.prop( 'disabled', true );
			$( '#wta-license-result' ).removeClass( 'is-visible is-success is-error' ).text( '' );

			$.ajax( {
				url: wtaAdmin.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'wta_activate_license',
					nonce: wtaAdmin.licenseNonce,
					wta_payload_encoding: 'base64',
					wta_license_key_encoded: encodeBase64( $( '#wta-license-key' ).val() )
				}
			} )
				.done( function ( response ) {
					var message = response && response.data && response.data.message
						? response.data.message
						: wtaAdmin.strings.error;
					var license = response && response.data && response.data.license
						? response.data.license
						: {};

					updateLicenseUi( license );
					showTemporaryResult( '#wta-license-result', response && response.success ? 'success' : 'error', message );
				} )
				.fail( function ( xhr ) {
					var message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message
						? xhr.responseJSON.data.message
						: '';

					if ( message ) {
						showTemporaryResult( '#wta-license-result', 'error', message );
						return;
					}

					submitNativeLicenseForm( 'activate' );
				} )
				.always( function () {
					$button.prop( 'disabled', false ).text( wtaAdmin.strings.activate );
					$deactivateButton.prop( 'disabled', false );
				} );
		} );

		$( '#wta-deactivate-license' ).on( 'click', function ( event ) {
			var $button = $( this );
			var $activateButton = $( '#wta-activate-license' );

			event.preventDefault();

			$button.prop( 'disabled', true ).text( wtaAdmin.strings.deactivating );
			$activateButton.prop( 'disabled', true );
			$( '#wta-license-result' ).removeClass( 'is-visible is-success is-error' ).text( '' );

			$.ajax( {
				url: wtaAdmin.ajaxUrl,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'wta_deactivate_license',
					nonce: wtaAdmin.licenseNonce
				}
			} )
				.done( function ( response ) {
					var message = response && response.data && response.data.message
						? response.data.message
						: wtaAdmin.strings.error;
					var license = response && response.data && response.data.license
						? response.data.license
						: {};

					updateLicenseUi( license );
					showTemporaryResult( '#wta-license-result', response && response.success ? 'success' : 'error', message );
				} )
				.fail( function ( xhr ) {
					var message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message
						? xhr.responseJSON.data.message
						: '';

					if ( message ) {
						showTemporaryResult( '#wta-license-result', 'error', message );
						return;
					}

					submitNativeLicenseForm( 'deactivate' );
				} )
				.always( function () {
					$button.prop( 'disabled', false ).text( wtaAdmin.strings.deactivate );
					$activateButton.prop( 'disabled', false );
				} );
		} );

		$( '.wta-placeholder-pill' ).on( 'click', function () {
			var $pill = $( this );
			var placeholder = $pill.data( 'placeholder' );
			var textarea = document.getElementById( 'wta-message-template' );

			if ( ! placeholder ) {
				return;
			}

			insertAtCursor( textarea, placeholder );

			$pill.addClass( 'is-inserted' );

			window.setTimeout( function () {
				$pill.removeClass( 'is-inserted' );
			}, 450 );
		} );

		$( '.wta-video-loader' ).on( 'click', function () {
			var $button = $( this );
			var $frame = $button.closest( '.wta-video-frame' );
			var videoSrc = $frame.data( 'video-src' );

			if ( ! videoSrc || $frame.find( 'iframe' ).length ) {
				return;
			}

			$frame
				.empty()
				.append( $( '<iframe />', {
					src: videoSrc,
					title: 'Woo Telegram Alert video guide',
					allow: 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share',
					allowfullscreen: 'allowfullscreen'
				} ) );
		} );
	} );
} )( jQuery );
