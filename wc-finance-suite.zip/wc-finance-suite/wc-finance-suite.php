<?php
/**
 * Plugin Name: WC Finance Suite
 * Description: WooCommerce-connected Profit & Loss, Balance Sheet and Cash Flow Statement with a clean admin dashboard and custom CSS option.
 * Version: 1.0.0
 * Requires Plugins: woocommerce
 * Text Domain: wc-finance-suite
 */
if (!defined('ABSPATH')) exit;

final class WCF {
    const DB = '1';

    /* ---------- Setup ---------- */
    static function init() {
        register_activation_hook(__FILE__, [__CLASS__, 'install']);
        add_action('before_woocommerce_init', function () {
            if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
                \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
            }
        });
        add_action('admin_init', function () { if (get_option('wcf_db') !== self::DB) self::install(); });
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_head', [__CLASS__, 'head']);
        add_action('admin_post_wcf_add_entry', [__CLASS__, 'add_entry']);
        add_action('admin_post_wcf_delete_entry', [__CLASS__, 'delete_entry']);
        add_action('admin_post_wcf_save_settings', [__CLASS__, 'save_settings']);
        foreach (['woocommerce_order_status_changed', 'woocommerce_update_order', 'woocommerce_new_order', 'woocommerce_order_refunded'] as $h) {
            add_action($h, function () { update_option('wcf_ver', microtime(true), false); });
        }
        add_action('woocommerce_product_options_pricing', function () {
            woocommerce_wp_text_input(['id' => '_wcf_cost', 'label' => 'Cost price (' . get_woocommerce_currency_symbol() . ')', 'data_type' => 'price', 'desc_tip' => true, 'description' => 'Used by WC Finance Suite for COGS.']);
        });
        add_action('woocommerce_admin_process_product_object', function ($p) {
            if (isset($_POST['_wcf_cost'])) $p->update_meta_data('_wcf_cost', wc_format_decimal(wp_unslash($_POST['_wcf_cost'])));
        });
    }

    static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $t = $wpdb->prefix . 'wcf_entries';
        dbDelta("CREATE TABLE $t (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            entry_date date NOT NULL,
            type varchar(30) NOT NULL,
            label varchar(190) NOT NULL DEFAULT '',
            amount decimal(18,2) NOT NULL DEFAULT 0,
            notes text,
            PRIMARY KEY  (id),
            KEY entry_date (entry_date),
            KEY type (type)
        ) " . $wpdb->get_charset_collate() . ";");
        update_option('wcf_db', self::DB);
    }

    static function types() {
        return [
            'expense'            => ['Operating Expense', 'out', 'Operating'],
            'other_income'       => ['Other Income', 'in', 'Operating'],
            'inventory_purchase' => ['Inventory Purchase', 'out', 'Operating'],
            'tax_payment'        => ['Tax Payment (VAT/Sales Tax)', 'out', 'Operating'],
            'asset_purchase'     => ['Asset Purchase', 'out', 'Investing'],
            'asset_sale'         => ['Asset Sale', 'in', 'Investing'],
            'loan_received'      => ['Loan Received', 'in', 'Financing'],
            'loan_repaid'        => ['Loan Repaid', 'out', 'Financing'],
            'owner_investment'   => ['Owner Investment', 'in', 'Financing'],
            'owner_drawing'      => ['Owner Drawing', 'out', 'Financing'],
        ];
    }

    static function opt($k = null) {
        $d = [
            'start_date' => gmdate('Y-01-01'), 'opening_cash' => 0, 'opening_inventory' => 0, 'opening_fixed' => 0, 'opening_loans' => 0,
            'statuses' => ['wc-completed', 'wc-processing'], 'cogs_pct' => 60, 'accent' => '#4f46e5', 'custom_css' => '',
        ];
        $o = wp_parse_args((array) get_option('wcf_settings', []), $d);
        return $k ? $o[$k] : $o;
    }

    /* ---------- Menu / assets ---------- */
    static function menu() {
        add_menu_page('Finance', 'Finance', 'manage_woocommerce', 'wcf', [__CLASS__, 'page'], 'dashicons-chart-area', 56);
    }

    static function is_page() { return isset($_GET['page']) && $_GET['page'] === 'wcf'; }

    static function head() {
        if (!self::is_page()) return;
        $a = esc_attr(self::opt('accent'));
        echo '<style id="wcf-base">:root{--wcf-accent:' . $a . '}' . self::css() . '</style>';
        $c = self::opt('custom_css');
        if ($c) echo '<style id="wcf-custom-css">' . wp_strip_all_tags($c) . '</style>';
    }

    static function css() {
        return <<<CSS
.wcf{--bg:#f6f7fb;--card:#fff;--ink:#0f172a;--mut:#64748b;--line:#e5e7eb;--pos:#059669;--neg:#dc2626;--r:14px;max-width:1280px;margin:20px 20px 0 0;color:var(--ink);font-size:14px}
.wcf *{box-sizing:border-box}
.wcf-hero{background:linear-gradient(135deg,var(--wcf-accent),#111827);color:#fff;border-radius:var(--r);padding:26px 30px;display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap}
.wcf-hero h1{color:#fff;margin:0;font-size:24px;font-weight:700;padding:0}
.wcf-hero p{margin:4px 0 0;opacity:.8}
.wcf-btn{display:inline-flex;align-items:center;gap:6px;background:var(--wcf-accent);color:#fff!important;border:0;border-radius:10px;padding:9px 16px;font-weight:600;cursor:pointer;text-decoration:none;font-size:13px;line-height:1.3}
.wcf-btn:hover{filter:brightness(1.1)}
.wcf-btn.ghost{background:rgba(255,255,255,.15)}
.wcf-btn.light{background:#fff;color:var(--ink)!important;border:1px solid var(--line)}
.wcf-nav{display:flex;gap:6px;margin:18px 0;background:var(--card);padding:6px;border-radius:12px;border:1px solid var(--line);flex-wrap:wrap}
.wcf-nav a{padding:9px 16px;border-radius:9px;text-decoration:none;color:var(--mut);font-weight:600}
.wcf-nav a:hover{background:var(--bg);color:var(--ink)}
.wcf-nav a.on{background:var(--wcf-accent);color:#fff}
.wcf-bar{display:flex;gap:10px;align-items:end;flex-wrap:wrap;background:var(--card);border:1px solid var(--line);border-radius:var(--r);padding:14px 16px;margin-bottom:18px}
.wcf-bar label{display:block;font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:var(--mut);margin-bottom:4px;font-weight:600}
.wcf-bar input[type=date]{border-radius:8px;border:1px solid var(--line);padding:6px 10px}
.wcf-pre{margin-left:auto;display:flex;gap:6px;flex-wrap:wrap}
.wcf-pre a{padding:6px 11px;border-radius:999px;background:var(--bg);text-decoration:none;color:var(--mut);font-size:12px;font-weight:600}
.wcf-pre a:hover{background:var(--wcf-accent);color:#fff}
.wcf-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin-bottom:18px}
.wcf-card{background:var(--card);border:1px solid var(--line);border-radius:var(--r);padding:20px;box-shadow:0 1px 2px rgba(0,0,0,.03)}
.wcf-card h3{margin:0 0 14px;font-size:15px}
.wcf-kpi small{color:var(--mut);text-transform:uppercase;letter-spacing:.05em;font-size:11px;font-weight:700}
.wcf-kpi b{display:block;font-size:26px;margin-top:6px;letter-spacing:-.02em}
.wcf-kpi i{display:block;font-style:normal;color:var(--mut);font-size:12px;margin-top:4px}
.wcf-kpi{border-top:3px solid var(--wcf-accent)}
.wcf-tbl{width:100%;border-collapse:collapse}
.wcf-tbl td,.wcf-tbl th{padding:10px 12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:middle}
.wcf-tbl td.n,.wcf-tbl th.n{text-align:right;font-variant-numeric:tabular-nums}
.wcf-tbl th{font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:var(--mut);background:var(--bg)}
.wcf-tbl tr.sec td{background:var(--bg);font-weight:700;font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--mut)}
.wcf-tbl tr.sub td:first-child{padding-left:30px}
.wcf-tbl tr.tot td{font-weight:700;border-top:2px solid var(--ink)}
.wcf-tbl tr.grand td{font-weight:800;font-size:15px;background:var(--bg);border-top:2px solid var(--ink)}
.wcf-tbl .neg,.neg{color:var(--neg)}
.wcf-tbl .pos,.pos{color:var(--pos)}
.wcf-two{display:grid;grid-template-columns:1fr 1fr;gap:18px}
.wcf-two.s{grid-template-columns:340px 1fr}
@media(max-width:1000px){.wcf-two,.wcf-two.s{grid-template-columns:1fr}}
.wcf-chart{display:flex;align-items:flex-end;gap:10px;height:210px;padding-top:10px;overflow-x:auto}
.wcf-col{flex:1;min-width:46px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%}
.wcf-bars{display:flex;align-items:flex-end;gap:4px;height:170px}
.wcf-bars span{width:16px;border-radius:5px 5px 0 0;min-height:2px;background:var(--wcf-accent)}
.wcf-bars span.p{background:#10b981}
.wcf-bars span.m{background:#f87171}
.wcf-col em{font-style:normal;font-size:11px;color:var(--mut);margin-top:6px}
.wcf-leg{display:flex;gap:14px;font-size:12px;color:var(--mut);margin-bottom:6px}
.wcf-leg i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:5px;background:var(--wcf-accent)}
.wcf-f label{display:block;font-weight:600;margin:12px 0 4px}
.wcf-f input[type=text],.wcf-f input[type=number],.wcf-f input[type=date],.wcf-f input[type=color],.wcf-f select,.wcf-f textarea{width:100%;border-radius:8px;border:1px solid var(--line);padding:8px 10px;max-width:100%}
.wcf-f textarea.code{font-family:ui-monospace,Menlo,monospace;min-height:220px}
.wcf-f small{color:var(--mut);display:block;margin-top:4px}
.wcf-f .row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.wcf-badge{display:inline-block;padding:3px 9px;border-radius:999px;font-size:11px;font-weight:700;background:#eef2ff;color:var(--wcf-accent)}
.wcf-badge.out{background:#fef2f2;color:var(--neg)}
.wcf-badge.in{background:#ecfdf5;color:var(--pos)}
.wcf-note{padding:11px 14px;border-radius:10px;margin-bottom:16px;font-weight:600}
.wcf-note.ok{background:#ecfdf5;color:#065f46}
.wcf-note.chk{background:#fffbeb;color:#92400e;font-weight:500;margin:14px 0 0}
.wcf-x{color:var(--neg);text-decoration:none;font-weight:700}
.wcf-title{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}
.wcf-title h2{margin:0;font-size:18px;padding:0}
@media print{#adminmenumain,#wpadminbar,#wpfooter,.wcf-nav,.wcf-bar,.wcf-hero .wcf-btn,.wcf-noprint{display:none!important}#wpcontent{margin-left:0!important}.wcf{margin:0}.wcf-hero{background:#fff!important;color:#000!important}.wcf-hero h1{color:#000}}
CSS;
    }

    /* ---------- Date helpers ---------- */
    static function ts($d, $end = false) {
        $dt = new DateTime($d . ($end ? ' 23:59:59' : ' 00:00:00'), wp_timezone());
        return $dt->getTimestamp();
    }
    static function today() { return wp_date('Y-m-d'); }
    static function d($s, $mod = '') { $x = new DateTime($s, wp_timezone()); if ($mod) $x->modify($mod); return $x->format('Y-m-d'); }
    static function g($a, $k) { return isset($a[$k]) ? (float) $a[$k] : 0.0; }
    static function m($v, $cls = true) {
        $c = $cls ? ($v < -0.004 ? 'neg' : '') : '';
        return '<span class="' . $c . '">' . wc_price($v) . '</span>';
    }

    /* ---------- Data layer ---------- */
    static function cost($product_id) {
        static $c = [];
        if (!isset($c[$product_id])) {
            $p = wc_get_product($product_id);
            $v = '';
            if ($p) {
                $v = $p->get_meta('_wcf_cost');
                if ($v === '' && $p->get_parent_id()) {
                    $par = wc_get_product($p->get_parent_id());
                    if ($par) $v = $par->get_meta('_wcf_cost');
                }
            }
            $c[$product_id] = $v;
        }
        return $c[$product_id];
    }

    static function orders($from, $to) {
        $st = self::opt('statuses');
        $key = 'wcf_o_' . md5($from . $to . wp_json_encode($st) . get_option('wcf_ver', '0') . self::opt('cogs_pct'));
        if (empty($_GET['refresh'])) { $c = get_transient($key); if ($c !== false) return $c; }
        $r = ['count' => 0, 'sub' => 0, 'disc' => 0, 'ship' => 0, 'fees' => 0, 'refunds' => 0, 'tax' => 0, 'receipts' => 0, 'rev' => 0, 'cogs' => 0, 'm' => []];
        if (!$st) return $r;
        $pct = (float) self::opt('cogs_pct') / 100;
        $page = 1;
        do {
            $ids = wc_get_orders(['limit' => 200, 'paged' => $page, 'status' => $st, 'type' => 'shop_order', 'return' => 'ids',
                'date_created' => self::ts($from) . '...' . self::ts($to, true)]);
            foreach ($ids as $id) {
                $o = wc_get_order($id);
                if (!$o) continue;
                $sub = (float) $o->get_subtotal(); $disc = (float) $o->get_discount_total(); $ship = (float) $o->get_shipping_total();
                $tax = (float) $o->get_total_tax(); $tot = (float) $o->get_total(); $ref = (float) $o->get_total_refunded(); $taxref = (float) $o->get_total_tax_refunded();
                $fees = $tot - ($sub - $disc + $ship + $tax);
                $refx = $ref - $taxref;
                $rev = $sub - $disc + $ship + $fees - $refx;
                $cogs = 0;
                foreach ($o->get_items() as $iid => $it) {
                    $qty = (float) $it->get_quantity();
                    $net = $qty + (float) $o->get_qty_refunded_for_item($iid);
                    if ($qty <= 0 || $net <= 0) continue;
                    $cost = self::cost($it->get_variation_id() ?: $it->get_product_id());
                    if ($cost !== '' && $cost !== null) $cogs += (float) $cost * $net;
                    else $cogs += $pct * (float) $o->get_line_total($it, false) * ($net / $qty);
                }
                $ym = $o->get_date_created() ? $o->get_date_created()->date('Y-m') : gmdate('Y-m');
                $r['count']++; $r['sub'] += $sub; $r['disc'] += $disc; $r['ship'] += $ship; $r['fees'] += $fees; $r['refunds'] += $refx;
                $r['tax'] += $tax - $taxref; $r['receipts'] += $tot - $ref; $r['rev'] += $rev; $r['cogs'] += $cogs;
                if (!isset($r['m'][$ym])) $r['m'][$ym] = ['rev' => 0, 'cogs' => 0];
                $r['m'][$ym]['rev'] += $rev; $r['m'][$ym]['cogs'] += $cogs;
            }
            $page++;
        } while (count($ids) === 200);
        set_transient($key, $r, 10 * MINUTE_IN_SECONDS);
        return $r;
    }

    static function ent($from, $to) {
        global $wpdb;
        $t = $wpdb->prefix . 'wcf_entries';
        $rows = $wpdb->get_results($wpdb->prepare("SELECT type,label,SUM(amount) amt FROM $t WHERE entry_date BETWEEN %s AND %s GROUP BY type,label ORDER BY amt DESC", $from, $to), ARRAY_A);
        $o = ['t' => [], 'l' => []];
        foreach ($rows as $r) {
            $o['t'][$r['type']] = ($o['t'][$r['type']] ?? 0) + (float) $r['amt'];
            $o['l'][$r['type']][$r['label'] ?: 'Unlabelled'] = (float) $r['amt'];
        }
        return $o;
    }

    static function ent_monthly($from, $to) {
        global $wpdb;
        $t = $wpdb->prefix . 'wcf_entries';
        $rows = $wpdb->get_results($wpdb->prepare("SELECT DATE_FORMAT(entry_date,'%%Y-%%m') ym, type, SUM(amount) amt FROM $t WHERE entry_date BETWEEN %s AND %s AND type IN ('expense','other_income') GROUP BY ym,type", $from, $to), ARRAY_A);
        $o = [];
        foreach ($rows as $r) $o[$r['ym']][$r['type']] = (float) $r['amt'];
        return $o;
    }

    static function pl($from, $to) {
        $o = self::orders($from, $to); $e = self::ent($from, $to);
        $opex = self::g($e['t'], 'expense'); $other = self::g($e['t'], 'other_income');
        $gp = $o['rev'] - $o['cogs'];
        return ['o' => $o, 'e' => $e, 'opex' => $opex, 'other' => $other, 'gp' => $gp, 'net' => $gp - $opex + $other];
    }

    static function cash_parts($from, $to) {
        $o = self::orders($from, $to); $e = self::ent($from, $to); $t = $e['t'];
        $p = [
            'receipts' => $o['receipts'], 'other_income' => self::g($t, 'other_income'), 'inventory' => -self::g($t, 'inventory_purchase'),
            'expense' => -self::g($t, 'expense'), 'tax' => -self::g($t, 'tax_payment'),
            'asset_purchase' => -self::g($t, 'asset_purchase'), 'asset_sale' => self::g($t, 'asset_sale'),
            'loan_in' => self::g($t, 'loan_received'), 'loan_out' => -self::g($t, 'loan_repaid'),
            'owner_in' => self::g($t, 'owner_investment'), 'owner_out' => -self::g($t, 'owner_drawing'),
        ];
        $p['op'] = $p['receipts'] + $p['other_income'] + $p['inventory'] + $p['expense'] + $p['tax'];
        $p['inv'] = $p['asset_purchase'] + $p['asset_sale'];
        $p['fin'] = $p['loan_in'] + $p['loan_out'] + $p['owner_in'] + $p['owner_out'];
        $p['net'] = $p['op'] + $p['inv'] + $p['fin'];
        return $p;
    }

    static function cashflow($from, $to) {
        $s = self::opt('start_date');
        if ($from < $s) $from = $s;
        $open = (float) self::opt('opening_cash');
        if ($from > $s) $open += self::cash_parts($s, self::d($from, '-1 day'))['net'];
        $p = self::cash_parts($from, max($from, $to));
        $p['open'] = $open; $p['close'] = $open + $p['net'];
        return $p;
    }

    static function balance($asof) {
        $s = self::opt('start_date');
        if ($asof < $s) $asof = $s;
        $oc = (float) self::opt('opening_cash'); $oi = (float) self::opt('opening_inventory');
        $of = (float) self::opt('opening_fixed'); $ol = (float) self::opt('opening_loans');
        $o = self::orders($s, $asof); $e = self::ent($s, $asof); $t = $e['t'];
        $cash = $oc + self::cash_parts($s, $asof)['net'];
        $inv = $oi + self::g($t, 'inventory_purchase') - $o['cogs'];
        $fixed = $of + self::g($t, 'asset_purchase') - self::g($t, 'asset_sale');
        $taxp = $o['tax'] - self::g($t, 'tax_payment');
        $loans = $ol + self::g($t, 'loan_received') - self::g($t, 'loan_repaid');
        $retained = self::pl($s, $asof)['net'];
        $capital = ($oc + $oi + $of - $ol) + self::g($t, 'owner_investment') - self::g($t, 'owner_drawing');
        $ta = $cash + $inv + $fixed; $tl = $taxp + $loans; $te = $capital + $retained;
        return compact('asof', 'cash', 'inv', 'fixed', 'taxp', 'loans', 'retained', 'capital', 'ta', 'tl', 'te');
    }

    /* ---------- Handlers ---------- */
    static function guard($nonce) {
        if (!current_user_can('manage_woocommerce')) wp_die('No permission');
        check_admin_referer($nonce);
    }
    static function back($tab, $msg = '') {
        wp_safe_redirect(add_query_arg(['page' => 'wcf', 'tab' => $tab, 'msg' => $msg], admin_url('admin.php')));
        exit;
    }
    static function add_entry() {
        self::guard('wcf_add');
        global $wpdb;
        $type = sanitize_key($_POST['type'] ?? '');
        if (!isset(self::types()[$type])) self::back('entries');
        $date = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['entry_date'] ?? '') ? $_POST['entry_date'] : self::today();
        $wpdb->insert($wpdb->prefix . 'wcf_entries', [
            'entry_date' => $date, 'type' => $type, 'label' => sanitize_text_field(wp_unslash($_POST['label'] ?? '')),
            'amount' => abs((float) ($_POST['amount'] ?? 0)), 'notes' => sanitize_textarea_field(wp_unslash($_POST['notes'] ?? '')),
        ]);
        self::back('entries', 'added');
    }
    static function delete_entry() {
        $id = (int) ($_GET['id'] ?? 0);
        self::guard('wcf_del_' . $id);
        global $wpdb;
        $wpdb->delete($wpdb->prefix . 'wcf_entries', ['id' => $id]);
        self::back('entries', 'deleted');
    }
    static function save_settings() {
        self::guard('wcf_settings');
        $p = wp_unslash($_POST);
        $valid = array_keys(wc_get_order_statuses());
        $o = [
            'start_date' => preg_match('/^\d{4}-\d{2}-\d{2}$/', $p['start_date'] ?? '') ? $p['start_date'] : gmdate('Y-01-01'),
            'opening_cash' => (float) ($p['opening_cash'] ?? 0), 'opening_inventory' => (float) ($p['opening_inventory'] ?? 0),
            'opening_fixed' => (float) ($p['opening_fixed'] ?? 0), 'opening_loans' => (float) ($p['opening_loans'] ?? 0),
            'statuses' => array_values(array_intersect((array) ($p['statuses'] ?? []), $valid)),
            'cogs_pct' => max(0, min(100, (float) ($p['cogs_pct'] ?? 60))),
            'accent' => sanitize_hex_color($p['accent'] ?? '') ?: '#4f46e5',
            'custom_css' => wp_strip_all_tags($p['custom_css'] ?? ''),
        ];
        update_option('wcf_settings', $o, false);
        update_option('wcf_ver', microtime(true), false);
        self::back('settings', 'saved');
    }

    /* ---------- Views ---------- */
    static function url($tab, $args = []) {
        return esc_url(add_query_arg(array_merge(['page' => 'wcf', 'tab' => $tab], $args), admin_url('admin.php')));
    }

    static function range() {
        $s = self::opt('start_date');
        $from = isset($_GET['from']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['from']) ? $_GET['from'] : max($s, wp_date('Y-01-01'));
        $to = isset($_GET['to']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['to']) ? $_GET['to'] : self::today();
        if ($from > $to) [$from, $to] = [$to, $from];
        return [$from, $to];
    }

    static function filter_bar($tab, $from, $to, $asof_only = false) {
        $y = wp_date('Y'); $mo = (int) wp_date('n'); $qs = ($y . '-' . sprintf('%02d', floor(($mo - 1) / 3) * 3 + 1) . '-01');
        $pre = [
            'This month' => [wp_date('Y-m-01'), self::today()],
            'Last month' => [self::d(wp_date('Y-m-01'), '-1 month'), self::d(wp_date('Y-m-01'), '-1 day')],
            'This quarter' => [$qs, self::today()],
            'This year' => [$y . '-01-01', self::today()],
            'Last year' => [($y - 1) . '-01-01', ($y - 1) . '-12-31'],
            'All time' => [self::opt('start_date'), self::today()],
        ];
        echo '<form class="wcf-bar" method="get"><input type="hidden" name="page" value="wcf"><input type="hidden" name="tab" value="' . esc_attr($tab) . '">';
        if (!$asof_only) echo '<div><label>From</label><input type="date" name="from" value="' . esc_attr($from) . '"></div>';
        echo '<div><label>' . ($asof_only ? 'As of' : 'To') . '</label><input type="date" name="to" value="' . esc_attr($to) . '"></div>';
        echo '<button class="wcf-btn">Apply</button><a class="wcf-btn light" href="' . self::url($tab, ['from' => $from, 'to' => $to, 'refresh' => 1]) . '">Refresh</a>';
        echo '<div class="wcf-pre">';
        foreach ($pre as $l => $r) echo '<a href="' . self::url($tab, ['from' => $r[0], 'to' => $r[1]]) . '">' . esc_html($l) . '</a>';
        echo '</div></form>';
    }

    static function row($label, $val, $cls = '') {
        return '<tr class="' . $cls . '"><td>' . $label . '</td><td class="n">' . $val . '</td></tr>';
    }

    static function page() {
        if (!current_user_can('manage_woocommerce')) return;
        if (!class_exists('WooCommerce')) { echo '<div class="wrap"><div class="notice notice-error"><p>WooCommerce is required.</p></div></div>'; return; }
        $tab = sanitize_key($_GET['tab'] ?? 'dashboard');
        $tabs = ['dashboard' => 'Dashboard', 'pl' => 'Profit & Loss', 'bs' => 'Balance Sheet', 'cf' => 'Cash Flow', 'entries' => 'Entries', 'settings' => 'Settings'];
        if (!isset($tabs[$tab])) $tab = 'dashboard';
        [$from, $to] = self::range();

        echo '<div class="wrap wcf"><div class="wcf-hero"><div><h1>Finance Suite</h1><p>' . esc_html(get_bloginfo('name')) . ' &middot; WooCommerce accounting reports</p></div>';
        echo '<div><a class="wcf-btn ghost" href="' . self::url('entries') . '">+ Add Entry</a> <button class="wcf-btn ghost" onclick="window.print()">Print</button></div></div>';
        echo '<nav class="wcf-nav">';
        foreach ($tabs as $k => $l) echo '<a class="' . ($k === $tab ? 'on' : '') . '" href="' . self::url($k) . '">' . esc_html($l) . '</a>';
        echo '</nav>';

        $msgs = ['saved' => 'Settings saved.', 'added' => 'Entry added.', 'deleted' => 'Entry deleted.'];
        if (!empty($_GET['msg']) && isset($msgs[$_GET['msg']])) echo '<div class="wcf-note ok">' . esc_html($msgs[$_GET['msg']]) . '</div>';

        switch ($tab) {
            case 'pl': self::filter_bar($tab, $from, $to); self::v_pl($from, $to); break;
            case 'bs': self::filter_bar($tab, $from, $to, true); self::v_bs($to); break;
            case 'cf': self::filter_bar($tab, $from, $to); self::v_cf($from, $to); break;
            case 'entries': self::v_entries(); break;
            case 'settings': self::v_settings(); break;
            default: self::filter_bar($tab, $from, $to); self::v_dash($from, $to);
        }
        echo '</div>';
    }

    static function v_dash($from, $to) {
        $p = self::pl($from, $to); $cf = self::cashflow($from, $to); $o = $p['o'];
        $margin = $o['rev'] > 0 ? round($p['net'] / $o['rev'] * 100, 1) : 0;
        echo '<div class="wcf-grid">';
        $k = [
            ['Net Revenue', self::m($o['rev']), $o['count'] . ' orders'],
            ['Gross Profit', self::m($p['gp']), 'After COGS ' . wc_price($o['cogs'])],
            ['Net Profit', self::m($p['net']), 'Margin ' . $margin . '%'],
            ['Net Cash Flow', self::m($cf['net']), 'Closing cash ' . wc_price($cf['close'])],
        ];
        foreach ($k as $x) echo '<div class="wcf-card wcf-kpi"><small>' . $x[0] . '</small><b>' . $x[1] . '</b><i>' . $x[2] . '</i></div>';
        echo '</div>';

        // monthly chart
        $em = self::ent_monthly($from, $to); $rows = []; $max = 1;
        $cur = new DateTime(substr($from, 0, 7) . '-01', wp_timezone()); $end = new DateTime(substr($to, 0, 7) . '-01', wp_timezone()); $n = 0;
        while ($cur <= $end && $n++ < 36) {
            $ym = $cur->format('Y-m'); $r = $o['m'][$ym] ?? ['rev' => 0, 'cogs' => 0];
            $net = $r['rev'] - $r['cogs'] - self::g($em[$ym] ?? [], 'expense') + self::g($em[$ym] ?? [], 'other_income');
            $rows[] = [$cur->format('M y'), $r['rev'], $net]; $max = max($max, $r['rev'], abs($net));
            $cur->modify('+1 month');
        }
        echo '<div class="wcf-card"><div class="wcf-title"><h3>Monthly Revenue vs Net Profit</h3></div><div class="wcf-leg"><span><i></i>Revenue</span><span><i style="background:#10b981"></i>Net profit</span><span><i style="background:#f87171"></i>Net loss</span></div><div class="wcf-chart">';
        foreach ($rows as $r) {
            echo '<div class="wcf-col" title="' . esc_attr($r[0]) . '"><div class="wcf-bars"><span style="height:' . round(max(0, $r[1]) / $max * 100) . '%"></span><span class="' . ($r[2] >= 0 ? 'p' : 'm') . '" style="height:' . round(abs($r[2]) / $max * 100) . '%"></span></div><em>' . esc_html($r[0]) . '</em></div>';
        }
        echo '</div></div>';

        $b = self::balance($to);
        echo '<div class="wcf-two" style="margin-top:18px"><div class="wcf-card"><h3>Position at ' . esc_html($to) . '</h3><table class="wcf-tbl">'
            . self::row('Total assets', self::m($b['ta'])) . self::row('Total liabilities', self::m($b['tl'])) . self::row('Total equity', self::m($b['te']), 'tot') . '</table></div>';
        echo '<div class="wcf-card"><h3>Cash Summary</h3><table class="wcf-tbl">'
            . self::row('Opening cash', self::m($cf['open'])) . self::row('Operating', self::m($cf['op'])) . self::row('Investing', self::m($cf['inv'])) . self::row('Financing', self::m($cf['fin']))
            . self::row('Closing cash', self::m($cf['close']), 'tot') . '</table></div></div>';
    }

    static function v_pl($from, $to) {
        $p = self::pl($from, $to); $o = $p['o'];
        $m = $o['rev'] > 0 ? round($p['net'] / $o['rev'] * 100, 1) : 0;
        echo '<div class="wcf-card"><div class="wcf-title"><h2>Profit &amp; Loss Statement</h2><span class="wcf-badge">' . esc_html($from . ' → ' . $to) . '</span></div><table class="wcf-tbl">';
        echo '<tr class="sec"><td colspan="2">Revenue</td></tr>';
        echo self::row('Gross product sales', self::m($o['sub']), 'sub') . self::row('Less: discounts', self::m(-$o['disc']), 'sub') . self::row('Shipping &amp; fees income', self::m($o['ship'] + $o['fees']), 'sub') . self::row('Less: refunds', self::m(-$o['refunds']), 'sub');
        echo self::row('Net revenue', self::m($o['rev']), 'tot');
        echo self::row('Cost of goods sold', self::m(-$o['cogs']));
        echo self::row('Gross profit <span class="wcf-badge">' . ($o['rev'] > 0 ? round($p['gp'] / $o['rev'] * 100, 1) : 0) . '%</span>', self::m($p['gp']), 'tot');
        echo '<tr class="sec"><td colspan="2">Operating Expenses</td></tr>';
        foreach (($p['e']['l']['expense'] ?? []) as $l => $a) echo self::row(esc_html($l), self::m(-$a), 'sub');
        if (empty($p['e']['l']['expense'])) echo self::row('<em>No expenses recorded</em>', '', 'sub');
        echo self::row('Total operating expenses', self::m(-$p['opex']), 'tot');
        echo '<tr class="sec"><td colspan="2">Other Income</td></tr>';
        foreach (($p['e']['l']['other_income'] ?? []) as $l => $a) echo self::row(esc_html($l), self::m($a), 'sub');
        echo self::row('Total other income', self::m($p['other']), 'tot');
        echo self::row('Net profit <span class="wcf-badge">' . $m . '%</span>', self::m($p['net']), 'grand');
        echo '</table></div>';
    }

    static function v_bs($asof) {
        $b = self::balance($asof);
        echo '<div class="wcf-title"><h2>Balance Sheet</h2><span class="wcf-badge">As of ' . esc_html($b['asof']) . '</span></div><div class="wcf-two">';
        echo '<div class="wcf-card"><h3>Assets</h3><table class="wcf-tbl">'
            . self::row('Cash &amp; bank', self::m($b['cash']), 'sub') . self::row('Inventory', self::m($b['inv']), 'sub') . self::row('Fixed assets', self::m($b['fixed']), 'sub')
            . self::row('Total assets', self::m($b['ta']), 'grand') . '</table></div>';
        echo '<div class="wcf-card"><h3>Liabilities &amp; Equity</h3><table class="wcf-tbl">'
            . '<tr class="sec"><td colspan="2">Liabilities</td></tr>'
            . self::row('Tax payable', self::m($b['taxp']), 'sub') . self::row('Loans', self::m($b['loans']), 'sub') . self::row('Total liabilities', self::m($b['tl']), 'tot')
            . '<tr class="sec"><td colspan="2">Equity</td></tr>'
            . self::row('Owner capital (net of drawings)', self::m($b['capital']), 'sub') . self::row('Retained earnings', self::m($b['retained']), 'sub') . self::row('Total equity', self::m($b['te']), 'tot')
            . self::row('Total liabilities &amp; equity', self::m($b['tl'] + $b['te']), 'grand') . '</table></div></div>';
        $diff = round($b['ta'] - $b['tl'] - $b['te'], 2);
        echo $diff == 0 ? '<div class="wcf-note ok" style="margin-top:16px">Balanced ✓ (Assets = Liabilities + Equity)</div>' : '<div class="wcf-note chk">Difference: ' . wc_price($diff) . '</div>';
    }

    static function v_cf($from, $to) {
        $c = self::cashflow($from, $to);
        echo '<div class="wcf-card"><div class="wcf-title"><h2>Cash Flow Statement</h2><span class="wcf-badge">' . esc_html(max($from, self::opt('start_date')) . ' → ' . $to) . '</span></div><table class="wcf-tbl">';
        echo '<tr class="sec"><td colspan="2">Operating activities</td></tr>';
        echo self::row('Receipts from customers (net of refunds, incl. tax)', self::m($c['receipts']), 'sub') . self::row('Other income', self::m($c['other_income']), 'sub') . self::row('Inventory purchases', self::m($c['inventory']), 'sub')
            . self::row('Operating expenses paid', self::m($c['expense']), 'sub') . self::row('Taxes paid', self::m($c['tax']), 'sub') . self::row('Net cash from operating', self::m($c['op']), 'tot');
        echo '<tr class="sec"><td colspan="2">Investing activities</td></tr>';
        echo self::row('Purchase of assets', self::m($c['asset_purchase']), 'sub') . self::row('Sale of assets', self::m($c['asset_sale']), 'sub') . self::row('Net cash from investing', self::m($c['inv']), 'tot');
        echo '<tr class="sec"><td colspan="2">Financing activities</td></tr>';
        echo self::row('Loans received', self::m($c['loan_in']), 'sub') . self::row('Loans repaid', self::m($c['loan_out']), 'sub') . self::row('Owner investment', self::m($c['owner_in']), 'sub')
            . self::row('Owner drawings', self::m($c['owner_out']), 'sub') . self::row('Net cash from financing', self::m($c['fin']), 'tot');
        echo self::row('Net change in cash', self::m($c['net']), 'tot') . self::row('Opening cash', self::m($c['open'])) . self::row('Closing cash', self::m($c['close']), 'grand');
        echo '</table></div>';
    }

    static function v_entries() {
        global $wpdb;
        $t = $wpdb->prefix . 'wcf_entries';
        $rows = $wpdb->get_results("SELECT * FROM $t ORDER BY entry_date DESC, id DESC LIMIT 300");
        echo '<div class="wcf-two s"><div class="wcf-card"><h3>Add Entry</h3><form class="wcf-f" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('wcf_add');
        echo '<input type="hidden" name="action" value="wcf_add_entry">';
        echo '<label>Type</label><select name="type">';
        $grp = '';
        foreach (self::types() as $k => $v) {
            if ($grp !== $v[2]) { if ($grp) echo '</optgroup>'; echo '<optgroup label="' . esc_attr($v[2]) . '">'; $grp = $v[2]; }
            echo '<option value="' . esc_attr($k) . '">' . esc_html($v[0]) . '</option>';
        }
        echo '</optgroup></select>';
        echo '<div class="row"><div><label>Date</label><input type="date" name="entry_date" value="' . esc_attr(self::today()) . '" required></div><div><label>Amount</label><input type="number" step="0.01" min="0" name="amount" required></div></div>';
        echo '<label>Label / Category</label><input type="text" name="label" placeholder="e.g. Rent, Facebook Ads, Salary" required>';
        echo '<small>Expenses are grouped by label in the P&amp;L.</small>';
        echo '<label>Notes</label><textarea name="notes" rows="2"></textarea><p><button class="wcf-btn">Save entry</button></p></form></div>';

        echo '<div class="wcf-card"><h3>Recent Entries</h3><div style="overflow:auto"><table class="wcf-tbl"><tr><th>Date</th><th>Type</th><th>Label</th><th class="n">Amount</th><th></th></tr>';
        $ty = self::types();
        foreach ($rows as $r) {
            $dir = $ty[$r->type][1] ?? 'out';
            $del = wp_nonce_url(admin_url('admin-post.php?action=wcf_delete_entry&id=' . $r->id), 'wcf_del_' . $r->id);
            echo '<tr><td>' . esc_html($r->entry_date) . '</td><td><span class="wcf-badge ' . $dir . '">' . esc_html($ty[$r->type][0] ?? $r->type) . '</span></td><td>' . esc_html($r->label) . '</td><td class="n">' . wc_price($r->amount) . '</td><td class="n"><a class="wcf-x" href="' . esc_url($del) . '" onclick="return confirm(\'Delete?\')">&times;</a></td></tr>';
        }
        if (!$rows) echo '<tr><td colspan="5" style="text-align:center;color:#64748b;padding:30px">No entries yet.</td></tr>';
        echo '</table></div></div></div>';
    }

    static function v_settings() {
        $o = self::opt();
        echo '<form class="wcf-f" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('wcf_settings');
        echo '<input type="hidden" name="action" value="wcf_save_settings"><div class="wcf-two">';
        echo '<div class="wcf-card"><h3>Books &amp; Opening Balances</h3>';
        echo '<label>Books start date</label><input type="date" name="start_date" value="' . esc_attr($o['start_date']) . '"><small>Orders and entries before this date are ignored.</small>';
        echo '<div class="row"><div><label>Opening cash</label><input type="number" step="0.01" name="opening_cash" value="' . esc_attr($o['opening_cash']) . '"></div><div><label>Opening inventory</label><input type="number" step="0.01" name="opening_inventory" value="' . esc_attr($o['opening_inventory']) . '"></div></div>';
        echo '<div class="row"><div><label>Opening fixed assets</label><input type="number" step="0.01" name="opening_fixed" value="' . esc_attr($o['opening_fixed']) . '"></div><div><label>Opening loans</label><input type="number" step="0.01" name="opening_loans" value="' . esc_attr($o['opening_loans']) . '"></div></div>';
        echo '<label>Order statuses counted as sales</label>';
        foreach (wc_get_order_statuses() as $k => $l) echo '<label style="font-weight:400;margin:4px 0"><input type="checkbox" name="statuses[]" value="' . esc_attr($k) . '" ' . checked(in_array($k, $o['statuses'], true), true, false) . '> ' . esc_html($l) . '</label>';
        echo '<label>Default COGS % (when product has no cost price)</label><input type="number" step="0.1" min="0" max="100" name="cogs_pct" value="' . esc_attr($o['cogs_pct']) . '"><small>Set exact cost per product in Product → General → Cost price.</small></div>';
        echo '<div class="wcf-card"><h3>Appearance</h3><label>Accent color</label><input type="color" name="accent" value="' . esc_attr($o['accent']) . '" style="height:42px;padding:3px">';
        echo '<label>Custom CSS</label><textarea class="code" name="custom_css" spellcheck="false" placeholder=".wcf-hero{background:#000}&#10;.wcf-card{border-radius:4px}">' . esc_textarea($o['custom_css']) . '</textarea><small>Applied only on Finance Suite pages. Wrapper class: <code>.wcf</code></small></div>';
        echo '</div><p><button class="wcf-btn">Save settings</button></p></form>';
    }
}
WCF::init();
