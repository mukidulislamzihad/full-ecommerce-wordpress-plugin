<?php
/**
 * Plugin Name: Custom Blog Showcase
 * Description: Admin panel theke blog post select kore shortcode diye (Elementor "Shortcode" widget soho) card-style showcase dekhan. Full customizable (color, text, column, excerpt) + fully responsive (min-width 320px).
 * Version: 1.0.0
 * Author: Custom
 * Text Domain: cbs
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CBS_OPT_POSTS', 'cbs_selected_posts' );
define( 'CBS_OPT_SETTINGS', 'cbs_settings' );
define( 'CBS_VERSION', '1.0.0' );

/* ----------------------------------------------------------
 * Default settings
 * ---------------------------------------------------------- */
function cbs_default_settings() {
	return array(
		'columns'          => 3,
		'fallback_count'   => 3, // kono post select na korle shobcheye notun koyta dekhabe
		'badge_text'       => 'BLOGS',
		'badge_bg'         => '#1e7145',
		'badge_color'      => '#ffffff',
		'button_text'      => 'READ MORE »',
		'button_color'     => '#1e7145',
		'title_color'      => '#1a1a1a',
		'excerpt_color'    => '#555555',
		'excerpt_words'    => 20,
		'show_author'      => 1,
		'show_comments'    => 1,
		'date_format'      => 'F j, Y',
		'card_bg'          => '#ffffff',
		'card_radius'      => 10,
		'heading_text'     => 'নতুন ব্লগ পড়ুন',
		'show_heading'     => 1,
		'custom_css'       => '',
	);
}
function cbs_get_settings() {
	$saved = get_option( CBS_OPT_SETTINGS, array() );
	return wp_parse_args( $saved, cbs_default_settings() );
}

/* ----------------------------------------------------------
 * Admin menu
 * ---------------------------------------------------------- */
add_action( 'admin_menu', function () {
	add_menu_page(
		'Blog Showcase',
		'Blog Showcase',
		'manage_options',
		'cbs-blog-showcase',
		'cbs_render_admin_page',
		'dashicons-grid-view',
		26
	);
} );

/* ----------------------------------------------------------
 * Enqueue admin assets (only on our page)
 * ---------------------------------------------------------- */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( strpos( $hook, 'cbs-blog-showcase' ) === false ) return;
	wp_enqueue_script( 'jquery-ui-sortable' );
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
} );

/* ----------------------------------------------------------
 * Save handler
 * ---------------------------------------------------------- */
add_action( 'admin_init', function () {
	if ( ! isset( $_POST['cbs_save_nonce'] ) || ! wp_verify_nonce( $_POST['cbs_save_nonce'], 'cbs_save_action' ) ) return;
	if ( ! current_user_can( 'manage_options' ) ) return;

	// Selected posts order (comma separated ids from hidden field, maintained by JS sortable)
	if ( isset( $_POST['cbs_order'] ) ) {
		$ids = array_filter( array_map( 'intval', explode( ',', sanitize_text_field( $_POST['cbs_order'] ) ) ) );
		update_option( CBS_OPT_POSTS, array_values( $ids ) );
	}

	$settings = cbs_default_settings();
	$settings['columns']        = max( 1, min( 6, intval( $_POST['columns'] ?? 3 ) ) );
	$settings['fallback_count'] = max( 0, intval( $_POST['fallback_count'] ?? 3 ) );
	$settings['badge_text']     = sanitize_text_field( $_POST['badge_text'] ?? 'BLOGS' );
	$settings['badge_bg']       = sanitize_hex_color( $_POST['badge_bg'] ?? '' ) ?: '#1e7145';
	$settings['badge_color']    = sanitize_hex_color( $_POST['badge_color'] ?? '' ) ?: '#ffffff';
	$settings['button_text']    = sanitize_text_field( $_POST['button_text'] ?? 'READ MORE »' );
	$settings['button_color']   = sanitize_hex_color( $_POST['button_color'] ?? '' ) ?: '#1e7145';
	$settings['title_color']    = sanitize_hex_color( $_POST['title_color'] ?? '' ) ?: '#1a1a1a';
	$settings['excerpt_color']  = sanitize_hex_color( $_POST['excerpt_color'] ?? '' ) ?: '#555555';
	$settings['excerpt_words']  = max( 5, intval( $_POST['excerpt_words'] ?? 20 ) );
	$settings['show_author']    = isset( $_POST['show_author'] ) ? 1 : 0;
	$settings['show_comments']  = isset( $_POST['show_comments'] ) ? 1 : 0;
	$settings['date_format']    = sanitize_text_field( $_POST['date_format'] ?? 'F j, Y' );
	$settings['card_bg']        = sanitize_hex_color( $_POST['card_bg'] ?? '' ) ?: '#ffffff';
	$settings['card_radius']    = max( 0, intval( $_POST['card_radius'] ?? 10 ) );
	$settings['heading_text']   = sanitize_text_field( $_POST['heading_text'] ?? '' );
	$settings['show_heading']   = isset( $_POST['show_heading'] ) ? 1 : 0;
	$settings['custom_css']     = isset( $_POST['custom_css'] ) ? wp_strip_all_tags( wp_unslash( $_POST['custom_css'] ) ) : '';

	update_option( CBS_OPT_SETTINGS, $settings );

	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-success is-dismissible"><p>সেভ হয়েছে।</p></div>';
	} );
} );

/* ----------------------------------------------------------
 * Admin page render
 * ---------------------------------------------------------- */
function cbs_render_admin_page() {
	$settings      = cbs_get_settings();
	$selected_ids  = get_option( CBS_OPT_POSTS, array() );

	$all_posts = get_posts( array(
		'post_type'      => 'post',
		'post_status'    => 'publish',
		'posts_per_page' => 300,
		'orderby'        => 'date',
		'order'          => 'DESC',
	) );

	$selected_posts = array();
	foreach ( $selected_ids as $id ) {
		$p = get_post( $id );
		if ( $p ) $selected_posts[] = $p;
	}
	?>
	<div class="wrap">
		<h1>Blog Showcase</h1>
		<p>এখান থেকে পোস্ট সিলেক্ট করুন ও সাজান, তারপর যেকোনো পেজে/Elementor Shortcode widget-এ বসিয়ে দিন: <code>[cbs_blog_showcase]</code></p>

		<form method="post">
			<?php wp_nonce_field( 'cbs_save_action', 'cbs_save_nonce' ); ?>
			<input type="hidden" name="cbs_order" id="cbs_order_field" value="<?php echo esc_attr( implode( ',', $selected_ids ) ); ?>">

			<h2 class="nav-tab-wrapper">
				<a href="#cbs-tab-select" class="nav-tab nav-tab-active" data-tab="select">পোস্ট সিলেক্ট</a>
				<a href="#cbs-tab-design" class="nav-tab" data-tab="design">ডিজাইন / টেক্সট</a>
			</h2>

			<div id="cbs-tab-select" class="cbs-tab-panel" style="display:block;">
				<div style="display:flex; gap:24px; margin-top:16px; flex-wrap:wrap;">
					<div style="flex:1; min-width:320px;">
						<h3>সব পোস্ট</h3>
						<input type="text" id="cbs-search" placeholder="পোস্ট খুঁজুন..." style="width:100%; margin-bottom:8px;">
						<div style="max-height:480px; overflow:auto; border:1px solid #ccd0d4; padding:8px; background:#fff;">
							<?php foreach ( $all_posts as $p ) :
								$checked = in_array( $p->ID, $selected_ids ) ? 'checked' : '';
								?>
								<label class="cbs-post-row" data-title="<?php echo esc_attr( strtolower( $p->post_title ) ); ?>" style="display:flex; align-items:center; gap:8px; padding:6px 0; border-bottom:1px solid #f0f0f0;">
									<input type="checkbox" class="cbs-post-check" value="<?php echo esc_attr( $p->ID ); ?>" data-title="<?php echo esc_attr( $p->post_title ); ?>" <?php echo $checked; ?>>
									<?php echo get_the_post_thumbnail( $p->ID, array( 32, 32 ) ) ?: '<span style="width:32px;height:32px;background:#eee;display:inline-block;"></span>'; ?>
									<span><?php echo esc_html( $p->post_title ); ?></span>
								</label>
							<?php endforeach; ?>
						</div>
					</div>
					<div style="flex:1; min-width:320px;">
						<h3>সিলেক্টেড (ড্র্যাগ করে অর্ডার ঠিক করুন)</h3>
						<ul id="cbs-selected-list" style="border:1px solid #ccd0d4; min-height:200px; padding:8px; background:#fff; list-style:none; margin:0;">
							<?php foreach ( $selected_posts as $p ) : ?>
								<li data-id="<?php echo esc_attr( $p->ID ); ?>" style="padding:8px; margin-bottom:6px; background:#f6f7f7; border:1px solid #ddd; cursor:move; display:flex; justify-content:space-between; align-items:center;">
									<span><?php echo esc_html( $p->post_title ); ?></span>
									<a href="#" class="cbs-remove" style="color:#b32d2e;">✕</a>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
				</div>
			</div>

			<div id="cbs-tab-design" class="cbs-tab-panel" style="display:none; margin-top:16px;">
				<table class="form-table">
					<tr><th>সেকশন হেডিং দেখাবে?</th><td><label><input type="checkbox" name="show_heading" <?php checked( $settings['show_heading'], 1 ); ?>> হ্যাঁ</label></td></tr>
					<tr><th>হেডিং টেক্সট</th><td><input type="text" name="heading_text" value="<?php echo esc_attr( $settings['heading_text'] ); ?>" class="regular-text"></td></tr>
					<tr><th>কলাম সংখ্যা (ডেস্কটপ)</th><td><input type="number" name="columns" min="1" max="6" value="<?php echo esc_attr( $settings['columns'] ); ?>"></td></tr>
					<tr><th>কোনো পোস্ট সিলেক্ট না থাকলে কয়টা latest দেখাবে</th><td><input type="number" name="fallback_count" min="0" value="<?php echo esc_attr( $settings['fallback_count'] ); ?>"></td></tr>
					<tr><th>Badge টেক্সট</th><td><input type="text" name="badge_text" value="<?php echo esc_attr( $settings['badge_text'] ); ?>" class="regular-text"></td></tr>
					<tr><th>Badge ব্যাকগ্রাউন্ড রং</th><td><input type="text" class="cbs-color" name="badge_bg" value="<?php echo esc_attr( $settings['badge_bg'] ); ?>"></td></tr>
					<tr><th>Badge টেক্সট রং</th><td><input type="text" class="cbs-color" name="badge_color" value="<?php echo esc_attr( $settings['badge_color'] ); ?>"></td></tr>
					<tr><th>বাটন টেক্সট</th><td><input type="text" name="button_text" value="<?php echo esc_attr( $settings['button_text'] ); ?>" class="regular-text"></td></tr>
					<tr><th>বাটন/লিংক রং</th><td><input type="text" class="cbs-color" name="button_color" value="<?php echo esc_attr( $settings['button_color'] ); ?>"></td></tr>
					<tr><th>টাইটেল রং</th><td><input type="text" class="cbs-color" name="title_color" value="<?php echo esc_attr( $settings['title_color'] ); ?>"></td></tr>
					<tr><th>এক্সসার্পট (বর্ণনা) রং</th><td><input type="text" class="cbs-color" name="excerpt_color" value="<?php echo esc_attr( $settings['excerpt_color'] ); ?>"></td></tr>
					<tr><th>এক্সসার্পট কতো শব্দ</th><td><input type="number" name="excerpt_words" min="5" value="<?php echo esc_attr( $settings['excerpt_words'] ); ?>"></td></tr>
					<tr><th>লেখকের অ্যাভাটার দেখাবে?</th><td><label><input type="checkbox" name="show_author" <?php checked( $settings['show_author'], 1 ); ?>> হ্যাঁ</label></td></tr>
					<tr><th>কমেন্ট সংখ্যা দেখাবে?</th><td><label><input type="checkbox" name="show_comments" <?php checked( $settings['show_comments'], 1 ); ?>> হ্যাঁ</label></td></tr>
					<tr><th>তারিখ ফরম্যাট (PHP date format)</th><td><input type="text" name="date_format" value="<?php echo esc_attr( $settings['date_format'] ); ?>" class="regular-text"><p class="description">উদাহরণ: F j, Y → August 28, 2026</p></td></tr>
					<tr><th>কার্ড ব্যাকগ্রাউন্ড রং</th><td><input type="text" class="cbs-color" name="card_bg" value="<?php echo esc_attr( $settings['card_bg'] ); ?>"></td></tr>
					<tr><th>কার্ড Corner Radius (px)</th><td><input type="number" name="card_radius" min="0" value="<?php echo esc_attr( $settings['card_radius'] ); ?>"></td></tr>
					<tr>
						<th>কাস্টম CSS</th>
						<td>
							<textarea name="custom_css" rows="10" class="large-text code" placeholder=".cbs-card{...} .cbs-title{...}"><?php echo esc_textarea( $settings['custom_css'] ); ?></textarea>
							<p class="description">এখানে যেকোনো CSS লিখলে সেটা showcase-এর সাথে লোড হবে (frontend-এ <code>.cbs-wrap</code> এর ভেতরের ক্লাসগুলো: <code>.cbs-card, .cbs-title, .cbs-excerpt, .cbs-badge, .cbs-readmore, .cbs-footer, .cbs-grid</code> ইত্যাদি)।</p>
						</td>
					</tr>
				</table>
			</div>

			<?php submit_button( 'সেভ করুন' ); ?>
		</form>
	</div>

	<script>
	jQuery(function($){
		$('.nav-tab-wrapper .nav-tab').on('click', function(e){
			e.preventDefault();
			$('.nav-tab-wrapper .nav-tab').removeClass('nav-tab-active');
			$(this).addClass('nav-tab-active');
			$('.cbs-tab-panel').hide();
			$('#cbs-tab-' + $(this).data('tab')).show();
		});

		$('.cbs-color').wpColorPicker();

		function updateOrderField(){
			var ids = [];
			$('#cbs-selected-list li').each(function(){ ids.push($(this).data('id')); });
			$('#cbs_order_field').val(ids.join(','));
		}

		$('#cbs-selected-list').sortable({ update: updateOrderField });

		$('.cbs-post-check').on('change', function(){
			var id = $(this).val(), title = $(this).data('title');
			if ( this.checked ) {
				if ( $('#cbs-selected-list li[data-id="'+id+'"]').length === 0 ) {
					$('#cbs-selected-list').append('<li data-id="'+id+'" style="padding:8px;margin-bottom:6px;background:#f6f7f7;border:1px solid #ddd;cursor:move;display:flex;justify-content:space-between;align-items:center;"><span>'+title+'</span><a href="#" class="cbs-remove" style="color:#b32d2e;">✕</a></li>');
				}
			} else {
				$('#cbs-selected-list li[data-id="'+id+'"]').remove();
			}
			updateOrderField();
		});

		$('#cbs-selected-list').on('click', '.cbs-remove', function(e){
			e.preventDefault();
			var id = $(this).closest('li').data('id');
			$(this).closest('li').remove();
			$('.cbs-post-check[value="'+id+'"]').prop('checked', false);
			updateOrderField();
		});

		$('#cbs-search').on('keyup', function(){
			var q = $(this).val().toLowerCase();
			$('.cbs-post-row').each(function(){
				$(this).toggle( $(this).data('title').toString().indexOf(q) > -1 );
			});
		});
	});
	</script>
	<?php
}

/* ----------------------------------------------------------
 * Front-end shortcode
 * ---------------------------------------------------------- */
add_shortcode( 'cbs_blog_showcase', 'cbs_shortcode_render' );

function cbs_shortcode_render( $atts ) {
	$atts = shortcode_atts( array( 'columns' => '' ), $atts, 'cbs_blog_showcase' );
	$settings = cbs_get_settings();
	$columns  = $atts['columns'] ? intval( $atts['columns'] ) : intval( $settings['columns'] );

	$ids = get_option( CBS_OPT_POSTS, array() );

	if ( empty( $ids ) ) {
		if ( intval( $settings['fallback_count'] ) <= 0 ) return '';
		$latest = get_posts( array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => intval( $settings['fallback_count'] ),
			'orderby'        => 'date',
			'order'          => 'DESC',
			'fields'         => 'ids',
		) );
		$ids = $latest;
	}

	if ( empty( $ids ) ) return '';

	cbs_enqueue_front_assets();

	ob_start();
	?>
	<div class="cbs-wrap" style="
		--cbs-badge-bg: <?php echo esc_attr( $settings['badge_bg'] ); ?>;
		--cbs-badge-color: <?php echo esc_attr( $settings['badge_color'] ); ?>;
		--cbs-button-color: <?php echo esc_attr( $settings['button_color'] ); ?>;
		--cbs-title-color: <?php echo esc_attr( $settings['title_color'] ); ?>;
		--cbs-excerpt-color: <?php echo esc_attr( $settings['excerpt_color'] ); ?>;
		--cbs-card-bg: <?php echo esc_attr( $settings['card_bg'] ); ?>;
		--cbs-radius: <?php echo esc_attr( $settings['card_radius'] ); ?>px;
		--cbs-columns: <?php echo esc_attr( $columns ); ?>;
	">
		<?php if ( $settings['show_heading'] && $settings['heading_text'] ) : ?>
			<h2 class="cbs-heading"><?php echo esc_html( $settings['heading_text'] ); ?></h2>
		<?php endif; ?>

		<div class="cbs-grid">
			<?php foreach ( $ids as $id ) :
				$post = get_post( $id );
				if ( ! $post || $post->post_status !== 'publish' ) continue;
				setup_postdata( $post );
				$thumb = get_the_post_thumbnail_url( $post, 'large' );
				$cats  = get_the_category( $post->ID );
				$badge = $settings['badge_text'];
				$excerpt = has_excerpt( $post->ID ) ? wp_trim_words( get_the_excerpt( $post ), $settings['excerpt_words'] ) : wp_trim_words( strip_shortcodes( wp_strip_all_tags( $post->post_content ) ), $settings['excerpt_words'] );
				?>
				<a class="cbs-card" href="<?php echo esc_url( get_permalink( $post ) ); ?>">
					<div class="cbs-thumb" style="<?php echo $thumb ? 'background-image:url(' . esc_url( $thumb ) . ');' : 'background:#eee;'; ?>">
						<span class="cbs-badge"><?php echo esc_html( $badge ); ?></span>
						<?php if ( $settings['show_author'] ) : ?>
							<span class="cbs-avatar"><?php echo get_avatar( $post->post_author, 48 ); ?></span>
						<?php endif; ?>
					</div>
					<div class="cbs-body">
						<h3 class="cbs-title"><?php echo esc_html( get_the_title( $post ) ); ?></h3>
						<p class="cbs-excerpt"><?php echo esc_html( $excerpt ); ?></p>
						<span class="cbs-readmore"><?php echo esc_html( $settings['button_text'] ); ?></span>
					</div>
					<div class="cbs-footer">
						<span><?php echo esc_html( get_the_date( $settings['date_format'], $post ) ); ?></span>
						<?php if ( $settings['show_comments'] ) : ?>
							<span>•&nbsp;<?php echo intval( get_comments_number( $post ) ); ?> Comment<?php echo intval( get_comments_number( $post ) ) === 1 ? '' : 's'; ?></span>
						<?php endif; ?>
					</div>
				</a>
			<?php endforeach; wp_reset_postdata(); ?>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

/* ----------------------------------------------------------
 * Front-end CSS (inline, min viewport 320px safe)
 * ---------------------------------------------------------- */
function cbs_enqueue_front_assets() {
	static $done = false;
	if ( $done ) return;
	$done = true;

	wp_register_style( 'cbs-front', false, array(), CBS_VERSION );
	wp_enqueue_style( 'cbs-front' );

	$css = "
	.cbs-wrap{max-width:1200px;margin:0 auto;padding:0 16px;box-sizing:border-box;}
	.cbs-wrap *{box-sizing:border-box;}
	.cbs-heading{text-align:center;font-weight:800;margin-bottom:28px;font-size:clamp(22px,4vw,34px);}
	.cbs-grid{display:grid;grid-template-columns:repeat(var(--cbs-columns,3),1fr);gap:24px;}
	@media (max-width:900px){.cbs-grid{grid-template-columns:repeat(2,1fr);}}
	@media (max-width:560px){.cbs-grid{grid-template-columns:1fr;}}
	.cbs-card{display:flex;flex-direction:column;background:var(--cbs-card-bg,#fff);border:1px solid #e5e5e5;border-radius:var(--cbs-radius,10px);overflow:hidden;text-decoration:none;color:inherit;transition:box-shadow .2s ease,transform .2s ease;min-width:0;}
	.cbs-card:hover{box-shadow:0 6px 18px rgba(0,0,0,.12);transform:translateY(-2px);}
	.cbs-thumb{position:relative;width:100%;padding-top:58%;background-size:cover;background-position:center;}
	.cbs-badge{position:absolute;top:12px;right:12px;background:var(--cbs-badge-bg,#1e7145);color:var(--cbs-badge-color,#fff);font-size:11px;font-weight:700;letter-spacing:.5px;padding:5px 12px;border-radius:999px;}
	.cbs-avatar{position:absolute;bottom:-20px;left:16px;width:40px;height:40px;border-radius:50%;overflow:hidden;border:3px solid #fff;background:#fff;box-shadow:0 2px 6px rgba(0,0,0,.15);}
	.cbs-avatar img{width:100%;height:100%;object-fit:cover;border-radius:50%;}
	.cbs-body{padding:28px 16px 12px;flex:1;}
	.cbs-title{font-size:18px;font-weight:700;color:var(--cbs-title-color,#1a1a1a);margin:0 0 8px;line-height:1.35;}
	.cbs-excerpt{font-size:14px;color:var(--cbs-excerpt-color,#555);line-height:1.6;margin:0 0 12px;}
	.cbs-readmore{display:inline-block;color:var(--cbs-button-color,#1e7145);font-weight:700;font-size:14px;}
	.cbs-footer{display:flex;gap:6px;flex-wrap:wrap;align-items:center;padding:12px 16px;border-top:1px solid #eee;font-size:12.5px;color:#777;}
	@media (max-width:320px){.cbs-body{padding:24px 10px 10px;}.cbs-footer{padding:10px;}.cbs-title{font-size:16px;}}
	";
	wp_add_inline_style( 'cbs-front', $css );

	$settings = cbs_get_settings();
	if ( ! empty( $settings['custom_css'] ) ) {
		wp_add_inline_style( 'cbs-front', $settings['custom_css'] );
	}
}
