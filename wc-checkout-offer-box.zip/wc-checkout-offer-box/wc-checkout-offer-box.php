<?php
/**
 * Plugin Name: WC Checkout Offer Box
 * Description: Checkout page-এ one-click offer box (order bump) — fully customizable.
 * Version: 1.1.0
 * Requires Plugins: woocommerce
 */
if (!defined('ABSPATH')) exit;

class WCO_Box {
    const OPT = 'wco_settings';

    static function fields() {
        return [
            'General' => [
                'enabled'    => ['চালু করুন', 'checkbox', 1],
                'product_id' => ['Product ID (simple product)', 'number', ''],
                'discount_type' => ['Discount type', 'select', 'fixed_off', ['fixed_off'=>'Fixed amount off','percent_off'=>'Percent off','fixed_price'=>'Fixed offer price','none'=>'No discount']],
                'discount_value' => ['Discount value', 'number', 50],
                'position'   => ['Box position', 'select', 'before_submit', ['before_submit'=>'Place Order বাটনের উপরে','before_payment'=>'Payment method-এর উপরে','after_payment'=>'Payment method-এর নিচে']],
            ],
            'Text' => [
                'header_text' => ['Header text', 'text', 'একই ডেলিভারি চার্জে স্পেশাল অফার!'],
                'title'       => ['Title (খালি রাখলে product name)', 'text', ''],
                'button_text' => ['Button text', 'text', 'অফার নিন'],
                'added_text'  => ['Added হলে button text', 'text', '✓ যোগ হয়েছে'],
                'badge_text'  => ['Badge text ({save} = সাশ্রয়)', 'text', '৳{save} ছাড়'],
                'currency'    => ['Currency symbol', 'text', '৳'],
                'show_badge'  => ['Badge দেখান', 'checkbox', 1],
                'show_image'  => ['Image দেখান', 'checkbox', 1],
            ],
            'Style' => [
                'header_bg'    => ['Header background', 'color', '#16a05d'],
                'header_color' => ['Header text color', 'color', '#ffffff'],
                'box_bg'       => ['Box background', 'color', '#f9fffb'],
                'border_color' => ['Border color', 'color', '#16a05d'],
                'border_style' => ['Border style', 'select', 'dashed', ['dashed'=>'Dashed','solid'=>'Solid','dotted'=>'Dotted','none'=>'None']],
                'radius'       => ['Border radius (px)', 'number', 14],
                'title_color'  => ['Title color', 'color', '#222222'],
                'title_size'   => ['Title font size (px)', 'number', 16],
                'price_color'  => ['Offer price color', 'color', '#16a05d'],
                'price_size'   => ['Offer price size (px)', 'number', 26],
                'old_price_color' => ['Old price color', 'color', '#888888'],
                'btn_bg'       => ['Button background', 'color', '#16a05d'],
                'btn_color'    => ['Button text color', 'color', '#ffffff'],
                'btn_radius'   => ['Button radius (px)', 'number', 8],
                'badge_bg'     => ['Badge background', 'color', '#ff2b3a'],
                'badge_color'  => ['Badge text color', 'color', '#ffffff'],
                'img_size'     => ['Image size (px)', 'number', 85],
                'margin'       => ['Box margin top/bottom (px)', 'number', 15],
            ],
        ];
    }

    static function get($k) {
        static $o = null;
        if ($o === null) $o = get_option(self::OPT, []);
        if (isset($o[$k])) return $o[$k];
        foreach (self::fields() as $g) if (isset($g[$k])) return $g[$k][2];
        return '';
    }

    static function init() {
        add_action('admin_menu', function () {
            add_submenu_page('woocommerce', 'Checkout Offer Box', 'Checkout Offer Box', 'manage_woocommerce', 'wco-box', [__CLASS__, 'page']);
        });
        add_action('admin_init', function () { register_setting('wco_group', self::OPT, [__CLASS__, 'sanitize']); });
        add_action('admin_enqueue_scripts', function ($h) {
            if (strpos($h, 'wco-box') !== false) { wp_enqueue_style('wp-color-picker'); wp_enqueue_script('wp-color-picker'); }
        });
        $pos = ['before_submit'=>'woocommerce_review_order_before_submit','before_payment'=>'woocommerce_review_order_before_payment','after_payment'=>'woocommerce_review_order_after_payment'];
        $hook = $pos[self::get('position')] ?? $pos['before_submit'];
        add_action($hook, [__CLASS__, 'render']);
        foreach (['woocommerce_review_order_after_submit','woocommerce_checkout_after_order_review','woocommerce_after_checkout_form'] as $fb) add_action($fb, [__CLASS__, 'render'], 99);
        add_action('wp_enqueue_scripts', [__CLASS__, 'assets']);
        add_action('wp_ajax_wco_html', [__CLASS__, 'ajax_html']);
        add_action('wp_ajax_nopriv_wco_html', [__CLASS__, 'ajax_html']);
        add_action('wp_ajax_wco_add', [__CLASS__, 'ajax']);
        add_action('wp_ajax_nopriv_wco_add', [__CLASS__, 'ajax']);
        add_action('woocommerce_before_calculate_totals', [__CLASS__, 'apply_price'], 20);
    }

    static function sanitize($in) {
        $out = [];
        foreach (self::fields() as $g) foreach ($g as $k => $f) {
            $v = $in[$k] ?? '';
            if ($f[1] === 'checkbox') $out[$k] = empty($in[$k]) ? 0 : 1;
            elseif ($f[1] === 'color') $out[$k] = sanitize_hex_color($v) ?: $f[2];
            elseif ($f[1] === 'number') $out[$k] = $v === '' ? '' : floatval($v);
            elseif ($f[1] === 'select') $out[$k] = isset($f[3][$v]) ? $v : $f[2];
            else $out[$k] = sanitize_text_field($v);
        }
        return $out;
    }

    static function page() {
        $o = get_option(self::OPT, []);
        echo '<div class="wrap"><h1>Checkout Offer Box</h1><form method="post" action="options.php">';
        settings_fields('wco_group');
        foreach (self::fields() as $group => $fs) {
            echo '<h2>' . esc_html($group) . '</h2><table class="form-table">';
            foreach ($fs as $k => $f) {
                $v = $o[$k] ?? $f[2]; $n = self::OPT . "[$k]";
                echo '<tr><th>' . esc_html($f[0]) . '</th><td>';
                if ($f[1] === 'checkbox') echo '<input type="checkbox" name="' . $n . '" value="1" ' . checked($v, 1, false) . '>';
                elseif ($f[1] === 'select') {
                    echo '<select name="' . $n . '">';
                    foreach ($f[3] as $ov => $ol) echo '<option value="' . esc_attr($ov) . '" ' . selected($v, $ov, false) . '>' . esc_html($ol) . '</option>';
                    echo '</select>';
                } else echo '<input class="' . ($f[1] === 'color' ? 'wco-color' : 'regular-text') . '" type="' . ($f[1] === 'color' ? 'text' : $f[1]) . '" step="any" name="' . $n . '" value="' . esc_attr($v) . '">';
                echo '</td></tr>';
            }
            echo '</table>';
        }
        submit_button();
        echo '</form></div><script>jQuery(function($){$(".wco-color").wpColorPicker();});</script>';
    }

    static function prices($p) {
        $reg = (float) $p->get_price(); $t = self::get('discount_type'); $d = (float) self::get('discount_value');
        $offer = $reg;
        if ($t === 'fixed_off') $offer = $reg - $d;
        elseif ($t === 'percent_off') $offer = $reg - ($reg * $d / 100);
        elseif ($t === 'fixed_price') $offer = $d;
        $offer = max(0, round($offer, wc_get_price_decimals()));
        return [$reg, $offer];
    }

    // Variable product হলে default/প্রথম available variation বেছে নেয়
    static function resolve($pid) {
        $p = wc_get_product($pid);
        if (!$p || !$p->is_type('variable')) return [$p, 0, []];
        $def = $p->get_default_attributes();
        $first = null;
        foreach ($p->get_available_variations() as $v) {
            $vo = wc_get_product($v['variation_id']);
            if (!$vo || !$vo->is_purchasable() || !$vo->is_in_stock()) continue;
            $attrs = $v['attributes'];
            $first = $first ?: [$vo, $vo->get_id(), $attrs];
            $match = $def ? true : false;
            foreach ($def as $k => $val) { $a = $attrs['attribute_' . $k] ?? ''; if ($a !== '' && $a !== $val) { $match = false; break; } }
            if ($match) return [$vo, $vo->get_id(), $attrs];
        }
        return $first ?: [false, 0, []];
    }

    static function in_cart() {
        $pid = (int) self::get('product_id');
        if (!WC()->cart) return false;
        foreach (WC()->cart->get_cart() as $i) if ((int) $i['product_id'] === $pid) return true;
        return false;
    }

    static $done = false;
    static function render() {
        if (self::$done || !self::get('enabled') || !function_exists('WC')) return;
        $pid = (int) self::get('product_id');
        $p = false; if ($pid) { list($p) = self::resolve($pid); if (!$p) $p = false; }
        if (!$p || !$p->is_purchasable() || !$p->is_in_stock()) return;
        $added = self::in_cart();
        self::$done = true;
        list($reg, $offer) = self::prices($p);
        $save = $reg - $offer; $cur = esc_html(self::get('currency'));
        $fmt = function ($n) use ($cur) { return $cur . ' ' . number_format_i18n($n, 0 == fmod($n, 1) ? 0 : 2); };
        $title = self::get('title') ?: $p->get_name();
        $badge = str_replace('{save}', number_format_i18n($save, 0), self::get('badge_text'));
        $g = function ($k) { return esc_attr(self::get($k)); };
        $bs = self::get('border_style');
        $css = "--hb:{$g('header_bg')};--hc:{$g('header_color')};--bb:{$g('box_bg')};--bc:{$g('border_color')};--r:{$g('radius')}px;--tc:{$g('title_color')};--ts:{$g('title_size')}px;--pc:{$g('price_color')};--ps:{$g('price_size')}px;--oc:{$g('old_price_color')};--btb:{$g('btn_bg')};--btc:{$g('btn_color')};--btr:{$g('btn_radius')}px;--bgb:{$g('badge_bg')};--bgc:{$g('badge_color')};--is:{$g('img_size')}px;--m:{$g('margin')}px;--bst:" . esc_attr($bs);
        ?>
        <div class="wco-box" style="<?php echo $css; ?>">
            <div class="wco-head"><?php echo esc_html(self::get('header_text')); ?></div>
            <div class="wco-body">
                <?php if (self::get('show_badge') && $save > 0) : ?><span class="wco-badge"><?php echo esc_html($badge); ?></span><?php endif; ?>
                <?php if (self::get('show_image')) : ?><div class="wco-img"><?php echo $p->get_image('woocommerce_thumbnail'); ?></div><?php endif; ?>
                <div class="wco-info">
                    <div class="wco-title"><?php echo esc_html($title); ?></div>
                    <div class="wco-row">
                        <?php if ($save > 0) : ?><del class="wco-old"><?php echo $fmt($reg); ?></del><?php endif; ?>
                        <span class="wco-price"><?php echo $fmt($offer); ?></span>
                        <button type="button" class="wco-btn<?php echo $added ? ' added' : ''; ?>" data-pid="<?php echo $pid; ?>"><?php echo esc_html($added ? self::get('added_text') : self::get('button_text')); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    static function assets() {
        if (!is_checkout() && !is_cart() && !function_exists('WC')) return;
        wp_register_style('wco', false); wp_enqueue_style('wco');
        wp_add_inline_style('wco', '
.wco-box{display:block!important;visibility:visible!important;margin:var(--m) 0;border:2px var(--bst) var(--bc);border-radius:var(--r);overflow:hidden;background:var(--bb)}
.wco-head{background:var(--hb);color:var(--hc);text-align:center;font-weight:700;padding:12px 10px;font-size:17px}
.wco-body{position:relative;display:flex;align-items:center;gap:16px;padding:16px}
.wco-img{flex:0 0 var(--is)}.wco-img img{width:var(--is);height:var(--is);object-fit:cover;border-radius:8px;display:block}
.wco-info{flex:1;min-width:0}
.wco-title{font-weight:700;color:var(--tc);font-size:var(--ts);margin-bottom:8px;line-height:1.4}
.wco-row{display:flex;align-items:center;flex-wrap:wrap;gap:10px}
.wco-old{color:var(--oc);font-size:15px}
.wco-price{color:var(--pc);font-size:var(--ps);font-weight:700}
.wco-btn{background:var(--btb)!important;color:var(--btc)!important;border:0;border-radius:var(--btr);padding:10px 22px;font-weight:600;cursor:pointer}
.wco-btn.added{opacity:.7;pointer-events:none}.wco-btn.loading{opacity:.6;pointer-events:none}
.wco-badge{position:absolute;top:-1px;left:-1px;background:var(--bgb);color:var(--bgc);font-size:12px;font-weight:700;padding:5px 10px;border-radius:0 0 8px 0;z-index:2}
@media(max-width:480px){.wco-body{gap:12px;padding:14px 12px}.wco-price{font-size:calc(var(--ps) - 4px)}}');
        wp_enqueue_script('jquery');
        if (is_checkout()) wp_add_inline_script('jquery', 'jQuery(function($){var U="' . esc_url(admin_url('admin-ajax.php')) . '",N="' . wp_create_nonce('wco') . '",busy=0;
$(document).on("click",".wco-btn",function(){var b=$(this);b.addClass("loading");$.post(U,{action:"wco_add",pid:b.data("pid"),n:N},function(){$(document.body).trigger("update_checkout");$(document.body).trigger("wc_fragment_refresh");}).always(function(){b.removeClass("loading");});});
function ok(){return $(".wco-box").filter(function(){return $(this).is(":visible")}).length>0;}
function put(h){if(!h||ok())return;$(".wco-box").remove();var t=$("#place_order,button[name=woocommerce_checkout_place_order],.wc-block-components-checkout-place-order-button,form.checkout button[type=submit]").filter(":visible").first();if(!t.length)t=$("form.checkout").find("button[type=submit]").last();var a=t.closest(".form-row,.place-order");a=a.length?a:t;if(a.length)a.first().before(h);else $("form.checkout").append(h);}
function fix(){if(busy||ok())return;busy=1;$.ajax({url:U,type:"POST",data:{action:"wco_html"},timeout:8000}).done(function(h){put(h);}).fail(function(){var t=$("#wco-tpl").html();put(t);}).always(function(){busy=0;});}
$(document.body).on("updated_checkout",function(){setTimeout(fix,300);});setTimeout(fix,800);setTimeout(fix,2500);setTimeout(fix,5000);$(window).on("resize orientationchange",function(){setTimeout(fix,400);});});');
        add_action('wp_footer', function () { if (is_checkout() && self::get('enabled')) { self::$done = false; ob_start(); self::render(); echo '<script type="text/template" id="wco-tpl">' . str_replace('</script', '<\/script', ob_get_clean()) . '</script>'; self::$done = true; } });
    }

    static function ajax_html() {
        nocache_headers();
        if (!WC()->cart) wc_load_cart();
        self::$done = false;
        ob_start(); self::render(); echo ob_get_clean();
        wp_die();
    }

    static function ajax() {
        check_ajax_referer('wco', 'n');
        if (!WC()->cart) wc_load_cart();
        $pid = (int) self::get('product_id');
        if ($pid && (int) ($_POST['pid'] ?? 0) === $pid && !self::in_cart()) {
            list($p, $vid, $attrs) = self::resolve($pid);
            if ($p) WC()->cart->add_to_cart($pid, 1, $vid, $attrs, ['wco_offer' => 1]);
        }
        wc_clear_notices(); // checkout-এ error notice যেন না দেখায়
        wp_send_json_success();
    }

    static function apply_price($cart) {
        if (is_admin() && !defined('DOING_AJAX')) return;
        foreach ($cart->get_cart() as $i) {
            if (!empty($i['wco_offer'])) {
                $p = wc_get_product($i['variation_id'] ?: $i['product_id']);
                if ($p) { $x = self::prices($p); $i['data']->set_price($x[1]); }
            }
        }
    }
}
add_action('plugins_loaded', ['WCO_Box', 'init']);
