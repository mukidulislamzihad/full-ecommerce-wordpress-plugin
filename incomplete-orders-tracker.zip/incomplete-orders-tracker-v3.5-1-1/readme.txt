=== Incomplete Orders Tracker ===
Contributors: mukidulislamzihad
Tags: woocommerce, incomplete checkout, abandoned checkout, order recovery
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 3.7.0
License: GPLv2 or later

Track incomplete WooCommerce checkout details and recover potential orders through WhatsApp or email.

== Description ==

Incomplete Orders Tracker captures customer contact and cart information while checkout is in progress. It supports both Classic Checkout and WooCommerce Block Checkout.

Features:

* Session-first incomplete checkout tracking.
* Automatic completion when a matching WooCommerce order is created.
* Configurable completion matching window.
* WhatsApp and email recovery actions.
* CSV export protected with WordPress permissions and nonce validation.
* Responsive admin dashboard.

== Changelog ==

= 3.7.0 =

* Removed license requirement — tracking is now always enabled.

= 3.6.2 =

* Fixed new checkout data not being saved on legacy database tables.
* Added automatic self-repair for missing tracking columns.
* Allowed the first checkout request after an update to complete a pending schema upgrade.

= 3.6.1 =

* Fixed legacy database rows showing an undefined product_name warning.
* Restored product names and links from saved cart or metadata when available.
* Added safe fallbacks for older incomplete-order records.

= 3.6.0 =

* Fixed Block Checkout order processed callback argument error.
* Added reliable checkout session persistence and order meta matching.
* Prevented old matching leads from being completed outside the configured window.
* Improved Classic and Block Checkout field and cart detection.
* Removed external icon dependency.
* Prevented public database error disclosure.
* Secured CSV export and protected spreadsheet cells from formula injection.
* Added native settings-save fallback for restrictive hosting environments.
* Refreshed admin list and settings designs.
