<?php
/**
 * Plugin Name: Contact Us Pro
 * Description: [contact_us] শর্টকোড দিয়ে কন্টাক্ট ফর্ম + কোম্পানি ইনফো। সাবমিশন অ্যাডমিনে দেখা যায়।
 * Version: 1.0.0
 */
if (!defined('ABSPATH')) exit;

class CUP {
    const OPT = 'cup_settings';
    const CPT = 'cup_entry';

    static function fields() {
        return [
            'name' => ['Your Name', 'Your full Name', 'text'],
            'email' => ['Your Email', 'Enter your Email', 'email'],
            'phone' => ['Phone Number', 'Enter your Number', 'tel'],
            'company' => ['Company Name', 'Enter your Company Name', 'text'],
            'message' => ['Your Message', 'Enter Your Message', 'textarea'],
        ];
    }

    static function defaults() {
        $d = [
            'button' => 'SUBMIT', 'success' => 'Thank you! Your message has been sent.',
            'error' => 'Please fill in all required fields correctly.', 'wait' => 'Too many attempts. Please try later.',
            'info_text' => '<strong>Falaq Food</strong> is a trusted food supplier company in Bangladesh, committed to delivering safe, high-quality, and natural products at affordable prices.',
            'phone' => '+8809613821489', 'address' => 'Headoffice: Bosila Future Town, Mohammadpur, Dhaka-1207', 'email' => 'support@falaqfood.com',
            'follow_title' => 'Follow Us', 'facebook' => '', 'x' => '', 'youtube' => '', 'instagram' => '', 'whatsapp' => '',
            'show_info' => 1, 'show_phone' => 1, 'show_address' => 1, 'show_email' => 1, 'show_social' => 1,
            'notify' => 1, 'notify_to' => get_option('admin_email'),
            'primary' => '#fb7d0a', 'text' => '#111111', 'border' => '#999999', 'radius' => '4', 'custom_css' => '',
        ];
        foreach (self::fields() as $k => $f) { $d["l_$k"] = $f[0]; $d["p_$k"] = $f[1]; $d["r_$k"] = 1; $d["s_$k"] = 1; }
        return $d;
    }

    static function g($k) { $o = wp_parse_args(get_option(self::OPT, []), self::defaults()); return $o[$k] ?? ''; }

    static function init() {
        add_shortcode('contact_us', [__CLASS__, 'shortcode']);
        add_action('admin_post_nopriv_cup_submit', [__CLASS__, 'submit']);
        add_action('admin_post_cup_submit', [__CLASS__, 'submit']);
        add_action('init', function () {
            register_post_type(self::CPT, [
                'labels' => ['name' => 'Contact Messages', 'singular_name' => 'Message', 'menu_name' => 'Contact Messages', 'all_items' => 'All Messages'],
                'public' => false, 'show_ui' => true, 'menu_icon' => 'dashicons-email-alt', 'menu_position' => 57,
                'supports' => ['title'], 'capabilities' => ['create_posts' => 'do_not_allow'], 'map_meta_cap' => true,
            ]);
        });
        add_action('admin_menu', function () {
            add_submenu_page('edit.php?post_type=' . self::CPT, 'Settings', 'Settings', 'manage_options', 'cup-settings', [__CLASS__, 'page']);
        });
        add_action('admin_init', function () { register_setting('cup_group', self::OPT, ['sanitize_callback' => [__CLASS__, 'sanitize']]); });
        add_action('add_meta_boxes', function () {
            add_meta_box('cup_data', 'Message Details', [__CLASS__, 'box'], self::CPT, 'normal', 'high');
        });
        add_filter('manage_' . self::CPT . '_posts_columns', function ($c) {
            return ['cb' => $c['cb'], 'title' => 'Name', 'cup_email' => 'Email', 'cup_phone' => 'Phone', 'cup_company' => 'Company', 'date' => 'Date'];
        });
        add_action('manage_' . self::CPT . '_posts_custom_column', function ($c, $id) {
            $d = get_post_meta($id, '_cup', true) ?: [];
            echo esc_html($d[substr($c, 4)] ?? '');
        }, 10, 2);
    }

    static function box($p) {
        $d = get_post_meta($p->ID, '_cup', true) ?: [];
        echo '<table class="widefat striped">';
        foreach (self::fields() as $k => $f) printf('<tr><th style="width:160px">%s</th><td>%s</td></tr>', esc_html(self::g("l_$k")), nl2br(esc_html($d[$k] ?? '')));
        printf('<tr><th>IP</th><td>%s</td></tr></table>', esc_html($d['ip'] ?? ''));
    }

    static function sanitize($in) {
        $out = [];
        foreach (self::defaults() as $k => $d) {
            $v = $in[$k] ?? '';
            if (preg_match('/^(show_|notify$|r_|s_)/', $k)) $out[$k] = empty($v) ? 0 : 1;
            elseif ($k === 'custom_css') $out[$k] = wp_strip_all_tags($v);
            elseif ($k === 'info_text') $out[$k] = wp_kses_post($v);
            elseif (in_array($k, ['primary', 'text', 'border'])) $out[$k] = sanitize_hex_color($v) ?: $d;
            elseif ($k === 'radius') $out[$k] = (string) absint($v);
            elseif (in_array($k, ['facebook', 'x', 'youtube', 'instagram', 'whatsapp'])) $out[$k] = esc_url_raw($v);
            elseif ($k === 'notify_to') $out[$k] = sanitize_email($v) ?: $d;
            else $out[$k] = sanitize_text_field($v);
        }
        return $out;
    }

    static function row($label, $name, $val, $type = 'text') {
        printf('<tr><th>%s</th><td><input type="%s" class="large-text" name="%s[%s]" value="%s"></td></tr>', esc_html($label), $type, self::OPT, $name, esc_attr($val));
    }
    static function chk($label, $name) {
        printf('<tr><th>%s</th><td><input type="checkbox" name="%s[%s]" value="1" %s></td></tr>', esc_html($label), self::OPT, $name, checked(self::g($name), 1, false));
    }

    static function page() {
        echo '<div class="wrap"><h1>Contact Us Pro – Settings</h1><p>Shortcode: <code>[contact_us]</code></p><form method="post" action="options.php">';
        settings_fields('cup_group');
        echo '<h2>Form Fields</h2><table class="form-table">';
        foreach (self::fields() as $k => $f) {
            self::row("$k – Label", "l_$k", self::g("l_$k"));
            self::row("$k – Placeholder", "p_$k", self::g("p_$k"));
            self::chk("$k – Show", "s_$k");
            self::chk("$k – Required", "r_$k");
        }
        self::row('Button text', 'button', self::g('button'));
        self::row('Success message', 'success', self::g('success'));
        self::row('Error message', 'error', self::g('error'));
        self::row('Rate-limit message', 'wait', self::g('wait'));
        self::chk('Email notification to admin', 'notify');
        self::row('Notification email', 'notify_to', self::g('notify_to'), 'email');
        echo '</table><h2>Info Panel</h2><table class="form-table">';
        self::chk('Show info panel', 'show_info');
        printf('<tr><th>Description (HTML ok)</th><td><textarea class="large-text" rows="3" name="%s[info_text]">%s</textarea></td></tr>', self::OPT, esc_textarea(self::g('info_text')));
        self::chk('Show phone', 'show_phone'); self::row('Phone', 'phone', self::g('phone'));
        self::chk('Show address', 'show_address'); self::row('Address', 'address', self::g('address'));
        self::chk('Show email', 'show_email'); self::row('Email', 'email', self::g('email'));
        self::chk('Show social', 'show_social'); self::row('Social title', 'follow_title', self::g('follow_title'));
        foreach (['facebook', 'x', 'youtube', 'instagram', 'whatsapp'] as $s) self::row(ucfirst($s) . ' URL (empty = hide)', $s, self::g($s), 'url');
        echo '</table><h2>Design</h2><table class="form-table">';
        foreach (['primary' => 'Main color', 'text' => 'Text color', 'border' => 'Input border color'] as $k => $l) self::row($l, $k, self::g($k), 'color');
        self::row('Border radius (px)', 'radius', self::g('radius'), 'number');
        printf('<tr><th>Custom CSS</th><td><textarea class="large-text code" rows="8" name="%s[custom_css]">%s</textarea></td></tr>', self::OPT, esc_textarea(self::g('custom_css')));
        echo '</table>';
        submit_button();
        echo '</form></div>';
    }

    static function submit() {
        $back = wp_get_referer() ?: home_url('/');
        $back = remove_query_arg('cup', $back);
        if (!isset($_POST['_cupn']) || !wp_verify_nonce($_POST['_cupn'], 'cup_submit') || !empty($_POST['cup_hp'])) { wp_safe_redirect(add_query_arg('cup', 'err', $back) . '#cup-form'); exit; }
        $ip = $_SERVER['REMOTE_ADDR'] ?? ''; $key = 'cup_rl_' . md5($ip); $n = (int) get_transient($key);
        if ($n >= 5) { wp_safe_redirect(add_query_arg('cup', 'wait', $back) . '#cup-form'); exit; }
        set_transient($key, $n + 1, 300);
        $in = $_POST['cup'] ?? []; $d = []; $ok = true;
        foreach (self::fields() as $k => $f) {
            if (!self::g("s_$k")) continue;
            $v = $f[2] === 'textarea' ? sanitize_textarea_field(wp_unslash($in[$k] ?? '')) : sanitize_text_field(wp_unslash($in[$k] ?? ''));
            if (self::g("r_$k") && $v === '') $ok = false;
            if ($k === 'email' && $v !== '' && !is_email($v)) $ok = false;
            $d[$k] = mb_substr($v, 0, 3000);
        }
        if (!$ok) { wp_safe_redirect(add_query_arg('cup', 'err', $back) . '#cup-form'); exit; }
        $d['ip'] = $ip;
        $id = wp_insert_post(['post_type' => self::CPT, 'post_status' => 'publish', 'post_title' => $d['name'] ?? ($d['email'] ?? 'Message')]);
        if ($id) update_post_meta($id, '_cup', $d);
        if (self::g('notify')) {
            $body = ''; foreach ($d as $k => $v) $body .= ucfirst($k) . ': ' . $v . "\n";
            $h = !empty($d['email']) ? ['Reply-To: ' . $d['email']] : [];
            wp_mail(self::g('notify_to'), 'New contact message: ' . ($d['name'] ?? ''), $body, $h);
        }
        wp_safe_redirect(add_query_arg('cup', 'ok', $back) . '#cup-form'); exit;
    }

    static function shortcode() {
        $msg = '';
        if (isset($_GET['cup'])) {
            $s = sanitize_key($_GET['cup']);
            if ($s === 'ok') $msg = '<div class="cup-msg cup-ok">' . esc_html(self::g('success')) . '</div>';
            elseif ($s === 'wait') $msg = '<div class="cup-msg cup-err">' . esc_html(self::g('wait')) . '</div>';
            elseif ($s === 'err') $msg = '<div class="cup-msg cup-err">' . esc_html(self::g('error')) . '</div>';
        }
        $ic = ['phone' => 'M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z',
            'address' => 'M12 2a7 7 0 0 0-7 7c0 5.300 7 13 7 13s7-7.700 7-13a7 7 0 0 0-7-7zm0 9.500a2.500 2.500 0 1 1 0-5 2.500 2.500 0 0 1 0 5z',
            'email' => 'M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 4-8 5-8-5V6l8 5 8-5v2z'];
        $soc = ['facebook' => 'f', 'x' => '𝕏', 'youtube' => '▶', 'instagram' => 'IG', 'whatsapp' => 'WA'];
        ob_start(); ?>
<div class="cup-wrap" id="cup-form">
<style>
.cup-wrap{--p:<?php echo esc_attr(self::g('primary')); ?>;--t:<?php echo esc_attr(self::g('text')); ?>;--b:<?php echo esc_attr(self::g('border')); ?>;--r:<?php echo (int) self::g('radius'); ?>px;max-width:1200px;margin:0 auto;padding:12px;min-width:0;color:var(--t);display:grid;grid-template-columns:1fr;gap:28px;font-family:inherit}
.cup-wrap *{box-sizing:border-box}
.cup-form{min-width:0}
.cup-grid{display:grid;grid-template-columns:1fr;gap:16px}
.cup-f{min-width:0}.cup-f.full{grid-column:1/-1}
.cup-f label{display:block;margin-bottom:6px;font-size:15px}
.cup-f label i{color:#d00;font-style:normal}
.cup-f input,.cup-f textarea{width:100%;max-width:100%;padding:12px 14px;border:1px solid var(--b);border-radius:var(--r);font-size:15px;background:#fff;color:var(--t);font-family:inherit}
.cup-f textarea{min-height:150px;resize:vertical}
.cup-f input:focus,.cup-f textarea:focus{outline:2px solid var(--p);outline-offset:0}
.cup-btn{display:block;width:100%;margin-top:18px;padding:15px;background:var(--p);color:#fff;border:0;border-radius:var(--r);font-weight:700;font-size:16px;cursor:pointer}
.cup-btn:hover{opacity:.9}
.cup-hp{position:absolute;left:-9999px;height:0;width:0;overflow:hidden}
.cup-msg{margin-bottom:16px;padding:12px 14px;border-radius:var(--r);font-size:15px}
.cup-ok{background:#e7f7ec;border-left:4px solid #2a9d4b}.cup-err{background:#fdecec;border-left:4px solid #d33}
.cup-info{min-width:0;word-break:break-word}
.cup-info p{margin:0 0 20px;font-size:clamp(15px,4vw,19px);line-height:1.6}
.cup-li{display:flex;gap:12px;align-items:flex-start;margin-bottom:16px;font-size:clamp(15px,4vw,19px);line-height:1.4}
.cup-li svg{flex:0 0 24px;width:24px;height:24px;fill:var(--p);margin-top:2px}
.cup-info h3{margin:24px 0 12px;font-size:22px;color:var(--t)}
.cup-soc{display:flex;flex-wrap:wrap;gap:10px}
.cup-soc a{width:48px;height:48px;border-radius:50%;background:var(--p);color:#fff;display:flex;align-items:center;justify-content:center;text-decoration:none;font-weight:700;font-size:15px}
@media(min-width:480px){.cup-grid{grid-template-columns:1fr 1fr}}
@media(min-width:900px){.cup-wrap{grid-template-columns:1.2fr 1fr;gap:40px}}
<?php echo wp_strip_all_tags(self::g('custom_css')); ?>
</style>
<form class="cup-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
<?php echo $msg; ?>
<input type="hidden" name="action" value="cup_submit">
<?php wp_nonce_field('cup_submit', '_cupn'); ?>
<div class="cup-hp"><input type="text" name="cup_hp" tabindex="-1" autocomplete="off"></div>
<div class="cup-grid">
<?php foreach (self::fields() as $k => $f) : if (!self::g("s_$k")) continue; $req = self::g("r_$k"); ?>
<div class="cup-f <?php echo $f[2] === 'textarea' ? 'full' : ''; ?>">
<label for="cup_<?php echo $k; ?>"><?php echo esc_html(self::g("l_$k")); ?><?php if ($req) echo ' <i>*</i>'; ?></label>
<?php if ($f[2] === 'textarea') : ?><textarea id="cup_<?php echo $k; ?>" name="cup[<?php echo $k; ?>]" <?php echo $req ? 'required' : ''; ?> placeholder="<?php echo esc_attr(self::g("p_$k")); ?>"></textarea>
<?php else : ?><input id="cup_<?php echo $k; ?>" type="<?php echo $f[2]; ?>" name="cup[<?php echo $k; ?>]" <?php echo $req ? 'required' : ''; ?> placeholder="<?php echo esc_attr(self::g("p_$k")); ?>"><?php endif; ?>
</div>
<?php endforeach; ?>
</div>
<button class="cup-btn" type="submit"><?php echo esc_html(self::g('button')); ?></button>
</form>
<?php if (self::g('show_info')) : ?>
<div class="cup-info">
<p><?php echo wp_kses_post(self::g('info_text')); ?></p>
<?php foreach (['phone', 'address', 'email'] as $k) if (self::g("show_$k") && self::g($k)) : ?>
<div class="cup-li"><svg viewBox="0 0 24 24"><path d="<?php echo $ic[$k]; ?>"/></svg><span><?php echo esc_html(self::g($k)); ?></span></div>
<?php endif; ?>
<?php if (self::g('show_social')) : $any = false; foreach ($soc as $k => $l) if (self::g($k)) $any = true; if ($any) : ?>
<h3><?php echo esc_html(self::g('follow_title')); ?></h3>
<div class="cup-soc"><?php foreach ($soc as $k => $l) if (self::g($k)) echo '<a href="' . esc_url(self::g($k)) . '" target="_blank" rel="noopener" aria-label="' . esc_attr($k) . '">' . esc_html($l) . '</a>'; ?></div>
<?php endif; endif; ?>
</div>
<?php endif; ?>
</div>
<?php return ob_get_clean();
    }
}
add_action('plugins_loaded', ['CUP', 'init']);
