<?php
/**
 * Plugin Name: Promo Banner Grid
 * Description: Admin panel theke promotional banner/ad card add-edit-delete-reorder kore shortcode diye bento-style grid dekhan. Full customizable + responsive (min-width 320px).
 * Version: 1.0.0
 * Author: Custom
 * Text Domain: pbg
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'PBG_OPT_ITEMS', 'pbg_items' );
define( 'PBG_OPT_SETTINGS', 'pbg_settings' );
define( 'PBG_VERSION', '1.0.0' );

function pbg_default_settings() {
	return array(
		'gap'            => 16,
		'radius'         => 14,
		'row_height'     => 150,
		'overlay_color'  => '#000000',
		'overlay_opacity'=> 20,
		'custom_css'     => '',
	);
}
function pbg_get_settings() { return wp_parse_args( get_option( PBG_OPT_SETTINGS, array() ), pbg_default_settings() ); }
function pbg_get_items() { $i = get_option( PBG_OPT_ITEMS, array() ); return is_array( $i ) ? $i : array(); }

add_action( 'admin_menu', function () {
	add_menu_page( 'Promo Banners', 'Promo Banners', 'manage_options', 'pbg-banners', 'pbg_render_admin_page', 'dashicons-images-alt2', 28 );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( strpos( $hook, 'pbg-banners' ) === false ) return;
	wp_enqueue_media();
	wp_enqueue_script( 'jquery-ui-sortable' );
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
} );

add_action( 'admin_init', function () {
	if ( ! isset( $_POST['pbg_save_nonce'] ) || ! wp_verify_nonce( $_POST['pbg_save_nonce'], 'pbg_save_action' ) ) return;
	if ( ! current_user_can( 'manage_options' ) ) return;

	$items = array();
	if ( ! empty( $_POST['items'] ) && is_array( $_POST['items'] ) ) {
		foreach ( $_POST['items'] as $it ) {
			$img = intval( $it['image_id'] ?? 0 );
			if ( ! $img && empty( $it['heading'] ) ) continue;
			$items[] = array(
				'image_id' => $img,
				'badge'    => sanitize_text_field( $it['badge'] ?? '' ),
				'heading'  => sanitize_textarea_field( $it['heading'] ?? '' ),
				'subtext'  => sanitize_text_field( $it['subtext'] ?? '' ),
				'link'     => esc_url_raw( $it['link'] ?? '' ),
				'size'     => in_array( $it['size'] ?? 'small', array( 'small', 'large' ), true ) ? $it['size'] : 'small',
				'text_color' => sanitize_hex_color( $it['text_color'] ?? '' ) ?: '#ffffff',
			);
		}
	}
	update_option( PBG_OPT_ITEMS, $items );

	$settings = pbg_default_settings();
	$settings['gap']             = max( 0, intval( $_POST['gap'] ?? 16 ) );
	$settings['radius']          = max( 0, intval( $_POST['radius'] ?? 14 ) );
	$settings['row_height']      = max( 60, intval( $_POST['row_height'] ?? 150 ) );
	$settings['overlay_color']   = sanitize_hex_color( $_POST['overlay_color'] ?? '' ) ?: '#000000';
	$settings['overlay_opacity'] = max( 0, min( 100, intval( $_POST['overlay_opacity'] ?? 20 ) ) );
	$settings['custom_css']      = wp_strip_all_tags( wp_unslash( $_POST['custom_css'] ?? '' ) );
	update_option( PBG_OPT_SETTINGS, $settings );

	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-success is-dismissible"><p>সেভ হয়েছে।</p></div>';
	} );
} );

function pbg_render_item_row( $it = array() ) {
	$it = wp_parse_args( $it, array( 'image_id' => 0, 'badge' => '', 'heading' => '', 'subtext' => '', 'link' => '', 'size' => 'small', 'text_color' => '#ffffff' ) );
	$img = $it['image_id'] ? wp_get_attachment_image_url( $it['image_id'], array( 120, 90 ) ) : '';
	?>
	<li class="pbg-item-row" style="background:#f6f7f7;border:1px solid #ddd;padding:14px;margin-bottom:10px;display:flex;gap:14px;align-items:flex-start;">
		<span class="pbg-drag" style="cursor:move;padding-top:8px;">☰</span>
		<div style="flex-shrink:0;text-align:center;width:120px;">
			<img class="pbg-img-preview" src="<?php echo esc_url( $img ); ?>" style="width:120px;height:90px;object-fit:cover;background:#ddd;display:<?php echo $img ? 'block' : 'none'; ?>;border-radius:6px;">
			<input type="hidden" class="pbg-image-id" data-field="image_id" value="<?php echo esc_attr( $it['image_id'] ); ?>">
			<button type="button" class="button pbg-choose-img" style="margin-top:6px;">ছবি সিলেক্ট</button>
		</div>
		<div style="flex:1; display:grid; grid-template-columns:1fr 1fr; gap:8px;">
			<input type="text" data-field="badge" placeholder="উপরের ছোট ব্যাজ/লোগো টেক্সট (optional)" value="<?php echo esc_attr( $it['badge'] ); ?>">
			<select data-field="size">
				<option value="small" <?php selected( $it['size'], 'small' ); ?>>ছোট কার্ড</option>
				<option value="large" <?php selected( $it['size'], 'large' ); ?>>বড় কার্ড</option>
			</select>
			<textarea data-field="heading" placeholder="বড় হেডিং টেক্সট" rows="2" style="grid-column:1/3;"><?php echo esc_textarea( $it['heading'] ); ?></textarea>
			<input type="text" data-field="subtext" placeholder="ছোট সাব-টেক্সট/বাটন/ফোন (optional)" value="<?php echo esc_attr( $it['subtext'] ); ?>">
			<input type="text" data-field="link" placeholder="লিংক (https://...)" value="<?php echo esc_attr( $it['link'] ); ?>">
			<span>টেক্সট রং: <input type="text" class="pbg-color" data-field="text_color" value="<?php echo esc_attr( $it['text_color'] ); ?>"></span>
		</div>
		<a href="#" class="pbg-remove-row" style="color:#b32d2e;padding-top:8px;">✕</a>
	</li>
	<?php
}

function pbg_render_admin_page() {
	$settings = pbg_get_settings();
	$items    = pbg_get_items();
	?>
	<div class="wrap">
		<h1>Promo Banners</h1>
		<p>ব্যানার যোগ/এডিট/রিঅর্ডার করুন, তারপর Elementor Shortcode widget-এ বসান: <code>[pbg_banners]</code></p>
		<form method="post">
			<?php wp_nonce_field( 'pbg_save_action', 'pbg_save_nonce' ); ?>
			<h2 class="nav-tab-wrapper">
				<a href="#pbg-tab-items" class="nav-tab nav-tab-active" data-tab="items">ব্যানার ম্যানেজ</a>
				<a href="#pbg-tab-design" class="nav-tab" data-tab="design">ডিজাইন</a>
			</h2>

			<div id="pbg-tab-items" class="pbg-tab-panel" style="display:block;margin-top:16px;">
				<ul id="pbg-item-list" style="list-style:none;margin:0;padding:0;max-width:900px;">
					<?php foreach ( $items as $it ) pbg_render_item_row( $it ); ?>
				</ul>
				<button type="button" class="button button-secondary" id="pbg-add-row">+ নতুন ব্যানার যোগ করুন</button>
			</div>

			<div id="pbg-tab-design" class="pbg-tab-panel" style="display:none;margin-top:16px;">
				<table class="form-table">
					<tr><th>গ্যাপ (px)</th><td><input type="number" name="gap" min="0" value="<?php echo esc_attr( $settings['gap'] ); ?>"></td></tr>
					<tr><th>Corner Radius (px)</th><td><input type="number" name="radius" min="0" value="<?php echo esc_attr( $settings['radius'] ); ?>"></td></tr>
					<tr><th>রো হাইট ইউনিট (px)</th><td><input type="number" name="row_height" min="60" value="<?php echo esc_attr( $settings['row_height'] ); ?>"><p class="description">গ্রিডের বেস রো-হাইট; বড় কার্ড এর দ্বিগুণ হবে।</p></td></tr>
					<tr><th>ওভারলে রং</th><td><input type="text" class="pbg-color-main" name="overlay_color" value="<?php echo esc_attr( $settings['overlay_color'] ); ?>"></td></tr>
					<tr><th>ওভারলে অপাসিটি (%)</th><td><input type="number" name="overlay_opacity" min="0" max="100" value="<?php echo esc_attr( $settings['overlay_opacity'] ); ?>"></td></tr>
					<tr><th>কাস্টম CSS</th><td><textarea name="custom_css" rows="8" class="large-text code"><?php echo esc_textarea( $settings['custom_css'] ); ?></textarea>
					<p class="description">ক্লাস: <code>.pbg-item, .pbg-heading, .pbg-badge, .pbg-subtext</code></p></td></tr>
				</table>
			</div>

			<?php submit_button( 'সেভ করুন' ); ?>
		</form>
	</div>

	<script type="text/template" id="pbg-row-template"><?php pbg_render_item_row(); ?></script>

	<script>
	jQuery(function($){
		$('.nav-tab-wrapper .nav-tab').on('click', function(e){
			e.preventDefault();
			$('.nav-tab-wrapper .nav-tab').removeClass('nav-tab-active');
			$(this).addClass('nav-tab-active');
			$('.pbg-tab-panel').hide();
			$('#pbg-tab-' + $(this).data('tab')).show();
		});

		$('.pbg-color-main').wpColorPicker();

		function pbgReindex(){
			$('#pbg-item-list .pbg-item-row').each(function(i){
				$(this).find('[data-field]').each(function(){
					$(this).attr('name', 'items[' + i + '][' + $(this).data('field') + ']');
				});
			});
			$('.pbg-color').each(function(){
				if ( ! $(this).hasClass('wp-color-picker') ) $(this).wpColorPicker();
			});
		}
		pbgReindex();

		$('#pbg-item-list').sortable({ handle: '.pbg-drag', update: pbgReindex });

		$('#pbg-add-row').on('click', function(){
			$('#pbg-item-list').append( $('#pbg-row-template').html() );
			pbgReindex();
		});

		$('#pbg-item-list').on('click', '.pbg-remove-row', function(e){
			e.preventDefault();
			$(this).closest('.pbg-item-row').remove();
			pbgReindex();
		});

		$('#pbg-item-list').on('click', '.pbg-choose-img', function(e){
			e.preventDefault();
			var row = $(this).closest('.pbg-item-row');
			var frame = wp.media({ title: 'ছবি নির্বাচন করুন', multiple: false, library: { type: 'image' } });
			frame.on('select', function(){
				var att = frame.state().get('selection').first().toJSON();
				row.find('.pbg-image-id').val(att.id);
				row.find('.pbg-img-preview').attr('src', (att.sizes && att.sizes.medium ? att.sizes.medium.url : att.url)).show();
			});
			frame.open();
		});

		$('form').on('submit', pbgReindex);
	});
	</script>
	<?php
}

/* Shortcode */
add_shortcode( 'pbg_banners', 'pbg_shortcode_render' );

function pbg_shortcode_render() {
	$settings = pbg_get_settings();
	$items    = pbg_get_items();
	if ( empty( $items ) ) return '';

	pbg_enqueue_front_assets();

	ob_start();
	?>
	<div class="pbg-grid" style="
		--pbg-gap: <?php echo esc_attr( $settings['gap'] ); ?>px;
		--pbg-radius: <?php echo esc_attr( $settings['radius'] ); ?>px;
		--pbg-row: <?php echo esc_attr( $settings['row_height'] ); ?>px;
	">
		<?php foreach ( $items as $it ) :
			$url = $it['image_id'] ? wp_get_attachment_image_url( $it['image_id'], 'large' ) : '';
			$tag = $it['link'] ? 'a' : 'div';
			$op  = $settings['overlay_opacity'] / 100;
			$rgb = sscanf( $settings['overlay_color'], "#%02x%02x%02x" );
			?>
			<<?php echo $tag; ?> class="pbg-item pbg-<?php echo esc_attr( $it['size'] ); ?>" <?php echo $it['link'] ? 'href="' . esc_url( $it['link'] ) . '"' : ''; ?> style="background-image:url('<?php echo esc_url( $url ); ?>');color:<?php echo esc_attr( $it['text_color'] ); ?>;">
				<span class="pbg-overlay" style="background:rgba(<?php echo intval( $rgb[0] ); ?>,<?php echo intval( $rgb[1] ); ?>,<?php echo intval( $rgb[2] ); ?>,<?php echo esc_attr( $op ); ?>);"></span>
				<span class="pbg-content">
					<?php if ( $it['badge'] ) : ?><span class="pbg-badge"><?php echo esc_html( $it['badge'] ); ?></span><?php endif; ?>
					<?php if ( $it['heading'] ) : ?><span class="pbg-heading"><?php echo nl2br( esc_html( $it['heading'] ) ); ?></span><?php endif; ?>
					<?php if ( $it['subtext'] ) : ?><span class="pbg-subtext"><?php echo esc_html( $it['subtext'] ); ?></span><?php endif; ?>
				</span>
			</<?php echo $tag; ?>>
		<?php endforeach; ?>
	</div>
	<?php
	return ob_get_clean();
}

function pbg_enqueue_front_assets() {
	static $done = false;
	if ( $done ) return;
	$done = true;
	wp_register_style( 'pbg-front', false, array(), PBG_VERSION );
	wp_enqueue_style( 'pbg-front' );

	$settings = pbg_get_settings();
	$css = "
	.pbg-grid{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:repeat(3,1fr);grid-auto-rows:var(--pbg-row,150px);grid-auto-flow:dense;gap:var(--pbg-gap,16px);padding:0 16px;box-sizing:border-box;}
	.pbg-grid *{box-sizing:border-box;}
	.pbg-item{position:relative;display:flex;align-items:flex-end;border-radius:var(--pbg-radius,14px);background-size:cover;background-position:center;overflow:hidden;text-decoration:none;grid-column:span 1;grid-row:span 1;}
	.pbg-item.pbg-large{grid-column:span 2;grid-row:span 2;}
	.pbg-overlay{position:absolute;inset:0;}
	.pbg-content{position:relative;z-index:1;padding:18px;display:flex;flex-direction:column;gap:8px;width:100%;}
	.pbg-badge{align-self:flex-start;background:rgba(255,255,255,.15);backdrop-filter:blur(2px);font-size:11px;font-weight:700;padding:4px 10px;border-radius:999px;}
	.pbg-heading{font-weight:800;font-size:clamp(15px,2.2vw,22px);line-height:1.35;white-space:pre-line;}
	.pbg-item.pbg-large .pbg-heading{font-size:clamp(18px,2.8vw,30px);}
	.pbg-subtext{font-size:13px;font-weight:600;opacity:.95;}
	@media (max-width:700px){.pbg-grid{grid-template-columns:repeat(2,1fr);}}
	@media (max-width:560px){.pbg-grid{grid-template-columns:1fr;grid-auto-rows:220px;}.pbg-item.pbg-large{grid-column:span 1;grid-row:span 1;}}
	@media (max-width:320px){.pbg-content{padding:12px;}.pbg-grid{grid-auto-rows:190px;}}
	";
	wp_add_inline_style( 'pbg-front', $css );
	if ( ! empty( $settings['custom_css'] ) ) wp_add_inline_style( 'pbg-front', $settings['custom_css'] );
}
