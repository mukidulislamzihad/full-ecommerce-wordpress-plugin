( function ( $ ) {
	'use strict';

	$( function () {
		var licenseToastTimer;

		function showLicenseRequiredMessage() {
			var config = window.bosAdmin || {};
			var $toast = $( '#bos-license-lock-toast' );

			if ( ! $toast.length ) {
				$toast = $( '<div>', {
					id: 'bos-license-lock-toast',
					'class': 'bos-license-lock-toast',
					role: 'alert',
					'aria-live': 'assertive'
				} );

				$( '<span>', {
					'class': 'dashicons dashicons-lock bos-license-lock-toast-icon',
					'aria-hidden': 'true'
				} ).appendTo( $toast );

				var $content = $( '<div>', { 'class': 'bos-license-lock-toast-content' } ).appendTo( $toast );
				$( '<strong>' ).text( config.licenseRequiredTitle || 'License required' ).appendTo( $content );
				$( '<span>' ).text( config.licenseRequiredMessage || 'Please activate your license to enable SafeOrder modules.' ).appendTo( $content );
				$( '<a>', {
					'class': 'button button-primary bos-license-lock-toast-button',
					href: config.licenseUrl || 'admin.php?page=bos-fraud-control&tab=license'
				} ).text( config.activateLicenseLabel || 'Activate License' ).appendTo( $content );

				$( '<button>', {
					type: 'button',
					'class': 'bos-license-lock-toast-close',
					'aria-label': config.dismissLabel || 'Dismiss'
				} ).html( '&times;' ).appendTo( $toast );

				$( 'body' ).append( $toast );
			}

			window.clearTimeout( licenseToastTimer );
			$toast.addClass( 'is-visible' );
			licenseToastTimer = window.setTimeout( function () {
				$toast.removeClass( 'is-visible' );
			}, 6500 );
		}

		$( document ).on( 'click', '[data-bos-license-locked]', function ( event ) {
			event.preventDefault();
			event.stopImmediatePropagation();
			showLicenseRequiredMessage();
		} );

		$( document ).on( 'keydown', '[data-bos-license-locked]', function ( event ) {
			if ( 'Enter' !== event.key && ' ' !== event.key ) {
				return;
			}

			event.preventDefault();
			showLicenseRequiredMessage();
		} );

		$( document ).on( 'click', '.bos-license-lock-toast-close', function () {
			window.clearTimeout( licenseToastTimer );
			$( this ).closest( '.bos-license-lock-toast' ).removeClass( 'is-visible' );
		} );

		$( document ).on( 'click', '.bos-delete-link', function ( event ) {
			if ( ! window.confirm( 'Remove this item?' ) ) {
				event.preventDefault();
			}
		} );

		$( document ).on( 'click', '.bos-switch-row i', function ( event ) {
			event.preventDefault();

			if ( $( this ).closest( '[data-bos-license-locked]' ).length ) {
				showLicenseRequiredMessage();
				return;
			}

			var $input = $( this ).siblings( 'input[type="checkbox"]' );
			$input.prop( 'checked', ! $input.prop( 'checked' ) ).trigger( 'change' );
		} );

		$( document ).on( 'change', '.bos-switch-row input[type="checkbox"][data-toggle-url]', function () {
			var url = $( this ).data( 'toggle-url' );

			if ( url ) {
				window.location.href = url;
			}
		} );

		$( document ).on( 'click', '.bos-order-fraud-action', function ( event ) {
			event.preventDefault();
			event.stopPropagation();

			var $button = $( this );
			var $box = $button.closest( '.bos-metabox' );
			var $notice = $box.find( '[data-bos-metabox-notice]' );
			var action = String( $button.data( 'bos-fraud-action' ) || '' );
			var request = {
				action: 'bos_order_fraud_action',
				order_id: $box.data( 'bos-order-id' ),
				bos_fraud_action: action,
				_wpnonce: $box.data( 'bos-order-nonce' )
			};

			if ( 'mark_suspicious' === action ) {
				request.bos_suspicious_reason = $box.find( '#bos_suspicious_reason' ).val();
			}

			$button.addClass( 'bsp-loading' ).prop( 'disabled', true ).attr( 'aria-busy', 'true' );
			$notice.prop( 'hidden', true ).removeClass( 'is-success is-error' ).text( '' );

			$.post( window.ajaxurl, request )
				.done( function ( response ) {
					var message = response && response.data && response.data.message ? response.data.message : 'SafeOrder fraud control updated.';
					$notice.addClass( 'is-success' ).text( message ).prop( 'hidden', false );
					window.setTimeout( function () {
						window.location.reload();
					}, 450 );
				} )
				.fail( function ( xhr ) {
					var response = xhr.responseJSON || {};
					var message = response.data && response.data.message ? response.data.message : 'Could not update SafeOrder fraud control.';
					$notice.addClass( 'is-error' ).text( message ).prop( 'hidden', false );
					$button.removeClass( 'bsp-loading' ).prop( 'disabled', false ).removeAttr( 'aria-busy' );
				} );
		} );

		$( document ).on( 'click', '[data-bos-confirm-license-deactivate]', function ( event ) {
			if ( ! window.confirm( 'Deactivate the SafeOrder Pro license for this website?' ) ) {
				event.preventDefault();
			}
		} );

		$( document ).on( 'submit', '.bos-wrap form', function () {
			var $button = $( this ).find( 'button[type="submit"]' ).first();

			if ( $button.length && ! $button.hasClass( 'button-link-delete' ) ) {
				$button.addClass( 'bsp-loading' ).attr( 'aria-busy', 'true' );
			}
		} );
	} );
}( jQuery ) );
