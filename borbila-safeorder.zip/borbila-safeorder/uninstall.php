<?php
/**
 * Uninstall safety for Borbila SafeOrder.
 *
 * @package Borbila_SafeOrder
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$settings = get_option( 'bos_settings', array() );

if ( empty( $settings['delete_data_on_uninstall'] ) ) {
	return;
}

global $wpdb;

$tables = array(
	$wpdb->prefix . 'borbila_blocked_customers',
	$wpdb->prefix . 'borbila_fraud_logs',
);

foreach ( $tables as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$table}" );
}

delete_option( 'bos_settings' );
delete_option( 'bos_db_version' );
delete_option( 'bos_license_key' );
delete_option( 'bos_license_source' );
delete_option( 'bos_license_status' );
delete_option( 'bos_license_message' );
delete_option( 'bos_license_last_checked' );
delete_option( 'bos_license_last_success' );
wp_clear_scheduled_hook( 'bos_license_daily_validation' );

$meta_keys = array(
	'_bos_suspicious',
	'_bos_suspicious_reason',
	'_bos_suspicious_marked_at',
	'_bos_suspicious_marked_by',
);

$placeholders = implode( ',', array_fill( 0, count( $meta_keys ), '%s' ) );
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key IN ({$placeholders})", $meta_keys ) );
