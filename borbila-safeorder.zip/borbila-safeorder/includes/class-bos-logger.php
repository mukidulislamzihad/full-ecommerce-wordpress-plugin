<?php
/**
 * Fraud activity logger.
 *
 * @package Borbila_SafeOrder
 */

defined( 'ABSPATH' ) || exit;

/**
 * Stores and reads fraud activity logs.
 */
class BOS_Logger {

	/**
	 * Returns fraud log table name.
	 *
	 * @return string
	 */
	public static function table_name() {
		global $wpdb;

		return $wpdb->prefix . 'borbila_fraud_logs';
	}

	/**
	 * Writes an activity log row.
	 *
	 * @param string $type Log type.
	 * @param array  $data Log data.
	 * @return int|false
	 */
	public function log( $type, $data = array() ) {
		global $wpdb;

		$order_id = isset( $data['order_id'] ) ? absint( $data['order_id'] ) : null;
		$order_id = $order_id > 0 ? $order_id : null;

		$inserted = $wpdb->insert(
			self::table_name(),
			array(
				'created_at' => current_time( 'mysql' ),
				'type'       => sanitize_key( $type ),
				'phone'      => isset( $data['phone'] ) ? sanitize_text_field( wp_unslash( $data['phone'] ) ) : '',
				'email'      => isset( $data['email'] ) ? sanitize_email( wp_unslash( $data['email'] ) ) : '',
				'ip'         => isset( $data['ip'] ) ? sanitize_text_field( wp_unslash( $data['ip'] ) ) : '',
				'order_id'   => $order_id,
				'message'    => isset( $data['message'] ) ? sanitize_textarea_field( wp_unslash( $data['message'] ) ) : '',
			),
			array( '%s', '%s', '%s', '%s', '%s', '%d', '%s' )
		);

		return $inserted ? (int) $wpdb->insert_id : false;
	}

	/**
	 * Gets recent activity logs.
	 *
	 * @param int $limit Number of logs.
	 * @return array
	 */
	public function get_recent( $limit = 20 ) {
		global $wpdb;

		$limit = max( 1, min( 100, absint( $limit ) ) );

		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table_name() . ' ORDER BY created_at DESC, id DESC LIMIT %d',
				$limit
			)
		);
	}

	/**
	 * Counts logs by type, optionally since a date.
	 *
	 * @param array  $types Log types.
	 * @param string $since Optional MySQL datetime.
	 * @return int
	 */
	public function count_by_types( $types, $since = '' ) {
		global $wpdb;

		$types = array_values( array_filter( array_map( 'sanitize_key', (array) $types ) ) );

		if ( empty( $types ) ) {
			return 0;
		}

		$placeholders = implode( ', ', array_fill( 0, count( $types ), '%s' ) );
		$params       = $types;
		$where        = "type IN ({$placeholders})";

		if ( ! empty( $since ) ) {
			$where   .= ' AND created_at >= %s';
			$params[] = sanitize_text_field( $since );
		}

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM ' . self::table_name() . " WHERE {$where}",
				$params
			)
		);
	}
}
