<?php
/**
 * WooCommerce order page fraud controls.
 *
 * @package Borbila_SafeOrder
 */

defined( 'ABSPATH' ) || exit;

/**
 * Adds order edit controls and suspicious order badges.
 */
class BOS_Order_Metabox {

	/**
	 * Fraud service.
	 *
	 * @var BOS_Fraud
	 */
	private $fraud;

	/**
	 * Logger.
	 *
	 * @var BOS_Logger
	 */
	private $logger;

	/**
	 * Constructor.
	 *
	 * @param BOS_Fraud  $fraud  Fraud service.
	 * @param BOS_Logger $logger Logger.
	 */
	public function __construct( $fraud, $logger ) {
		$this->fraud  = $fraud;
		$this->logger = $logger;
	}

	/**
	 * Registers hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ), 20, 2 );
		add_action( 'admin_post_bos_order_fraud_action', array( $this, 'handle_order_action' ) );
		add_action( 'wp_ajax_bos_order_fraud_action', array( $this, 'handle_order_action' ) );
		add_action( 'admin_notices', array( $this, 'render_order_notice' ) );
	}

	/**
	 * Adds fraud control meta boxes.
	 *
	 * @param string          $screen Screen ID.
	 * @param WP_Post|object $object Current object.
	 * @return void
	 */
	public function add_meta_box( $screen, $object ) {
		unset( $object );

		$order_screen = function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop_order' ) : 'woocommerce_page_wc-orders';

		if ( ! in_array( $screen, array( 'shop_order', $order_screen ), true ) ) {
			return;
		}

		add_meta_box(
			'bos_fraud_control',
			__( 'SafeOrder Fraud Control', 'borbila-safeorder' ),
			array( $this, 'render_meta_box' ),
			$screen,
			'side',
			'high'
		);
	}

	/**
	 * Renders fraud control meta box.
	 *
	 * @param WP_Post|WC_Order $object Current order object.
	 * @return void
	 */
	public function render_meta_box( $object ) {
		$order = $object instanceof WC_Order ? $object : wc_get_order( $object->ID );

		if ( ! $order ) {
			return;
		}

		if ( ! $this->current_user_can_edit_order( $order->get_id() ) ) {
			echo '<p>' . esc_html__( 'You do not have permission to manage fraud controls for this order.', 'borbila-safeorder' ) . '</p>';
			return;
		}

		$phone      = $order->get_billing_phone();
		$email      = $order->get_billing_email();
		$ip         = $order->get_customer_ip_address();
		$suspicious = $this->fraud->is_order_suspicious( $order );
		$reason     = $this->fraud->get_suspicious_reason( $order );
		?>
		<div
			class="bos-metabox"
			data-bos-order-id="<?php echo esc_attr( $order->get_id() ); ?>"
			data-bos-order-nonce="<?php echo esc_attr( wp_create_nonce( 'bos_order_fraud_' . $order->get_id() ) ); ?>"
		>
			<div class="bos-metabox-notice" data-bos-metabox-notice hidden></div>
			<div class="bos-customer-facts">
				<?php $this->render_summary_line( __( 'Phone', 'borbila-safeorder' ), $phone ? $phone : __( 'Not available', 'borbila-safeorder' ) ); ?>
				<?php $this->render_summary_line( __( 'Email', 'borbila-safeorder' ), $email ? $email : __( 'Not available', 'borbila-safeorder' ) ); ?>
				<?php $this->render_summary_line( __( 'IP', 'borbila-safeorder' ), $ip ? $ip : __( 'Not available', 'borbila-safeorder' ) ); ?>
				<?php $this->render_summary_line( __( 'Fraud status', 'borbila-safeorder' ), $suspicious ? __( 'Suspicious', 'borbila-safeorder' ) : __( 'Clear', 'borbila-safeorder' ) ); ?>
				<?php $this->render_summary_line( __( 'Phone status', 'borbila-safeorder' ), $phone && $this->fraud->is_blocked( 'phone', $phone ) ? __( 'Blocked', 'borbila-safeorder' ) : __( 'Allowed', 'borbila-safeorder' ) ); ?>
				<?php $this->render_summary_line( __( 'Email status', 'borbila-safeorder' ), $email && $this->fraud->is_blocked( 'email', $email ) ? __( 'Blocked', 'borbila-safeorder' ) : __( 'Allowed', 'borbila-safeorder' ) ); ?>
				<?php $this->render_summary_line( __( 'IP status', 'borbila-safeorder' ), $ip && $this->fraud->is_blocked( 'ip', $ip ) ? __( 'Blocked', 'borbila-safeorder' ) : __( 'Allowed', 'borbila-safeorder' ) ); ?>
				<?php $this->render_summary_line( __( 'Previous orders', 'borbila-safeorder' ), (string) $this->count_previous_orders( $order ) ); ?>
			</div>

			<?php if ( $suspicious ) : ?>
				<div class="bos-order-warning"><?php esc_html_e( 'Marked as suspicious', 'borbila-safeorder' ); ?></div>
				<?php if ( $reason ) : ?>
					<p class="bos-note"><?php echo esc_html( $reason ); ?></p>
				<?php endif; ?>
			<?php endif; ?>

			<div class="bos-order-actions">
				<?php
				$this->render_action_button( $order, 'block_phone', __( 'Block Phone', 'borbila-safeorder' ), ! empty( $phone ) );
				$this->render_action_button( $order, 'block_email', __( 'Block Email', 'borbila-safeorder' ), ! empty( $email ) );
				$this->render_action_button( $order, 'block_ip', __( 'Block IP', 'borbila-safeorder' ), ! empty( $ip ) );
				?>
			</div>

			<div class="bos-suspicious-form">
				<label for="bos_suspicious_reason"><?php esc_html_e( 'Suspicious note', 'borbila-safeorder' ); ?></label>
				<textarea id="bos_suspicious_reason" rows="3"><?php echo esc_textarea( $reason ); ?></textarea>
				<button type="button" class="button bos-full-button bos-order-fraud-action" data-bos-fraud-action="mark_suspicious"><?php esc_html_e( 'Mark as Suspicious', 'borbila-safeorder' ); ?></button>
			</div>

			<?php if ( $suspicious ) : ?>
				<?php $this->render_action_button( $order, 'clear_suspicious', __( 'Clear Suspicious Mark', 'borbila-safeorder' ), true, 'bos-clear-button' ); ?>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Handles order fraud actions.
	 *
	 * @return void
	 */
	public function handle_order_action() {
		$order_id = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;

		check_admin_referer( 'bos_order_fraud_' . $order_id );

		if ( ! $this->current_user_can_edit_order( $order_id ) ) {
			wp_die( esc_html__( 'You do not have permission to manage this order.', 'borbila-safeorder' ) );
		}

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			wp_die( esc_html__( 'Order not found.', 'borbila-safeorder' ) );
		}

		$action = isset( $_POST['bos_fraud_action'] ) ? sanitize_key( wp_unslash( $_POST['bos_fraud_action'] ) ) : '';
		$result = true;
		$type   = '';
		$value  = '';

		switch ( $action ) {
			case 'block_phone':
				$type  = 'phone';
				$value = $order->get_billing_phone();
				break;

			case 'block_email':
				$type  = 'email';
				$value = $order->get_billing_email();
				break;

			case 'block_ip':
				$type  = 'ip';
				$value = $order->get_customer_ip_address();
				break;

			case 'mark_suspicious':
				$reason = isset( $_POST['bos_suspicious_reason'] ) ? sanitize_textarea_field( wp_unslash( $_POST['bos_suspicious_reason'] ) ) : '';
				$reason = $reason ? $reason : __( 'Marked from order page.', 'borbila-safeorder' );
				$result = $this->fraud->mark_order_suspicious( $order, $reason );

				if ( ! is_wp_error( $result ) ) {
					$this->logger->log(
						'suspicious_order_mark',
						array(
							'phone'    => $order->get_billing_phone(),
							'email'    => $order->get_billing_email(),
							'ip'       => $order->get_customer_ip_address(),
							'order_id' => $order_id,
							'message'  => $reason,
						)
					);
				}
				break;

			case 'clear_suspicious':
				$result = $this->fraud->clear_order_suspicious( $order );

				if ( ! is_wp_error( $result ) ) {
					$this->logger->log(
						'suspicious_order_clear',
						array(
							'phone'    => $order->get_billing_phone(),
							'email'    => $order->get_billing_email(),
							'ip'       => $order->get_customer_ip_address(),
							'order_id' => $order_id,
							'message'  => 'Suspicious order mark cleared.',
						)
					);
				}
				break;

			default:
				$result = new WP_Error( 'bos_invalid_action', __( 'Invalid fraud action.', 'borbila-safeorder' ) );
				break;
		}

		if ( $type && ! $value ) {
			$result = new WP_Error( 'bos_empty_value', __( 'No customer value was available to block.', 'borbila-safeorder' ) );
		} elseif ( $type ) {
			$result = $this->fraud->add_blocked_customer(
				$type,
				$value,
				sprintf(
					/* translators: %d: order ID */
					__( 'Blocked from order #%d.', 'borbila-safeorder' ),
					$order_id
				)
			);

			if ( ! is_wp_error( $result ) ) {
				$this->logger->log(
					'blocked_' . $type,
					array(
						'phone'    => $order->get_billing_phone(),
						'email'    => $order->get_billing_email(),
						'ip'       => $order->get_customer_ip_address(),
						'order_id' => $order_id,
						'message'  => sprintf(
							/* translators: 1: type, 2: order ID */
							__( 'Blocked %1$s from order #%2$d.', 'borbila-safeorder' ),
							$type,
							$order_id
						),
					)
				);
			}
		}

		$notice = is_wp_error( $result ) ? $result->get_error_message() : __( 'SafeOrder fraud control updated.', 'borbila-safeorder' );

		if ( wp_doing_ajax() ) {
			if ( is_wp_error( $result ) ) {
				wp_send_json_error( array( 'message' => $notice ), 400 );
			}

			wp_send_json_success( array( 'message' => $notice ) );
		}

		$this->redirect_to_order( $order, $notice, is_wp_error( $result ) ? 'error' : 'success' );
	}

	/**
	 * Renders order action notices.
	 *
	 * @return void
	 */
	public function render_order_notice() {
		if ( empty( $_GET['bos_order_notice'] ) ) {
			return;
		}

		$type    = isset( $_GET['bos_order_notice_type'] ) && 'error' === sanitize_key( wp_unslash( $_GET['bos_order_notice_type'] ) ) ? 'error' : 'success';
		$message = sanitize_text_field( rawurldecode( wp_unslash( $_GET['bos_order_notice'] ) ) );

		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $type ),
			esc_html( $message )
		);
	}

	/**
	 * Renders a summary line.
	 *
	 * @param string $label Label.
	 * @param string $value Value.
	 * @return void
	 */
	private function render_summary_line( $label, $value ) {
		?>
		<p><span><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( $value ); ?></strong></p>
		<?php
	}

	/**
	 * Counts previous orders for the same phone/email.
	 *
	 * @param WC_Order $order Order.
	 * @return int
	 */
	private function count_previous_orders( $order ) {
		$phone = BOS_Fraud::normalize_phone( $order->get_billing_phone() );
		$email = sanitize_email( $order->get_billing_email() );
		$args  = array(
			'limit'  => 50,
			'return' => 'ids',
			'status' => array( 'wc-pending', 'wc-processing', 'wc-on-hold', 'wc-completed', 'wc-cancelled', 'wc-refunded' ),
		);

		if ( $phone ) {
			$args['billing_phone'] = $phone;
		} elseif ( $email ) {
			$args['billing_email'] = $email;
		} else {
			return 0;
		}

		$count = 0;

		foreach ( wc_get_orders( $args ) as $order_id ) {
			if ( absint( $order_id ) !== $order->get_id() ) {
				++$count;
			}
		}

		return $count;
	}

	/**
	 * Renders a POST action button.
	 *
	 * @param WC_Order $order   Order.
	 * @param string   $action  Fraud action.
	 * @param string   $label   Button label.
	 * @param bool     $enabled Enabled.
	 * @param string   $class   Extra class.
	 * @return void
	 */
	private function render_action_button( $order, $action, $label, $enabled = true, $class = '' ) {
		unset( $order );
		?>
		<button type="button" class="button bos-full-button bos-order-fraud-action <?php echo esc_attr( $class ); ?>" data-bos-fraud-action="<?php echo esc_attr( $action ); ?>" <?php disabled( ! $enabled ); ?>><?php echo esc_html( $label ); ?></button>
		<?php
	}

	/**
	 * Checks order edit permissions.
	 *
	 * @param int $order_id Order ID.
	 * @return bool
	 */
	private function current_user_can_edit_order( $order_id ) {
		return current_user_can( 'edit_shop_order', absint( $order_id ) ) || current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
	}

	/**
	 * Redirects back to order screen.
	 *
	 * @param WC_Order $order  Order.
	 * @param string   $notice Notice.
	 * @param string   $type   Notice type.
	 * @return void
	 */
	private function redirect_to_order( $order, $notice, $type ) {
		$url = method_exists( $order, 'get_edit_order_url' ) ? $order->get_edit_order_url() : admin_url( 'post.php?post=' . absint( $order->get_id() ) . '&action=edit' );
		$url = add_query_arg(
			array(
				'bos_order_notice'      => rawurlencode( $notice ),
				'bos_order_notice_type' => 'error' === $type ? 'error' : 'success',
			),
			$url
		);

		wp_safe_redirect( $url );
		exit;
	}
}
