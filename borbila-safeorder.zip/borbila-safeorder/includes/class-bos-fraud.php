<?php
/**
 * Core fraud utilities and data access.
 *
 * @package Borbila_SafeOrder
 */

defined( 'ABSPATH' ) || exit;

/**
 * Handles block lists, suspicious order state, and order counting.
 */
class BOS_Fraud {

	const META_SUSPICIOUS       = '_bos_suspicious';
	const META_SUSPICIOUS_NOTE  = '_bos_suspicious_reason';
	const META_SUSPICIOUS_DATE  = '_bos_suspicious_marked_at';
	const META_SUSPICIOUS_USER  = '_bos_suspicious_marked_by';
	const BLOCK_ERROR_MESSAGE   = 'দুঃখিত, আপনার অর্ডারটি গ্রহণ করা যাচ্ছে না।';
	const PHONE_ERROR_MESSAGE   = 'সঠিক ১১ ডিজিটের মোবাইল নাম্বার দিন।';

	/**
	 * Logger instance.
	 *
	 * @var BOS_Logger
	 */
	private $logger;

	/**
	 * Constructor.
	 *
	 * @param BOS_Logger $logger Logger instance.
	 */
	public function __construct( $logger ) {
		$this->logger = $logger;
	}

	/**
	 * Returns blocked customers table name.
	 *
	 * @return string
	 */
	public static function blocked_table_name() {
		global $wpdb;

		return $wpdb->prefix . 'borbila_blocked_customers';
	}

	/**
	 * Normalizes Bangladesh phone numbers to 11 digit local format.
	 *
	 * @param string $phone Raw phone.
	 * @return string Empty string when invalid.
	 */
	public static function normalize_phone( $phone ) {
		$phone = trim( (string) $phone );

		if ( '' === $phone ) {
			return '';
		}

		$phone = strtr(
			$phone,
			array(
				'০' => '0',
				'১' => '1',
				'২' => '2',
				'৩' => '3',
				'৪' => '4',
				'৫' => '5',
				'৬' => '6',
				'৭' => '7',
				'৮' => '8',
				'৯' => '9',
			)
		);
		$phone = preg_replace( '/[\s\-().]/', '', $phone );

		if ( 0 === strpos( $phone, '00880' ) ) {
			$phone = '+' . substr( $phone, 2 );
		}

		if ( 1 === preg_match( '/^\+8801[0-9]{9}$/', $phone ) ) {
			return substr( $phone, 3 );
		}

		if ( 1 !== preg_match( '/^[0-9]+$/', $phone ) ) {
			return '';
		}

		if ( 1 === preg_match( '/^8801[0-9]{9}$/', $phone ) ) {
			return substr( $phone, 2 );
		}

		if ( 1 === preg_match( '/^01[0-9]{9}$/', $phone ) ) {
			return $phone;
		}

		return '';
	}

	/**
	 * Gets the customer IP address.
	 *
	 * @return string
	 */
	public static function get_client_ip() {
		if ( class_exists( 'WC_Geolocation' ) ) {
			$ip = WC_Geolocation::get_ip_address();
		} else {
			$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		}

		return sanitize_text_field( $ip );
	}

	/**
	 * Sanitizes and validates a block-list value.
	 *
	 * @param string $type  Value type.
	 * @param string $value Raw value.
	 * @return string|WP_Error
	 */
	public static function normalize_block_value( $type, $value ) {
		$type  = sanitize_key( $type );
		$value = is_string( $value ) ? trim( wp_unslash( $value ) ) : '';

		if ( 'phone' === $type ) {
			$normalized = self::normalize_phone( $value );

			return $normalized ? $normalized : new WP_Error( 'bos_invalid_phone', __( 'Enter a valid Bangladesh phone number.', 'borbila-safeorder' ) );
		}

		if ( 'email' === $type ) {
			$email = sanitize_email( strtolower( $value ) );

			return is_email( $email ) ? $email : new WP_Error( 'bos_invalid_email', __( 'Enter a valid email address.', 'borbila-safeorder' ) );
		}

		if ( 'ip' === $type ) {
			$ip       = sanitize_text_field( $value );
			$is_valid = function_exists( 'rest_is_ip_address' ) ? rest_is_ip_address( $ip ) : filter_var( $ip, FILTER_VALIDATE_IP );

			return $is_valid ? $ip : new WP_Error( 'bos_invalid_ip', __( 'Enter a valid IP address.', 'borbila-safeorder' ) );
		}

		return new WP_Error( 'bos_invalid_type', __( 'Choose a valid block type.', 'borbila-safeorder' ) );
	}

	/**
	 * Adds a customer identifier to the block list.
	 *
	 * @param string $type   phone/email/ip.
	 * @param string $value  Value to block.
	 * @param string $reason Reason.
	 * @return int|WP_Error
	 */
	public function add_blocked_customer( $type, $value, $reason = '' ) {
		global $wpdb;

		$type = sanitize_key( $type );

		if ( ! in_array( $type, array( 'phone', 'email', 'ip' ), true ) ) {
			return new WP_Error( 'bos_invalid_type', __( 'Choose a valid block type.', 'borbila-safeorder' ) );
		}

		$value = self::normalize_block_value( $type, $value );

		if ( is_wp_error( $value ) ) {
			return $value;
		}

		if ( $this->get_blocked_customer( $type, $value ) ) {
			return new WP_Error( 'bos_duplicate_block', __( 'This value is already blocked.', 'borbila-safeorder' ) );
		}

		$inserted = $wpdb->insert(
			self::blocked_table_name(),
			array(
				'type'       => $type,
				'value'      => $value,
				'reason'     => sanitize_textarea_field( $reason ),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s' )
		);

		if ( ! $inserted ) {
			return new WP_Error( 'bos_insert_failed', __( 'Could not save block list item.', 'borbila-safeorder' ) );
		}

		return (int) $wpdb->insert_id;
	}

	/**
	 * Gets a blocked customer row.
	 *
	 * @param string $type  phone/email/ip.
	 * @param string $value Normalized value.
	 * @return object|null
	 */
	public function get_blocked_customer( $type, $value ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::blocked_table_name() . ' WHERE type = %s AND value = %s LIMIT 1',
				sanitize_key( $type ),
				sanitize_text_field( $value )
			)
		);
	}

	/**
	 * Checks whether a customer identifier is blocked.
	 *
	 * @param string $type  phone/email/ip.
	 * @param string $value Raw value.
	 * @return bool
	 */
	public function is_blocked( $type, $value ) {
		$value = self::normalize_block_value( $type, $value );

		if ( is_wp_error( $value ) ) {
			return false;
		}

		return (bool) $this->get_blocked_customer( $type, $value );
	}

	/**
	 * Gets blocked customers.
	 *
	 * @param int $limit Limit.
	 * @return array
	 */
	public function get_blocked_customers( $limit = 100 ) {
		global $wpdb;

		$limit = max( 1, min( 500, absint( $limit ) ) );

		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::blocked_table_name() . ' ORDER BY created_at DESC, id DESC LIMIT %d',
				$limit
			)
		);
	}

	/**
	 * Deletes a blocked customer row.
	 *
	 * @param int $id Row ID.
	 * @return bool
	 */
	public function delete_blocked_customer( $id ) {
		global $wpdb;

		$id = absint( $id );

		if ( ! $id ) {
			return false;
		}

		return (bool) $wpdb->query(
			$wpdb->prepare(
				'DELETE FROM ' . self::blocked_table_name() . ' WHERE id = %d',
				$id
			)
		);
	}

	/**
	 * Counts block-list rows.
	 *
	 * @return int
	 */
	public function count_blocked_customers() {
		global $wpdb;

		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::blocked_table_name() );
	}

	/**
	 * Marks an order as suspicious.
	 *
	 * @param WC_Order|int $order  Order object or ID.
	 * @param string       $reason Reason.
	 * @return bool|WP_Error
	 */
	public function mark_order_suspicious( $order, $reason = '' ) {
		$order = $order instanceof WC_Order ? $order : wc_get_order( absint( $order ) );

		if ( ! $order ) {
			return new WP_Error( 'bos_invalid_order', __( 'Order not found.', 'borbila-safeorder' ) );
		}

		$order->update_meta_data( self::META_SUSPICIOUS, 'yes' );
		$order->update_meta_data( self::META_SUSPICIOUS_NOTE, sanitize_textarea_field( $reason ) );
		$order->update_meta_data( self::META_SUSPICIOUS_DATE, current_time( 'mysql' ) );
		$order->update_meta_data( self::META_SUSPICIOUS_USER, get_current_user_id() );
		$order->save();

		return true;
	}

	/**
	 * Clears the suspicious flag from an order.
	 *
	 * @param WC_Order|int $order Order object or ID.
	 * @return bool|WP_Error
	 */
	public function clear_order_suspicious( $order ) {
		$order = $order instanceof WC_Order ? $order : wc_get_order( absint( $order ) );

		if ( ! $order ) {
			return new WP_Error( 'bos_invalid_order', __( 'Order not found.', 'borbila-safeorder' ) );
		}

		$order->delete_meta_data( self::META_SUSPICIOUS );
		$order->delete_meta_data( self::META_SUSPICIOUS_NOTE );
		$order->delete_meta_data( self::META_SUSPICIOUS_DATE );
		$order->delete_meta_data( self::META_SUSPICIOUS_USER );
		$order->save();

		return true;
	}

	/**
	 * Checks whether an order is suspicious.
	 *
	 * @param WC_Order|int $order Order object or ID.
	 * @return bool
	 */
	public function is_order_suspicious( $order ) {
		$order = $order instanceof WC_Order ? $order : wc_get_order( absint( $order ) );

		return $order && 'yes' === $order->get_meta( self::META_SUSPICIOUS, true );
	}

	/**
	 * Gets suspicious reason.
	 *
	 * @param WC_Order|int $order Order object or ID.
	 * @return string
	 */
	public function get_suspicious_reason( $order ) {
		$order = $order instanceof WC_Order ? $order : wc_get_order( absint( $order ) );

		return $order ? (string) $order->get_meta( self::META_SUSPICIOUS_NOTE, true ) : '';
	}

	/**
	 * Counts suspicious orders.
	 *
	 * @return int
	 */
	public function count_suspicious_orders() {
		$result = wc_get_orders(
			array(
				'limit'      => 1,
				'paginate'   => true,
				'return'     => 'ids',
				'meta_query' => array(
					array(
						'key'     => self::META_SUSPICIOUS,
						'value'   => 'yes',
						'compare' => '=',
					),
				),
			)
		);

		return is_object( $result ) && isset( $result->total ) ? absint( $result->total ) : 0;
	}

	/**
	 * Gets recent suspicious orders.
	 *
	 * @param int $limit Limit.
	 * @return array
	 */
	public function get_recent_suspicious_orders( $limit = 10 ) {
		return wc_get_orders(
			array(
				'limit'      => max( 1, min( 50, absint( $limit ) ) ),
				'orderby'    => 'date',
				'order'      => 'DESC',
				'return'     => 'objects',
				'meta_query' => array(
					array(
						'key'     => self::META_SUSPICIOUS,
						'value'   => 'yes',
						'compare' => '=',
					),
				),
			)
		);
	}

	/**
	 * Counts existing orders by field within a time window.
	 *
	 * @param string $field        billing_phone or customer_ip_address.
	 * @param string $value        Field value.
	 * @param int    $hours        Window in hours.
	 * @param int    $max_to_check Optional max to query plus one.
	 * @return int
	 */
	public function count_orders_by_field( $field, $value, $hours, $max_to_check = 0 ) {
		$field = sanitize_key( $field );
		$value = sanitize_text_field( $value );
		$hours = max( 1, absint( $hours ) );

		if ( '' === $value || ! in_array( $field, array( 'billing_phone', 'customer_ip_address' ), true ) ) {
			return 0;
		}

		$limit = $max_to_check > 0 ? max( 1, absint( $max_to_check ) + 1 ) : -1;

		$args = array(
			'type'         => 'shop_order',
			'status'       => apply_filters( 'bos_countable_order_statuses', array( 'wc-pending', 'wc-processing', 'wc-on-hold', 'wc-completed' ) ),
			'limit'        => $limit,
			'return'       => 'ids',
			'date_created' => '>' . ( time() - ( $hours * HOUR_IN_SECONDS ) ),
			$field         => $value,
		);

		return count( wc_get_orders( $args ) );
	}
}
