<?php
/**
 * Fraud Control settings and block-list form handlers.
 *
 * @package Borbila_SafeOrder
 */

defined( 'ABSPATH' ) || exit;

/**
 * Saves Fraud Control settings and blocked customer records.
 */
class BOS_Settings {

	const OPTION_NAME = 'bos_settings';

	/**
	 * Fraud service.
	 *
	 * @var BOS_Fraud
	 */
	private $fraud;

	/**
	 * Logger.
	 *
	 * @var BOS_Logger
	 */
	private $logger;

	/**
	 * License service.
	 *
	 * @var BOS_License
	 */
	private $license;

	/**
	 * Constructor.
	 *
	 * @param BOS_Fraud   $fraud   Fraud service.
	 * @param BOS_Logger  $logger  Logger.
	 * @param BOS_License $license License service.
	 */
	public function __construct( $fraud, $logger, $license ) {
		$this->fraud   = $fraud;
		$this->logger  = $logger;
		$this->license = $license;
	}

	/**
	 * Default settings.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'allow_shop_manager_access'  => 0,
			'delete_data_on_uninstall'   => 0,
			'module_fraud_protection'    => 1,
			'module_phone_validation'    => 1,
			'module_block_list'          => 1,
			'module_order_limit'         => 1,
			'module_order_risk_tagging'  => 1,
			'same_phone_restriction_enabled' => 0,
			'same_ip_restriction_enabled'    => 0,
			'same_restriction_window_hours'  => 24,
			'same_restriction_max_orders'    => 2,
			'global_limit_enabled'           => 0,
			'global_phone_max_orders'        => 2,
			'global_ip_max_orders'           => 2,
			'global_limit_window_hours'      => 24,
		);
	}

	/**
	 * Gets module setting keys and labels.
	 *
	 * @return array
	 */
	public static function modules() {
		return array(
			'fraud_protection'    => __( 'Fraud Protection', 'borbila-safeorder' ),
			'phone_validation'    => __( 'Phone Validation', 'borbila-safeorder' ),
			'block_list'          => __( 'Block List', 'borbila-safeorder' ),
			'order_limit'         => __( 'Order Limit', 'borbila-safeorder' ),
			'order_risk_tagging'  => __( 'Suspicious Orders', 'borbila-safeorder' ),
		);
	}

	/**
	 * Gets merged settings.
	 *
	 * @return array
	 */
	public static function get_settings() {
		$settings = get_option( self::OPTION_NAME, array() );
		$defaults = self::defaults();

		return array_intersect_key( wp_parse_args( is_array( $settings ) ? $settings : array(), $defaults ), $defaults );
	}

	/**
	 * Checks whether a module is enabled.
	 *
	 * @param string $module Module slug without module_ prefix.
	 * @return bool
	 */
	public static function is_module_enabled( $module ) {
		$settings = self::get_settings();
		$key      = 'module_' . sanitize_key( $module );

		return ! empty( $settings[ $key ] );
	}

	/**
	 * Checks whether current user can view plugin pages.
	 *
	 * @return bool
	 */
	public static function current_user_can_view() {
		$settings = self::get_settings();

		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		return ! empty( $settings['allow_shop_manager_access'] ) && current_user_can( 'manage_woocommerce' );
	}

	/**
	 * Registers admin-post handlers.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'admin_post_bos_save_settings', array( $this, 'handle_save_settings' ) );
		add_action( 'admin_post_bos_toggle_module', array( $this, 'handle_toggle_module' ) );
		add_action( 'admin_post_bos_add_blocked_customer', array( $this, 'handle_add_blocked_customer' ) );
		add_action( 'admin_post_bos_delete_blocked_customer', array( $this, 'handle_delete_blocked_customer' ) );
	}

	/**
	 * Checks whether current user can manage this plugin.
	 *
	 * @return bool
	 */
	public static function current_user_can_manage() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Saves Fraud Control settings.
	 *
	 * @return void
	 */
	public function handle_save_settings() {
		check_admin_referer( 'bos_save_settings' );

		if ( ! self::current_user_can_manage() ) {
			wp_die( esc_html__( 'You do not have permission to manage these settings.', 'borbila-safeorder' ) );
		}

		$section  = isset( $_POST['bos_settings_section'] ) ? sanitize_key( wp_unslash( $_POST['bos_settings_section'] ) ) : 'order_limits';
		$settings = self::get_settings();

		$license_locked_keys = array(
			'same_phone_restriction_enabled',
			'same_ip_restriction_enabled',
			'global_limit_enabled',
		);

		foreach ( $this->get_keys_for_save( $section ) as $key ) {
			if ( ! $this->license->is_active() && in_array( $key, $license_locked_keys, true ) ) {
				continue;
			}

			$settings[ $key ] = $this->sanitize_setting_value( $key, isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : null );
		}

		update_option( self::OPTION_NAME, $settings );
		$this->redirect_with_notice( 'settings-saved', 'success', $section );
	}

	/**
	 * Toggles a Fraud Control module from an inline tab switch.
	 *
	 * @return void
	 */
	public function handle_toggle_module() {
		check_admin_referer( 'bos_toggle_module' );

		if ( ! self::current_user_can_manage() ) {
			wp_die( esc_html__( 'You do not have permission to manage module settings.', 'borbila-safeorder' ) );
		}

		if ( ! $this->license->is_active() ) {
			$this->redirect_to_license_required();
		}

		$module  = isset( $_REQUEST['module'] ) ? sanitize_key( wp_unslash( $_REQUEST['module'] ) ) : '';
		$modules = self::modules();

		if ( ! isset( $modules[ $module ] ) ) {
			wp_die( esc_html__( 'Invalid module.', 'borbila-safeorder' ) );
		}

		$settings = self::get_settings();
		$settings[ 'module_' . $module ] = ! empty( $_REQUEST['enabled'] ) ? 1 : 0;

		update_option( self::OPTION_NAME, $settings );

		$return_url = isset( $_REQUEST['redirect'] ) ? esc_url_raw( rawurldecode( wp_unslash( $_REQUEST['redirect'] ) ) ) : wp_get_referer();
		$return_url = wp_validate_redirect( $return_url, admin_url( 'admin.php?page=bos-fraud-control' ) );

		wp_safe_redirect( $return_url );
		exit;
	}

	/**
	 * Adds a blocked customer identifier.
	 *
	 * @return void
	 */
	public function handle_add_blocked_customer() {
		check_admin_referer( 'bos_add_blocked_customer' );

		if ( ! self::current_user_can_manage() ) {
			wp_die( esc_html__( 'You do not have permission to manage blocked customers.', 'borbila-safeorder' ) );
		}

		$type   = isset( $_POST['bos_type'] ) ? sanitize_key( wp_unslash( $_POST['bos_type'] ) ) : '';
		$value  = isset( $_POST['bos_value'] ) ? sanitize_text_field( wp_unslash( $_POST['bos_value'] ) ) : '';
		$reason = isset( $_POST['bos_reason'] ) ? sanitize_textarea_field( wp_unslash( $_POST['bos_reason'] ) ) : '';
		$result = $this->fraud->add_blocked_customer( $type, $value, $reason );

		if ( is_wp_error( $result ) ) {
			$this->redirect_with_notice( rawurlencode( $result->get_error_message() ), 'error', 'blocked-customers' );
		}

		$normalized = BOS_Fraud::normalize_block_value( $type, $value );
		$log_data   = array(
			'message' => sprintf(
				/* translators: %s: block type */
				__( 'Blocked %s from Fraud Control.', 'borbila-safeorder' ),
				$type
			),
		);

		if ( ! is_wp_error( $normalized ) ) {
			$log_data[ $type ] = $normalized;
		}

		$this->logger->log( 'blocked_' . $type, $log_data );
		$this->redirect_with_notice( 'block-added', 'success', 'blocked-customers' );
	}

	/**
	 * Deletes a blocked customer identifier.
	 *
	 * @return void
	 */
	public function handle_delete_blocked_customer() {
		$id = isset( $_GET['id'] ) ? absint( wp_unslash( $_GET['id'] ) ) : 0;

		check_admin_referer( 'bos_delete_blocked_customer_' . $id );

		if ( ! self::current_user_can_manage() ) {
			wp_die( esc_html__( 'You do not have permission to manage blocked customers.', 'borbila-safeorder' ) );
		}

		$deleted = $this->fraud->delete_blocked_customer( $id );
		$this->redirect_with_notice( $deleted ? 'block-deleted' : 'block-delete-failed', $deleted ? 'success' : 'error', 'blocked-customers' );
	}

	/**
	 * Sanitizes an integer with min/max bounds.
	 *
	 * @param mixed $value Value.
	 * @param int   $min   Minimum.
	 * @param int   $max   Maximum.
	 * @return int
	 */
	private function sanitize_positive_int( $value, $min, $max ) {
		$value = absint( $value );
		$value = max( absint( $min ), $value );

		return min( absint( $max ), $value );
	}

	/**
	 * Gets setting keys for a section save.
	 *
	 * @param string $section Section key.
	 * @return array
	 */
	private function get_keys_for_save( $section ) {
		return array(
			'same_phone_restriction_enabled',
			'same_ip_restriction_enabled',
			'same_restriction_window_hours',
			'same_restriction_max_orders',
			'global_limit_enabled',
			'global_phone_max_orders',
			'global_ip_max_orders',
			'global_limit_window_hours',
		);
	}

	/**
	 * Sanitizes a setting by key.
	 *
	 * @param string $key   Setting key.
	 * @param mixed  $value Raw value.
	 * @return mixed
	 */
	public function sanitize_setting_value( $key, $value ) {
		$key = sanitize_key( $key );

		if ( 0 === strpos( $key, 'module_' ) || in_array( $key, array( 'allow_shop_manager_access', 'delete_data_on_uninstall', 'same_phone_restriction_enabled', 'same_ip_restriction_enabled', 'global_limit_enabled' ), true ) ) {
			return ! empty( $value ) ? 1 : 0;
		}

		if ( in_array( $key, array( 'same_restriction_window_hours', 'global_limit_window_hours' ), true ) ) {
			return $this->sanitize_positive_int( $value, 1, 720 );
		}

		if ( in_array( $key, array( 'same_restriction_max_orders', 'global_phone_max_orders', 'global_ip_max_orders' ), true ) ) {
			return $this->sanitize_positive_int( $value, 1, 999 );
		}

		$defaults = self::defaults();

		return isset( $defaults[ $key ] ) ? $defaults[ $key ] : sanitize_text_field( (string) $value );
	}

	/**
	 * Redirects back to Fraud Control with a notice marker.
	 *
	 * @param string $message Notice code or encoded text.
	 * @param string $type    success/error.
	 * @param string $tab     Fraud Control tab key.
	 * @return void
	 */
	private function redirect_with_notice( $message, $type = 'success', $tab = 'blocked-customers' ) {
		$tab = sanitize_key( $tab );

		if ( 'order_limits' === $tab ) {
			$tab = 'order-limits';
		}

		$url = add_query_arg(
			array(
				'page'            => 'bos-fraud-control',
				'tab'             => $tab,
				'bos_notice'      => sanitize_text_field( $message ),
				'bos_notice_type' => 'error' === $type ? 'error' : 'success',
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Redirects locked module requests to the license screen.
	 *
	 * @return void
	 */
	private function redirect_to_license_required() {
		$url = add_query_arg(
			array(
				'page'                 => 'bos-fraud-control',
				'tab'                  => 'license',
				'bos_license_required' => 1,
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}
}
