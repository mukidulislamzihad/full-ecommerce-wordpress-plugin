<?php
/**
 * Checkout fraud guard.
 *
 * @package Borbila_SafeOrder
 */

defined( 'ABSPATH' ) || exit;

/**
 * Validates checkout data and blocks risky orders.
 */
class BOS_Checkout {

	/**
	 * Fraud service.
	 *
	 * @var BOS_Fraud
	 */
	private $fraud;

	/**
	 * Logger.
	 *
	 * @var BOS_Logger
	 */
	private $logger;

	/**
	 * Constructor.
	 *
	 * @param BOS_Fraud  $fraud  Fraud service.
	 * @param BOS_Logger $logger Logger.
	 */
	public function __construct( $fraud, $logger ) {
		$this->fraud  = $fraud;
		$this->logger = $logger;
	}

	/**
	 * Registers checkout hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_filter( 'woocommerce_checkout_posted_data', array( $this, 'normalize_checkout_phone' ), 20 );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'validate_classic_checkout' ), 20, 2 );
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( $this, 'validate_store_api_checkout' ), 20, 2 );
	}

	/**
	 * Normalizes valid classic checkout phone input before WooCommerce creates the order.
	 *
	 * @param array $data Posted checkout data.
	 * @return array
	 */
	public function normalize_checkout_phone( $data ) {
		if ( ! BOS_Settings::is_module_enabled( 'phone_validation' ) ) {
			return $data;
		}

		if ( isset( $data['billing_phone'] ) ) {
			$phone = BOS_Fraud::normalize_phone( wc_clean( wp_unslash( $data['billing_phone'] ) ) );

			if ( $phone ) {
				$data['billing_phone'] = $phone;
			}
		}

		return $data;
	}

	/**
	 * Validates classic shortcode checkout.
	 *
	 * @param array    $data   Posted checkout data.
	 * @param WP_Error $errors Checkout errors.
	 * @return void
	 */
	public function validate_classic_checkout( $data, $errors ) {
		$raw_phone = isset( $data['billing_phone'] ) ? wc_clean( wp_unslash( $data['billing_phone'] ) ) : '';
		$phone     = BOS_Fraud::normalize_phone( $raw_phone );
		$email     = isset( $data['billing_email'] ) ? sanitize_email( wp_unslash( $data['billing_email'] ) ) : '';
		$ip        = BOS_Fraud::get_client_ip();
		$validate_phone = (bool) apply_filters( 'borbila_safeorder_phone_validation', BOS_Settings::is_module_enabled( 'phone_validation' ), $raw_phone, $data );

		if ( $validate_phone && '' !== trim( (string) $raw_phone ) && ! $phone ) {
			$errors->add( 'bos_invalid_phone', BOS_Fraud::PHONE_ERROR_MESSAGE );
			$this->logger->log(
				'blocked_checkout',
				array(
					'phone'   => sanitize_text_field( $raw_phone ),
					'email'   => $email,
					'ip'      => $ip,
					'message' => 'Invalid billing phone number.',
				)
			);
			return;
		}

		$block = $this->get_checkout_block_reason( $phone, $email, $ip );

		do_action( 'borbila_safeorder_after_fraud_check', $block, $phone, $email, $ip, 0 );

		if ( $block ) {
			$errors->add( 'bos_checkout_blocked', BOS_Fraud::BLOCK_ERROR_MESSAGE );
			$this->logger->log(
				$block['type'],
				array(
					'phone'   => $phone,
					'email'   => $email,
					'ip'      => $ip,
					'message' => $block['message'],
				)
			);
			do_action( 'borbila_safeorder_after_order_blocked', $block, $phone, $email, $ip, 0 );
		}
	}

	/**
	 * Validates Store API / Checkout Block checkout.
	 *
	 * @param WC_Order        $order   Draft order.
	 * @param WP_REST_Request $request Store API request.
	 * @return void
	 *
	 * @throws Exception When checkout should be blocked.
	 */
	public function validate_store_api_checkout( $order, $request ) {
		if ( ! $order instanceof WC_Order || ! $request instanceof WP_REST_Request ) {
			return;
		}

		$billing   = (array) $request->get_param( 'billing_address' );
		$raw_phone = isset( $billing['phone'] ) ? wc_clean( wp_unslash( $billing['phone'] ) ) : $order->get_billing_phone();
		$phone     = BOS_Fraud::normalize_phone( $raw_phone );
		$email     = isset( $billing['email'] ) ? sanitize_email( wp_unslash( $billing['email'] ) ) : $order->get_billing_email();
		$ip        = BOS_Fraud::get_client_ip();
		$order_id  = $order instanceof WC_Order ? $order->get_id() : 0;
		$validate_phone = (bool) apply_filters( 'borbila_safeorder_phone_validation', BOS_Settings::is_module_enabled( 'phone_validation' ), $raw_phone, $billing );

		if ( $validate_phone && '' !== trim( (string) $raw_phone ) && ! $phone ) {
			$this->logger->log(
				'blocked_checkout',
				array(
					'phone'    => sanitize_text_field( $raw_phone ),
					'email'    => $email,
					'ip'       => $ip,
					'order_id' => $order_id,
					'message'  => 'Invalid billing phone number.',
				)
			);
			$this->throw_store_api_error( 'bos_invalid_phone', BOS_Fraud::PHONE_ERROR_MESSAGE );
		}

		if ( $phone ) {
			$order->set_billing_phone( $phone );
		}

		if ( $email ) {
			$order->set_billing_email( $email );
		}

		$block = $this->get_checkout_block_reason( $phone, $email, $ip );

		do_action( 'borbila_safeorder_after_fraud_check', $block, $phone, $email, $ip, $order_id );

		if ( $block ) {
			$this->logger->log(
				$block['type'],
				array(
					'phone'    => $phone,
					'email'    => $email,
					'ip'       => $ip,
					'order_id' => $order_id,
					'message'  => $block['message'],
				)
			);
			do_action( 'borbila_safeorder_after_order_blocked', $block, $phone, $email, $ip, $order_id );
			$this->throw_store_api_error( 'bos_checkout_blocked', BOS_Fraud::BLOCK_ERROR_MESSAGE );
		}
	}

	/**
	 * Determines whether checkout should be blocked.
	 *
	 * @param string $phone Normalized phone.
	 * @param string $email Email.
	 * @param string $ip    IP address.
	 * @return array|null
	 */
	private function get_checkout_block_reason( $phone, $email, $ip ) {
		if ( ! BOS_Settings::is_module_enabled( 'fraud_protection' ) ) {
			return null;
		}

		if ( BOS_Settings::is_module_enabled( 'block_list' ) && $phone && $this->fraud->is_blocked( 'phone', $phone ) ) {
			return array(
				'type'    => 'blocked_checkout',
				'message' => 'Blocked checkout attempt: phone number is blocked.',
			);
		}

		if ( BOS_Settings::is_module_enabled( 'block_list' ) && $email && $this->fraud->is_blocked( 'email', $email ) ) {
			return array(
				'type'    => 'blocked_checkout',
				'message' => 'Blocked checkout attempt: email address is blocked.',
			);
		}

		if ( BOS_Settings::is_module_enabled( 'block_list' ) && $ip && $this->fraud->is_blocked( 'ip', $ip ) ) {
			return array(
				'type'    => 'blocked_checkout',
				'message' => 'Blocked checkout attempt: IP address is blocked.',
			);
		}

		$settings = BOS_Settings::get_settings();

		if ( BOS_Settings::is_module_enabled( 'order_limit' ) && ! empty( $settings['same_phone_restriction_enabled'] ) && $phone ) {
			$count = $this->fraud->count_orders_by_field( 'billing_phone', $phone, $settings['same_restriction_window_hours'], $settings['same_restriction_max_orders'] );

			if ( $count >= absint( $settings['same_restriction_max_orders'] ) ) {
				return array(
					'type'    => 'order_limit_exceeded',
					'message' => 'Same phone order restriction exceeded.',
				);
			}
		}

		if ( BOS_Settings::is_module_enabled( 'order_limit' ) && ! empty( $settings['same_ip_restriction_enabled'] ) && $ip ) {
			$count = $this->fraud->count_orders_by_field( 'customer_ip_address', $ip, $settings['same_restriction_window_hours'], $settings['same_restriction_max_orders'] );

			if ( $count >= absint( $settings['same_restriction_max_orders'] ) ) {
				return array(
					'type'    => 'order_limit_exceeded',
					'message' => 'Same IP order restriction exceeded.',
				);
			}
		}

		if ( BOS_Settings::is_module_enabled( 'order_limit' ) && ! empty( $settings['global_limit_enabled'] ) ) {
			$phone_count = $this->fraud->count_orders_by_field( 'billing_phone', $phone, $settings['global_limit_window_hours'], $settings['global_phone_max_orders'] );

			if ( $phone_count >= absint( $settings['global_phone_max_orders'] ) ) {
				return array(
					'type'    => 'order_limit_exceeded',
					'message' => 'Global phone order limit exceeded.',
				);
			}

			if ( $ip ) {
				$ip_count = $this->fraud->count_orders_by_field( 'customer_ip_address', $ip, $settings['global_limit_window_hours'], $settings['global_ip_max_orders'] );

				if ( $ip_count >= absint( $settings['global_ip_max_orders'] ) ) {
					return array(
						'type'    => 'order_limit_exceeded',
						'message' => 'Global IP order limit exceeded.',
					);
				}
			}
		}

		return null;
	}

	/**
	 * Throws a Store API compatible checkout error.
	 *
	 * @param string $code    Error code.
	 * @param string $message Error message.
	 * @return void
	 *
	 * @throws Exception Always throws.
	 */
	private function throw_store_api_error( $code, $message ) {
		if ( class_exists( '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException' ) ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( $code, $message, 400 );
		}

		throw new Exception( $message );
	}
}
