<?php
/**
 * Fraud Control admin page.
 *
 * @package Borbila_SafeOrder
 */

defined( 'ABSPATH' ) || exit;

/**
 * Renders SafeOrder Fraud Control screens.
 */
class BOS_Admin {

	/**
	 * Fraud service.
	 *
	 * @var BOS_Fraud
	 */
	private $fraud;

	/**
	 * Logger.
	 *
	 * @var BOS_Logger
	 */
	private $logger;

	/**
	 * Settings handler.
	 *
	 * @var BOS_Settings
	 */
	private $settings_handler;

	/**
	 * License service.
	 *
	 * @var BOS_License
	 */
	private $license;

	/**
	 * Constructor.
	 *
	 * @param BOS_Fraud    $fraud    Fraud service.
	 * @param BOS_Logger   $logger   Logger.
	 * @param BOS_Settings $settings Settings handler.
	 * @param BOS_License  $license  License service.
	 */
	public function __construct( $fraud, $logger, $settings, $license ) {
		$this->fraud            = $fraud;
		$this->logger           = $logger;
		$this->settings_handler = $settings;
		$this->license          = $license;
	}

	/**
	 * Registers admin hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_notices', array( $this, 'render_admin_notice' ) );
	}

	/**
	 * Admin capability used for menu pages.
	 *
	 * @param string $context Capability context.
	 * @return string
	 */
	public static function capability( $context = 'view' ) {
		if ( 'manage' === $context ) {
			return 'manage_options';
		}

		$settings = BOS_Settings::get_settings();

		return ! empty( $settings['allow_shop_manager_access'] ) ? 'manage_woocommerce' : 'manage_options';
	}

	/**
	 * Checks whether current user can view plugin admin screens.
	 *
	 * @return bool
	 */
	public static function can_view() {
		return BOS_Settings::current_user_can_view();
	}

	/**
	 * Checks whether current user can manage plugin settings.
	 *
	 * @return bool
	 */
	public static function can_manage() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Registers the single Fraud Control menu.
	 *
	 * @return void
	 */
	public function register_menu() {
		add_menu_page(
			__( 'SafeOrder', 'borbila-safeorder' ),
			__( 'SafeOrder', 'borbila-safeorder' ),
			self::capability(),
			'bos-fraud-control',
			array( $this, 'render_fraud_control_page' ),
			'dashicons-shield-alt',
			56
		);
	}

	/**
	 * Enqueues scoped admin assets.
	 *
	 * @param string $hook Hook suffix.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		$screen    = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$screen_id = $screen ? $screen->id : '';
		$page      = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		$is_order  = in_array( $screen_id, array( 'shop_order', 'edit-shop_order', 'woocommerce_page_wc-orders' ), true ) || false !== strpos( $screen_id, 'wc-orders' );

		if ( 'bos-fraud-control' !== $page && 'toplevel_page_bos-fraud-control' !== $screen_id && ! $is_order ) {
			return;
		}

		$admin_css_file    = BOS_PLUGIN_PATH . 'assets/css/admin.css';
		$admin_css_version = BOS_VERSION . ( file_exists( $admin_css_file ) ? '-' . filemtime( $admin_css_file ) : '' );
		$admin_js_file     = BOS_PLUGIN_PATH . 'assets/js/admin.js';
		$admin_js_version  = BOS_VERSION . ( file_exists( $admin_js_file ) ? '-' . filemtime( $admin_js_file ) : '' );

		wp_enqueue_style( 'bos-admin', BOS_PLUGIN_URL . 'assets/css/admin.css', array(), $admin_css_version );
		wp_enqueue_script( 'bos-admin', BOS_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), $admin_js_version, true );
		wp_localize_script(
			'bos-admin',
			'bosAdmin',
			array(
				'licenseRequiredTitle'   => __( 'License required', 'borbila-safeorder' ),
				'licenseRequiredMessage' => __( 'Please activate your license to enable SafeOrder modules.', 'borbila-safeorder' ),
				'activateLicenseLabel'   => __( 'Activate License', 'borbila-safeorder' ),
				'dismissLabel'           => __( 'Dismiss', 'borbila-safeorder' ),
				'licenseUrl'             => admin_url( 'admin.php?page=bos-fraud-control&tab=license' ),
			)
		);
	}

	/**
	 * Renders redirected admin notices.
	 *
	 * @return void
	 */
	public function render_admin_notice() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

		if ( 'bos-fraud-control' !== $page || empty( $_GET['bos_notice'] ) ) {
			return;
		}

		$notice = sanitize_text_field( wp_unslash( $_GET['bos_notice'] ) );
		$type   = isset( $_GET['bos_notice_type'] ) && 'error' === sanitize_key( wp_unslash( $_GET['bos_notice_type'] ) ) ? 'error' : 'success';

		$messages = array(
			'settings-saved'      => __( 'Settings saved.', 'borbila-safeorder' ),
			'block-added'         => __( 'Blocked customer saved.', 'borbila-safeorder' ),
			'block-deleted'       => __( 'Blocked customer removed.', 'borbila-safeorder' ),
			'block-delete-failed' => __( 'Could not remove blocked customer.', 'borbila-safeorder' ),
		);

		$message = isset( $messages[ $notice ] ) ? $messages[ $notice ] : rawurldecode( $notice );

		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $type ),
			esc_html( $message )
		);
	}

	/**
	 * Renders Fraud Control section with internal tabs.
	 *
	 * @return void
	 */
	public function render_fraud_control_page() {
		if ( ! self::can_view() ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'borbila-safeorder' ) );
		}

		$active = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'blocked-customers';
		$tabs   = array(
			'blocked-customers'  => array(
				'label' => __( 'Blocked Customers', 'borbila-safeorder' ),
				'icon'  => 'dashicons-shield',
				'url'   => admin_url( 'admin.php?page=bos-fraud-control&tab=blocked-customers' ),
			),
			'phone-validation'   => array(
				'label' => __( 'Phone Validation', 'borbila-safeorder' ),
				'icon'  => 'dashicons-smartphone',
				'url'   => admin_url( 'admin.php?page=bos-fraud-control&tab=phone-validation' ),
			),
			'order-limits'       => array(
				'label' => __( 'Order Limits', 'borbila-safeorder' ),
				'icon'  => 'dashicons-clock',
				'url'   => admin_url( 'admin.php?page=bos-fraud-control&tab=order-limits' ),
			),
			'fraud-logs'         => array(
				'label' => __( 'Fraud Logs', 'borbila-safeorder' ),
				'icon'  => 'dashicons-list-view',
				'url'   => admin_url( 'admin.php?page=bos-fraud-control&tab=fraud-logs' ),
			),
			'suspicious-orders'  => array(
				'label' => __( 'Suspicious Orders', 'borbila-safeorder' ),
				'icon'  => 'dashicons-warning',
				'url'   => admin_url( 'admin.php?page=bos-fraud-control&tab=suspicious-orders' ),
			),
			'license'            => array(
				'label' => __( 'License', 'borbila-safeorder' ),
				'icon'  => 'dashicons-admin-network',
				'url'   => admin_url( 'admin.php?page=bos-fraud-control&tab=license' ),
			),
		);

		$active = isset( $tabs[ $active ] ) ? $active : 'blocked-customers';
		?>
		<div class="wrap bos-wrap">
			<?php self::render_header( __( 'SafeOrder Pro', 'borbila-safeorder' ), __( 'Smarter WooCommerce fraud protection, safer orders, and faster customer review.', 'borbila-safeorder' ), $this->license->is_active() ); ?>
			<?php self::render_section_tabs( $tabs, $active ); ?>
				<?php
				switch ( $active ) {
					case 'phone-validation':
						$this->render_phone_validation_tab();
						break;
					case 'order-limits':
						$this->render_order_limits_tab();
						break;
					case 'fraud-logs':
						$this->render_fraud_logs_tab();
						break;
					case 'suspicious-orders':
						$this->render_suspicious_orders_tab();
						break;
					case 'license':
						$this->render_license_tab();
						break;
					case 'blocked-customers':
					default:
						$this->render_blocked_customers_tab();
						break;
				}
				?>
			<?php self::close_section_tabs(); ?>
		</div>
		<?php
	}

	/**
	 * Renders a consistent page header.
	 *
	 * @param string $title    Title.
	 * @param string $subtitle      Subtitle.
	 * @param bool   $license_active License status.
	 * @return void
	 */
	public static function render_header( $title, $subtitle, $license_active = false ) {
		?>
		<div class="bos-page-header">
			<div class="bos-page-title">
				<span class="bos-brand-mark" aria-hidden="true"><span class="dashicons dashicons-shield-alt"></span></span>
				<div>
					<h1><?php echo esc_html( $title ); ?></h1>
					<p><?php echo esc_html( $subtitle ); ?></p>
				</div>
			</div>
			<div class="bos-header-badges">
				<span class="bos-license-badge <?php echo $license_active ? 'is-active' : 'is-inactive'; ?>">
					<span class="dashicons <?php echo $license_active ? 'dashicons-yes-alt' : 'dashicons-lock'; ?>" aria-hidden="true"></span>
					<?php echo esc_html( $license_active ? __( 'Licensed', 'borbila-safeorder' ) : __( 'License required', 'borbila-safeorder' ) ); ?>
				</span>
				<span class="bos-version-badge"><?php echo esc_html( 'v' . BOS_VERSION ); ?></span>
			</div>
		</div>
		<?php
	}

	/**
	 * Opens a two-column tab layout.
	 *
	 * @param array  $tabs   Tabs.
	 * @param string $active Active key.
	 * @return void
	 */
	public static function render_section_tabs( $tabs, $active ) {
		?>
		<div class="bos-section-layout">
			<nav class="bos-section-tabs" aria-label="<?php esc_attr_e( 'Fraud Control tabs', 'borbila-safeorder' ); ?>">
				<?php foreach ( $tabs as $key => $tab ) : ?>
					<a class="bos-section-tab <?php echo esc_attr( $active === $key ? 'active' : '' ); ?>" href="<?php echo esc_url( $tab['url'] ); ?>">
						<?php if ( ! empty( $tab['icon'] ) ) : ?>
							<span class="dashicons <?php echo esc_attr( $tab['icon'] ); ?>" aria-hidden="true"></span>
						<?php endif; ?>
						<?php echo esc_html( $tab['label'] ); ?>
					</a>
				<?php endforeach; ?>
			</nav>
			<div class="bos-section-content">
		<?php
	}

	/**
	 * Closes a two-column tab layout.
	 *
	 * @return void
	 */
	public static function close_section_tabs() {
		echo '</div></div>';
	}

	/**
	 * Renders a module toggle.
	 *
	 * @param string $module Module key.
	 * @return void
	 */
	public function render_module_toggle( $module ) {
		if ( ! self::can_manage() ) {
			return;
		}

		$module      = sanitize_key( $module );
		$enabled     = BOS_Settings::is_module_enabled( $module );
		$licensed    = $this->license->is_active();
		$current_url = remove_query_arg( array( 'bos_notice', 'bos_notice_type' ) );
		$toggle_url  = wp_nonce_url(
			add_query_arg(
				array(
					'action'   => 'bos_toggle_module',
					'module'   => $module,
					'enabled'  => $enabled ? 0 : 1,
					'redirect' => rawurlencode( $current_url ),
				),
				admin_url( 'admin-post.php' )
			),
			'bos_toggle_module'
		);
		?>
		<label
			class="bos-switch-row <?php echo $licensed ? '' : 'is-license-locked'; ?>"
			title="<?php echo esc_attr( $licensed ? __( 'Toggle module', 'borbila-safeorder' ) : __( 'Please activate your license', 'borbila-safeorder' ) ); ?>"
			<?php if ( ! $licensed ) : ?>data-bos-license-locked role="button" tabindex="0" aria-disabled="true"<?php endif; ?>
		>
			<input
				type="checkbox"
				<?php checked( $enabled ); ?>
				<?php if ( $licensed ) : ?>data-toggle-url="<?php echo esc_url( $toggle_url ); ?>"<?php else : ?>disabled aria-disabled="true"<?php endif; ?>
			/>
			<i aria-hidden="true"></i>
			<?php if ( ! $licensed ) : ?>
				<span class="bos-switch-lock dashicons dashicons-lock" aria-hidden="true"></span>
			<?php endif; ?>
		</label>
		<?php
	}

	/**
	 * Renders a disabled module card.
	 *
	 * @param string $module Module.
	 * @param string $title  Title.
	 * @return void
	 */
	private function render_disabled_card( $module, $title ) {
		?>
		<section class="bos-card">
			<div class="bos-card-head">
				<h2><?php echo esc_html( $title ); ?></h2>
				<?php $this->render_module_toggle( $module ); ?>
			</div>
			<p class="bos-empty"><?php esc_html_e( 'This Fraud Control module is disabled.', 'borbila-safeorder' ); ?></p>
		</section>
		<?php
	}

	/**
	 * Renders blocked customers tab.
	 *
	 * @return void
	 */
	private function render_blocked_customers_tab() {
		if ( ! BOS_Settings::is_module_enabled( 'block_list' ) ) {
			$this->render_disabled_card( 'block_list', __( 'Blocked Customers', 'borbila-safeorder' ) );
			return;
		}

		$rows = $this->fraud->get_blocked_customers( 200 );
		?>
		<div class="bos-grid-two bos-grid-blocks">
			<section class="bos-card">
				<div class="bos-card-head">
					<h2><?php esc_html_e( 'Add blocked customer', 'borbila-safeorder' ); ?></h2>
					<?php $this->render_module_toggle( 'block_list' ); ?>
				</div>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bos-card-body bos-block-form">
					<input type="hidden" name="action" value="bos_add_blocked_customer" />
					<?php wp_nonce_field( 'bos_add_blocked_customer' ); ?>

					<label class="bos-field">
						<span><?php esc_html_e( 'Type', 'borbila-safeorder' ); ?></span>
						<select name="bos_type">
							<option value="phone"><?php esc_html_e( 'Phone number', 'borbila-safeorder' ); ?></option>
							<option value="email"><?php esc_html_e( 'Email address', 'borbila-safeorder' ); ?></option>
							<option value="ip"><?php esc_html_e( 'IP address', 'borbila-safeorder' ); ?></option>
						</select>
					</label>

					<label class="bos-field">
						<span><?php esc_html_e( 'Value', 'borbila-safeorder' ); ?></span>
						<input type="text" name="bos_value" />
					</label>

					<label class="bos-field">
						<span><?php esc_html_e( 'Reason', 'borbila-safeorder' ); ?></span>
						<textarea name="bos_reason" rows="4"></textarea>
					</label>

					<button type="submit" class="button button-primary bos-primary"><?php esc_html_e( 'Add to Block List', 'borbila-safeorder' ); ?></button>
				</form>
			</section>

			<section class="bos-card bos-card-wide">
				<div class="bos-card-head">
					<h2><?php esc_html_e( 'Blocked customers', 'borbila-safeorder' ); ?></h2>
				</div>
				<?php if ( empty( $rows ) ) : ?>
					<p class="bos-empty"><?php esc_html_e( 'No blocked customers yet.', 'borbila-safeorder' ); ?></p>
				<?php else : ?>
					<table class="widefat fixed striped bos-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Type', 'borbila-safeorder' ); ?></th>
								<th><?php esc_html_e( 'Value', 'borbila-safeorder' ); ?></th>
								<th><?php esc_html_e( 'Reason', 'borbila-safeorder' ); ?></th>
								<th><?php esc_html_e( 'Created', 'borbila-safeorder' ); ?></th>
								<th><?php esc_html_e( 'Action', 'borbila-safeorder' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $rows as $row ) : ?>
								<tr>
									<td><span class="bos-pill"><?php echo esc_html( ucfirst( $row->type ) ); ?></span></td>
									<td><?php echo esc_html( $row->value ); ?></td>
									<td><?php echo esc_html( $row->reason ); ?></td>
									<td><?php echo esc_html( mysql2date( 'M j, Y H:i', $row->created_at ) ); ?></td>
									<td>
										<a class="button button-link-delete bos-delete-link" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=bos_delete_blocked_customer&id=' . absint( $row->id ) ), 'bos_delete_blocked_customer_' . absint( $row->id ) ) ); ?>">
											<?php esc_html_e( 'Remove', 'borbila-safeorder' ); ?>
										</a>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</section>
		</div>
		<?php
	}

	/**
	 * Renders phone validation tab.
	 *
	 * @return void
	 */
	private function render_phone_validation_tab() {
		?>
		<section class="bos-card">
			<div class="bos-card-head">
				<h2><?php esc_html_e( 'Phone Validation', 'borbila-safeorder' ); ?></h2>
				<?php $this->render_module_toggle( 'phone_validation' ); ?>
			</div>
			<div class="bos-card-body">
				<p class="bos-description"><?php esc_html_e( 'Validates Bangladesh mobile numbers during WooCommerce checkout and logs invalid attempts.', 'borbila-safeorder' ); ?></p>
			</div>
		</section>
		<?php
	}

	/**
	 * Renders order limits tab.
	 *
	 * @return void
	 */
	private function render_order_limits_tab() {
		if ( ! BOS_Settings::is_module_enabled( 'order_limit' ) ) {
			$this->render_disabled_card( 'order_limit', __( 'Order Limits', 'borbila-safeorder' ) );
			return;
		}

		$settings = BOS_Settings::get_settings();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bos-settings-form">
			<input type="hidden" name="action" value="bos_save_settings" />
			<input type="hidden" name="bos_settings_section" value="order_limits" />
			<?php wp_nonce_field( 'bos_save_settings' ); ?>

			<section class="bos-card">
				<div class="bos-card-head">
					<h2><?php esc_html_e( 'Order Limits', 'borbila-safeorder' ); ?></h2>
					<?php $this->render_module_toggle( 'order_limit' ); ?>
				</div>
				<div class="bos-card-body bos-grid-two">
					<div>
						<?php $this->render_toggle_input( 'same_phone_restriction_enabled', __( 'Limit repeated phone orders', 'borbila-safeorder' ), $settings['same_phone_restriction_enabled'] ); ?>
						<?php $this->render_number_input( 'same_restriction_window_hours', __( 'Same customer window hours', 'borbila-safeorder' ), $settings['same_restriction_window_hours'] ); ?>
						<?php $this->render_number_input( 'same_restriction_max_orders', __( 'Max orders in same window', 'borbila-safeorder' ), $settings['same_restriction_max_orders'] ); ?>
					</div>
					<div>
						<?php $this->render_toggle_input( 'same_ip_restriction_enabled', __( 'Limit repeated IP orders', 'borbila-safeorder' ), $settings['same_ip_restriction_enabled'] ); ?>
						<?php $this->render_toggle_input( 'global_limit_enabled', __( 'Enable global limits', 'borbila-safeorder' ), $settings['global_limit_enabled'] ); ?>
						<?php $this->render_number_input( 'global_limit_window_hours', __( 'Global window hours', 'borbila-safeorder' ), $settings['global_limit_window_hours'] ); ?>
						<?php $this->render_number_input( 'global_phone_max_orders', __( 'Global max phone orders', 'borbila-safeorder' ), $settings['global_phone_max_orders'] ); ?>
						<?php $this->render_number_input( 'global_ip_max_orders', __( 'Global max IP orders', 'borbila-safeorder' ), $settings['global_ip_max_orders'] ); ?>
					</div>
				</div>
			</section>

			<div class="bos-actions">
				<button type="submit" class="button button-primary bos-primary"><?php esc_html_e( 'Save Settings', 'borbila-safeorder' ); ?></button>
			</div>
		</form>
		<?php
	}

	/**
	 * Renders fraud logs tab.
	 *
	 * @return void
	 */
	private function render_fraud_logs_tab() {
		if ( ! BOS_Settings::is_module_enabled( 'fraud_protection' ) ) {
			$this->render_disabled_card( 'fraud_protection', __( 'Fraud Logs', 'borbila-safeorder' ) );
			return;
		}

		$args  = $this->get_log_table_args();
		$rows  = $this->get_fraud_logs( $args );
		$total = $this->count_fraud_logs( $args );
		?>
		<section class="bos-card">
			<div class="bos-card-head">
				<h2><?php esc_html_e( 'Fraud Logs', 'borbila-safeorder' ); ?></h2>
				<?php $this->render_module_toggle( 'fraud_protection' ); ?>
			</div>
			<?php $this->render_log_filters( $args ); ?>
			<?php if ( empty( $rows ) ) : ?>
				<p class="bos-empty"><?php esc_html_e( 'No fraud logs found.', 'borbila-safeorder' ); ?></p>
			<?php else : ?>
				<table class="widefat fixed striped bos-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Type', 'borbila-safeorder' ); ?></th>
							<th><?php esc_html_e( 'Customer', 'borbila-safeorder' ); ?></th>
							<th><?php esc_html_e( 'Message', 'borbila-safeorder' ); ?></th>
							<th><?php esc_html_e( 'Order', 'borbila-safeorder' ); ?></th>
							<th><?php esc_html_e( 'Date', 'borbila-safeorder' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $rows as $log ) : ?>
							<tr>
								<td><span class="bos-log-type bos-log-type-<?php echo esc_attr( sanitize_html_class( $log->type ) ); ?>"><?php echo esc_html( ucwords( str_replace( '_', ' ', $log->type ) ) ); ?></span></td>
								<td>
									<div class="bos-contact-stack">
										<?php echo esc_html( $log->phone ? $log->phone : '-' ); ?>
										<small><?php echo esc_html( $log->email ? $log->email : $log->ip ); ?></small>
									</div>
								</td>
								<td><?php echo esc_html( $log->message ); ?></td>
								<td>
									<?php if ( $log->order_id ) : ?>
										<a href="<?php echo esc_url( $this->get_order_edit_url( $log->order_id ) ); ?>">#<?php echo esc_html( absint( $log->order_id ) ); ?></a>
									<?php else : ?>
										&mdash;
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( mysql2date( 'M j, Y H:i', $log->created_at ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</section>
		<?php $this->render_simple_pagination( $total, array_merge( $args, array( 'tab' => 'fraud-logs' ) ) ); ?>
		<?php
	}

	/**
	 * Renders suspicious orders tab.
	 *
	 * @return void
	 */
	private function render_suspicious_orders_tab() {
		if ( ! BOS_Settings::is_module_enabled( 'order_risk_tagging' ) ) {
			$this->render_disabled_card( 'order_risk_tagging', __( 'Suspicious Orders', 'borbila-safeorder' ) );
			return;
		}

		$paged = isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1;
		$query = wc_get_orders(
			array(
				'limit'      => 20,
				'paged'      => $paged,
				'paginate'   => true,
				'return'     => 'objects',
				'orderby'    => 'date',
				'order'      => 'DESC',
				'meta_query' => array(
					array(
						'key'     => BOS_Fraud::META_SUSPICIOUS,
						'value'   => 'yes',
						'compare' => '=',
					),
				),
			)
		);
		$orders = is_object( $query ) && isset( $query->orders ) ? $query->orders : array();
		$total  = is_object( $query ) && isset( $query->total ) ? absint( $query->total ) : 0;
		?>
		<section class="bos-card">
			<div class="bos-card-head">
				<h2><?php esc_html_e( 'Suspicious Orders', 'borbila-safeorder' ); ?></h2>
				<?php $this->render_module_toggle( 'order_risk_tagging' ); ?>
			</div>
			<?php if ( empty( $orders ) ) : ?>
				<p class="bos-empty"><?php esc_html_e( 'No suspicious orders found.', 'borbila-safeorder' ); ?></p>
			<?php else : ?>
				<table class="widefat fixed striped bos-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Order', 'borbila-safeorder' ); ?></th>
							<th><?php esc_html_e( 'Customer', 'borbila-safeorder' ); ?></th>
							<th><?php esc_html_e( 'Reason', 'borbila-safeorder' ); ?></th>
							<th><?php esc_html_e( 'Status', 'borbila-safeorder' ); ?></th>
							<th><?php esc_html_e( 'Actions', 'borbila-safeorder' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $orders as $order ) : ?>
							<tr>
								<td><a href="<?php echo esc_url( $this->get_order_edit_url( $order->get_id() ) ); ?>">#<?php echo esc_html( $order->get_order_number() ); ?></a></td>
								<td>
									<div class="bos-contact-stack">
										<?php echo esc_html( trim( $order->get_formatted_billing_full_name() ) ?: $order->get_billing_phone() ); ?>
										<small><?php echo esc_html( $order->get_billing_email() ); ?></small>
									</div>
								</td>
								<td><?php echo esc_html( wp_trim_words( $this->fraud->get_suspicious_reason( $order ), 18 ) ); ?></td>
								<td><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></td>
								<td>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bos-inline-form">
										<input type="hidden" name="action" value="bos_order_fraud_action" />
										<input type="hidden" name="order_id" value="<?php echo esc_attr( $order->get_id() ); ?>" />
										<input type="hidden" name="bos_fraud_action" value="clear_suspicious" />
										<?php wp_nonce_field( 'bos_order_fraud_' . $order->get_id() ); ?>
										<button type="submit" class="button"><?php esc_html_e( 'Clear', 'borbila-safeorder' ); ?></button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</section>
		<?php $this->render_simple_pagination( $total, array( 'tab' => 'suspicious-orders', 'paged' => $paged, 'per_page' => 20 ) ); ?>
		<?php
	}

	/**
	 * Renders the Borbila license screen.
	 *
	 * @return void
	 */
	private function render_license_tab() {
		$active       = $this->license->is_active();
		$notice       = $this->license->pop_admin_notice();
		$last_checked = $this->license->get_last_checked();
		$can_manage   = current_user_can( 'manage_options' );
		$required     = isset( $_GET['bos_license_required'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['bos_license_required'] ) );
		?>
		<?php if ( $required ) : ?>
			<div class="bos-license-notice is-error" role="alert">
				<span class="dashicons dashicons-lock" aria-hidden="true"></span>
				<?php esc_html_e( 'Please activate your license to enable SafeOrder modules.', 'borbila-safeorder' ); ?>
			</div>
		<?php endif; ?>
		<?php if ( ! empty( $notice['message'] ) ) : ?>
			<div class="bos-license-notice <?php echo ! empty( $notice['success'] ) ? 'is-success' : 'is-error'; ?>" role="status">
				<span class="dashicons <?php echo ! empty( $notice['success'] ) ? 'dashicons-yes-alt' : 'dashicons-warning'; ?>" aria-hidden="true"></span>
				<?php echo esc_html( $notice['message'] ); ?>
			</div>
		<?php endif; ?>

		<section class="bos-license-hero <?php echo $active ? 'is-active' : 'is-inactive'; ?>">
			<div class="bos-license-hero-icon" aria-hidden="true">
				<span class="dashicons <?php echo $active ? 'dashicons-shield-alt' : 'dashicons-lock'; ?>"></span>
			</div>
			<div>
				<span class="bos-license-kicker"><?php esc_html_e( 'Borbila licensing', 'borbila-safeorder' ); ?></span>
				<h2><?php echo esc_html( $active ? __( 'SafeOrder Pro is licensed', 'borbila-safeorder' ) : __( 'Activate SafeOrder Pro', 'borbila-safeorder' ) ); ?></h2>
				<p><?php echo esc_html( $active ? __( 'This website is verified and connected to your Borbila license.', 'borbila-safeorder' ) : __( 'Enter your license key to verify this website and receive licensed updates and support.', 'borbila-safeorder' ) ); ?></p>
			</div>
			<span class="bos-license-state"><?php echo esc_html( $active ? __( 'Active', 'borbila-safeorder' ) : __( 'Not activated', 'borbila-safeorder' ) ); ?></span>
		</section>

		<div class="bos-license-details">
			<div><span><?php esc_html_e( 'Website', 'borbila-safeorder' ); ?></span><strong><?php echo esc_html( $this->license->get_domain() ); ?></strong></div>
			<div><span><?php esc_html_e( 'Template ID', 'borbila-safeorder' ); ?></span><strong><?php echo esc_html( BOS_LICENSE_TEMPLATE_ID ); ?></strong></div>
			<div><span><?php esc_html_e( 'License key', 'borbila-safeorder' ); ?></span><strong><?php echo esc_html( $active ? $this->license->get_masked_key() : __( 'Not stored', 'borbila-safeorder' ) ); ?></strong></div>
			<div><span><?php esc_html_e( 'Validity', 'borbila-safeorder' ); ?></span><strong><?php echo esc_html( $active ? __( 'Lifetime', 'borbila-safeorder' ) : __( 'Not active', 'borbila-safeorder' ) ); ?></strong></div>
			<div><span><?php esc_html_e( 'Last checked', 'borbila-safeorder' ); ?></span><strong><?php echo esc_html( $last_checked ? wp_date( 'M j, Y · g:i a', $last_checked ) : __( 'Never', 'borbila-safeorder' ) ); ?></strong></div>
		</div>

		<?php if ( $can_manage ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bos-license-form">
				<input type="hidden" name="action" value="bos_license_action" />
				<?php wp_nonce_field( 'bos_license_action', 'bos_license_nonce' ); ?>
				<?php if ( ! $active ) : ?>
					<label for="bos_license_key"><?php esc_html_e( 'Borbila license key', 'borbila-safeorder' ); ?></label>
					<div class="bos-license-input-row">
						<input type="text" id="bos_license_key" name="bos_license_key" placeholder="BRB-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false" />
						<button type="submit" name="license_operation" value="activate" class="button button-primary bos-license-primary">
							<span class="dashicons dashicons-unlock" aria-hidden="true"></span>
							<?php esc_html_e( 'Activate License', 'borbila-safeorder' ); ?>
						</button>
					</div>
				<?php else : ?>
					<div class="bos-license-actions">
						<button type="submit" name="license_operation" value="check" class="button bos-license-check"><span class="dashicons dashicons-update" aria-hidden="true"></span><?php esc_html_e( 'Check License', 'borbila-safeorder' ); ?></button>
						<button type="submit" name="license_operation" value="deactivate" class="button bos-license-deactivate" data-bos-confirm-license-deactivate><span class="dashicons dashicons-dismiss" aria-hidden="true"></span><?php esc_html_e( 'Deactivate License', 'borbila-safeorder' ); ?></button>
					</div>
				<?php endif; ?>
			</form>
		<?php endif; ?>

		<div class="bos-license-help">
			<div>
				<strong><?php esc_html_e( 'Need a license?', 'borbila-safeorder' ); ?></strong>
				<span><?php esc_html_e( 'View your available Borbila licenses and activation details.', 'borbila-safeorder' ); ?></span>
			</div>
			<a href="https://borbila.com/my-account/licenses/" class="button bos-get-license" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Get License', 'borbila-safeorder' ); ?><span class="dashicons dashicons-external" aria-hidden="true"></span></a>
		</div>
		<?php
	}

	/**
	 * Renders a toggle input.
	 *
	 * @param string $key     Setting key.
	 * @param string $label   Label.
	 * @param mixed  $checked Checked value.
	 * @return void
	 */
	private function render_toggle_input( $key, $label, $checked ) {
		$licensed = $this->license->is_active();
		?>
		<label
			class="bos-switch-row bos-switch-setting <?php echo $licensed ? '' : 'is-license-locked'; ?>"
			title="<?php echo esc_attr( $licensed ? $label : __( 'Please activate your license', 'borbila-safeorder' ) ); ?>"
			<?php if ( ! $licensed ) : ?>data-bos-license-locked role="button" tabindex="0" aria-disabled="true"<?php endif; ?>
		>
			<span><?php echo esc_html( $label ); ?></span>
			<input type="checkbox" name="<?php echo esc_attr( $key ); ?>" value="1" <?php checked( $checked ); ?> <?php disabled( ! $licensed ); ?> />
			<i aria-hidden="true"></i>
			<?php if ( ! $licensed ) : ?>
				<span class="bos-switch-lock dashicons dashicons-lock" aria-hidden="true"></span>
			<?php endif; ?>
		</label>
		<?php
	}

	/**
	 * Renders a number input.
	 *
	 * @param string $key   Setting key.
	 * @param string $label Label.
	 * @param mixed  $value Value.
	 * @return void
	 */
	private function render_number_input( $key, $label, $value ) {
		?>
		<label class="bos-field bos-field-inline">
			<span><?php echo esc_html( $label ); ?></span>
			<input type="number" min="1" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $value ); ?>" />
		</label>
		<?php
	}

	/**
	 * Renders an empty state.
	 *
	 * @param string $title Title.
	 * @param string $body  Body.
	 * @return void
	 */
	private function render_empty_state( $title, $body ) {
		?>
		<div class="bos-empty-state">
			<span class="dashicons dashicons-chart-line" aria-hidden="true"></span>
			<h3><?php echo esc_html( $title ); ?></h3>
			<p><?php echo esc_html( $body ); ?></p>
		</div>
		<?php
	}

	/**
	 * Gets fraud log table args.
	 *
	 * @return array
	 */
	private function get_log_table_args() {
		return array(
			'type'     => isset( $_GET['type'] ) ? sanitize_key( wp_unslash( $_GET['type'] ) ) : '',
			'date'     => isset( $_GET['date'] ) ? sanitize_text_field( wp_unslash( $_GET['date'] ) ) : '',
			'search'   => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '',
			'paged'    => isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1,
			'per_page' => 20,
		);
	}

	/**
	 * Gets fraud logs.
	 *
	 * @param array $args Query args.
	 * @return array
	 */
	private function get_fraud_logs( $args ) {
		global $wpdb;

		$where  = $this->build_log_where_sql( $args );
		$offset = ( max( 1, absint( $args['paged'] ) ) - 1 ) * absint( $args['per_page'] );
		$sql    = 'SELECT * FROM ' . BOS_Logger::table_name() . " {$where['sql']} ORDER BY created_at DESC, id DESC LIMIT %d OFFSET %d";
		$params = array_merge( $where['params'], array( absint( $args['per_page'] ), $offset ) );

		return $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
	}

	/**
	 * Counts fraud logs.
	 *
	 * @param array $args Query args.
	 * @return int
	 */
	private function count_fraud_logs( $args ) {
		global $wpdb;

		$where = $this->build_log_where_sql( $args );
		$sql   = 'SELECT COUNT(*) FROM ' . BOS_Logger::table_name() . " {$where['sql']}";

		return (int) $wpdb->get_var( $where['params'] ? $wpdb->prepare( $sql, $where['params'] ) : $sql );
	}

	/**
	 * Builds log WHERE SQL.
	 *
	 * @param array $args Query args.
	 * @return array
	 */
	private function build_log_where_sql( $args ) {
		global $wpdb;

		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $args['type'] ) ) {
			$where[]  = 'type = %s';
			$params[] = sanitize_key( $args['type'] );
		}

		if ( ! empty( $args['date'] ) ) {
			$where[]  = 'DATE(created_at) = %s';
			$params[] = sanitize_text_field( $args['date'] );
		}

		if ( ! empty( $args['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where[]  = '(phone LIKE %s OR email LIKE %s OR ip LIKE %s OR message LIKE %s OR order_id = %d)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = absint( $args['search'] );
		}

		return array(
			'sql'    => 'WHERE ' . implode( ' AND ', $where ),
			'params' => $params,
		);
	}

	/**
	 * Renders log filters.
	 *
	 * @param array $args Query args.
	 * @return void
	 */
	private function render_log_filters( $args ) {
		?>
		<form method="get" class="bos-filters">
			<input type="hidden" name="page" value="bos-fraud-control" />
			<input type="hidden" name="tab" value="fraud-logs" />
			<select name="type">
				<option value=""><?php esc_html_e( 'All log types', 'borbila-safeorder' ); ?></option>
				<?php foreach ( array( 'blocked_checkout', 'blocked_phone', 'blocked_email', 'blocked_ip', 'order_limit_exceeded', 'suspicious_order_mark', 'suspicious_order_clear' ) as $type ) : ?>
					<option value="<?php echo esc_attr( $type ); ?>" <?php selected( $args['type'], $type ); ?>><?php echo esc_html( ucwords( str_replace( '_', ' ', $type ) ) ); ?></option>
				<?php endforeach; ?>
			</select>
			<input type="date" name="date" value="<?php echo esc_attr( $args['date'] ); ?>" />
			<input type="search" name="s" value="<?php echo esc_attr( $args['search'] ); ?>" placeholder="<?php esc_attr_e( 'Search phone, email, IP, order, message', 'borbila-safeorder' ); ?>" />
			<button type="submit" class="button button-primary bos-primary"><?php esc_html_e( 'Filter', 'borbila-safeorder' ); ?></button>
		</form>
		<?php
	}

	/**
	 * Renders simple pagination.
	 *
	 * @param int   $total Total rows.
	 * @param array $args  Query args.
	 * @return void
	 */
	private function render_simple_pagination( $total, $args ) {
		$per_page = isset( $args['per_page'] ) ? max( 1, absint( $args['per_page'] ) ) : 20;
		$pages    = (int) ceil( absint( $total ) / $per_page );
		$current  = isset( $args['paged'] ) ? max( 1, absint( $args['paged'] ) ) : 1;

		if ( $pages <= 1 ) {
			return;
		}

		echo '<div class="bos-pagination">';
		for ( $i = 1; $i <= $pages; $i++ ) {
			$query_args = array_merge( $args, array( 'page' => 'bos-fraud-control', 'paged' => $i ) );
			if ( isset( $query_args['search'] ) ) {
				$query_args['s'] = $query_args['search'];
				unset( $query_args['search'] );
			}
			unset( $query_args['per_page'] );
			printf(
				'<a class="%1$s" href="%2$s">%3$s</a>',
				esc_attr( $i === $current ? 'active' : '' ),
				esc_url( add_query_arg( $query_args, admin_url( 'admin.php' ) ) ),
				esc_html( $i )
			);
		}
		echo '</div>';
	}

	/**
	 * Gets order edit URL.
	 *
	 * @param int $order_id Order ID.
	 * @return string
	 */
	private function get_order_edit_url( $order_id ) {
		$order = wc_get_order( absint( $order_id ) );

		if ( $order && method_exists( $order, 'get_edit_order_url' ) ) {
			return $order->get_edit_order_url();
		}

		return admin_url( 'post.php?post=' . absint( $order_id ) . '&action=edit' );
	}
}
