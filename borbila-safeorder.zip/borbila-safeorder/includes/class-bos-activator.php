<?php
/**
 * Activation routines.
 *
 * @package Borbila_SafeOrder
 */

defined( 'ABSPATH' ) || exit;

/**
 * Creates Fraud Control tables and default settings.
 */
class BOS_Activator {

	/**
	 * Runs on plugin activation.
	 *
	 * @return void
	 */
	public static function activate() {
		self::create_tables();
		self::ensure_default_settings();
		update_option( 'bos_db_version', BOS_VERSION );
	}

	/**
	 * Runs on plugin deactivation.
	 *
	 * @return void
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( BOS_License::CRON_HOOK );
	}

	/**
	 * Creates or upgrades tables when plugin version changes.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		$db_version = get_option( 'bos_db_version', '0' );

		if ( version_compare( $db_version, BOS_VERSION, '<' ) ) {
			self::activate();
			return;
		}

		self::maybe_create_missing_tables();
	}

	/**
	 * Creates plugin database tables.
	 *
	 * @return void
	 */
	public static function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();
		$blocked_table   = $wpdb->prefix . 'borbila_blocked_customers';
		$logs_table      = $wpdb->prefix . 'borbila_fraud_logs';

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql_blocked = "CREATE TABLE {$blocked_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			type varchar(20) NOT NULL,
			value varchar(191) NOT NULL,
			reason text NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY type_value (type, value),
			KEY type (type),
			KEY value (value)
		) {$charset_collate};";

		$sql_logs = "CREATE TABLE {$logs_table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			type varchar(50) NOT NULL,
			phone varchar(32) NULL,
			email varchar(191) NULL,
			ip varchar(45) NULL,
			order_id bigint(20) unsigned NULL,
			message text NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY type (type),
			KEY phone (phone),
			KEY email (email),
			KEY ip (ip),
			KEY order_id (order_id)
		) {$charset_collate};";

		dbDelta( $sql_blocked );
		dbDelta( $sql_logs );
	}

	/**
	 * Creates missing Fraud Control tables.
	 *
	 * @return void
	 */
	private static function maybe_create_missing_tables() {
		global $wpdb;

		$tables = array(
			$wpdb->prefix . 'borbila_blocked_customers',
			$wpdb->prefix . 'borbila_fraud_logs',
		);

		foreach ( $tables as $table ) {
			$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );

			if ( $table !== $exists ) {
				self::create_tables();
				return;
			}
		}
	}

	/**
	 * Creates default plugin settings when absent.
	 *
	 * @return void
	 */
	private static function ensure_default_settings() {
		$settings = get_option( BOS_Settings::OPTION_NAME, false );

		if ( false === $settings ) {
			add_option( BOS_Settings::OPTION_NAME, BOS_Settings::defaults() );
			return;
		}

		if ( is_array( $settings ) ) {
			$defaults = BOS_Settings::defaults();
			update_option( BOS_Settings::OPTION_NAME, array_intersect_key( wp_parse_args( $settings, $defaults ), $defaults ) );
		}
	}
}
