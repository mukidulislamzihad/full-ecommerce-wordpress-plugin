<?php
/**
 * Plugin Name: SafeOrder Pro
 * Plugin URI: https://borbila.com/
 * Description: WooCommerce fraud control, block list, phone validation, order limits, fraud logs, and suspicious order review.
 * Version: 4.1.1
 * Author: Borbila
 * Author URI: https://borbila.com/
 * Text Domain: borbila-safeorder
 * Requires at least: 6.4
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * WC requires at least: 8.0
 * WC tested up to: 10.0
 *
 * @package Borbila_SafeOrder
 */

defined( 'ABSPATH' ) || exit;

define( 'BOS_VERSION', '4.1.1' );
define( 'BOS_PLUGIN_FILE', __FILE__ );
define( 'BOS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'BOS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'BOS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'BOS_WP_TESTED_UP_TO', '6.8' );
define( 'BOS_LICENSE_API_URL', 'https://borbila.com/wp-json/borbila-license/v1' );
define( 'BOS_LICENSE_TEMPLATE_ID', 'safeorder-pro' );

require_once BOS_PLUGIN_PATH . 'includes/class-bos-activator.php';
require_once BOS_PLUGIN_PATH . 'includes/class-bos-logger.php';
require_once BOS_PLUGIN_PATH . 'includes/class-bos-fraud.php';
require_once BOS_PLUGIN_PATH . 'includes/class-bos-settings.php';
require_once BOS_PLUGIN_PATH . 'includes/class-bos-license.php';
require_once BOS_PLUGIN_PATH . 'includes/class-bos-admin.php';
require_once BOS_PLUGIN_PATH . 'includes/class-bos-checkout.php';
require_once BOS_PLUGIN_PATH . 'includes/class-bos-order-metabox.php';

register_activation_hook( __FILE__, array( 'BOS_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'BOS_Activator', 'deactivate' ) );

add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
		}
	}
);

/**
 * Shows a safe notice when WooCommerce is unavailable.
 *
 * @return void
 */
function bos_woocommerce_missing_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	echo '<div class="notice notice-error"><p>';
	echo esc_html__( 'SafeOrder requires WooCommerce. Fraud Control is disabled until WooCommerce is active.', 'borbila-safeorder' );
	echo '</p></div>';
}

/**
 * Adds a Fraud Control shortcut on the plugins screen.
 *
 * @param array $links Plugin action links.
 * @return array
 */
function bos_plugin_action_links( $links ) {
	$fraud_link = sprintf(
		'<a href="%1$s">%2$s</a>',
		esc_url( admin_url( 'admin.php?page=bos-fraud-control' ) ),
		esc_html__( 'Fraud Control', 'borbila-safeorder' )
	);

	array_unshift( $links, $fraud_link );

	return $links;
}
add_filter( 'plugin_action_links_' . BOS_PLUGIN_BASENAME, 'bos_plugin_action_links' );

/**
 * Boots Fraud Control services after WooCommerce is loaded.
 *
 * @return void
 */
function bos_bootstrap() {
	load_plugin_textdomain( 'borbila-safeorder', false, dirname( BOS_PLUGIN_BASENAME ) . '/languages' );

	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'bos_woocommerce_missing_notice' );
		return;
	}

	BOS_Activator::maybe_upgrade();

	$logger   = new BOS_Logger();
	$fraud    = new BOS_Fraud( $logger );
	$license  = new BOS_License();
	$settings = new BOS_Settings( $fraud, $logger, $license );
	$admin    = new BOS_Admin( $fraud, $logger, $settings, $license );
	$guard    = new BOS_Checkout( $fraud, $logger );
	$orders   = new BOS_Order_Metabox( $fraud, $logger );

	$license->init();
	$settings->init();
	$admin->init();
	$orders->init();

	if ( BOS_Settings::is_module_enabled( 'phone_validation' ) || BOS_Settings::is_module_enabled( 'fraud_protection' ) || BOS_Settings::is_module_enabled( 'block_list' ) || BOS_Settings::is_module_enabled( 'order_limit' ) ) {
		$guard->init();
	}
}
add_action( 'plugins_loaded', 'bos_bootstrap', 20 );
