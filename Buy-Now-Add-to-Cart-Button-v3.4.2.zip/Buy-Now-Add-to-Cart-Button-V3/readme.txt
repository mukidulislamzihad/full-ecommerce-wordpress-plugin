=== Buy Now & Add to Cart Button ===
Contributors: Borbila
Tags: elementor, woocommerce, add to cart, buy now, ajax
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 3.4.2
License: GPLv2 or later

Borbila Elementor widgets for AJAX Add to Cart and Buy Now actions.

== Features ==

* Borbila Add To Cart widget.
* Borbila Buy Now widget.
* Borbila Add to Cart & Buy Now combined widget.
* Widget-only operation: no buttons or storefront behavior are inserted automatically.
* Works in Single Product templates, product pages and Elementor/WooCommerce product loops.
* Editable button text, icons, placement, quantity, variation visibility, redirects, feedback messages and responsive styling in Elementor.
* Optional widget price with live selected-variation price updates.
* Dropdown, visual swatch, or hidden auto-selected variation modes.
* Selected variation image syncing for matching single-product galleries and current loop cards.
* Works with simple and variable WooCommerce products.
* Instantly syncs the selected variation's regular/sale price and featured gallery image on single-product pages.

== Setup ==

1. Activate WooCommerce and Elementor.
2. Activate this plugin.
3. Edit a Single Product template, product page or Loop Item with Elementor.
4. Add a Borbila widget and configure all content, behavior and design controls inside that widget.

Internal widget IDs and CSS hooks keep their original names so existing Elementor pages remain compatible after updating.

== Changelog ==

= 3.4.2 =
* Hidden WooCommerce's injected View cart link inside Borbila widgets after a successful AJAX add-to-cart action.

= 3.4.1 =
* Removed the Buy Now admin menu and overview dashboard completely.
* The plugin now runs only as Elementor widgets with no standalone settings page.

= 3.4.0 =
* Removed the activation-gate system and its dashboard screen.
* Made all Elementor widgets, rendering and AJAX cart actions available immediately.
* Added automatic cleanup for legacy activation data and scheduled checks.
* Simplified the temporary WordPress dashboard to a clean widget overview.

= 3.3.0 =
* Converted the plugin to widget-only operation and removed global widget controls/overrides.
* Simplified the WordPress dashboard to an Elementor widget overview.
* Added current-product resolution for Single Product and product-loop contexts.
* Added per-widget quantity on/off, product price, variation visible/hidden and variation price/image sync controls.
* Hidden variation mode now selects the product default or first purchasable in-stock variation automatically.
* Added local widget price updates and scoped loop-card image updates for selected variations.
* Removed the legacy automatic Buy Now trigger behavior.

= 3.2.1 =
* Fixed variation-image synchronization for custom Elementor Image widgets used as the single-product hero image.
* Detects the nearest shared product-detail image without hard-coded Elementor IDs.
* Excludes Elementor loops, related products, headers and footers from image replacement.
* Fixed the custom variation Clear action so the original product image and price are restored.

= 3.2.0 =
* Added selected-variation regular and sale price synchronization for the main single-product price.
* Added selected-variation featured image synchronization for WooCommerce and Elementor product galleries.
* Restores the original variable-product price and featured image when selections are cleared.
* Keeps synchronization scoped to the current single product and excludes related, upsell and loop products.

= 3.1.2 =
* Redesigned the admin dashboard with a classic professional visual style.
* Changed settings navigation to a vertical tab layout.

= 3.1.1 =
* Renamed the WordPress admin menu label to Buy Now.
* Reorganized the settings dashboard into General, Content, Behavior and Design tabs.
* Added stale nonce recovery, WooCommerce cart-session initialization and AJAX endpoint fallback.
* Improved first-click reliability for cached pages and guest sessions.
* Fixed wildcard variation matching and selected variation attributes.
* Made mini-cart fragment failures non-blocking so successful cart actions still complete.

= 3.1.0 =
* Added a redesigned admin settings dashboard.
* Added editable global content, behavior, typography, sizing and colors.
* Updated all user-facing Elementor widget branding from Subhan to Borbila.

= 3.0.0 =
* Added the unified WooCommerce Product Actions widget.
