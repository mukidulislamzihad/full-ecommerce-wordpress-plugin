<?php
namespace Subhan_EAC;

use Subhan_EAC\Services\Cart_Action_Service;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin bootstrap.
 */
final class Init {

	private static ?Init $instance = null;

	public static function instance() : Init {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		$this->load_dependencies();

		add_action( 'init', array( $this, 'load_textdomain' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );

		// Prefer WooCommerce's lighter AJAX endpoint when available.
		add_action( 'wc_ajax_subhan_eac_widget_action', array( $this, 'handle_widget_action' ) );
		add_action( 'wc_ajax_nopriv_subhan_eac_widget_action', array( $this, 'handle_widget_action' ) );
		add_action( 'wp_ajax_subhan_eac_widget_action', array( $this, 'handle_widget_action' ) );
		add_action( 'wp_ajax_nopriv_subhan_eac_widget_action', array( $this, 'handle_widget_action' ) );
		add_action( 'wp_ajax_subhan_eac_refresh_nonce', array( $this, 'refresh_nonce' ) );
		add_action( 'wp_ajax_nopriv_subhan_eac_refresh_nonce', array( $this, 'refresh_nonce' ) );
	}

	private function load_dependencies() : void {
		require_once SUBHAN_EAC_PLUGIN_DIR . 'includes/helpers/class-product-helper.php';
		require_once SUBHAN_EAC_PLUGIN_DIR . 'includes/helpers/class-render-helper.php';
		require_once SUBHAN_EAC_PLUGIN_DIR . 'includes/services/class-cart-action-service.php';
	}

	/**
	 * Load Elementor widget classes only after Elementor is loaded.
	 */
	private function load_widget_dependencies() : void {
		require_once SUBHAN_EAC_PLUGIN_DIR . 'includes/widgets/class-base-product-action-widget.php';
		require_once SUBHAN_EAC_PLUGIN_DIR . 'includes/widgets/product-actions.php';
		require_once SUBHAN_EAC_PLUGIN_DIR . 'includes/widgets/add-to-cart.php';
		require_once SUBHAN_EAC_PLUGIN_DIR . 'includes/widgets/buy-now.php';
	}

	public function load_textdomain() : void {
		load_plugin_textdomain(
			'subhan-elementor-ajax-cart',
			false,
			dirname( SUBHAN_EAC_PLUGIN_BASENAME ) . '/languages'
		);
	}

	/**
	 * Register (do not enqueue) frontend assets.
	 * Elementor will enqueue only when widget is used.
	 */
	public function register_assets() : void {
		$script_path = SUBHAN_EAC_PLUGIN_DIR . 'assets/js/frontend.js';
		$style_path  = SUBHAN_EAC_PLUGIN_DIR . 'assets/css/style.css';

		wp_register_script(
			'subhan-eac-frontend-script',
			SUBHAN_EAC_PLUGIN_URL . 'assets/js/frontend.js',
			array( 'jquery' ),
			file_exists( $script_path ) ? (string) filemtime( $script_path ) : '1.0.0',
			true
		);

		wp_localize_script(
			'subhan-eac-frontend-script',
			'SubhanEACFrontend',
			array(
				'ajaxUrl'         => $this->get_ajax_url(),
				'fallbackAjaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonceUrl'        => admin_url( 'admin-ajax.php' ),
				'cartUrl'         => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
				'checkoutUrl'     => function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '',
				'nonce'           => wp_create_nonce( 'subhan_eac_widget_action' ),
				'i18n'            => array(
					'loading'         => esc_html__( 'Processing…', 'subhan-elementor-ajax-cart' ),
					'success'         => esc_html__( 'Action completed successfully.', 'subhan-elementor-ajax-cart' ),
					'error'           => esc_html__( 'Unable to process this request.', 'subhan-elementor-ajax-cart' ),
					'selectVariation' => esc_html__( 'Please choose product options first.', 'subhan-elementor-ajax-cart' ),
				),
			)
		);

		wp_register_style(
			'subhan-eac-frontend-style',
			SUBHAN_EAC_PLUGIN_URL . 'assets/css/style.css',
			array(),
			file_exists( $style_path ) ? (string) filemtime( $style_path ) : '1.0.0'
		);

	}

	/**
	 * Use WooCommerce's AJAX endpoint when available to reduce admin-ajax overhead.
	 */
	private function get_ajax_url() : string {
		if ( function_exists( 'wc_ajax_url' ) ) {
			return esc_url_raw( str_replace( '%%endpoint%%', 'subhan_eac_widget_action', wc_ajax_url() ) );
		}

		return admin_url( 'admin-ajax.php' );
	}

	public function register_widgets( $widgets_manager ) : void {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}

		$this->load_widget_dependencies();

		$widgets_manager->register( new \Subhan_EAC\Widgets\Product_Actions() );
		$widgets_manager->register( new \Subhan_EAC\Widgets\Add_To_Cart() );
		$widgets_manager->register( new \Subhan_EAC\Widgets\Buy_Now() );
	}

	public function handle_widget_action() : void {
		if ( function_exists( 'nocache_headers' ) ) {
			nocache_headers();
		}

		if ( ! check_ajax_referer( 'subhan_eac_widget_action', 'nonce', false ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Security check failed. Retrying with a fresh session…', 'subhan-elementor-ajax-cart' ),
					'code'    => 'invalid_nonce',
				),
				403
			);
		}

		if ( ! $this->ensure_cart_ready() ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'WooCommerce cart is not ready.', 'subhan-elementor-ajax-cart' ),
					'code'    => 'cart_not_ready',
				),
				400
			);
		}

		$result = Cart_Action_Service::handle_action( $_POST );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html( $result->get_error_message() ),
					'code'    => esc_html( $result->get_error_code() ),
				),
				400
			);
		}

		wp_send_json_success( $result );
	}

	/** Return a fresh nonce so full-page caches cannot break cart actions. */
	public function refresh_nonce() : void {
		if ( function_exists( 'nocache_headers' ) ) {
			nocache_headers();
		}

		wp_send_json_success(
			array(
				'nonce'    => wp_create_nonce( 'subhan_eac_widget_action' ),
				'ajax_url' => $this->get_ajax_url(),
			)
		);
	}

	/** Initialize WooCommerce session/cart in all AJAX contexts. */
	private function ensure_cart_ready() : bool {
		if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'WC' ) ) {
			return false;
		}

		if ( ( ! WC()->session || ! WC()->cart ) && function_exists( 'wc_load_cart' ) ) {
			try {
				wc_load_cart();
			} catch ( \Throwable $error ) {
				do_action( 'borbila_eac_cart_bootstrap_error', $error );
				return false;
			}
		}

		return WC()->cart instanceof \WC_Cart;
	}
}
