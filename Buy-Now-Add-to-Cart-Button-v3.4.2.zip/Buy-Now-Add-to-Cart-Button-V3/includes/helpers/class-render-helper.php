<?php
namespace Subhan_EAC\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Markup helper for variable product selectors.
 */
final class Render_Helper {

	/**
	 * Build a lightweight variation list for the frontend.
	 *
	 * Each entry only keeps what we need for instant matching:
	 * variation ID, attributes, and stock/purchasable flags.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private static function build_variation_data( \WC_Product $product ) : array {
		$variation_ids = $product->get_children();
		if ( empty( $variation_ids ) || ! is_array( $variation_ids ) ) {
			return array();
		}

		$variation_data = array();

		foreach ( $variation_ids as $variation_id ) {
			$variation = wc_get_product( absint( $variation_id ) );
			if ( ! $variation instanceof \WC_Product_Variation ) {
				continue;
			}

			$attributes = self::normalize_variation_attributes( $variation->get_variation_attributes() );
			if ( empty( $attributes ) ) {
				continue;
			}

			$variation_data[] = array(
				'id'          => absint( $variation->get_id() ),
				'attributes'  => $attributes,
				'active'      => true,
				'purchasable' => $variation->is_purchasable(),
				'in_stock'    => $variation->is_in_stock(),
				'price_html'  => wp_kses_post( $variation->get_price_html() ),
				'price'       => wc_format_decimal( $variation->get_price() ),
				'regular_price' => wc_format_decimal( $variation->get_regular_price() ),
				'sale_price'  => wc_format_decimal( $variation->get_sale_price() ),
				'image'       => self::get_variation_image_data( $variation ),
			);
		}

		return $variation_data;
	}

	/**
	 * Return only the image fields needed to update the main product gallery.
	 * An empty array intentionally means that the parent product image should
	 * remain in use for this variation.
	 *
	 * @return array<string, int|string>
	 */
	private static function get_variation_image_data( \WC_Product_Variation $variation ) : array {
		$image_id = absint( $variation->get_image_id() );
		if ( ! $image_id ) {
			return array();
		}

		$single = wp_get_attachment_image_src( $image_id, 'woocommerce_single' );
		$full   = wp_get_attachment_image_src( $image_id, 'full' );
		if ( ! is_array( $single ) || empty( $single[0] ) || ! is_array( $full ) || empty( $full[0] ) ) {
			return array();
		}

		return array(
			'id'          => $image_id,
			'src'         => esc_url_raw( (string) $single[0] ),
			'src_width'   => absint( $single[1] ?? 0 ),
			'src_height'  => absint( $single[2] ?? 0 ),
			'srcset'      => (string) wp_get_attachment_image_srcset( $image_id, 'woocommerce_single' ),
			'sizes'       => (string) wp_get_attachment_image_sizes( $image_id, 'woocommerce_single' ),
			'full_src'    => esc_url_raw( (string) $full[0] ),
			'full_width'  => absint( $full[1] ?? 0 ),
			'full_height' => absint( $full[2] ?? 0 ),
			'alt'         => sanitize_text_field( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ),
			'title'       => sanitize_text_field( (string) get_the_title( $image_id ) ),
		);
	}

	/**
	 * Normalize variation attributes so frontend matching stays consistent.
	 *
	 * @param array<string, mixed> $attributes Raw variation attributes.
	 * @return array<string, string>
	 */
	private static function normalize_variation_attributes( array $attributes ) : array {
		$clean = array();

		foreach ( $attributes as $attribute_key => $attribute_value ) {
			$key   = sanitize_text_field( (string) $attribute_key );
			$value = sanitize_text_field( (string) $attribute_value );

			if ( '' === $key ) {
				continue;
			}

			// An empty value is a valid WooCommerce "Any…" wildcard.
			$clean[ $key ] = $value;
		}

		if ( empty( $clean ) ) {
			return array();
		}

		ksort( $clean );

		return $clean;
	}

	/**
	 * Render variation selector form.
	 */
	public static function render_variation_form( \WC_Product $product, string $layout = 'dropdown', string $visibility = 'visible' ) : string {
		if ( ! $product->is_type( 'variable' ) ) {
			return '';
		}

		$attributes = $product->get_variation_attributes();
		if ( empty( $attributes ) ) {
			return '';
		}

		$variation_data = self::build_variation_data( $product );
		$variation_json = wp_json_encode( $variation_data );
		$variation_attr = function_exists( 'wc_esc_json' )
			? wc_esc_json( $variation_json )
			: _wp_specialchars( $variation_json, ENT_QUOTES, 'UTF-8', true );

		$layout             = 'swatches' === $layout ? 'swatches' : 'dropdown';
		$visibility         = 'hidden' === $visibility ? 'hidden' : 'visible';
		$default_attributes = $product->get_default_attributes();
		$form_classes       = array(
			'variations_form',
			'cart',
			'subhan-eac-variation-form',
			'subhan-eac-layout-' . $layout,
		);
		if ( 'hidden' === $visibility ) {
			$form_classes[] = 'subhan-eac-variations-hidden';
		}

		ob_start();
		?>
		<form class="<?php echo esc_attr( implode( ' ', $form_classes ) ); ?>" method="post" enctype="multipart/form-data" data-product_id="<?php echo esc_attr( (string) $product->get_id() ); ?>" data-subhan-variation-data="<?php echo $variation_attr; ?>" data-layout="<?php echo esc_attr( $layout ); ?>" data-variation-visibility="<?php echo esc_attr( $visibility ); ?>" <?php echo 'hidden' === $visibility ? 'aria-hidden="true"' : ''; ?>>
			<div class="subhan-eac-variation-rows">
				<?php
				foreach ( $attributes as $attribute_name => $options ) :
					$field_id = sanitize_title( $attribute_name ) . '-' . wp_generate_password( 6, false, false );
					$selected = $default_attributes[ sanitize_title( $attribute_name ) ] ?? '';
					?>
					<div class="subhan-eac-variation-row">
						<label class="subhan-eac-variation-label" for="<?php echo esc_attr( $field_id ); ?>">
							<?php echo esc_html( wc_attribute_label( $attribute_name ) ); ?>
						</label>

						<div class="subhan-eac-variation-value" data-attribute-name="<?php echo esc_attr( $attribute_name ); ?>">
							<?php
							wc_dropdown_variation_attribute_options(
								array(
									'options'          => $options,
									'attribute'        => $attribute_name,
									'product'          => $product,
									'show_option_none' => esc_html__( 'Choose an option', 'subhan-elementor-ajax-cart' ),
									'id'               => $field_id,
									'selected'         => $selected,
								)
							);
							?>

							<?php if ( 'swatches' === $layout ) : ?>
								<div class="subhan-eac-swatches" data-source-id="<?php echo esc_attr( $field_id ); ?>"></div>
							<?php endif; ?>
						</div>
					</div>
					<?php
				endforeach;
				?>
			</div>

			<input type="hidden" name="product_id" value="<?php echo esc_attr( (string) $product->get_id() ); ?>">
			<input type="hidden" name="variation_id" class="variation_id" value="0">

			<?php
			echo wp_kses_post(
				apply_filters(
					'woocommerce_reset_variations_link',
					'<a class="reset_variations" href="#" aria-label="' . esc_attr__( 'Clear options', 'subhan-elementor-ajax-cart' ) . '">' . esc_html__( 'Clear', 'subhan-elementor-ajax-cart' ) . '</a>'
				)
			);
			?>
		</form>
		<?php

		$markup = (string) ob_get_clean();
		return (string) apply_filters( 'subhan_eac_variation_form_markup', $markup, $product, $layout, $visibility );
	}
}
