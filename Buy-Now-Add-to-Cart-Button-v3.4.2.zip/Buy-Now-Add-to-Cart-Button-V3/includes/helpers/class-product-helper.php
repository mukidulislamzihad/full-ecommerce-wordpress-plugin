<?php
namespace Subhan_EAC\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Product lookup and validation helper.
 */
final class Product_Helper {

	/**
	 * Resolve product based on widget setting.
	 */
	public static function resolve_product( array $settings ) : ?\WC_Product {
		$source = isset( $settings['product_source'] ) && 'custom' === $settings['product_source']
			? 'custom'
			: 'current';

		if ( 'custom' === $source ) {
			$product_id = isset( $settings['custom_product_id'] ) ? absint( $settings['custom_product_id'] ) : 0;
			if ( ! $product_id ) {
				return null;
			}

			$product = wc_get_product( $product_id );
			return $product instanceof \WC_Product ? $product : null;
		}

		global $product, $post;

		// WooCommerce sets the global product for both native loops and most
		// Elementor Loop Item renders. Prefer it so every card resolves itself.
		if ( $product instanceof \WC_Product ) {
			return $product;
		}

		$candidate_ids = array();
		$current_id    = get_the_ID();
		if ( $current_id ) {
			$candidate_ids[] = absint( $current_id );
		}
		if ( $post instanceof \WP_Post ) {
			$candidate_ids[] = absint( $post->ID );
		}
		if ( function_exists( 'get_queried_object_id' ) ) {
			$candidate_ids[] = absint( get_queried_object_id() );
		}

		foreach ( array_unique( array_filter( $candidate_ids ) ) as $product_id ) {
			if ( 'product' !== get_post_type( $product_id ) ) {
				continue;
			}
			$current_product = wc_get_product( $product_id );
			if ( $current_product instanceof \WC_Product ) {
				return $current_product;
			}
		}

		return null;
	}

	/**
	 * Whether product can be rendered for this widget.
	 */
	public static function can_render_product( \WC_Product $product, bool $hide_if_out_of_stock ) : bool {
		if ( ! $product->exists() ) {
			return false;
		}

		if ( $hide_if_out_of_stock && ! $product->is_in_stock() ) {
			return false;
		}

		if ( $product->is_type( 'external' ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Determine whether quantity field should appear.
	 */
	public static function supports_quantity( \WC_Product $product ) : bool {
		if ( $product->is_sold_individually() ) {
			return false;
		}

		if ( $product->is_type( 'grouped' ) || $product->is_type( 'external' ) ) {
			return false;
		}

		return true;
	}
}
