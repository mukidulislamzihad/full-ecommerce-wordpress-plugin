<?php
namespace Subhan_EAC\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Service responsible for secure cart actions from widget frontend.
 */
final class Cart_Action_Service {

	/**
	 * Validate and execute action.
	 *
	 * @return array|\WP_Error
	 */
	public static function handle_action( array $request ) {
		$raw = wp_unslash( $request );

		$action_type = isset( $raw['action_type'] ) ? sanitize_key( $raw['action_type'] ) : 'add_to_cart';
		if ( ! in_array( $action_type, array( 'add_to_cart', 'buy_now' ), true ) ) {
			return new \WP_Error( 'invalid_action', esc_html__( 'Invalid action type.', 'subhan-elementor-ajax-cart' ) );
		}

		$product_id = isset( $raw['product_id'] ) ? absint( $raw['product_id'] ) : 0;
		if ( ! $product_id ) {
			return new \WP_Error( 'missing_product', esc_html__( 'Product is required.', 'subhan-elementor-ajax-cart' ) );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product instanceof \WC_Product ) {
			return new \WP_Error( 'invalid_product', esc_html__( 'Invalid product.', 'subhan-elementor-ajax-cart' ) );
		}

		$variation_id = isset( $raw['variation_id'] ) ? absint( $raw['variation_id'] ) : 0;
		$variation    = self::sanitize_variation_attributes( $raw['variation'] ?? array() );

		if ( $product->is_type( 'variation' ) ) {
			$variation_id = $product_id;
			$product_id   = $product->get_parent_id();
			$product      = wc_get_product( $product_id );
		}

		if ( ! $product instanceof \WC_Product ) {
			return new \WP_Error( 'invalid_parent_product', esc_html__( 'Parent product is invalid.', 'subhan-elementor-ajax-cart' ) );
		}

		if ( ! $product->is_purchasable() ) {
			return new \WP_Error( 'not_purchasable', esc_html__( 'This product cannot be purchased.', 'subhan-elementor-ajax-cart' ) );
		}

		if ( ! $product->is_in_stock() ) {
			return new \WP_Error( 'out_of_stock', esc_html__( 'This product is out of stock.', 'subhan-elementor-ajax-cart' ) );
		}

		$quantity         = isset( $raw['quantity'] ) ? max( 1, absint( $raw['quantity'] ) ) : 1;
		$purchase_product = $product;

		if ( $product->is_type( 'variable' ) ) {
			if ( ! $variation_id ) {
				return new \WP_Error( 'missing_variation', esc_html__( 'Please choose product options first.', 'subhan-elementor-ajax-cart' ) );
			}

			if ( 'product_variation' !== get_post_type( $variation_id ) || absint( wp_get_post_parent_id( $variation_id ) ) !== absint( $product_id ) ) {
				return new \WP_Error( 'invalid_variation', esc_html__( 'Selected variation is invalid.', 'subhan-elementor-ajax-cart' ) );
			}

			$variation_product = wc_get_product( $variation_id );
			if ( ! $variation_product instanceof \WC_Product_Variation ) {
				return new \WP_Error( 'invalid_variation', esc_html__( 'Selected variation is invalid.', 'subhan-elementor-ajax-cart' ) );
			}

			if ( ! $variation_product->is_purchasable() ) {
				return new \WP_Error( 'variation_not_purchasable', esc_html__( 'This variation cannot be purchased.', 'subhan-elementor-ajax-cart' ) );
			}

			if ( ! $variation_product->is_in_stock() ) {
				return new \WP_Error( 'variation_out_of_stock', esc_html__( 'This variation is out of stock.', 'subhan-elementor-ajax-cart' ) );
			}

			if ( empty( $variation ) ) {
				$variation = function_exists( 'wc_get_product_variation_attributes' ) ? wc_get_product_variation_attributes( $variation_id ) : array();
			}

			$purchase_product = $variation_product;
		}

		if ( $purchase_product->is_sold_individually() ) {
			$quantity = 1;
		} else {
			$min_quantity = max( 1, absint( $purchase_product->get_min_purchase_quantity() ) );
			// WooCommerce returns -1 for unlimited quantity in some cases.
			// absint( -1 ) becomes 1, which wrongly forces quantity to 1.
			$max_quantity_raw = (int) $purchase_product->get_max_purchase_quantity();
			$max_quantity     = $max_quantity_raw > 0 ? $max_quantity_raw : 0;

			if ( $quantity < $min_quantity ) {
				$quantity = $min_quantity;
			}

			if ( $max_quantity > 0 && $quantity > $max_quantity ) {
				$quantity = $max_quantity;
			}
		}

		// Keep a single latest cart line per product in widget flow:
		// add/buy actions replace previous line with the new quantity/selection.
		self::remove_existing_product_lines( $product_id );

		$cart_item_key = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation );
		if ( ! $cart_item_key ) {
			$notice_message = self::get_last_cart_error_notice();
			return new \WP_Error(
				'add_to_cart_failed',
				$notice_message ? $notice_message : esc_html__( 'Could not add item to cart.', 'subhan-elementor-ajax-cart' )
			);
		}

		// Persist immediately so first-time/guest AJAX requests do not require a
		// page refresh before WooCommerce sees the new cart session.
		self::persist_cart_state();

		$redirect_url = self::get_redirect_url( $raw );
		if ( is_wp_error( $redirect_url ) ) {
			return $redirect_url;
		}

		do_action( 'subhan_eac_cart_action_success', $cart_item_key, $product_id, $quantity, $action_type, $raw );

		$fragments_payload = array(
			'fragments' => array(),
			'cart_hash' => '',
		);

		if ( 'buy_now' !== $action_type ) {
			try {
				$fragments_payload = self::get_cart_fragments_payload();
			} catch ( \Throwable $error ) {
				// Theme mini-cart overrides can fail outside normal page rendering.
				// The frontend will use WooCommerce's fragment refresh fallback.
				do_action( 'borbila_eac_fragment_error', $error );
			}
		}

		return array(
			'cart_count'    => WC()->cart->get_cart_contents_count(),
			'redirect_url'  => $redirect_url,
			'action_type'   => $action_type,
			'cart_item_key' => $cart_item_key,
			'fragments'     => $fragments_payload['fragments'],
			'cart_hash'     => $fragments_payload['cart_hash'],
		);
	}

	/**
	 * Keep selected variation attributes, including values used by wildcard
	 * ("Any…") variations. WooCommerce performs the final validation.
	 *
	 * @param mixed $attributes
	 * @return array<string, string>
	 */
	private static function sanitize_variation_attributes( $attributes ) : array {
		if ( ! is_array( $attributes ) ) {
			return array();
		}

		$clean = array();
		foreach ( $attributes as $key => $value ) {
			if ( ! is_scalar( $value ) ) {
				continue;
			}
			$key = sanitize_key( (string) $key );
			if ( 0 !== strpos( $key, 'attribute_' ) ) {
				continue;
			}
			$clean[ $key ] = sanitize_text_field( (string) $value );
		}

		return $clean;
	}

	/** Persist cart totals, session data and guest cookies defensively. */
	private static function persist_cart_state() : void {
		if ( ! WC()->cart ) {
			return;
		}

		try {
			WC()->cart->calculate_totals();
		} catch ( \Throwable $error ) {
			do_action( 'borbila_eac_cart_totals_error', $error );
		}

		try {
			WC()->cart->set_session();
			WC()->cart->maybe_set_cart_cookies();
		} catch ( \Throwable $error ) {
			do_action( 'borbila_eac_cart_session_error', $error );
		}
	}

	/**
	 * @param mixed $variation
	 */
	private static function get_last_cart_error_notice() : string {
		if ( ! function_exists( 'wc_get_notices' ) ) {
			return '';
		}

		$notices = wc_get_notices( 'error' );
		if ( empty( $notices ) || ! is_array( $notices ) ) {
			return '';
		}

		$last = end( $notices );
		if ( is_array( $last ) && isset( $last['notice'] ) ) {
			return wp_strip_all_tags( (string) $last['notice'] );
		}

		if ( is_string( $last ) ) {
			return wp_strip_all_tags( $last );
		}

		return '';
	}

	/**
	 * Build Woo-style fragments payload for instant cart UI updates via AJAX.
	 *
	 * @return array{fragments: array<string, string>, cart_hash: string}
	 */
	private static function get_cart_fragments_payload() : array {
		if ( ! function_exists( 'woocommerce_mini_cart' ) || ! WC()->cart ) {
			return array(
				'fragments' => array(),
				'cart_hash' => '',
			);
		}

		ob_start();
		woocommerce_mini_cart();
		$mini_cart = (string) ob_get_clean();

		$fragments = apply_filters(
			'woocommerce_add_to_cart_fragments',
			array(
				'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
			)
		);

		return array(
			'fragments' => is_array( $fragments ) ? $fragments : array(),
			'cart_hash' => (string) WC()->cart->get_cart_hash(),
		);
	}

	/**
	 * @param array<string, mixed> $request
	 * @return string|\WP_Error
	 */
	private static function get_redirect_url( array $request ) {
		$enable_redirect = ! empty( $request['enable_redirect'] );
		$target          = isset( $request['redirect_target'] ) ? sanitize_key( $request['redirect_target'] ) : 'cart';
		$action_type     = isset( $request['action_type'] ) ? sanitize_key( $request['action_type'] ) : 'add_to_cart';

		if ( ! $enable_redirect ) {
			return '';
		}

		if ( 'checkout' === $target ) {
			return (string) wc_get_checkout_url();
		}

		if ( 'cart' === $target ) {
			return (string) wc_get_cart_url();
		}

		if ( 'custom' === $target ) {
			$custom_url = isset( $request['redirect_custom_url'] ) ? esc_url_raw( (string) $request['redirect_custom_url'] ) : '';
			if ( ! $custom_url ) {
				if ( 'buy_now' === $action_type ) {
					return (string) wc_get_checkout_url();
				}

				return new \WP_Error( 'missing_redirect_url', esc_html__( 'Custom redirect URL is missing.', 'subhan-elementor-ajax-cart' ) );
			}

			$safe_redirect = wp_validate_redirect( $custom_url, '' );
			if ( ! $safe_redirect ) {
				if ( 'buy_now' === $action_type ) {
					return (string) wc_get_checkout_url();
				}

				return new \WP_Error( 'unsafe_redirect', esc_html__( 'Redirect URL is not allowed.', 'subhan-elementor-ajax-cart' ) );
			}

			return $safe_redirect;
		}

		if ( 'buy_now' === $action_type ) {
			return (string) wc_get_checkout_url();
		}

		return '';
	}

	/**
	 * Remove all existing cart lines of the same product ID.
	 * For variable products, product_id is the parent product ID, so this
	 * removes old variation rows before adding the latest selected one.
	 */
	private static function remove_existing_product_lines( int $product_id ) : void {
		if ( $product_id <= 0 || ! WC()->cart ) {
			return;
		}

		$cart = WC()->cart->get_cart();
		if ( empty( $cart ) || ! is_array( $cart ) ) {
			return;
		}

		foreach ( $cart as $cart_item_key => $cart_item ) {
			$item_parent_id = isset( $cart_item['product_id'] ) ? absint( $cart_item['product_id'] ) : 0;
			if ( $item_parent_id !== $product_id ) {
				continue;
			}

			WC()->cart->remove_cart_item( (string) $cart_item_key );
		}
	}
}
