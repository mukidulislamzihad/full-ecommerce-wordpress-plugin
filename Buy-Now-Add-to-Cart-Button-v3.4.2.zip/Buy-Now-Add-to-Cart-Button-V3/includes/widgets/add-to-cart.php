<?php
namespace Subhan_EAC\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Add_To_Cart extends Base_Product_Action_Widget {

	public function get_name() {
		return 'subhan_add_to_cart';
	}

	public function get_title() {
		return esc_html__( 'Borbila Add To Cart', 'subhan-elementor-ajax-cart' );
	}

	public function get_icon() {
		return 'eicon-cart-medium';
	}

	public function get_categories() {
		return array( 'basic' );
	}

	public function get_keywords() {
		return array( 'woocommerce', 'cart', 'add to cart', 'ajax', 'borbila' );
	}

	protected function get_action_type() : string {
		return 'add_to_cart';
	}

	protected function get_default_button_text() : string {
		return esc_html__( 'Add to Cart', 'subhan-elementor-ajax-cart' );
	}

	protected function get_default_success_message() : string {
		return esc_html__( 'Product added to cart.', 'subhan-elementor-ajax-cart' );
	}

	protected function get_default_error_message() : string {
		return esc_html__( 'Could not add product to cart.', 'subhan-elementor-ajax-cart' );
	}

	protected function get_default_redirect_enabled() : bool {
		return false;
	}

	protected function get_default_redirect_target() : string {
		return 'cart';
	}
}
