<?php
namespace Subhan_EAC\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Widget_Base;
use Subhan_EAC\Helpers\Product_Helper;
use Subhan_EAC\Helpers\Render_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shared base for product action Elementor widgets.
 */
abstract class Base_Product_Action_Widget extends Widget_Base {

	abstract protected function get_action_type() : string;

	abstract protected function get_default_button_text() : string;

	protected function get_default_success_message() : string {
		return esc_html__( 'Action completed successfully.', 'subhan-elementor-ajax-cart' );
	}

	protected function get_default_error_message() : string {
		return esc_html__( 'Unable to process this request.', 'subhan-elementor-ajax-cart' );
	}

	protected function get_default_redirect_enabled() : bool {
		return false;
	}

	protected function get_default_redirect_target() : string {
		return 'cart';
	}

	public function get_script_depends() : array {
		return array( 'subhan-eac-frontend-script' );
	}

	public function get_style_depends() : array {
		return array( 'subhan-eac-frontend-style' );
	}

	protected function register_controls() {
		$this->register_content_controls();
		$this->register_behavior_controls();
		$this->register_message_controls();
		$this->register_button_style_controls();
		$this->register_price_style_controls();
		$this->register_variation_style_controls();
		$this->register_quantity_style_controls();
		$this->register_message_style_controls();
	}

	private function register_content_controls() : void {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'product_source',
			array(
				'label'   => esc_html__( 'Product Source', 'subhan-elementor-ajax-cart' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'current',
				'options' => array(
					'current' => esc_html__( 'Current Product (Single / Loop)', 'subhan-elementor-ajax-cart' ),
					'custom'  => esc_html__( 'Custom Product ID', 'subhan-elementor-ajax-cart' ),
				),
			)
		);

		$this->add_control(
			'custom_product_id',
			array(
				'label'       => esc_html__( 'Custom Product ID', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 0,
				'min'         => 0,
				'description' => esc_html__( 'Use Current Product inside a Single Product template or Elementor Loop Item. Use an ID for a fixed product.', 'subhan-elementor-ajax-cart' ),
				'condition'   => array(
					'product_source' => 'custom',
				),
			)
		);

		$this->add_control(
			'button_text',
			array(
				'label'       => esc_html__( 'Button Text', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => $this->get_default_button_text(),
				'placeholder' => $this->get_default_button_text(),
			)
		);

		$this->add_control(
			'button_icon',
			array(
				'label' => esc_html__( 'Icon', 'subhan-elementor-ajax-cart' ),
				'type'  => Controls_Manager::ICONS,
			)
		);

		$this->add_control(
			'icon_position',
			array(
				'label'   => esc_html__( 'Icon Position', 'subhan-elementor-ajax-cart' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'left',
				'options' => array(
					'left'  => esc_html__( 'Left', 'subhan-elementor-ajax-cart' ),
					'right' => esc_html__( 'Right', 'subhan-elementor-ajax-cart' ),
				),
			)
		);

		$this->add_responsive_control(
			'align',
			array(
				'label'   => esc_html__( 'Alignment', 'subhan-elementor-ajax-cart' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'subhan-elementor-ajax-cart' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'subhan-elementor-ajax-cart' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'subhan-elementor-ajax-cart' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'   => 'left',
				'toggle'    => true,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget-inner' => 'text-align: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'show_product_price',
			array(
				'label'        => esc_html__( 'Show Product Price', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'Hide', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => '',
				'description'  => esc_html__( 'Useful in product loops. The price updates when a variation changes.', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'enable_quantity',
			array(
				'label'        => esc_html__( 'Enable Quantity', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'variation_layout',
			array(
				'label'   => esc_html__( 'Variation Layout', 'subhan-elementor-ajax-cart' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'swatches',
				'options' => array(
					'dropdown' => esc_html__( 'Dropdown', 'subhan-elementor-ajax-cart' ),
					'swatches' => esc_html__( 'Swatches', 'subhan-elementor-ajax-cart' ),
				),
			)
		);

		$this->add_control(
			'variation_visibility',
			array(
				'label'       => esc_html__( 'Variation Selector', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'visible',
				'options'     => array(
					'visible' => esc_html__( 'Visible', 'subhan-elementor-ajax-cart' ),
					'hidden'  => esc_html__( 'Hidden (Auto Select)', 'subhan-elementor-ajax-cart' ),
				),
				'description' => esc_html__( 'Hidden mode uses the product default variation, otherwise the first available variation.', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'sync_product_presentation',
			array(
				'label'        => esc_html__( 'Sync Variation Price & Image', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => esc_html__( 'Updates the matching single-product gallery or current loop-card image.', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'full_width',
			array(
				'label'        => esc_html__( 'Full Width Button', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'additional_class',
			array(
				'label' => esc_html__( 'Additional CSS Class', 'subhan-elementor-ajax-cart' ),
				'type'  => Controls_Manager::TEXT,
			)
		);

		$this->end_controls_section();
	}

	private function register_behavior_controls() : void {
		$this->start_controls_section(
			'behavior_section',
			array(
				'label' => esc_html__( 'Behavior', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'enable_redirect',
			array(
				'label'        => esc_html__( 'Redirect After Click', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => $this->get_default_redirect_enabled() ? 'yes' : '',
			)
		);

		$this->add_control(
			'redirect_target',
			array(
				'label'     => esc_html__( 'Redirect Target', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => $this->get_default_redirect_target(),
				'options'   => array(
					'cart'     => esc_html__( 'Cart', 'subhan-elementor-ajax-cart' ),
					'checkout' => esc_html__( 'Checkout', 'subhan-elementor-ajax-cart' ),
					'custom'   => esc_html__( 'Custom URL', 'subhan-elementor-ajax-cart' ),
				),
				'condition' => array(
					'enable_redirect' => 'yes',
				),
			)
		);

		$this->add_control(
			'redirect_custom_url',
			array(
				'label'         => esc_html__( 'Custom Redirect URL', 'subhan-elementor-ajax-cart' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => 'https://example.com/thank-you',
				'show_external' => false,
				'dynamic'       => array( 'active' => true ),
				'condition'     => array(
					'enable_redirect' => 'yes',
					'redirect_target' => 'custom',
				),
			)
		);

		$this->add_control(
			'loading_show_spinner',
			array(
				'label'        => esc_html__( 'Show Spinner While Loading', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'loading_text',
			array(
				'label'       => esc_html__( 'Loading Text', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Processing…', 'subhan-elementor-ajax-cart' ),
				'placeholder' => esc_html__( 'Processing…', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'hide_if_out_of_stock',
			array(
				'label'        => esc_html__( 'Hide If Out of Stock', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->end_controls_section();
	}

	private function register_message_controls() : void {
		$this->start_controls_section(
			'message_section',
			array(
				'label' => esc_html__( 'Messages', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_success_message',
			array(
				'label'        => esc_html__( 'Show Success Message', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'success_message',
			array(
				'label'       => esc_html__( 'Success Message', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => $this->get_default_success_message(),
				'placeholder' => $this->get_default_success_message(),
				'condition'   => array(
					'show_success_message' => 'yes',
				),
			)
		);

		$this->add_control(
			'show_error_message',
			array(
				'label'        => esc_html__( 'Show Error Message', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'error_message',
			array(
				'label'       => esc_html__( 'Error Message', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => $this->get_default_error_message(),
				'placeholder' => $this->get_default_error_message(),
				'condition'   => array(
					'show_error_message' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_button_style_controls() : void {
		$this->start_controls_section(
			'style_button_section',
			array(
				'label' => esc_html__( 'Style: Button', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .subhan-eac-btn',
			)
		);

		$this->add_control(
			'button_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-btn' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-btn' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'button_border',
				'selector' => '{{WRAPPER}} .subhan-eac-btn',
			)
		);

		$this->add_responsive_control(
			'button_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'button_padding',
			array(
				'label'      => esc_html__( 'Padding', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'button_margin',
			array(
				'label'      => esc_html__( 'Margin', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'icon_spacing',
			array(
				'label'      => esc_html__( 'Icon Spacing', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-btn .subhan-eac-icon-left'  => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .subhan-eac-btn .subhan-eac-icon-right' => 'margin-left: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->start_controls_tabs( 'button_state_tabs' );

		$this->start_controls_tab(
			'button_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'button_hover_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-btn:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_hover_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-btn:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_hover_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'condition' => array(
					'button_border_border!' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-btn:hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'button_disabled_tab',
			array(
				'label' => esc_html__( 'Disabled', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'button_disabled_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-btn:disabled, {{WRAPPER}} .subhan-eac-btn.is-loading' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_disabled_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-btn:disabled, {{WRAPPER}} .subhan-eac-btn.is-loading' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_disabled_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'condition' => array(
					'button_border_border!' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-btn:disabled, {{WRAPPER}} .subhan-eac-btn.is-loading' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_disabled_opacity',
			array(
				'label'     => esc_html__( 'Opacity', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 0.1,
				'max'       => 1,
				'step'      => 0.05,
				'default'   => 1,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-btn:disabled, {{WRAPPER}} .subhan-eac-btn.is-loading' => 'opacity: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_price_style_controls() : void {
		$this->start_controls_section(
			'style_price_section',
			array(
				'label' => esc_html__( 'Style: Price', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_typography',
				'selector' => '{{WRAPPER}} .subhan-eac-widget-price',
			)
		);

		$this->add_control(
			'price_color',
			array(
				'label'     => esc_html__( 'Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget-price' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'price_spacing',
			array(
				'label'      => esc_html__( 'Bottom Spacing', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-widget-price' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_variation_style_controls() : void {
		$this->start_controls_section(
			'style_variation_section',
			array(
				'label' => esc_html__( 'Style: Variations', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'variation_typography',
				'selector' => '{{WRAPPER}} .subhan-eac-variation-label, {{WRAPPER}} .subhan-eac-variation-value select, {{WRAPPER}} .subhan-eac-swatch',
			)
		);

		$this->add_control(
			'variation_label_color',
			array(
				'label'     => esc_html__( 'Label Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .subhan-eac-variation-label' => 'color: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'variation_text_color',
			array(
				'label'     => esc_html__( 'Option Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .subhan-eac-variation-value select, {{WRAPPER}} .subhan-eac-swatch' => 'color: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'variation_bg_color',
			array(
				'label'     => esc_html__( 'Option Background', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .subhan-eac-variation-value select, {{WRAPPER}} .subhan-eac-swatch' => 'background-color: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'variation_active_color',
			array(
				'label'     => esc_html__( 'Active Option Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .subhan-eac-swatch.is-active' => 'color: {{VALUE}};border-color: {{VALUE}};' ),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'variation_border',
				'selector' => '{{WRAPPER}} .subhan-eac-variation-value select, {{WRAPPER}} .subhan-eac-swatch',
			)
		);

		$this->add_responsive_control(
			'variation_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array( '{{WRAPPER}} .subhan-eac-variation-value select, {{WRAPPER}} .subhan-eac-swatch' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);

		$this->add_responsive_control(
			'variation_spacing',
			array(
				'label'      => esc_html__( 'Rows Gap', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
				'selectors'  => array( '{{WRAPPER}} .subhan-eac-variation-rows' => 'gap: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->end_controls_section();
	}

	private function register_quantity_style_controls() : void {
		$this->start_controls_section(
			'style_quantity_section',
			array(
				'label' => esc_html__( 'Style: Quantity', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'quantity_typography',
				'selector' => '{{WRAPPER}} .subhan-eac-qty-control, {{WRAPPER}} .subhan-eac-qty-input, {{WRAPPER}} .subhan-eac-qty-btn',
			)
		);

		$this->add_control(
			'quantity_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-qty-input, {{WRAPPER}} .subhan-eac-qty-btn' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'quantity_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-qty-control, {{WRAPPER}} .subhan-eac-qty-input, {{WRAPPER}} .subhan-eac-qty-btn' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'quantity_border',
				'selector' => '{{WRAPPER}} .subhan-eac-qty-control',
			)
		);

		$this->add_responsive_control(
			'quantity_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-qty-control' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'quantity_padding',
			array(
				'label'      => esc_html__( 'Input Padding', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-qty-input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_message_style_controls() : void {
		$this->start_controls_section(
			'style_message_section',
			array(
				'label' => esc_html__( 'Style: Message', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'message_typography',
				'selector' => '{{WRAPPER}} .subhan-eac-message',
			)
		);

		$this->add_control(
			'message_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-message' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'message_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-message' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'message_border',
				'selector' => '{{WRAPPER}} .subhan-eac-message',
			)
		);

		$this->add_responsive_control(
			'message_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-message' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'message_padding',
			array(
				'label'      => esc_html__( 'Padding', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-message' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'message_margin',
			array(
				'label'      => esc_html__( 'Margin', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-message' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Normalize and sanitize settings for frontend use.
	 *
	 * @return array<string, mixed>
	 */
	private function get_normalized_settings() : array {
		$settings = $this->get_settings_for_display();

		$product_source = isset( $settings['product_source'] ) && 'custom' === $settings['product_source'] ? 'custom' : 'current';
		$icon_position  = isset( $settings['icon_position'] ) && 'right' === $settings['icon_position'] ? 'right' : 'left';
		$variation_ui         = isset( $settings['variation_layout'] ) && 'swatches' === $settings['variation_layout'] ? 'swatches' : 'dropdown';
		$variation_visibility = isset( $settings['variation_visibility'] ) && 'hidden' === $settings['variation_visibility'] ? 'hidden' : 'visible';
		$redirect_target = isset( $settings['redirect_target'] ) ? sanitize_key( (string) $settings['redirect_target'] ) : $this->get_default_redirect_target();

		if ( ! in_array( $redirect_target, array( 'cart', 'checkout', 'custom' ), true ) ) {
			$redirect_target = $this->get_default_redirect_target();
		}

		$redirect_custom_url = '';
		if ( ! empty( $settings['redirect_custom_url']['url'] ) ) {
			$redirect_custom_url = esc_url_raw( (string) $settings['redirect_custom_url']['url'] );
		}

		$normalized = array(
			'product_source'       => $product_source,
			'custom_product_id'    => isset( $settings['custom_product_id'] ) ? absint( $settings['custom_product_id'] ) : 0,
			'button_text'          => sanitize_text_field( (string) ( $settings['button_text'] ?? $this->get_default_button_text() ) ),
			'button_icon'          => isset( $settings['button_icon'] ) && is_array( $settings['button_icon'] ) ? $settings['button_icon'] : array(),
			'icon_position'        => $icon_position,
			'additional_class'     => sanitize_text_field( (string) ( $settings['additional_class'] ?? '' ) ),
			'show_product_price'   => ! empty( $settings['show_product_price'] ),
			'enable_quantity'      => ! empty( $settings['enable_quantity'] ),
			'enable_redirect'      => ! empty( $settings['enable_redirect'] ),
			'redirect_target'      => $redirect_target,
			'redirect_custom_url'  => $redirect_custom_url,
			'loading_show_spinner' => ! empty( $settings['loading_show_spinner'] ),
			'loading_text'         => sanitize_text_field( (string) ( $settings['loading_text'] ?? '' ) ),
			'show_success_message' => ! empty( $settings['show_success_message'] ),
			'success_message'      => sanitize_text_field( (string) ( $settings['success_message'] ?? $this->get_default_success_message() ) ),
			'show_error_message'   => ! empty( $settings['show_error_message'] ),
			'error_message'        => sanitize_text_field( (string) ( $settings['error_message'] ?? $this->get_default_error_message() ) ),
			'hide_if_out_of_stock' => ! empty( $settings['hide_if_out_of_stock'] ),
			'variation_layout'     => $variation_ui,
			'variation_visibility' => $variation_visibility,
			'sync_product_presentation' => ! empty( $settings['sync_product_presentation'] ),
			'full_width'           => ! empty( $settings['full_width'] ),
		);

		return $normalized;
	}

	protected function render() {
		$settings = $this->get_normalized_settings();
		$product  = Product_Helper::resolve_product( $settings );

		if ( ! $product instanceof \WC_Product ) {
			return;
		}

		if ( ! Product_Helper::can_render_product( $product, (bool) $settings['hide_if_out_of_stock'] ) ) {
			return;
		}

		if ( ! $product->is_purchasable() ) {
			return;
		}

		$show_quantity = (bool) $settings['enable_quantity'] && Product_Helper::supports_quantity( $product );
		$is_disabled   = ! $product->is_in_stock();
		$button_text   = $settings['button_text'] ? $settings['button_text'] : $this->get_default_button_text();

		$wrapper_classes = array(
			'subhan-eac-widget',
			'subhan-eac-widget--' . $this->get_action_type(),
			$settings['full_width'] ? 'subhan-eac-has-full-width' : '',
		);

		$wrapper_classes = array_filter( $wrapper_classes );
		$wrapper_classes = array_merge( $wrapper_classes, $this->sanitize_extra_classes( (string) $settings['additional_class'] ) );

		$icon_html = $this->get_icon_html( (array) $settings['button_icon'], (string) $settings['icon_position'] );

		$min_qty = max( 1, (int) $product->get_min_purchase_quantity() );
		$max_qty = (int) $product->get_max_purchase_quantity();

		echo '<div class="' . esc_attr( implode( ' ', $wrapper_classes ) ) . '"'
			. ' data-action-type="' . esc_attr( $this->get_action_type() ) . '"'
			. ' data-product-id="' . esc_attr( (string) $product->get_id() ) . '"'
			. ' data-product-type="' . esc_attr( $product->get_type() ) . '"'
			. ' data-sync-presentation="' . esc_attr( $settings['sync_product_presentation'] ? '1' : '0' ) . '"'
			. ' data-enable-quantity="' . esc_attr( $show_quantity ? '1' : '0' ) . '"'
			. ' data-enable-redirect="' . esc_attr( $settings['enable_redirect'] ? '1' : '0' ) . '"'
			. ' data-redirect-target="' . esc_attr( (string) $settings['redirect_target'] ) . '"'
			. ' data-redirect-url="' . esc_attr( (string) $settings['redirect_custom_url'] ) . '"'
			. ' data-loading-spinner="' . esc_attr( $settings['loading_show_spinner'] ? '1' : '0' ) . '"'
			. ' data-loading-text="' . esc_attr( (string) $settings['loading_text'] ) . '"'
			. ' data-show-success="' . esc_attr( $settings['show_success_message'] ? '1' : '0' ) . '"'
			. ' data-success-message="' . esc_attr( (string) $settings['success_message'] ) . '"'
			. ' data-show-error="' . esc_attr( $settings['show_error_message'] ? '1' : '0' ) . '"'
			. ' data-error-message="' . esc_attr( (string) $settings['error_message'] ) . '"'
			. '>';

		echo '<div class="subhan-eac-widget-inner">';
		if ( $settings['show_product_price'] ) {
			echo '<div class="subhan-eac-widget-price">' . wp_kses_post( $product->get_price_html() ) . '</div>';
		}

		if ( $product->is_type( 'variable' ) ) {
			echo Render_Helper::render_variation_form( $product, (string) $settings['variation_layout'], (string) $settings['variation_visibility'] );
		}

		echo '<div class="subhan-eac-actions">';

		if ( $show_quantity ) {
			echo '<div class="subhan-eac-qty-control" data-min="' . esc_attr( (string) $min_qty ) . '" data-max="' . esc_attr( (string) $max_qty ) . '">';
			echo '<button type="button" class="subhan-eac-qty-btn subhan-eac-qty-minus" aria-label="' . esc_attr__( 'Decrease quantity', 'subhan-elementor-ajax-cart' ) . '">-</button>';
			echo '<input type="number" class="subhan-eac-qty-input" min="' . esc_attr( (string) $min_qty ) . '"' . ( $max_qty > 0 ? ' max="' . esc_attr( (string) $max_qty ) . '"' : '' ) . ' step="1" value="' . esc_attr( (string) $min_qty ) . '" inputmode="numeric" aria-label="' . esc_attr__( 'Quantity', 'subhan-elementor-ajax-cart' ) . '">';
			echo '<button type="button" class="subhan-eac-qty-btn subhan-eac-qty-plus" aria-label="' . esc_attr__( 'Increase quantity', 'subhan-elementor-ajax-cart' ) . '">+</button>';
			echo '</div>';
		}

		$button_classes = array( 'subhan-eac-btn', 'elementor-button' );
		$button_classes[] = 'subhan-eac-' . str_replace( '_', '-', $this->get_action_type() );
		if ( $settings['full_width'] ) {
			$button_classes[] = 'is-full-width';
		}

		echo '<button type="button" class="' . esc_attr( implode( ' ', $button_classes ) ) . '"' . ( $is_disabled ? ' disabled' : '' ) . '>';
		echo '<span class="subhan-eac-spinner" aria-hidden="true"></span>';
		if ( 'left' === $settings['icon_position'] ) {
			echo $icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '<span class="subhan-eac-btn-label">' . esc_html( $button_text ) . '</span>';
		if ( 'right' === $settings['icon_position'] ) {
			echo $icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</button>';

		echo '</div>';
		echo '<div class="subhan-eac-message" role="status" aria-live="polite"></div>';
		echo '</div>';
		echo '</div>';
	}

	/**
	 * @return array<int, string>
	 */
	private function sanitize_extra_classes( string $raw_classes ) : array {
		if ( '' === trim( $raw_classes ) ) {
			return array();
		}

		$classes = preg_split( '/\s+/', $raw_classes );
		if ( ! is_array( $classes ) ) {
			return array();
		}

		$clean = array();
		foreach ( $classes as $class_name ) {
			$sanitized = sanitize_html_class( $class_name );
			if ( $sanitized ) {
				$clean[] = $sanitized;
			}
		}

		return $clean;
	}

	private function get_icon_html( array $icon, string $position ) : string {
		if ( empty( $icon['value'] ) ) {
			return '';
		}

		ob_start();
		Icons_Manager::render_icon( $icon, array( 'aria-hidden' => 'true' ) );
		$rendered_icon = trim( (string) ob_get_clean() );

		if ( '' === $rendered_icon ) {
			return '';
		}

		return '<span class="subhan-eac-icon subhan-eac-icon-' . esc_attr( $position ) . '">' . $rendered_icon . '</span>';
	}
}
