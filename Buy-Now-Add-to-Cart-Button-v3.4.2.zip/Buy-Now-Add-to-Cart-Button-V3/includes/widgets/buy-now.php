<?php
namespace Subhan_EAC\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Buy_Now extends Base_Product_Action_Widget {

	public function get_name() {
		return 'subhan_buy_now';
	}

	public function get_title() {
		return esc_html__( 'Borbila Buy Now', 'subhan-elementor-ajax-cart' );
	}

	public function get_icon() {
		return 'eicon-woocommerce';
	}

	public function get_categories() {
		return array( 'basic' );
	}

	public function get_keywords() {
		return array( 'woocommerce', 'buy now', 'checkout', 'instant checkout', 'borbila' );
	}

	protected function get_action_type() : string {
		return 'buy_now';
	}

	protected function get_default_button_text() : string {
		return esc_html__( 'Buy Now', 'subhan-elementor-ajax-cart' );
	}

	protected function get_default_success_message() : string {
		return esc_html__( 'Redirecting to checkout…', 'subhan-elementor-ajax-cart' );
	}

	protected function get_default_error_message() : string {
		return esc_html__( 'Could not start checkout.', 'subhan-elementor-ajax-cart' );
	}

	protected function get_default_redirect_enabled() : bool {
		return true;
	}

	protected function get_default_redirect_target() : string {
		return 'checkout';
	}
}
