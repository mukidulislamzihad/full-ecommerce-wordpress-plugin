<?php
namespace Subhan_EAC\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Icons_Manager;
use Elementor\Widget_Base;
use Subhan_EAC\Helpers\Product_Helper;
use Subhan_EAC\Helpers\Render_Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Unified product action widget (Add to Cart + Buy Now) with shared variation/quantity UI.
 */
class Product_Actions extends Widget_Base {

	public function get_name() {
		return 'subhan_product_actions';
	}

	public function get_title() {
		return esc_html__( 'Borbila Add to Cart & Buy Now', 'subhan-elementor-ajax-cart' );
	}

	public function get_icon() {
		return 'eicon-product-add-to-cart';
	}

	public function get_categories() {
		return array( 'basic' );
	}

	public function get_keywords() {
		return array( 'woocommerce', 'product', 'add to cart', 'buy now', 'variation', 'quantity', 'borbila' );
	}

	public function get_script_depends() : array {
		return array( 'subhan-eac-frontend-script' );
	}

	public function get_style_depends() : array {
		return array( 'subhan-eac-frontend-style' );
	}

	protected function register_controls() {
		$this->register_content_controls();
		$this->register_behavior_controls();
		$this->register_message_controls();
		$this->register_layout_style_controls();
		$this->register_common_button_style_controls();
		$this->register_add_to_cart_button_style_controls();
		$this->register_buy_now_button_style_controls();
		$this->register_price_style_controls();
		$this->register_variation_style_controls();
		$this->register_quantity_style_controls();
		$this->register_message_style_controls();
	}

	private function register_content_controls() : void {
		$this->start_controls_section(
			'content_section',
			array(
				'label' => esc_html__( 'Content', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'product_source',
			array(
				'label'   => esc_html__( 'Product Source', 'subhan-elementor-ajax-cart' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'current',
				'options' => array(
					'current' => esc_html__( 'Current Product (Single / Loop)', 'subhan-elementor-ajax-cart' ),
					'custom'  => esc_html__( 'Custom Product ID', 'subhan-elementor-ajax-cart' ),
				),
			)
		);

		$this->add_control(
			'custom_product_id',
			array(
				'label'       => esc_html__( 'Custom Product ID', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 0,
				'min'         => 0,
				'description' => esc_html__( 'Use Current Product inside a Single Product template or Elementor Loop Item. Use an ID for a fixed product.', 'subhan-elementor-ajax-cart' ),
				'condition'   => array(
					'product_source' => 'custom',
				),
			)
		);

		$this->add_control(
			'show_add_to_cart',
			array(
				'label'        => esc_html__( 'Show Add to Cart', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'add_to_cart_text',
			array(
				'label'       => esc_html__( 'Add to Cart Text', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Add to Cart', 'subhan-elementor-ajax-cart' ),
				'placeholder' => esc_html__( 'Add to Cart', 'subhan-elementor-ajax-cart' ),
				'condition'   => array(
					'show_add_to_cart' => 'yes',
				),
			)
		);

		$this->add_control(
			'add_to_cart_icon',
			array(
				'label'     => esc_html__( 'Add to Cart Icon', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::ICONS,
				'condition' => array(
					'show_add_to_cart' => 'yes',
				),
			)
		);

		$this->add_control(
			'add_to_cart_icon_position',
			array(
				'label'     => esc_html__( 'Add to Cart Icon Position', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'left',
				'options'   => array(
					'left'  => esc_html__( 'Left', 'subhan-elementor-ajax-cart' ),
					'right' => esc_html__( 'Right', 'subhan-elementor-ajax-cart' ),
				),
				'condition' => array(
					'show_add_to_cart' => 'yes',
				),
			)
		);

		$this->add_control(
			'show_buy_now',
			array(
				'label'        => esc_html__( 'Show Buy Now', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'buy_now_text',
			array(
				'label'       => esc_html__( 'Buy Now Text', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Buy Now', 'subhan-elementor-ajax-cart' ),
				'placeholder' => esc_html__( 'Buy Now', 'subhan-elementor-ajax-cart' ),
				'condition'   => array(
					'show_buy_now' => 'yes',
				),
			)
		);

		$this->add_control(
			'buy_now_icon',
			array(
				'label'     => esc_html__( 'Buy Now Icon', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::ICONS,
				'condition' => array(
					'show_buy_now' => 'yes',
				),
			)
		);

		$this->add_control(
			'buy_now_icon_position',
			array(
				'label'     => esc_html__( 'Buy Now Icon Position', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'left',
				'options'   => array(
					'left'  => esc_html__( 'Left', 'subhan-elementor-ajax-cart' ),
					'right' => esc_html__( 'Right', 'subhan-elementor-ajax-cart' ),
				),
				'condition' => array(
					'show_buy_now' => 'yes',
				),
			)
		);

		$this->add_control(
			'buy_now_position',
			array(
				'label'       => esc_html__( 'Buy Now Position', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'right',
				'options'     => array(
					'right'  => esc_html__( 'Right of Add to Cart', 'subhan-elementor-ajax-cart' ),
					'left'   => esc_html__( 'Left of Add to Cart', 'subhan-elementor-ajax-cart' ),
					'bottom' => esc_html__( 'Bottom of Add to Cart', 'subhan-elementor-ajax-cart' ),
				),
				'condition'   => array(
					'show_add_to_cart' => 'yes',
					'show_buy_now'     => 'yes',
				),
				'description' => esc_html__( 'Control Buy Now button placement relative to Add to Cart.', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'show_product_price',
			array(
				'label'        => esc_html__( 'Show Product Price', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'Hide', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => '',
				'description'  => esc_html__( 'Useful in product loops. The price updates when a variation changes.', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'enable_quantity',
			array(
				'label'        => esc_html__( 'Enable Quantity', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'variation_layout',
			array(
				'label'   => esc_html__( 'Variation Layout', 'subhan-elementor-ajax-cart' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'swatches',
				'options' => array(
					'dropdown' => esc_html__( 'Dropdown', 'subhan-elementor-ajax-cart' ),
					'swatches' => esc_html__( 'Swatches', 'subhan-elementor-ajax-cart' ),
				),
			)
		);

		$this->add_control(
			'variation_visibility',
			array(
				'label'       => esc_html__( 'Variation Selector', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'visible',
				'options'     => array(
					'visible' => esc_html__( 'Visible', 'subhan-elementor-ajax-cart' ),
					'hidden'  => esc_html__( 'Hidden (Auto Select)', 'subhan-elementor-ajax-cart' ),
				),
				'description' => esc_html__( 'Hidden mode uses the product default variation, otherwise the first available variation.', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'sync_product_presentation',
			array(
				'label'        => esc_html__( 'Sync Variation Price & Image', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => esc_html__( 'Updates the matching single-product gallery or current loop-card image.', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'full_width',
			array(
				'label'        => esc_html__( 'Full Width Buttons', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'additional_class',
			array(
				'label' => esc_html__( 'Additional CSS Class', 'subhan-elementor-ajax-cart' ),
				'type'  => Controls_Manager::TEXT,
			)
		);

		$this->end_controls_section();
	}

	private function register_behavior_controls() : void {
		$this->start_controls_section(
			'behavior_section',
			array(
				'label' => esc_html__( 'Behavior', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'add_to_cart_enable_redirect',
			array(
				'label'        => esc_html__( 'Add to Cart Redirect', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => array(
					'show_add_to_cart' => 'yes',
				),
			)
		);

		$this->add_control(
			'add_to_cart_redirect_target',
			array(
				'label'     => esc_html__( 'Add to Cart Redirect Target', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'cart',
				'options'   => array(
					'cart'     => esc_html__( 'Cart', 'subhan-elementor-ajax-cart' ),
					'checkout' => esc_html__( 'Checkout', 'subhan-elementor-ajax-cart' ),
					'custom'   => esc_html__( 'Custom URL', 'subhan-elementor-ajax-cart' ),
				),
				'condition' => array(
					'show_add_to_cart'          => 'yes',
					'add_to_cart_enable_redirect' => 'yes',
				),
			)
		);

		$this->add_control(
			'add_to_cart_redirect_custom_url',
			array(
				'label'         => esc_html__( 'Add to Cart Custom Redirect URL', 'subhan-elementor-ajax-cart' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => 'https://example.com/thank-you',
				'show_external' => false,
				'dynamic'       => array( 'active' => true ),
				'condition'     => array(
					'show_add_to_cart'            => 'yes',
					'add_to_cart_enable_redirect' => 'yes',
					'add_to_cart_redirect_target' => 'custom',
				),
			)
		);

		$this->add_control(
			'buy_now_enable_redirect',
			array(
				'label'        => esc_html__( 'Buy Now Redirect', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array(
					'show_buy_now' => 'yes',
				),
			)
		);

		$this->add_control(
			'buy_now_redirect_target',
			array(
				'label'     => esc_html__( 'Buy Now Redirect Target', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'checkout',
				'options'   => array(
					'cart'     => esc_html__( 'Cart', 'subhan-elementor-ajax-cart' ),
					'checkout' => esc_html__( 'Checkout', 'subhan-elementor-ajax-cart' ),
					'custom'   => esc_html__( 'Custom URL', 'subhan-elementor-ajax-cart' ),
				),
				'condition' => array(
					'show_buy_now'         => 'yes',
					'buy_now_enable_redirect' => 'yes',
				),
			)
		);

		$this->add_control(
			'buy_now_redirect_custom_url',
			array(
				'label'         => esc_html__( 'Buy Now Custom Redirect URL', 'subhan-elementor-ajax-cart' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => 'https://example.com/checkout',
				'show_external' => false,
				'dynamic'       => array( 'active' => true ),
				'condition'     => array(
					'show_buy_now'            => 'yes',
					'buy_now_enable_redirect' => 'yes',
					'buy_now_redirect_target' => 'custom',
				),
			)
		);

		$this->add_control(
			'loading_show_spinner',
			array(
				'label'        => esc_html__( 'Show Spinner While Loading', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'loading_text',
			array(
				'label'       => esc_html__( 'Loading Text', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Processing…', 'subhan-elementor-ajax-cart' ),
				'placeholder' => esc_html__( 'Processing…', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'hide_if_out_of_stock',
			array(
				'label'        => esc_html__( 'Hide If Out of Stock', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->end_controls_section();
	}

	private function register_message_controls() : void {
		$this->start_controls_section(
			'message_section',
			array(
				'label' => esc_html__( 'Messages', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_success_message',
			array(
				'label'        => esc_html__( 'Show Success Message', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'success_message',
			array(
				'label'       => esc_html__( 'Success Message', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Action completed successfully.', 'subhan-elementor-ajax-cart' ),
				'placeholder' => esc_html__( 'Action completed successfully.', 'subhan-elementor-ajax-cart' ),
				'condition'   => array(
					'show_success_message' => 'yes',
				),
			)
		);

		$this->add_control(
			'show_error_message',
			array(
				'label'        => esc_html__( 'Show Error Message', 'subhan-elementor-ajax-cart' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'subhan-elementor-ajax-cart' ),
				'label_off'    => esc_html__( 'No', 'subhan-elementor-ajax-cart' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'error_message',
			array(
				'label'       => esc_html__( 'Error Message', 'subhan-elementor-ajax-cart' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Unable to process this request.', 'subhan-elementor-ajax-cart' ),
				'placeholder' => esc_html__( 'Unable to process this request.', 'subhan-elementor-ajax-cart' ),
				'condition'   => array(
					'show_error_message' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_layout_style_controls() : void {
		$this->start_controls_section(
			'style_layout_section',
			array(
				'label' => esc_html__( 'Style: Layout', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'align',
			array(
				'label'   => esc_html__( 'Alignment', 'subhan-elementor-ajax-cart' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'subhan-elementor-ajax-cart' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'subhan-elementor-ajax-cart' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'subhan-elementor-ajax-cart' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'default'   => 'left',
				'toggle'    => true,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-widget-inner' => 'text-align: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'buttons_gap',
			array(
				'label'      => esc_html__( 'Buttons Gap', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-buttons' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'action_row_gap',
			array(
				'label'      => esc_html__( 'Quantity/Button Gap', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-actions' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_common_button_style_controls() : void {
		$this->start_controls_section(
			'style_common_button_section',
			array(
				'label' => esc_html__( 'Style: Common Button', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn',
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'button_border',
				'selector' => '{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn',
			)
		);

		$this->add_responsive_control(
			'button_border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'button_padding',
			array(
				'label'      => esc_html__( 'Padding', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'button_margin',
			array(
				'label'      => esc_html__( 'Margin', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'icon_spacing',
			array(
				'label'      => esc_html__( 'Icon Spacing', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn .subhan-eac-icon-left'  => 'margin-right: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn .subhan-eac-icon-right' => 'margin-left: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'button_disabled_text_color',
			array(
				'label'     => esc_html__( 'Disabled Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn:disabled, {{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn.is-loading' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_disabled_bg_color',
			array(
				'label'     => esc_html__( 'Disabled Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn:disabled, {{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn.is-loading' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_disabled_opacity',
			array(
				'label'     => esc_html__( 'Disabled Opacity', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 0.1,
				'max'       => 1,
				'step'      => 0.05,
				'default'   => 1,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn:disabled, {{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-btn.is-loading' => 'opacity: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_add_to_cart_button_style_controls() : void {
		$this->start_controls_section(
			'style_add_to_cart_button_section',
			array(
				'label' => esc_html__( 'Style: Add to Cart Button', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( 'add_to_cart_button_tabs' );

		$this->start_controls_tab(
			'add_to_cart_button_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'add_to_cart_button_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-add-to-cart' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'add_to_cart_button_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-add-to-cart' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'add_to_cart_button_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-add-to-cart' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'add_to_cart_button_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'add_to_cart_button_hover_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-add-to-cart:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'add_to_cart_button_hover_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-add-to-cart:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'add_to_cart_button_hover_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-add-to-cart:hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_buy_now_button_style_controls() : void {
		$this->start_controls_section(
			'style_buy_now_button_section',
			array(
				'label' => esc_html__( 'Style: Buy Now Button', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs( 'buy_now_button_tabs' );

		$this->start_controls_tab(
			'buy_now_button_normal_tab',
			array(
				'label' => esc_html__( 'Normal', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'buy_now_button_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-buy-now' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'buy_now_button_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-buy-now' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'buy_now_button_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-buy-now' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'buy_now_button_hover_tab',
			array(
				'label' => esc_html__( 'Hover', 'subhan-elementor-ajax-cart' ),
			)
		);

		$this->add_control(
			'buy_now_button_hover_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-buy-now:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'buy_now_button_hover_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-buy-now:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'buy_now_button_hover_border_color',
			array(
				'label'     => esc_html__( 'Border Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget--product-actions .subhan-eac-buy-now:hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	private function register_price_style_controls() : void {
		$this->start_controls_section(
			'style_price_section',
			array(
				'label' => esc_html__( 'Style: Price', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_typography',
				'selector' => '{{WRAPPER}} .subhan-eac-widget-price',
			)
		);

		$this->add_control(
			'price_color',
			array(
				'label'     => esc_html__( 'Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-widget-price' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'price_spacing',
			array(
				'label'      => esc_html__( 'Bottom Spacing', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 80 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-widget-price' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_variation_style_controls() : void {
		$this->start_controls_section(
			'style_variation_section',
			array(
				'label' => esc_html__( 'Style: Variation', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'variation_label_typography',
				'selector' => '{{WRAPPER}} .subhan-eac-variation-label',
			)
		);

		$this->add_control(
			'variation_label_color',
			array(
				'label'     => esc_html__( 'Label Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-variation-label' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'variation_form_bg_color',
			array(
				'label'     => esc_html__( 'Container Background', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-variation-form' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'variation_form_border',
				'selector' => '{{WRAPPER}} .subhan-eac-variation-form',
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'variation_form_shadow',
				'selector' => '{{WRAPPER}} .subhan-eac-variation-form',
			)
		);

		$this->add_responsive_control(
			'variation_form_radius',
			array(
				'label'      => esc_html__( 'Container Radius', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-variation-form' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'variation_form_padding',
			array(
				'label'      => esc_html__( 'Container Padding', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-variation-form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'variation_rows_gap',
			array(
				'label'      => esc_html__( 'Rows Gap', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-variation-rows' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'variation_swatches_gap',
			array(
				'label'      => esc_html__( 'Swatches Gap', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 30,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-swatches' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'variation_swatch_heading',
			array(
				'label'     => esc_html__( 'Swatch Design', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'variation_swatch_typography',
				'selector' => '{{WRAPPER}} .subhan-eac-swatch',
			)
		);

		$this->add_control(
			'variation_swatch_text_color',
			array(
				'label'     => esc_html__( 'Swatch Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-swatch' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'variation_swatch_bg_color',
			array(
				'label'     => esc_html__( 'Swatch Background', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-swatch' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'variation_swatch_border',
				'selector' => '{{WRAPPER}} .subhan-eac-swatch',
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'variation_swatch_shadow',
				'selector' => '{{WRAPPER}} .subhan-eac-swatch',
			)
		);

		$this->add_responsive_control(
			'variation_swatch_radius',
			array(
				'label'      => esc_html__( 'Swatch Radius', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-swatch' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'variation_swatch_padding',
			array(
				'label'      => esc_html__( 'Swatch Padding', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-swatch' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'variation_swatch_height',
			array(
				'label'      => esc_html__( 'Swatch Height', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 24,
						'max' => 80,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-swatch' => 'height: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'variation_swatch_hover_heading',
			array(
				'label'     => esc_html__( 'Swatch Hover', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'variation_swatch_hover_text_color',
			array(
				'label'     => esc_html__( 'Hover Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-swatch:hover:not(.is-disabled):not(:disabled)'        => 'color: {{VALUE}};',
					'{{WRAPPER}} .subhan-eac-swatch:focus-visible:not(.is-disabled):not(:disabled)' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'variation_swatch_hover_bg_color',
			array(
				'label'     => esc_html__( 'Hover Background', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-swatch:hover:not(.is-disabled):not(:disabled)'        => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .subhan-eac-swatch:focus-visible:not(.is-disabled):not(:disabled)' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'variation_swatch_hover_border_color',
			array(
				'label'     => esc_html__( 'Hover Border Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-swatch:hover:not(.is-disabled):not(:disabled)'        => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .subhan-eac-swatch:focus-visible:not(.is-disabled):not(:disabled)' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'variation_swatch_active_text_color',
			array(
				'label'     => esc_html__( 'Active Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-swatch.is-active' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'variation_swatch_active_bg_color',
			array(
				'label'     => esc_html__( 'Active Background', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-swatch.is-active' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'variation_swatch_active_border_color',
			array(
				'label'     => esc_html__( 'Active Border Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-swatch.is-active' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'variation_dropdown_heading',
			array(
				'label'     => esc_html__( 'Dropdown Design', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_control(
			'variation_dropdown_text_color',
			array(
				'label'     => esc_html__( 'Dropdown Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-variation-value select' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'variation_dropdown_bg_color',
			array(
				'label'     => esc_html__( 'Dropdown Background', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-variation-value select' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'variation_dropdown_border',
				'selector' => '{{WRAPPER}} .subhan-eac-variation-value select',
			)
		);

		$this->add_responsive_control(
			'variation_dropdown_radius',
			array(
				'label'      => esc_html__( 'Dropdown Radius', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-variation-value select' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'variation_dropdown_padding',
			array(
				'label'      => esc_html__( 'Dropdown Padding', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-variation-value select' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_quantity_style_controls() : void {
		$this->start_controls_section(
			'style_quantity_section',
			array(
				'label' => esc_html__( 'Style: Quantity', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'quantity_typography',
				'selector' => '{{WRAPPER}} .subhan-eac-qty-control, {{WRAPPER}} .subhan-eac-qty-input, {{WRAPPER}} .subhan-eac-qty-btn',
			)
		);

		$this->add_control(
			'quantity_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-qty-input, {{WRAPPER}} .subhan-eac-qty-btn' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'quantity_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-qty-control, {{WRAPPER}} .subhan-eac-qty-btn' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'quantity_input_bg_color',
			array(
				'label'     => esc_html__( 'Input Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-qty-input' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'quantity_control_width',
			array(
				'label'      => esc_html__( 'Control Width', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array(
						'min' => 60,
						'max' => 320,
					),
					'%'  => array(
						'min' => 10,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-qty-control' => 'width: {{SIZE}}{{UNIT}}; min-width: 0;',
				),
			)
		);

		$this->add_responsive_control(
			'quantity_height',
			array(
				'label'      => esc_html__( 'Control Height', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 24,
						'max' => 70,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-qty-control' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .subhan-eac-qty-btn'     => 'height: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .subhan-eac-qty-input'   => 'height: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'quantity_button_width',
			array(
				'label'      => esc_html__( 'Plus/Minus Width', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 18,
						'max' => 80,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-qty-btn' => 'width: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}; flex: 0 0 {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'quantity_input_width',
			array(
				'label'      => esc_html__( 'Input Width', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 24,
						'max' => 140,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-qty-input' => 'width: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'quantity_border',
				'selector' => '{{WRAPPER}} .subhan-eac-qty-control',
			)
		);

		$this->add_responsive_control(
			'quantity_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-qty-control' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'quantity_padding',
			array(
				'label'      => esc_html__( 'Input Padding', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-qty-input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function register_message_style_controls() : void {
		$this->start_controls_section(
			'style_message_section',
			array(
				'label' => esc_html__( 'Style: Message', 'subhan-elementor-ajax-cart' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'message_typography',
				'selector' => '{{WRAPPER}} .subhan-eac-message',
			)
		);

		$this->add_control(
			'message_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-message' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'message_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'subhan-elementor-ajax-cart' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .subhan-eac-message' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			array(
				'name'     => 'message_border',
				'selector' => '{{WRAPPER}} .subhan-eac-message',
			)
		);

		$this->add_responsive_control(
			'message_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-message' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'message_padding',
			array(
				'label'      => esc_html__( 'Padding', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-message' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'message_margin',
			array(
				'label'      => esc_html__( 'Margin', 'subhan-elementor-ajax-cart' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .subhan-eac-message' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * @return array<string, mixed>
	 */
	private function get_normalized_settings() : array {
		$settings = $this->get_settings_for_display();

		$product_source = isset( $settings['product_source'] ) && 'custom' === $settings['product_source'] ? 'custom' : 'current';
		$variation_ui         = isset( $settings['variation_layout'] ) && 'swatches' === $settings['variation_layout'] ? 'swatches' : 'dropdown';
		$variation_visibility = isset( $settings['variation_visibility'] ) && 'hidden' === $settings['variation_visibility'] ? 'hidden' : 'visible';

		$normalized = array(
			'product_source'                  => $product_source,
			'custom_product_id'               => isset( $settings['custom_product_id'] ) ? absint( $settings['custom_product_id'] ) : 0,
			'show_add_to_cart'                => ! empty( $settings['show_add_to_cart'] ),
			'add_to_cart_text'                => sanitize_text_field( (string) ( $settings['add_to_cart_text'] ?? esc_html__( 'Add to Cart', 'subhan-elementor-ajax-cart' ) ) ),
			'add_to_cart_icon'                => isset( $settings['add_to_cart_icon'] ) && is_array( $settings['add_to_cart_icon'] ) ? $settings['add_to_cart_icon'] : array(),
			'add_to_cart_icon_position'       => $this->sanitize_icon_position( $settings['add_to_cart_icon_position'] ?? 'left' ),
			'show_buy_now'                    => ! empty( $settings['show_buy_now'] ),
			'buy_now_text'                    => sanitize_text_field( (string) ( $settings['buy_now_text'] ?? esc_html__( 'Buy Now', 'subhan-elementor-ajax-cart' ) ) ),
			'buy_now_icon'                    => isset( $settings['buy_now_icon'] ) && is_array( $settings['buy_now_icon'] ) ? $settings['buy_now_icon'] : array(),
			'buy_now_icon_position'           => $this->sanitize_icon_position( $settings['buy_now_icon_position'] ?? 'left' ),
			'buy_now_position'                => $this->sanitize_buy_now_position( $settings['buy_now_position'] ?? 'right' ),
			'show_product_price'              => ! empty( $settings['show_product_price'] ),
			'enable_quantity'                 => ! empty( $settings['enable_quantity'] ),
			'variation_layout'                => $variation_ui,
			'variation_visibility'            => $variation_visibility,
			'sync_product_presentation'       => ! empty( $settings['sync_product_presentation'] ),
			'full_width'                      => ! empty( $settings['full_width'] ),
			'additional_class'                => sanitize_text_field( (string) ( $settings['additional_class'] ?? '' ) ),
			'add_to_cart_enable_redirect'     => ! empty( $settings['add_to_cart_enable_redirect'] ),
			'add_to_cart_redirect_target'     => $this->sanitize_redirect_target( $settings['add_to_cart_redirect_target'] ?? 'cart', 'cart' ),
			'add_to_cart_redirect_custom_url' => $this->sanitize_url_control_value( $settings['add_to_cart_redirect_custom_url'] ?? array() ),
			'buy_now_enable_redirect'         => ! empty( $settings['buy_now_enable_redirect'] ),
			'buy_now_redirect_target'         => $this->sanitize_redirect_target( $settings['buy_now_redirect_target'] ?? 'checkout', 'checkout' ),
			'buy_now_redirect_custom_url'     => $this->sanitize_url_control_value( $settings['buy_now_redirect_custom_url'] ?? array() ),
			'loading_show_spinner'            => ! empty( $settings['loading_show_spinner'] ),
			'loading_text'                    => sanitize_text_field( (string) ( $settings['loading_text'] ?? '' ) ),
			'show_success_message'            => ! empty( $settings['show_success_message'] ),
			'success_message'                 => sanitize_text_field( (string) ( $settings['success_message'] ?? esc_html__( 'Action completed successfully.', 'subhan-elementor-ajax-cart' ) ) ),
			'show_error_message'              => ! empty( $settings['show_error_message'] ),
			'error_message'                   => sanitize_text_field( (string) ( $settings['error_message'] ?? esc_html__( 'Unable to process this request.', 'subhan-elementor-ajax-cart' ) ) ),
			'hide_if_out_of_stock'            => ! empty( $settings['hide_if_out_of_stock'] ),
		);

		return $normalized;
	}

	private function sanitize_icon_position( $position ) : string {
		return 'right' === $position ? 'right' : 'left';
	}

	private function sanitize_buy_now_position( $position ) : string {
		$clean = sanitize_key( (string) $position );
		if ( ! in_array( $clean, array( 'right', 'left', 'bottom' ), true ) ) {
			return 'right';
		}
		return $clean;
	}

	private function sanitize_redirect_target( $target, string $default ) : string {
		$clean = sanitize_key( (string) $target );
		if ( ! in_array( $clean, array( 'cart', 'checkout', 'custom' ), true ) ) {
			return $default;
		}
		return $clean;
	}

	/**
	 * @param mixed $url_control
	 */
	private function sanitize_url_control_value( $url_control ) : string {
		if ( ! is_array( $url_control ) || empty( $url_control['url'] ) ) {
			return '';
		}
		return esc_url_raw( (string) $url_control['url'] );
	}

	protected function render() {
		$settings = $this->get_normalized_settings();

		if ( ! $settings['show_add_to_cart'] && ! $settings['show_buy_now'] ) {
			return;
		}

		$product = Product_Helper::resolve_product( $settings );
		if ( ! $product instanceof \WC_Product ) {
			return;
		}

		if ( ! Product_Helper::can_render_product( $product, (bool) $settings['hide_if_out_of_stock'] ) ) {
			return;
		}

		if ( ! $product->is_purchasable() ) {
			return;
		}

		$show_quantity = (bool) $settings['enable_quantity'] && Product_Helper::supports_quantity( $product );
		$is_disabled   = ! $product->is_in_stock();
		$min_qty       = max( 1, (int) $product->get_min_purchase_quantity() );
		$max_qty       = (int) $product->get_max_purchase_quantity();
		$render_buy_now_bottom = $settings['show_add_to_cart'] && $settings['show_buy_now'] && 'bottom' === $settings['buy_now_position'];
		$show_buy_now_inline   = $settings['show_buy_now'] && ! $render_buy_now_bottom;

		$wrapper_classes = array(
			'subhan-eac-widget',
			'subhan-eac-widget--product-actions',
			$settings['full_width'] ? 'subhan-eac-has-full-width' : '',
		);

		if ( $settings['show_add_to_cart'] && $settings['show_buy_now'] ) {
			$wrapper_classes[] = 'subhan-eac-buy-now-' . $settings['buy_now_position'];
		}

		$wrapper_classes = array_filter( $wrapper_classes );
		$wrapper_classes = array_merge( $wrapper_classes, $this->sanitize_extra_classes( (string) $settings['additional_class'] ) );

		echo '<div class="' . esc_attr( implode( ' ', $wrapper_classes ) ) . '"'
			. ' data-action-type="add_to_cart"'
			. ' data-product-id="' . esc_attr( (string) $product->get_id() ) . '"'
			. ' data-product-type="' . esc_attr( $product->get_type() ) . '"'
			. ' data-sync-presentation="' . esc_attr( $settings['sync_product_presentation'] ? '1' : '0' ) . '"'
			. ' data-enable-quantity="' . esc_attr( $show_quantity ? '1' : '0' ) . '"'
			. ' data-enable-redirect="0"'
			. ' data-redirect-target="cart"'
			. ' data-redirect-url=""'
			. ' data-loading-spinner="' . esc_attr( $settings['loading_show_spinner'] ? '1' : '0' ) . '"'
			. ' data-loading-text="' . esc_attr( (string) $settings['loading_text'] ) . '"'
			. ' data-show-success="' . esc_attr( $settings['show_success_message'] ? '1' : '0' ) . '"'
			. ' data-success-message="' . esc_attr( (string) $settings['success_message'] ) . '"'
			. ' data-show-error="' . esc_attr( $settings['show_error_message'] ? '1' : '0' ) . '"'
			. ' data-error-message="' . esc_attr( (string) $settings['error_message'] ) . '"'
			. '>';

		echo '<div class="subhan-eac-widget-inner">';
		if ( $settings['show_product_price'] ) {
			echo '<div class="subhan-eac-widget-price">' . wp_kses_post( $product->get_price_html() ) . '</div>';
		}

		if ( $product->is_type( 'variable' ) ) {
			echo Render_Helper::render_variation_form( $product, (string) $settings['variation_layout'], (string) $settings['variation_visibility'] );
		}

		echo '<div class="subhan-eac-actions">';

		if ( $show_quantity ) {
			echo '<div class="subhan-eac-qty-control" data-min="' . esc_attr( (string) $min_qty ) . '" data-max="' . esc_attr( (string) $max_qty ) . '">';
			echo '<button type="button" class="subhan-eac-qty-btn subhan-eac-qty-minus" aria-label="' . esc_attr__( 'Decrease quantity', 'subhan-elementor-ajax-cart' ) . '">-</button>';
			echo '<input type="number" class="subhan-eac-qty-input" min="' . esc_attr( (string) $min_qty ) . '"' . ( $max_qty > 0 ? ' max="' . esc_attr( (string) $max_qty ) . '"' : '' ) . ' step="1" value="' . esc_attr( (string) $min_qty ) . '" inputmode="numeric" aria-label="' . esc_attr__( 'Quantity', 'subhan-elementor-ajax-cart' ) . '">';
			echo '<button type="button" class="subhan-eac-qty-btn subhan-eac-qty-plus" aria-label="' . esc_attr__( 'Increase quantity', 'subhan-elementor-ajax-cart' ) . '">+</button>';
			echo '</div>';
		}

		echo '<div class="subhan-eac-buttons">';

		if ( $settings['show_add_to_cart'] ) {
			$this->render_action_button(
				'add_to_cart',
				(string) $settings['add_to_cart_text'],
				(array) $settings['add_to_cart_icon'],
				(string) $settings['add_to_cart_icon_position'],
				(bool) $settings['add_to_cart_enable_redirect'],
				(string) $settings['add_to_cart_redirect_target'],
				(string) $settings['add_to_cart_redirect_custom_url'],
				(bool) $settings['full_width'],
				$is_disabled
			);
		}

		if ( $show_buy_now_inline ) {
			$this->render_action_button(
				'buy_now',
				(string) $settings['buy_now_text'],
				(array) $settings['buy_now_icon'],
				(string) $settings['buy_now_icon_position'],
				(bool) $settings['buy_now_enable_redirect'],
				(string) $settings['buy_now_redirect_target'],
				(string) $settings['buy_now_redirect_custom_url'],
				(bool) $settings['full_width'],
				$is_disabled
			);
		}

		echo '</div>';
		echo '</div>';

		if ( $render_buy_now_bottom ) {
			echo '<div class="subhan-eac-buy-now-bottom-wrap">';
			$this->render_action_button(
				'buy_now',
				(string) $settings['buy_now_text'],
				(array) $settings['buy_now_icon'],
				(string) $settings['buy_now_icon_position'],
				(bool) $settings['buy_now_enable_redirect'],
				(string) $settings['buy_now_redirect_target'],
				(string) $settings['buy_now_redirect_custom_url'],
				true,
				$is_disabled
			);
			echo '</div>';
		}

		echo '<div class="subhan-eac-message" role="status" aria-live="polite"></div>';
		echo '</div>';
		echo '</div>';
	}

	private function render_action_button(
		string $action_type,
		string $button_text,
		array $icon,
		string $icon_position,
		bool $enable_redirect,
		string $redirect_target,
		string $redirect_url,
		bool $full_width,
		bool $is_disabled
	) : void {
		$action_type = 'buy_now' === $action_type ? 'buy_now' : 'add_to_cart';
		$icon_html   = $this->get_icon_html( $icon, $icon_position );

		$button_classes = array(
			'subhan-eac-btn',
			'elementor-button',
			'add_to_cart' === $action_type ? 'subhan-eac-add-to-cart' : 'subhan-eac-buy-now',
		);

		if ( $full_width ) {
			$button_classes[] = 'is-full-width';
		}

		echo '<button type="button" class="' . esc_attr( implode( ' ', $button_classes ) ) . '"'
			. ' data-action-type="' . esc_attr( $action_type ) . '"'
			. ' data-enable-redirect="' . esc_attr( $enable_redirect ? '1' : '0' ) . '"'
			. ' data-redirect-target="' . esc_attr( $redirect_target ) . '"'
			. ' data-redirect-url="' . esc_attr( $redirect_url ) . '"'
			. ( $is_disabled ? ' disabled' : '' )
			. '>';

		echo '<span class="subhan-eac-spinner" aria-hidden="true"></span>';

		if ( 'left' === $icon_position ) {
			echo $icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		echo '<span class="subhan-eac-btn-label">' . esc_html( $button_text ) . '</span>';

		if ( 'right' === $icon_position ) {
			echo $icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		echo '</button>';
	}

	/**
	 * @return array<int, string>
	 */
	private function sanitize_extra_classes( string $raw_classes ) : array {
		if ( '' === trim( $raw_classes ) ) {
			return array();
		}

		$classes = preg_split( '/\s+/', $raw_classes );
		if ( ! is_array( $classes ) ) {
			return array();
		}

		$clean = array();
		foreach ( $classes as $class_name ) {
			$sanitized = sanitize_html_class( (string) $class_name );
			if ( $sanitized ) {
				$clean[] = $sanitized;
			}
		}

		return $clean;
	}

	private function get_icon_html( array $icon, string $position ) : string {
		if ( empty( $icon['value'] ) ) {
			return '';
		}

		ob_start();
		Icons_Manager::render_icon( $icon, array( 'aria-hidden' => 'true' ) );
		$rendered_icon = trim( (string) ob_get_clean() );

		if ( '' === $rendered_icon ) {
			return '';
		}

		return '<span class="subhan-eac-icon subhan-eac-icon-' . esc_attr( $position ) . '">' . $rendered_icon . '</span>';
	}
}
