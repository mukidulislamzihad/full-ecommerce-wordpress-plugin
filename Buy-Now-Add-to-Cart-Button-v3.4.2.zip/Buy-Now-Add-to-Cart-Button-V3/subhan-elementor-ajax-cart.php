<?php
/**
 * Plugin Name: Buy Now & Add to Cart Button
 * Description: Widget-only Borbila Elementor Add to Cart and Buy Now controls for single products and WooCommerce loops, with reliable AJAX cart actions.
 * Version: 3.4.2
 * Author: Borbila
 * Author URI:  https://borbila.com
 * Text Domain: subhan-elementor-ajax-cart
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

define( 'SUBHAN_EAC_PLUGIN_FILE', __FILE__ );
define( 'SUBHAN_EAC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SUBHAN_EAC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'SUBHAN_EAC_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'SUBHAN_EAC_VERSION', '3.4.2' );

require_once SUBHAN_EAC_PLUGIN_DIR . 'includes/class-init.php';

/** Remove data and scheduled checks left by versions that required activation. */
add_action(
	'init',
	static function() : void {
		if ( wp_next_scheduled( 'borbila_eac_daily_license_check' ) ) {
			wp_clear_scheduled_hook( 'borbila_eac_daily_license_check' );
		}

		if ( false !== get_option( 'borbila_eac_license', false ) ) {
			delete_option( 'borbila_eac_license' );
		}
	},
	1
);

register_activation_hook(
	__FILE__,
	static function() : void {
		wp_clear_scheduled_hook( 'borbila_eac_daily_license_check' );
		delete_option( 'borbila_eac_license' );
	}
);

\Subhan_EAC\Init::instance();
