(function ($) {
    'use strict';

    var cfg = window.SubhanEACFrontend || {};
    var i18n = cfg.i18n || {};

    var SELECTORS = {
        widget: '.subhan-eac-widget',
        button: '.subhan-eac-btn',
        buttonLabel: '.subhan-eac-btn-label',
        message: '.subhan-eac-message',
        qtyInput: '.subhan-eac-qty-input',
        qtyMinus: '.subhan-eac-qty-minus',
        qtyPlus: '.subhan-eac-qty-plus',
        variationForm: '.subhan-eac-variation-form',
        swatch: '.subhan-eac-swatch',
        resetVariations: '.subhan-eac-variation-form .reset_variations'
    };

    function asBool(value) {
        return value === true || value === 'true' || value === 1 || value === '1' || value === 'yes';
    }

    function asInt(value, fallback) {
        var parsed = parseInt(value, 10);
        return isNaN(parsed) ? fallback : parsed;
    }

    function valueOrFallback(value, fallback) {
        return typeof value === 'undefined' ? fallback : value;
    }

    function escapeSelectorValue(value) {
        if (window.CSS && typeof window.CSS.escape === 'function') {
            return window.CSS.escape(value);
        }
        return String(value).replace(/([ #;?%&,.+*~':"!^$\[\]()=>|\/@])/g, '\\$1');
    }

    function getWidgetData($widget) {
        return {
            actionType: String($widget.data('action-type') || 'add_to_cart'),
            productId: asInt($widget.data('product-id'), 0),
            productType: String($widget.data('product-type') || ''),
            syncPresentation: asBool($widget.data('sync-presentation')),
            enableQuantity: asBool($widget.data('enable-quantity')),
            enableRedirect: asBool($widget.data('enable-redirect')),
            redirectTarget: String($widget.data('redirect-target') || 'cart'),
            redirectUrl: String($widget.data('redirect-url') || ''),
            loadingSpinner: asBool($widget.data('loading-spinner')),
            loadingText: String($widget.data('loading-text') || ''),
            showSuccess: asBool($widget.data('show-success')),
            successMessage: String($widget.data('success-message') || ''),
            showError: asBool($widget.data('show-error')),
            errorMessage: String($widget.data('error-message') || '')
        };
    }

    function getActionData($button, widgetData) {
        var actionTypeRaw = String(valueOrFallback($button.data('action-type'), widgetData.actionType || 'add_to_cart'));
        var actionType = actionTypeRaw === 'buy_now' ? 'buy_now' : 'add_to_cart';

        var enableRedirectRaw = valueOrFallback($button.data('enable-redirect'), widgetData.enableRedirect);
        var redirectTargetRaw = String(valueOrFallback($button.data('redirect-target'), widgetData.redirectTarget || 'cart'));
        var redirectTarget = redirectTargetRaw === 'checkout' || redirectTargetRaw === 'custom' ? redirectTargetRaw : 'cart';

        return {
            actionType: actionType,
            enableRedirect: asBool(enableRedirectRaw),
            redirectTarget: redirectTarget,
            redirectUrl: String(valueOrFallback($button.data('redirect-url'), widgetData.redirectUrl || ''))
        };
    }

    function clearMessage($widget) {
        var $message = $widget.find(SELECTORS.message).first();
        if (!$message.length) {
            return;
        }

        $message.removeClass('is-visible is-success is-error').text('');
    }

    function showMessage($widget, type, text) {
        var $message = $widget.find(SELECTORS.message).first();
        if (!$message.length || !text) {
            return;
        }

        $message
            .removeClass('is-success is-error')
            .addClass('is-visible is-' + type)
            .text(text);
    }

    function setLoadingState($button, widgetData, isLoading) {
        var $label = $button.find(SELECTORS.buttonLabel).first();
        var originalText = String($button.data('original-text') || $label.text());

        if (!$button.data('has-original-text')) {
            $button.data('original-text', originalText);
            $button.data('has-original-text', 1);
        }

        if (isLoading) {
            $button.addClass('is-loading');
            $button.prop('disabled', true);

            if (widgetData.loadingSpinner) {
                $button.addClass('show-spinner');
            } else {
                $button.removeClass('show-spinner');
            }

            if (widgetData.loadingText) {
                $label.text(widgetData.loadingText);
            }
        } else {
            $button.removeClass('is-loading show-spinner');

            if (!$button.data('hard-disabled')) {
                $button.prop('disabled', false);
            }

            $label.text(originalText);
        }
    }

    function sanitizeQtyValue($input) {
        var min = asInt($input.attr('min'), 1);
        var max = asInt($input.attr('max'), 0);
        var value = asInt($input.val(), min);

        if (value < min) {
            value = min;
        }

        if (max > 0 && value > max) {
            value = max;
        }

        $input.val(value);
        return value;
    }

    function getVariationPayload($widget) {
        var $form = $widget.find(SELECTORS.variationForm).first();
        if (!$form.length) {
            return {
                hasForm: false,
                missingSelection: false,
                variationId: 0,
                variation: {}
            };
        }

        return syncVariationState($form);
    }

    function getVariationEntries($form) {
        if (!$form.length) {
            return [];
        }

        var cachedEntries = $form.data('subhanEacVariationEntries');
        if ($.isArray(cachedEntries)) {
            return cachedEntries;
        }

        var raw = String($form.attr('data-subhan-variation-data') || '');
        if (!raw) {
            $form.data('subhanEacVariationEntries', []);
            return [];
        }

        try {
            var parsed = JSON.parse(raw);
            var entries = $.isArray(parsed) ? parsed : [];
            $form.data('subhanEacVariationEntries', entries);
            return entries;
        } catch (e) {
            $form.data('subhanEacVariationEntries', []);
            return [];
        }
    }

    function buildVariationSignature(attributes) {
        var keys = Object.keys(attributes || {}).sort();
        var parts = [];

        for (var i = 0; i < keys.length; i += 1) {
            var key = String(keys[i] || '');
            var value = String(attributes[key] || '').trim();

            if (!key || !value) {
                continue;
            }

            parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
        }

        return parts.join('|');
    }

    function getSelectedVariationAttributes($form) {
        var variation = {};
        var missing = false;

        $form.find('select[name^="attribute_"]').each(function () {
            var $select = $(this);
            var fieldName = String($select.attr('name') || '');
            var value = String($select.val() || '');

            if (!fieldName) {
                return;
            }

            variation[fieldName] = value;
            if (!value) {
                missing = true;
            }
        });

        return {
            missingSelection: missing,
            variation: variation
        };
    }

    function variationEntryIsAvailable(entry) {
        return !!entry && !!entry.id && !!entry.attributes && entry.active !== false && entry.purchasable !== false && entry.in_stock !== false;
    }

    function variationEntryMatches(entryAttributes, selectedAttributes, overrideAttribute, overrideValue) {
        var matched = true;

        $.each(selectedAttributes, function (attributeKey, selectedValue) {
            var value = String(selectedValue || '');
            if (attributeKey === overrideAttribute) {
                value = String(overrideValue || '');
            }

            if (!value) {
                return true;
            }

            var expected = String((entryAttributes && entryAttributes[attributeKey]) || '');
            // Empty variation attributes are WooCommerce "Any…" wildcards.
            if (expected && expected !== value) {
                matched = false;
                return false;
            }

            return true;
        });

        return matched;
    }

    function getVariationLookup($form) {
        if (!$form.length) {
            return {};
        }

        var cachedLookup = $form.data('subhanEacVariationLookup');
        if (cachedLookup && typeof cachedLookup === 'object' && !$.isArray(cachedLookup)) {
            return cachedLookup;
        }

        var entries = getVariationEntries($form);
        var lookup = {};

        $.each(entries, function (_, entry) {
            if (!variationEntryIsAvailable(entry)) {
                return true;
            }

            var signature = buildVariationSignature(entry.attributes || {});
            var variationId = asInt(entry.id, 0);

            if (signature && variationId > 0) {
                lookup[signature] = variationId;
            }
        });

        $form.data('subhanEacVariationLookup', lookup);
        return lookup;
    }

    function resolveVariationIdFromLookup($form, selectedAttributes) {
        var lookup = getVariationLookup($form);
        var signature = buildVariationSignature(selectedAttributes);
        var exactMatch = signature ? asInt(lookup[signature], 0) : 0;

        if (exactMatch > 0) {
            return exactMatch;
        }

        // Fall back to wildcard-aware matching for variations configured with
        // one or more "Any…" attributes.
        var entries = getVariationEntries($form);
        for (var i = 0; i < entries.length; i += 1) {
            var entry = entries[i];
            if (variationEntryIsAvailable(entry) && variationEntryMatches(entry.attributes || {}, selectedAttributes)) {
                return asInt(entry.id, 0);
            }
        }

        return 0;
    }

    function getVariationEntryById($form, variationId) {
        var entries = getVariationEntries($form);
        var targetId = asInt(variationId, 0);

        for (var i = 0; i < entries.length; i += 1) {
            if (asInt(entries[i] && entries[i].id, 0) === targetId) {
                return entries[i];
            }
        }

        return null;
    }

    function getCurrentSingleProductId() {
        var className = String(document.body && document.body.className || '');
        var match = className.match(/(?:^|\s)postid-(\d+)(?:\s|$)/);

        if (match && match[1]) {
            return asInt(match[1], 0);
        }

        var $product = $('div.product[id^="product-"]').first();
        var productMatch = String($product.attr('id') || '').match(/^product-(\d+)$/);
        return productMatch && productMatch[1] ? asInt(productMatch[1], 0) : 0;
    }

    function shouldSyncSingleProductPresentation($form) {
        var hasSingleProduct = $('body').hasClass('single-product') || $('.elementor-location-single.product, [data-elementor-type="product"]').length > 0;
        if (!hasSingleProduct) {
            return false;
        }

        var formProductId = asInt($form.attr('data-product_id'), 0);
        var pageProductId = getCurrentSingleProductId();

        return formProductId > 0 && (!pageProductId || formProductId === pageProductId);
    }

    function isSecondaryProductElement() {
        return $(this).closest('.related, .upsells, .cross-sells, .products, .wc-block-grid, .elementor-loop-container, .e-loop-item, .elementor-widget-woocommerce-products, .elementor-widget-woocommerce-product-related, .elementor-widget-woocommerce-product-upsell').length > 0;
    }

    function getSinglePriceTargets(productId) {
        var $targets = $();

        $targets = $targets.add($('.elementor-location-single.product .elementor-widget-woocommerce-product-price .price'));
        $targets = $targets.add($('[data-elementor-type="product"] .elementor-widget-woocommerce-product-price .price'));
        $targets = $targets.add($('#product-' + productId + ' .summary > .price, #product-' + productId + ' .entry-summary > .price'));

        return $targets.filter(function () {
            return !isSecondaryProductElement.call(this);
        });
    }

    function captureOriginalPrice($price) {
        if ($price.data('subhanEacOriginalPriceCaptured')) {
            return;
        }

        $price.data('subhanEacOriginalPriceCaptured', 1);
        $price.data('subhanEacOriginalPriceHtml', $price.html());
    }

    function updateSingleProductPrice(productId, priceHtml) {
        var $targets = getSinglePriceTargets(productId);

        $targets.each(function () {
            var $price = $(this);
            captureOriginalPrice($price);

            if (priceHtml) {
                // price_html is generated and sanitized by WooCommerce on the server.
                $price.html(priceHtml);
            } else {
                $price.html(String($price.data('subhanEacOriginalPriceHtml') || ''));
            }
        });
    }

    function getNearbyElementorImageTarget($form) {
        var $ancestor = $form.parent();

        while ($ancestor.length && !$ancestor.is('body')) {
            var $candidates = $ancestor
                .find('.elementor-widget-image:not(.elementor-widget-theme-site-logo) img, .elementor-widget-theme-post-featured-image img')
                .filter(function () {
                    if (isSecondaryProductElement.call(this) || $(this).closest('header, footer, .elementor-location-header, .elementor-location-footer').length) {
                        return false;
                    }

                    var rect = this.getBoundingClientRect();
                    return rect.width >= 120 && rect.height >= 120;
                });

            if ($candidates.length) {
                // The first ancestor containing a sizeable image is the closest
                // shared product-detail container. This supports custom Elementor
                // hero images without touching lower product loops.
                return $candidates.first();
            }

            $ancestor = $ancestor.parent();
        }

        return $();
    }

    function getSingleImageTargets(productId, $form) {
        var $targets = $();
        var mainSelectors = [
            '#product-' + productId + ' .woocommerce-product-gallery__wrapper .woocommerce-product-gallery__image:first-child img',
            '#product-' + productId + ' .woocommerce-product-gallery__image:first img.wp-post-image',
            '.elementor-location-single.product .elementor-widget-woocommerce-product-images .woocommerce-product-gallery__image:first img',
            '[data-elementor-type="product"] .elementor-widget-woocommerce-product-images .woocommerce-product-gallery__image:first img'
        ];

        for (var i = 0; i < mainSelectors.length; i += 1) {
            $targets = $targets.add($(mainSelectors[i]));
        }

        $targets = $targets.filter(function () {
            return !isSecondaryProductElement.call(this);
        });

        if (!$targets.length && $form && $form.length) {
            $targets = getNearbyElementorImageTarget($form);
        }

        return $targets;
    }

    function readImageAttribute($image, name) {
        var value = $image.attr(name);
        return typeof value === 'undefined' ? null : String(value);
    }

    function captureOriginalImage($image) {
        if ($image.data('subhanEacOriginalImageCaptured')) {
            return;
        }

        var attributes = {};
        var names = ['src', 'srcset', 'sizes', 'alt', 'title', 'width', 'height', 'data-src', 'data-large_image', 'data-large_image_width', 'data-large_image_height'];

        for (var i = 0; i < names.length; i += 1) {
            attributes[names[i]] = readImageAttribute($image, names[i]);
        }

        var $link = $image.closest('.woocommerce-product-gallery__image').find('a').first();
        $image.data('subhanEacOriginalImageCaptured', 1);
        $image.data('subhanEacOriginalImageAttributes', attributes);
        $image.data('subhanEacOriginalImageLink', $link.length ? readImageAttribute($link, 'href') : null);
    }

    function setOrRemoveAttribute($element, name, value) {
        if (value === null || typeof value === 'undefined' || value === '') {
            $element.removeAttr(name);
            return;
        }

        $element.attr(name, String(value));
    }

    function restoreSingleProductImage($image) {
        var attributes = $image.data('subhanEacOriginalImageAttributes') || {};

        $.each(attributes, function (name, value) {
            setOrRemoveAttribute($image, name, value);
        });

        var $link = $image.closest('.woocommerce-product-gallery__image').find('a').first();
        if ($link.length) {
            setOrRemoveAttribute($link, 'href', $image.data('subhanEacOriginalImageLink'));
        }
    }

    function updateSingleProductImage(productId, image, $form) {
        var $targets = getSingleImageTargets(productId, $form);
        var hasVariationImage = image && image.src;

        $targets.each(function () {
            var $image = $(this);
            captureOriginalImage($image);

            if (!hasVariationImage) {
                restoreSingleProductImage($image);
                return;
            }

            setOrRemoveAttribute($image, 'src', image.src);
            setOrRemoveAttribute($image, 'srcset', image.srcset);
            setOrRemoveAttribute($image, 'sizes', image.sizes);
            setOrRemoveAttribute($image, 'alt', image.alt);
            setOrRemoveAttribute($image, 'title', image.title);
            setOrRemoveAttribute($image, 'width', image.src_width);
            setOrRemoveAttribute($image, 'height', image.src_height);
            setOrRemoveAttribute($image, 'data-src', image.src);
            setOrRemoveAttribute($image, 'data-large_image', image.full_src || image.src);
            setOrRemoveAttribute($image, 'data-large_image_width', image.full_width || image.src_width);
            setOrRemoveAttribute($image, 'data-large_image_height', image.full_height || image.src_height);

            var $link = $image.closest('.woocommerce-product-gallery__image').find('a').first();
            if ($link.length) {
                setOrRemoveAttribute($link, 'href', image.full_src || image.src);
            }
        });

        if ($targets.length) {
            var $gallery = $targets.first().closest('.woocommerce-product-gallery');
            $gallery.find('.zoomImg').attr('src', hasVariationImage ? (image.full_src || image.src) : String($targets.first().attr('data-large_image') || $targets.first().attr('src') || ''));
            $gallery.trigger('woocommerce_gallery_reset_slide_position');
        }
    }

    function syncSingleProductPresentation($form, variationId) {
        if (!shouldSyncSingleProductPresentation($form)) {
            return;
        }

        var productId = asInt($form.attr('data-product_id'), 0);
        var entry = getVariationEntryById($form, variationId);

        updateSingleProductPrice(productId, entry && entry.price_html ? String(entry.price_html) : '');
        updateSingleProductImage(productId, entry && entry.image ? entry.image : null, $form);

        $(document.body).trigger('subhan_eac_variation_presentation_changed', [entry, $form]);
    }

    function syncLoopProductImage($form, entry) {
        var $card = $form.closest('.e-loop-item, li.product, .wc-block-grid__product, .products .product').first();
        if (!$card.length) {
            return;
        }

        var $image = $card.find('.woocommerce-loop-product__link img, .attachment-woocommerce_thumbnail, img.wp-post-image').first();
        if (!$image.length) {
            return;
        }

        captureOriginalImage($image);
        var image = entry && entry.image ? entry.image : null;
        if (!image || !image.src) {
            restoreSingleProductImage($image);
            return;
        }

        setOrRemoveAttribute($image, 'src', image.src);
        setOrRemoveAttribute($image, 'srcset', image.srcset);
        setOrRemoveAttribute($image, 'sizes', image.sizes);
        setOrRemoveAttribute($image, 'alt', image.alt);
        setOrRemoveAttribute($image, 'title', image.title);
        setOrRemoveAttribute($image, 'width', image.src_width);
        setOrRemoveAttribute($image, 'height', image.src_height);
        setOrRemoveAttribute($image, 'data-src', image.src);
    }

    function syncConfiguredProductPresentation($form, variationId) {
        var $widget = $form.closest(SELECTORS.widget);
        if (!$widget.length || !asBool($widget.data('sync-presentation'))) {
            return;
        }

        var entry = getVariationEntryById($form, variationId);
        if (shouldSyncSingleProductPresentation($form)) {
            syncSingleProductPresentation($form, variationId);
        } else {
            syncLoopProductImage($form, entry);
            $(document.body).trigger('subhan_eac_variation_presentation_changed', [entry, $form]);
        }
    }

    function syncWidgetPrice($form, variationId) {
        var $price = $form.closest(SELECTORS.widget).find('.subhan-eac-widget-price').first();
        if (!$price.length) {
            return;
        }

        if (!$price.data('subhanEacOriginalPriceCaptured')) {
            $price.data('subhanEacOriginalPriceCaptured', 1);
            $price.data('subhanEacOriginalPriceHtml', $price.html());
        }

        var entry = getVariationEntryById($form, variationId);
        if (entry && entry.price_html) {
            $price.html(String(entry.price_html));
        } else {
            $price.html(String($price.data('subhanEacOriginalPriceHtml') || ''));
        }
    }

    function ensureHiddenVariationSelection($form) {
        if (String($form.attr('data-variation-visibility') || 'visible') !== 'hidden') {
            return;
        }

        var state = getSelectedVariationAttributes($form);
        if (!state.missingSelection && resolveVariationIdFromLookup($form, state.variation) > 0) {
            return;
        }

        var entries = getVariationEntries($form);
        var selectedEntry = null;
        for (var i = 0; i < entries.length; i += 1) {
            if (variationEntryIsAvailable(entries[i])) {
                selectedEntry = entries[i];
                break;
            }
        }

        if (!selectedEntry) {
            return;
        }

        $form.find('select[name^="attribute_"]').each(function () {
            var $select = $(this);
            var attributeName = String($select.attr('name') || '');
            var targetValue = String((selectedEntry.attributes && selectedEntry.attributes[attributeName]) || '');

            if (targetValue && $select.find('option[value="' + escapeSelectorValue(targetValue) + '"]').length) {
                $select.val(targetValue);
                return;
            }

            var $fallback = $select.find('option[value!=""]:not(:disabled)').first();
            if ($fallback.length) {
                $select.val(String($fallback.attr('value') || ''));
            }
        });
    }

    function updateVariationOptionAvailability($form, selectedAttributes) {
        var entries = getVariationEntries($form);

        if (!entries.length) {
            return;
        }

        $form.find('select[name^="attribute_"]').each(function () {
            var $select = $(this);
            var attributeName = String($select.attr('name') || '');

            if (!attributeName) {
                return;
            }

            $select.find('option').each(function () {
                var $option = $(this);
                var optionValue = String($option.attr('value') || '');

                if (!optionValue) {
                    return;
                }

                var available = false;

                for (var i = 0; i < entries.length; i += 1) {
                    var entry = entries[i];

                    if (!variationEntryIsAvailable(entry)) {
                        continue;
                    }

                    if (variationEntryMatches(entry.attributes || {}, selectedAttributes, attributeName, optionValue)) {
                        available = true;
                        break;
                    }
                }

                $option.prop('disabled', !available);
            });
        });
    }

    function syncVariationState($form) {
        if (!$form.length) {
            return {
                hasForm: false,
                missingSelection: false,
                variationId: 0,
                variation: {}
            };
        }

        var variationState = getSelectedVariationAttributes($form);
        var variationId = 0;
        var selectCount = $form.find('select[name^="attribute_"]').length;

        // Single-attribute forms are the common mobile path; keep them lightweight
        // and avoid recalculating availability on every tap.
        if (selectCount > 1) {
            updateVariationOptionAvailability($form, variationState.variation);
        }

        $form.find('select[name^="attribute_"]').each(function () {
            syncSwatchState($(this));
        });

        if (!variationState.missingSelection) {
            variationId = resolveVariationIdFromLookup($form, variationState.variation);
        }

        $form.find('input[name="variation_id"]').val(variationId);

        syncWidgetPrice($form, variationId);
        syncConfiguredProductPresentation($form, variationId);

        return {
            hasForm: true,
            missingSelection: variationState.missingSelection,
            variationId: variationId,
            variation: variationState.variation
        };
    }

    function syncSwatchState($select) {
        var value = String($select.val() || '');
        var safeValue = escapeSelectorValue(value);
        var $container = $select.siblings('.subhan-eac-swatches').first();

        if (!$container.length) {
            return;
        }

        var availability = {};
        $select.find('option').each(function () {
            var $option = $(this);
            var optionValue = String($option.attr('value') || '');
            if (!optionValue) {
                return;
            }

            availability[optionValue] = $option.is(':disabled');
        });

        $container.find(SELECTORS.swatch).each(function () {
            var $swatch = $(this);
            var swatchValue = String($swatch.data('value') || '');
            var isDisabled = !!availability[swatchValue];

            $swatch
                .toggleClass('is-disabled', isDisabled)
                .prop('disabled', isDisabled)
                .attr('aria-disabled', isDisabled ? 'true' : 'false');
        });

        $container.find(SELECTORS.swatch).removeClass('is-active');
        if (value) {
            $container.find(SELECTORS.swatch + '[data-value="' + safeValue + '"]').addClass('is-active');
        }
    }

    function buildSwatches($form) {
        if (!$form.length) {
            return;
        }

        if (!$form.hasClass('subhan-eac-layout-swatches')) {
            return;
        }

        $form.find('select[name^="attribute_"]').each(function () {
            var $select = $(this);
            var $swatches = $select.siblings('.subhan-eac-swatches').first();

            if (!$swatches.length) {
                return;
            }

            if ($swatches.children().length) {
                syncSwatchState($select);
                return;
            }

            $swatches.empty();

            $select.find('option').each(function () {
                var $option = $(this);
                var value = String($option.attr('value') || '');
                var label = String($option.text() || '').trim();
                var isDisabled = $option.is(':disabled');

                if (!value || !label) {
                    return;
                }

                var $swatch = $('<button type="button" class="subhan-eac-swatch"></button>');
                $swatch.attr('data-value', value);
                $swatch.text(label);
                if (isDisabled) {
                    $swatch
                        .addClass('is-disabled')
                        .prop('disabled', true)
                        .attr('aria-disabled', 'true');
                }
                $swatches.append($swatch);
            });

            syncSwatchState($select);
        });
    }

    function initVariationForms(context) {
        $(SELECTORS.variationForm, context).each(function () {
            var $form = $(this);
            ensureHiddenVariationSelection($form);
            buildSwatches($form);
            syncVariationState($form);
        });
    }

    function getFallbackMessage(type) {
        if (type === 'success') {
            return i18n.success || 'Done successfully.';
        }
        return i18n.error || 'Something went wrong.';
    }

    function getUserMessage(widgetData, type, serverMessage) {
        if (type === 'success' && widgetData.showSuccess) {
            return widgetData.successMessage || serverMessage || getFallbackMessage('success');
        }

        if (type === 'error' && widgetData.showError) {
            return serverMessage || widgetData.errorMessage || getFallbackMessage('error');
        }

        return '';
    }

    function buildPayload($widget, widgetData, actionData) {
        var payload = {
            action: 'subhan_eac_widget_action',
            nonce: cfg.nonce || '',
            action_type: actionData.actionType,
            product_id: widgetData.productId,
            quantity: 1,
            enable_redirect: actionData.enableRedirect ? 1 : 0,
            redirect_target: actionData.redirectTarget,
            redirect_custom_url: actionData.redirectUrl
        };

        if (widgetData.enableQuantity) {
            var $qty = $widget.find(SELECTORS.qtyInput).first();
            if ($qty.length) {
                payload.quantity = sanitizeQtyValue($qty);
            }
        }

        var variationPayload = getVariationPayload($widget);
        if (variationPayload.hasForm) {
            payload.variation_id = variationPayload.variationId;
            payload.variation = variationPayload.variation;
        }

        return payload;
    }

    function removeWooViewCartLink($button) {
        var $widget = $button.closest(SELECTORS.widget);
        if (!$widget.length) {
            return;
        }

        $widget.find('a.added_to_cart').remove();
    }

    function maybeTriggerWooRefresh(responseData, $button) {
        var fragments = responseData && responseData.fragments ? responseData.fragments : null;
        var cartHash = responseData && responseData.cart_hash ? String(responseData.cart_hash) : '';

        if (fragments && typeof fragments === 'object') {
            $.each(fragments, function (selector, html) {
                if (typeof selector !== 'string') {
                    return;
                }

                $(selector).replaceWith(html);
            });

            // Keep compatibility with Woo/theme mini-cart listeners.
            $(document.body).trigger('added_to_cart', [fragments, cartHash, $button]);
            removeWooViewCartLink($button);
            window.setTimeout(function () {
                removeWooViewCartLink($button);
            }, 0);
            return;
        }

        // Fallback when fragments are not present in response.
        $(document.body).trigger('wc_fragment_refresh');
    }

    function normalizeEndpoint(url) {
        var raw = String(url || '');
        if (!raw) {
            return '';
        }

        try {
            var parsed = new window.URL(raw, window.location.href);
            // Cached HTML after HTTPS/domain changes can contain an old AJAX
            // origin. Keep the valid WordPress path/query on the current site.
            if (parsed.protocol !== window.location.protocol || parsed.host !== window.location.host) {
                parsed.protocol = window.location.protocol;
                parsed.host = window.location.host;
            }
            return parsed.toString();
        } catch (e) {
            return raw;
        }
    }

    function extractErrorMessage(xhr, response) {
        if (response && response.data && response.data.message) {
            return String(response.data.message);
        }

        if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
            return String(xhr.responseJSON.data.message);
        }

        if (xhr && xhr.responseText) {
            try {
                var parsed = JSON.parse(xhr.responseText);
                if (parsed && parsed.data && parsed.data.message) {
                    return String(parsed.data.message);
                }
            } catch (e) {
                return '';
            }
        }

        return '';
    }

    function responseErrorCode(xhr, response) {
        if (response && response.data && response.data.code) {
            return String(response.data.code);
        }
        if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.code) {
            return String(xhr.responseJSON.data.code);
        }
        return '';
    }

    function isNonceFailure(xhr, response) {
        var code = responseErrorCode(xhr, response);
        var message = extractErrorMessage(xhr, response).toLowerCase();
        var interceptedForbidden = xhr && asInt(xhr.status, 0) === 403 && !code;
        return code === 'invalid_nonce' || interceptedForbidden || message.indexOf('security check failed') !== -1 || message.indexOf('invalid nonce') !== -1;
    }

    function refreshNonce() {
        var endpoint = normalizeEndpoint(cfg.nonceUrl || cfg.fallbackAjaxUrl);
        if (!endpoint) {
            return $.Deferred().reject().promise();
        }

        return $.ajax({
            url: endpoint,
            method: 'GET',
            dataType: 'json',
            cache: false,
            timeout: 12000,
            data: {
                action: 'subhan_eac_refresh_nonce',
                cache_bust: Date.now()
            }
        }).then(function (response) {
            if (!response || !response.success || !response.data || !response.data.nonce) {
                return $.Deferred().reject().promise();
            }

            cfg.nonce = String(response.data.nonce);
            if (response.data.ajax_url) {
                cfg.ajaxUrl = normalizeEndpoint(response.data.ajax_url);
            }
            return cfg.nonce;
        });
    }

    function finishActionError($widget, $button, widgetData, message) {
        setLoadingState($button, widgetData, false);
        showMessage($widget, 'error', getUserMessage(widgetData, 'error', message || getFallbackMessage('error')));
    }

    function submitAction($widget, $button, widgetData, actionData, payload, state, endpoint) {
        endpoint = normalizeEndpoint(endpoint || cfg.ajaxUrl || cfg.fallbackAjaxUrl);
        if (!endpoint) {
            finishActionError($widget, $button, widgetData, getFallbackMessage('error'));
            return;
        }

        $.ajax({
            url: endpoint,
            method: 'POST',
            dataType: 'json',
            cache: false,
            timeout: 25000,
            data: payload
        })
            .done(function (response) {
                if (!response || !response.success) {
                    if (!state.nonceRetried && isNonceFailure(null, response)) {
                        state.nonceRetried = true;
                        refreshNonce()
                            .done(function () {
                                payload.nonce = cfg.nonce;
                                submitAction($widget, $button, widgetData, actionData, payload, state, cfg.ajaxUrl || cfg.fallbackAjaxUrl);
                            })
                            .fail(function () {
                                finishActionError($widget, $button, widgetData, extractErrorMessage(null, response));
                            });
                        return;
                    }


                    if (!state.sessionRetried && responseErrorCode(null, response) === 'cart_not_ready') {
                        state.sessionRetried = true;
                        window.setTimeout(function () {
                            submitAction($widget, $button, widgetData, actionData, payload, state, cfg.fallbackAjaxUrl || endpoint);
                        }, 250);
                        return;
                    }

                    var responseFallback = normalizeEndpoint(cfg.fallbackAjaxUrl);
                    if (!state.fallbackRetried && !responseErrorCode(null, response) && responseFallback && responseFallback !== endpoint) {
                        state.fallbackRetried = true;
                        submitAction($widget, $button, widgetData, actionData, payload, state, responseFallback);
                        return;
                    }

                    finishActionError($widget, $button, widgetData, extractErrorMessage(null, response));
                    return;
                }

                setLoadingState($button, widgetData, false);
                var responseData = response.data || {};
                var redirectUrl = responseData.redirect_url ? String(responseData.redirect_url) : '';

                if (actionData.actionType === 'buy_now' && redirectUrl) {
                    window.location.replace(redirectUrl);
                    return;
                }

                maybeTriggerWooRefresh(responseData, $button);
                var successMessage = responseData.message ? String(responseData.message) : getFallbackMessage('success');
                showMessage($widget, 'success', getUserMessage(widgetData, 'success', successMessage));

                if (redirectUrl) {
                    window.location.assign(redirectUrl);
                }
            })
            .fail(function (xhr) {
                if (!state.nonceRetried && isNonceFailure(xhr, null)) {
                    state.nonceRetried = true;
                    refreshNonce()
                        .done(function () {
                            payload.nonce = cfg.nonce;
                            submitAction($widget, $button, widgetData, actionData, payload, state, cfg.ajaxUrl || cfg.fallbackAjaxUrl);
                        })
                        .fail(function () {
                            finishActionError($widget, $button, widgetData, extractErrorMessage(xhr, null));
                        });
                    return;
                }

                if (!state.sessionRetried && responseErrorCode(xhr, null) === 'cart_not_ready') {
                    state.sessionRetried = true;
                    window.setTimeout(function () {
                        submitAction($widget, $button, widgetData, actionData, payload, state, cfg.fallbackAjaxUrl || endpoint);
                    }, 250);
                    return;
                }

                var fallback = normalizeEndpoint(cfg.fallbackAjaxUrl);
                if (!state.fallbackRetried && fallback && fallback !== endpoint) {
                    state.fallbackRetried = true;
                    submitAction($widget, $button, widgetData, actionData, payload, state, fallback);
                    return;
                }

                var status = xhr ? asInt(xhr.status, 0) : 0;
                if (!state.networkRetried && (status === 0 || status === 429 || status >= 500)) {
                    state.networkRetried = true;
                    window.setTimeout(function () {
                        submitAction($widget, $button, widgetData, actionData, payload, state, fallback || endpoint);
                    }, 350);
                    return;
                }

                finishActionError($widget, $button, widgetData, extractErrorMessage(xhr, null));
            });
    }

    function handleActionClick(e) {
        e.preventDefault();

        var $button = $(this);
        var $widget = $button.closest(SELECTORS.widget);
        if (!$widget.length) {
            return;
        }

        var widgetData = getWidgetData($widget);
        if (!widgetData.productId) {
            return;
        }

        clearMessage($widget);

        var actionData = getActionData($button, widgetData);
        var payload = buildPayload($widget, widgetData, actionData);
        if (payload.hasOwnProperty('variation_id') && payload.variation_id < 1) {
            var variationMessage = getUserMessage(widgetData, 'error', i18n.selectVariation || 'Please choose product options first.');
            showMessage($widget, 'error', variationMessage);
            return;
        }

        setLoadingState($button, widgetData, true);

        submitAction(
            $widget,
            $button,
            widgetData,
            actionData,
            payload,
            { nonceRetried: false, sessionRetried: false, fallbackRetried: false, networkRetried: false },
            cfg.ajaxUrl || cfg.fallbackAjaxUrl
        );
    }

    function handleQtyClick(e) {
        e.preventDefault();

        var $btn = $(this);
        var $input = $btn.closest('.subhan-eac-qty-control').find(SELECTORS.qtyInput).first();

        if (!$input.length) {
            return;
        }

        var value = sanitizeQtyValue($input);
        var min = asInt($input.attr('min'), 1);
        var max = asInt($input.attr('max'), 0);

        if ($btn.hasClass('subhan-eac-qty-plus')) {
            value += 1;
        } else {
            value -= 1;
        }

        if (value < min) {
            value = min;
        }

        if (max > 0 && value > max) {
            value = max;
        }

        $input.val(value).trigger('change');
    }

    function handleQtyInputChange() {
        sanitizeQtyValue($(this));
    }

    function handleSwatchClick(e) {
        e.preventDefault();

        var $swatch = $(this);
        if ($swatch.hasClass('is-disabled') || $swatch.prop('disabled')) {
            return;
        }

        var selectedValue = String($swatch.data('value') || '');
        var $valueWrap = $swatch.closest('.subhan-eac-variation-value');
        var $select = $valueWrap.find('select[name^="attribute_"]').first();

        if (!$select.length) {
            return;
        }

        $select.val(selectedValue).trigger('change');
    }

    function handleSelectChange() {
        var $select = $(this);
        syncVariationState($select.closest(SELECTORS.variationForm));
    }

    function handleResetVariations(e) {
        e.preventDefault();

        var $form = $(this).closest(SELECTORS.variationForm);

        $form.find('select[name^="attribute_"]').val('');
        $form.find('input[name="variation_id"]').val(0);

        setTimeout(function () {
            ensureHiddenVariationSelection($form);
            syncVariationState($form);
        }, 20);
    }

    function handleVariationFormStateSync() {
        var $form = $(this);
        syncVariationState($form);
    }

    function markInitiallyDisabledButtons() {
        $(SELECTORS.button).each(function () {
            var $button = $(this);
            if ($button.is(':disabled')) {
                $button.data('hard-disabled', 1);
            }
        });
    }

    function bindEvents() {
        $(document).on('click', SELECTORS.button, handleActionClick);
        $(document).on('click', SELECTORS.qtyMinus + ', ' + SELECTORS.qtyPlus, handleQtyClick);
        $(document).on('change input', SELECTORS.qtyInput, handleQtyInputChange);
        $(document).on('click', SELECTORS.swatch, handleSwatchClick);
        $(document).on('change', SELECTORS.variationForm + ' select[name^="attribute_"]', handleSelectChange);
        $(document).on('click', SELECTORS.resetVariations, handleResetVariations);
        $(document).on('woocommerce_update_variation_values found_variation hide_variation reset_data', SELECTORS.variationForm, handleVariationFormStateSync);
    }

    $(function () {
        initVariationForms(document);
        markInitiallyDisabledButtons();
        bindEvents();

        if (window.elementorFrontend && window.elementorFrontend.hooks) {
            window.elementorFrontend.hooks.addAction('frontend/element_ready/global', function ($scope) {
                if ($scope && $scope.length) {
                    initVariationForms($scope[0]);
                    markInitiallyDisabledButtons();
                }
            });
        }
    });
})(jQuery);
