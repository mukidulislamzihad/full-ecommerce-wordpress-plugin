<?php
/**
 * Plugin Name: Confirmed Order Meta CAPI
 * Description: অর্ডার "Confirmed" হলে তবেই Meta (Facebook) এ Purchase ইভেন্ট পাঠায় (Conversions API)। সাথে ব্রাউজার পিক্সেল (PageView, ViewContent, AddToCart)।
 * Version: 1.1.0
 * Requires Plugins: woocommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// HPOS compatibility.
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );

class COMC_Plugin {

	const OPT = 'comc_settings';

	public function __construct() {
		add_action( 'init', array( $this, 'register_status' ) );
		add_filter( 'wc_order_statuses', array( $this, 'add_status' ) );
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'woocommerce_checkout_create_order', array( $this, 'save_browser_data' ), 10, 1 );
		add_action( 'woocommerce_order_status_changed', array( $this, 'on_status_change' ), 10, 4 );

		// Browser pixel (PageView, ViewContent, AddToCart).
		add_action( 'wp_head', array( $this, 'pixel_head' ), 1 );
		add_action( 'wp_footer', array( $this, 'pixel_footer' ), 99 );
	}

	/* ---------- Browser pixel ---------- */
	public function pixel_head() {
		if ( is_admin() ) {
			return;
		}
		$o   = $this->opts();
		$pid = $o['pixel_id'];
		if ( ! $pid ) {
			return;
		}
		$cur = $o['currency'] ? $o['currency'] : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'BDT' );
		?>
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init','<?php echo esc_js( $pid ); ?>');
fbq('track','PageView');
</script>
		<?php
		if ( function_exists( 'is_product' ) && is_product() ) {
			$product = wc_get_product( get_the_ID() );
			if ( $product ) {
				?>
<script>
fbq('track','ViewContent',{
  content_ids:['<?php echo esc_js( $product->get_id() ); ?>'],
  content_type:'product',
  value:<?php echo (float) $product->get_price(); ?>,
  currency:'<?php echo esc_js( $cur ); ?>'
});
</script>
				<?php
			}
		}
	}

	public function pixel_footer() {
		if ( is_admin() ) {
			return;
		}
		$o = $this->opts();
		if ( ! $o['pixel_id'] ) {
			return;
		}
		$cur = $o['currency'] ? $o['currency'] : ( function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'BDT' );
		?>
<script>
jQuery(function($){
  $(document.body).on('added_to_cart', function(){
    if (typeof fbq === 'function') fbq('track','AddToCart',{currency:'<?php echo esc_js( $cur ); ?>'});
  });
});
</script>
		<?php
	}

	/* ---------- Custom "Confirmed" status ---------- */
	public function register_status() {
		register_post_status( 'wc-confirmed', array(
			'label'                     => 'Confirmed',
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			'label_count'               => _n_noop( 'Confirmed <span class="count">(%s)</span>', 'Confirmed <span class="count">(%s)</span>' ),
		) );
	}

	public function add_status( $statuses ) {
		$new = array();
		foreach ( $statuses as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'wc-processing' === $key ) {
				$new['wc-confirmed'] = 'Confirmed';
			}
		}
		if ( ! isset( $new['wc-confirmed'] ) ) {
			$new['wc-confirmed'] = 'Confirmed';
		}
		return $new;
	}

	/* ---------- Settings ---------- */
	private function opts() {
		return wp_parse_args( get_option( self::OPT, array() ), array(
			'pixel_id'    => '',
			'token'       => '',
			'test_code'   => '',
			'trigger'     => 'confirmed',
			'currency'    => '',
		) );
	}

	public function menu() {
		add_submenu_page( 'woocommerce', 'Meta Confirmed Purchase', 'Meta Confirmed Purchase', 'manage_woocommerce', 'comc', array( $this, 'page' ) );
	}

	public function register_settings() {
		register_setting( 'comc_group', self::OPT, array( 'sanitize_callback' => array( $this, 'sanitize' ) ) );
	}

	public function sanitize( $in ) {
		return array(
			'pixel_id'  => preg_replace( '/\D/', '', $in['pixel_id'] ?? '' ),
			'token'     => sanitize_text_field( $in['token'] ?? '' ),
			'test_code' => sanitize_text_field( $in['test_code'] ?? '' ),
			'trigger'   => sanitize_key( $in['trigger'] ?? 'confirmed' ),
			'currency'  => strtoupper( sanitize_text_field( $in['currency'] ?? '' ) ),
		);
	}

	public function page() {
		$o        = $this->opts();
		$statuses = wc_get_order_statuses();
		?>
		<div class="wrap">
			<h1>Meta Confirmed Purchase</h1>
			<p>অর্ডার স্ট্যাটাস নিচে সিলেক্ট করা স্ট্যাটাসে গেলে তবেই Meta-তে <b>Purchase</b> ইভেন্ট যাবে।</p>
			<form method="post" action="options.php">
				<?php settings_fields( 'comc_group' ); ?>
				<table class="form-table">
					<tr><th>Pixel ID</th><td><input type="text" class="regular-text" name="<?php echo self::OPT; ?>[pixel_id]" value="<?php echo esc_attr( $o['pixel_id'] ); ?>"></td></tr>
					<tr><th>Access Token (Conversions API)</th><td><input type="password" class="large-text" name="<?php echo self::OPT; ?>[token]" value="<?php echo esc_attr( $o['token'] ); ?>"></td></tr>
					<tr><th>Test Event Code (ঐচ্ছিক)</th><td><input type="text" class="regular-text" name="<?php echo self::OPT; ?>[test_code]" value="<?php echo esc_attr( $o['test_code'] ); ?>"><p class="description">টেস্ট শেষে ফাঁকা রাখুন।</p></td></tr>
					<tr><th>যে স্ট্যাটাসে Purchase যাবে</th><td>
						<select name="<?php echo self::OPT; ?>[trigger]">
							<?php foreach ( $statuses as $key => $label ) : $slug = str_replace( 'wc-', '', $key ); ?>
								<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $o['trigger'], $slug ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select></td></tr>
					<tr><th>Currency (ফাঁকা = স্টোরের)</th><td><input type="text" size="5" name="<?php echo self::OPT; ?>[currency]" value="<?php echo esc_attr( $o['currency'] ); ?>" placeholder="BDT"></td></tr>
				</table>
				<?php submit_button(); ?>
			</form>
			<p><b>জরুরি:</b> আপনার অন্য কোনো Pixel প্লাগিন/থিম যেন চেকআউট বা Thank You পেজে <code>Purchase</code> ইভেন্ট না পাঠায়, নইলে ফেক অর্ডারও গোনা হবে।</p>
		</div>
		<?php
	}

	/* ---------- Capture browser data at checkout ---------- */
	public function save_browser_data( $order ) {
		$order->update_meta_data( '_comc_fbp', isset( $_COOKIE['_fbp'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['_fbp'] ) ) : '' );
		$order->update_meta_data( '_comc_fbc', isset( $_COOKIE['_fbc'] ) ? sanitize_text_field( wp_unslash( $_COOKIE['_fbc'] ) ) : '' );
		$order->update_meta_data( '_comc_ip', $this->client_ip() );
		$order->update_meta_data( '_comc_ua', isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '' );
	}

	private function client_ip() {
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ) as $k ) {
			if ( ! empty( $_SERVER[ $k ] ) ) {
				$ip = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $k ] ) ) )[0] );
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}
		return '';
	}

	/* ---------- Send Purchase on status change ---------- */
	public function on_status_change( $order_id, $from, $to, $order ) {
		$o = $this->opts();
		if ( ! $o['pixel_id'] || ! $o['token'] || $to !== $o['trigger'] ) {
			return;
		}
		if ( $order->get_meta( '_comc_sent' ) ) {
			return; // একবারই পাঠাবে
		}

		$res = $this->send_purchase( $order, $o );

		if ( is_wp_error( $res ) ) {
			$order->add_order_note( 'Meta Purchase ব্যর্থ: ' . $res->get_error_message() );
			return;
		}
		$code = wp_remote_retrieve_response_code( $res );
		$body = wp_remote_retrieve_body( $res );
		if ( 200 === $code ) {
			$order->update_meta_data( '_comc_sent', time() );
			$order->add_order_note( 'Meta-তে Purchase ইভেন্ট পাঠানো হয়েছে (Confirmed)।' );
		} else {
			$order->add_order_note( 'Meta Purchase ব্যর্থ (' . $code . '): ' . $body );
		}
		$order->save();
	}

	private function h( $v ) {
		$v = strtolower( trim( (string) $v ) );
		return '' === $v ? null : hash( 'sha256', $v );
	}

	private function phone( $p ) {
		$d = preg_replace( '/\D/', '', (string) $p );
		if ( 11 === strlen( $d ) && '0' === $d[0] ) { // BD: 01XXXXXXXXX -> 8801XXXXXXXXX
			$d = '880' . substr( $d, 1 );
		}
		return $d;
	}

	private function send_purchase( $order, $o ) {
		$ud = array_filter( array(
			'em'                => array_filter( array( $this->h( $order->get_billing_email() ) ) ),
			'ph'                => array_filter( array( $this->h( $this->phone( $order->get_billing_phone() ) ) ) ),
			'fn'                => array_filter( array( $this->h( $order->get_billing_first_name() ) ) ),
			'ln'                => array_filter( array( $this->h( $order->get_billing_last_name() ) ) ),
			'ct'                => array_filter( array( $this->h( preg_replace( '/\s+/', '', $order->get_billing_city() ) ) ) ),
			'country'           => array_filter( array( $this->h( $order->get_billing_country() ) ) ),
			'external_id'       => array_filter( array( $this->h( $order->get_customer_id() ? $order->get_customer_id() : $order->get_billing_email() ) ) ),
			'client_ip_address' => $order->get_meta( '_comc_ip' ),
			'client_user_agent' => $order->get_meta( '_comc_ua' ),
			'fbp'               => $order->get_meta( '_comc_fbp' ),
			'fbc'               => $order->get_meta( '_comc_fbc' ),
		) );

		$ids = array();
		$contents = array();
		foreach ( $order->get_items() as $item ) {
			$pid = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();
			$ids[] = (string) $pid;
			$contents[] = array( 'id' => (string) $pid, 'quantity' => (int) $item->get_quantity() );
		}

		$event = array(
			'event_name'       => 'Purchase',
			'event_time'       => time(),
			'event_id'         => 'order_' . $order->get_id(),
			'action_source'    => 'website',
			'event_source_url' => $order->get_checkout_order_received_url(),
			'user_data'        => $ud,
			'custom_data'      => array(
				'value'        => (float) $order->get_total(),
				'currency'     => $o['currency'] ? $o['currency'] : $order->get_currency(),
				'content_type' => 'product',
				'content_ids'  => $ids,
				'contents'     => $contents,
				'num_items'    => (int) $order->get_item_count(),
				'order_id'     => (string) $order->get_order_number(),
			),
		);

		$payload = array(
			'data'         => array( $event ),
			'access_token' => $o['token'],
		);
		if ( $o['test_code'] ) {
			$payload['test_event_code'] = $o['test_code'];
		}

		return wp_remote_post( 'https://graph.facebook.com/v21.0/' . $o['pixel_id'] . '/events', array(
			'timeout' => 20,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( $payload ),
		) );
	}
}

new COMC_Plugin();
