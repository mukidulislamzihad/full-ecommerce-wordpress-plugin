<?php
/**
 * Plugin Name: Custom 404 Designer
 * Description: Shortcode [custom_404] দিয়ে যেকোনো জায়গায় সুন্দর 404 পেজ ডিজাইন দেখান। অ্যাডমিন প্যানেল থেকে ৪টি টেমপ্লেটের একটি বেছে নিন।
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: custom-404-designer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class C404_Designer {

	const OPT = 'c404_settings';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_shortcode( 'custom_404', array( $this, 'shortcode' ) );
	}

	/* ---------- Settings ---------- */

	public static function defaults() {
		return array(
			'template'    => 1,
			'title'       => 'Oops! Page Not Found',
			'message'     => 'আপনি যে পেজটি খুঁজছেন সেটি সরানো হয়েছে, মুছে ফেলা হয়েছে বা কখনো ছিলই না।',
			'btn_text'    => 'Back to Home',
			'btn_url'     => '',
			'show_search' => 1,
		);
	}

	public static function get() {
		return wp_parse_args( get_option( self::OPT, array() ), self::defaults() );
	}

	public static function templates() {
		return array(
			1 => 'Minimal Clean',
			2 => 'Purple Gradient',
			3 => 'Dark Glitch',
			4 => 'Playful Shapes',
		);
	}

	/* ---------- Admin ---------- */

	public function menu() {
		add_menu_page( '404 Designer', '404 Designer', 'manage_options', 'custom-404-designer', array( $this, 'admin_page' ), 'dashicons-warning', 80 );
	}

	public function admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_POST['c404_save'] ) && check_admin_referer( 'c404_save_action', 'c404_nonce' ) ) {
			$new = array(
				'template'    => max( 1, min( 4, (int) ( $_POST['c404_template'] ?? 1 ) ) ),
				'title'       => sanitize_text_field( wp_unslash( $_POST['c404_title'] ?? '' ) ),
				'message'     => sanitize_textarea_field( wp_unslash( $_POST['c404_message'] ?? '' ) ),
				'btn_text'    => sanitize_text_field( wp_unslash( $_POST['c404_btn_text'] ?? '' ) ),
				'btn_url'     => esc_url_raw( wp_unslash( $_POST['c404_btn_url'] ?? '' ) ),
				'show_search' => isset( $_POST['c404_show_search'] ) ? 1 : 0,
			);
			update_option( self::OPT, $new );
			echo '<div class="notice notice-success is-dismissible"><p>সেভ হয়েছে ✔</p></div>';
		}

		$s = self::get();
		echo self::css(); // phpcs:ignore WordPress.Security.EscapeOutput
		?>
		<style>
			.c404-admin-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px;margin:20px 0}
			.c404-card{background:#fff;border:3px solid #dcdcde;border-radius:10px;overflow:hidden;cursor:pointer;display:block;position:relative;transition:.2s}
			.c404-card:hover{border-color:#8c8f94}
			.c404-card input{position:absolute;top:10px;left:10px;z-index:5;width:20px;height:20px}
			.c404-card.active{border-color:#2271b1;box-shadow:0 0 0 2px rgba(34,113,177,.25)}
			.c404-card .c404-name{padding:10px 14px;font-weight:600;border-top:1px solid #eee;background:#fafafa}
			.c404-preview{height:230px;overflow:hidden;position:relative;pointer-events:none}
			.c404-preview .c404-scale{width:200%;transform:scale(.5);transform-origin:top left}
			.c404-preview .c404-wrap{min-height:460px}
			.c404-form td,.c404-form th{padding:8px 10px 8px 0}
			.c404-form input[type=text],.c404-form input[type=url],.c404-form textarea{width:420px;max-width:100%}
			.c404-code{background:#f0f0f1;padding:4px 10px;border-radius:4px;font-size:14px}
		</style>
		<div class="wrap">
			<h1>404 Designer</h1>
			<p>যে পেজ বা Elementor 404 টেমপ্লেটে ডিজাইন দেখাতে চান সেখানে এই শর্টকোড বসান: <code class="c404-code">[custom_404]</code>
			&nbsp;|&nbsp; নির্দিষ্ট টেমপ্লেট: <code class="c404-code">[custom_404 template="3"]</code></p>

			<form method="post">
				<?php wp_nonce_field( 'c404_save_action', 'c404_nonce' ); ?>

				<h2>টেমপ্লেট বেছে নিন</h2>
				<div class="c404-admin-grid">
					<?php foreach ( self::templates() as $id => $name ) : ?>
						<label class="c404-card <?php echo (int) $s['template'] === $id ? 'active' : ''; ?>">
							<input type="radio" name="c404_template" value="<?php echo (int) $id; ?>" <?php checked( (int) $s['template'], $id ); ?>>
							<div class="c404-preview"><div class="c404-scale"><?php echo self::render( $s, $id, false ); // phpcs:ignore ?></div></div>
							<div class="c404-name">Template <?php echo (int) $id; ?> — <?php echo esc_html( $name ); ?></div>
						</label>
					<?php endforeach; ?>
				</div>

				<h2>লেখা ও বাটন</h2>
				<table class="c404-form">
					<tr><th>Title</th><td><input type="text" name="c404_title" value="<?php echo esc_attr( $s['title'] ); ?>"></td></tr>
					<tr><th>Message</th><td><textarea name="c404_message" rows="3"><?php echo esc_textarea( $s['message'] ); ?></textarea></td></tr>
					<tr><th>Button Text</th><td><input type="text" name="c404_btn_text" value="<?php echo esc_attr( $s['btn_text'] ); ?>"></td></tr>
					<tr><th>Button Link</th><td><input type="url" name="c404_btn_url" value="<?php echo esc_attr( $s['btn_url'] ); ?>" placeholder="<?php echo esc_attr( home_url( '/' ) ); ?>"><br><small>ফাঁকা রাখলে হোম পেজে যাবে।</small></td></tr>
					<tr><th>Search Box</th><td><label><input type="checkbox" name="c404_show_search" value="1" <?php checked( $s['show_search'], 1 ); ?>> সার্চ বক্স দেখান</label></td></tr>
				</table>

				<p><button type="submit" name="c404_save" class="button button-primary button-large">Save Changes</button></p>
			</form>
		</div>
		<script>
			document.querySelectorAll('.c404-card input').forEach(function(r){
				r.addEventListener('change',function(){
					document.querySelectorAll('.c404-card').forEach(function(c){c.classList.remove('active')});
					r.closest('.c404-card').classList.add('active');
				});
			});
		</script>
		<?php
	}

	/* ---------- Shortcode ---------- */

	public function shortcode( $atts ) {
		$s = self::get();
		$a = shortcode_atts(
			array(
				'template' => $s['template'],
				'title'    => $s['title'],
				'message'  => $s['message'],
				'button'   => $s['btn_text'],
				'link'     => $s['btn_url'],
				'search'   => $s['show_search'] ? 'yes' : 'no',
			),
			$atts,
			'custom_404'
		);

		$s['title']       = $a['title'];
		$s['message']     = $a['message'];
		$s['btn_text']    = $a['button'];
		$s['btn_url']     = $a['link'];
		$s['show_search'] = in_array( strtolower( $a['search'] ), array( 'yes', '1', 'true' ), true ) ? 1 : 0;

		$tpl = max( 1, min( 4, (int) $a['template'] ) );

		return self::css() . self::render( $s, $tpl, true );
	}

	/* ---------- Markup ---------- */

	public static function render( $s, $tpl, $live = true ) {
		$url = $s['btn_url'] ? $s['btn_url'] : home_url( '/' );

		ob_start();
		?>
		<div class="c404-wrap c404-t<?php echo (int) $tpl; ?>">
			<?php if ( 4 === (int) $tpl ) : ?>
				<span class="c404-shape s1"></span><span class="c404-shape s2"></span><span class="c404-shape s3"></span><span class="c404-shape s4"></span>
			<?php endif; ?>
			<div class="c404-inner">
				<div class="c404-code" data-text="404">404</div>
				<h2 class="c404-title"><?php echo esc_html( $s['title'] ); ?></h2>
				<p class="c404-msg"><?php echo esc_html( $s['message'] ); ?></p>
				<?php if ( ! empty( $s['show_search'] ) ) : ?>
					<form class="c404-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" <?php echo $live ? '' : 'onsubmit="return false"'; ?>>
						<input type="search" name="s" placeholder="Search...">
						<button type="submit">Search</button>
					</form>
				<?php endif; ?>
				<?php if ( ! empty( $s['btn_text'] ) ) : ?>
					<a class="c404-btn" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $s['btn_text'] ); ?></a>
				<?php endif; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/* ---------- CSS ---------- */

	public static function css() {
		static $printed = false;
		if ( $printed ) {
			return '';
		}
		$printed = true;

		return '<style id="c404-styles">
.c404-wrap{box-sizing:border-box;position:relative;overflow:hidden;width:100%;min-height:70vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:60px 20px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
.c404-wrap *{box-sizing:border-box}
.c404-inner{position:relative;z-index:2;max-width:640px;width:100%}
.c404-code{font-weight:800;line-height:1;margin:0 0 10px}
.c404-title{margin:0 0 12px;font-size:30px;font-weight:700;line-height:1.25}
.c404-msg{margin:0 auto 26px;font-size:17px;line-height:1.6;max-width:520px}
.c404-search{display:flex;max-width:420px;margin:0 auto 22px;gap:0}
.c404-search input{flex:1;padding:12px 16px;border:1px solid #ccc;border-right:0;border-radius:8px 0 0 8px;font-size:15px;outline:0;min-width:0;margin:0;height:auto}
.c404-search button{padding:12px 20px;border:0;border-radius:0 8px 8px 0;cursor:pointer;font-weight:600;font-size:15px;margin:0}
.c404-btn{display:inline-block;padding:14px 34px;border-radius:50px;text-decoration:none!important;font-weight:600;font-size:16px;transition:.25s}
.c404-btn:hover{transform:translateY(-3px)}

/* T1 Minimal */
.c404-t1{background:#fff;color:#222}
.c404-t1 .c404-code{font-size:150px;color:#111;letter-spacing:-6px}
.c404-t1 .c404-msg{color:#666}
.c404-t1 .c404-search button{background:#111;color:#fff}
.c404-t1 .c404-btn{background:#111;color:#fff}
.c404-t1 .c404-btn:hover{background:#444}

/* T2 Gradient */
.c404-t2{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff}
.c404-t2 .c404-inner{background:rgba(255,255,255,.12);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.3);border-radius:24px;padding:50px 30px;box-shadow:0 20px 60px rgba(0,0,0,.2)}
.c404-t2 .c404-code{font-size:130px;text-shadow:0 8px 30px rgba(0,0,0,.25)}
.c404-t2 .c404-msg{color:rgba(255,255,255,.9)}
.c404-t2 .c404-search input{border-color:transparent}
.c404-t2 .c404-search button{background:#2d1b4e;color:#fff}
.c404-t2 .c404-btn{background:#fff;color:#764ba2}

/* T3 Dark Glitch */
.c404-t3{background:#0b0f19;color:#e6edf3}
.c404-t3 .c404-code{font-size:150px;position:relative;color:#fff;display:inline-block;font-family:"Courier New",monospace}
.c404-t3 .c404-code:before,.c404-t3 .c404-code:after{content:attr(data-text);position:absolute;left:0;top:0;width:100%;height:100%}
.c404-t3 .c404-code:before{color:#00f0ff;transform:translate(-3px,0);clip-path:inset(0 0 55% 0);animation:c404g1 2.4s infinite linear alternate-reverse}
.c404-t3 .c404-code:after{color:#ff2e63;transform:translate(3px,0);clip-path:inset(55% 0 0 0);animation:c404g2 2s infinite linear alternate-reverse}
@keyframes c404g1{0%{transform:translate(-3px,0)}50%{transform:translate(4px,-2px)}100%{transform:translate(-5px,2px)}}
@keyframes c404g2{0%{transform:translate(3px,0)}50%{transform:translate(-4px,2px)}100%{transform:translate(5px,-2px)}}
.c404-t3 .c404-msg{color:#8b98a9}
.c404-t3 .c404-search input{background:#161b27;border-color:#2a3345;color:#fff}
.c404-t3 .c404-search button{background:#00f0ff;color:#0b0f19}
.c404-t3 .c404-btn{background:transparent;color:#00f0ff;border:2px solid #00f0ff;border-radius:6px}
.c404-t3 .c404-btn:hover{background:#00f0ff;color:#0b0f19;box-shadow:0 0 25px rgba(0,240,255,.6)}

/* T4 Playful */
.c404-t4{background:#fff7ec;color:#2b2b3c}
.c404-t4 .c404-code{font-size:150px;color:#ff6b6b;text-shadow:6px 6px 0 #ffd166,12px 12px 0 #4ecdc4}
.c404-t4 .c404-msg{color:#5b5b70}
.c404-t4 .c404-search input{border:2px solid #2b2b3c;border-right:0}
.c404-t4 .c404-search button{background:#2b2b3c;color:#fff}
.c404-t4 .c404-btn{background:#ff6b6b;color:#fff;box-shadow:5px 5px 0 #2b2b3c}
.c404-t4 .c404-btn:hover{box-shadow:2px 2px 0 #2b2b3c;transform:translate(3px,3px)}
.c404-shape{position:absolute;z-index:1;opacity:.9;animation:c404f 6s ease-in-out infinite}
.c404-shape.s1{width:90px;height:90px;border-radius:50%;background:#ffd166;top:12%;left:8%}
.c404-shape.s2{width:70px;height:70px;background:#4ecdc4;top:65%;left:14%;transform:rotate(20deg);animation-delay:1s}
.c404-shape.s3{width:0;height:0;border-left:45px solid transparent;border-right:45px solid transparent;border-bottom:78px solid #ff6b6b;top:15%;right:10%;animation-delay:2s}
.c404-shape.s4{width:80px;height:80px;border-radius:50%;border:12px solid #6c5ce7;top:68%;right:12%;animation-delay:3s}
@keyframes c404f{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(-22px) rotate(12deg)}}

@media(max-width:600px){
.c404-t1 .c404-code,.c404-t3 .c404-code,.c404-t4 .c404-code{font-size:96px}
.c404-t2 .c404-code{font-size:90px}
.c404-title{font-size:24px}
.c404-shape{opacity:.5}
}
</style>';
	}
}

new C404_Designer();
