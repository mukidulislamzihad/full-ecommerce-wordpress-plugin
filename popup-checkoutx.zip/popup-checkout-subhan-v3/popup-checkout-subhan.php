<?php
/*
Plugin Name: Popup Checkout for WooCommerce
Description: Fast, mobile-friendly WooCommerce popup checkout with flexible design, shipping and order bump controls.
Version: 2.0.0
Requires PHP: 7.4
Requires at least: 6.2
Requires Plugins: woocommerce
Tested up to: 7.0
Author: Borbila
Author URI: https://borbila.com
Text Domain: popup-checkout-subhan
License: GPLv2 or later
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PCS_POPUP_CHECKOUT_VERSION', '2.0.0' );
define( 'PCS_POPUP_CHECKOUT_FILE', __FILE__ );
define( 'PCS_POPUP_CHECKOUT_PATH', plugin_dir_path( __FILE__ ) );

require_once PCS_POPUP_CHECKOUT_PATH . 'includes/class-pcs-license.php';

if ( ! class_exists( 'PCS_Popup_Checkout_WC' ) ) :

class PCS_Popup_Checkout_WC {
	const OPT_KEY      = 'pcs_popup_checkout_settings';
	const NONCE_ACTION = 'pcs_popup_checkout_nonce';

		public function __construct() {
			PCS_License::register_hooks();

			// Frontend
			add_action( 'init', array( $this, 'maybe_disable_theme_checkout_overrides' ), 1 );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
			add_action( 'wp_footer', array( $this, 'render_modal_html' ) );
			add_action( 'wp_head', array( $this, 'output_custom_css' ), 99 );


		// Default buttons (optional) - single and loop
		add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'buy_now_button_single' ), 25 );
		add_action( 'woocommerce_after_shop_loop_item', array( $this, 'buy_now_button_loop' ), 20 );

		// Woo wc-ajax endpoint (returns HTML, not JSON)
		add_action( 'wc_ajax_pcs_popup_checkout_form', array( $this, 'ajax_checkout_form' ) );
		add_action( 'wc_ajax_nopriv_pcs_popup_checkout_form', array( $this, 'ajax_checkout_form' ) );
		add_action( 'wc_ajax_pcs_popup_update_cart_item', array( $this, 'ajax_popup_update_cart_item' ) );
		add_action( 'wc_ajax_nopriv_pcs_popup_update_cart_item', array( $this, 'ajax_popup_update_cart_item' ) );
		add_action( 'wc_ajax_pcs_popup_toggle_order_bump', array( $this, 'ajax_popup_toggle_order_bump' ) );
		add_action( 'wc_ajax_nopriv_pcs_popup_toggle_order_bump', array( $this, 'ajax_popup_toggle_order_bump' ) );

		// Admin
		add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_assets' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_codemirror' ) );
		add_action( 'admin_notices', array( $this, 'woocommerce_dependency_notice' ) );
		add_action( 'admin_post_pcs_license_action', array( $this, 'handle_license_action' ) );
		add_action( 'wp_ajax_pcs_activate_license', array( $this, 'ajax_activate_license' ) );
		add_action( 'wp_ajax_pcs_deactivate_license', array( $this, 'ajax_deactivate_license' ) );
		add_action( 'wp_ajax_pcs_save_settings', array( $this, 'ajax_save_settings' ) );

		// Settings link next to Deactivate
		add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), array( $this, 'plugin_action_links' ) );
		add_filter('plugin_row_meta', array($this, 'add_plugin_row_meta'), 10, 2);


		// Place order button text (popup request only)
			add_filter( 'woocommerce_order_button_text', array( $this, 'filter_order_button_text' ) );
				add_filter( 'woocommerce_checkout_fields', array( $this, 'filter_popup_checkout_fields' ), 99999 );
				add_filter( 'woocommerce_checkout_posted_data', array( $this, 'normalize_popup_posted_data' ), 20 );
				add_filter( 'woocommerce_cart_needs_shipping', array( $this, 'filter_popup_cart_needs_shipping' ), 999 );
				add_filter( 'woocommerce_cart_needs_shipping_address', array( $this, 'filter_popup_shipping_address_requirement' ), 999 );
				add_filter( 'woocommerce_cart_get_fees', array( $this, 'filter_popup_checkout_fees' ), 999, 2 );
					add_filter( 'woocommerce_enable_order_notes_field', array( $this, 'filter_popup_order_notes_field' ), 999 );
					add_filter( 'woocommerce_coupons_enabled', array( $this, 'filter_popup_coupons_enabled' ), 999 );
					add_filter( 'woocommerce_available_payment_gateways', array( $this, 'filter_popup_payment_gateways' ), 999 );
				add_filter( 'woocommerce_cart_item_name', array( $this, 'filter_popup_checkout_cart_item_name' ), 99999, 3 );
				add_filter( 'woocommerce_cart_item_subtotal', array( $this, 'filter_popup_checkout_cart_item_subtotal' ), 99999, 3 );
				add_filter( 'woocommerce_checkout_cart_item_visible', array( $this, 'filter_popup_checkout_cart_item_visible' ), 99999, 3 );
				add_filter( 'woodmart_replace_checkout_template_condition', array( $this, 'filter_popup_disable_woodmart_checkout_table' ), 99999 );
				add_filter( 'woocommerce_checkout_registration_required', array( $this, 'filter_popup_registration_required' ), 999 );
				add_filter( 'woocommerce_checkout_registration_enabled', array( $this, 'filter_popup_registration_enabled' ), 999 );
			add_action( 'woocommerce_checkout_before_customer_details', array( $this, 'output_popup_context_field' ), 5 );
			add_action( 'woocommerce_checkout_before_order_review', array( $this, 'render_popup_shipping_methods' ), 5 );
			add_action( 'woocommerce_review_order_after_cart_contents', array( $this, 'render_popup_order_bump_offer_row' ), 40 );
			add_action( 'woocommerce_checkout_update_order_review', array( $this, 'capture_popup_shipping_selection' ), 10, 1 );
			add_action( 'woocommerce_cart_calculate_fees', array( $this, 'apply_popup_shipping_fee' ), 99, 1 );
			add_action( 'woocommerce_checkout_create_order', array( $this, 'mark_popup_order_meta' ), 10, 2 );
			add_action( 'woocommerce_checkout_update_order_meta', array( $this, 'mark_popup_order_meta_by_id' ), 10, 1 );
			add_filter( 'woocommerce_get_return_url', array( $this, 'add_popup_flag_to_return_url' ), 10, 2 );
		add_filter( 'woocommerce_get_checkout_order_received_url', array( $this, 'add_popup_flag_to_return_url' ), 10, 2 );
		add_filter( 'body_class', array( $this, 'add_popup_order_body_class' ) );

		// Elementor widget
		add_action( 'elementor/widgets/register', array( $this, 'register_elementor_widget' ) );
		add_action( 'elementor/elements/categories_registered', array( $this, 'register_elementor_category' ) );
	}

	/* ------------------------- Settings ------------------------- */

	public function get_settings() : array {
		$defaults = array(
			'enable_on_shop'      => 1,
			'enable_default_btns' => 0, // user wants widget; keep defaults OFF by default
				'button_text'         => 'Buy Now',
				'primary_color'       => '#f7a200',
				'button_bg'           => '#0f172a',
				'button_text_color'   => '#ffffff',
			'button_radius'       => 14,
			'button_font_size'    => 15,
			'button_padding_y'    => 12,
			'button_padding_x'    => 18,
			'fixed_place_order'   => 1,
			'order_btn_text'      => 'আপনার অর্ডার কনফার্ম করতে ক্লিক করুন',
			'loading_animation'   => 1,
			'theme_accent_color'  => '#f7a200',
			'theme_header_start'  => '#ececec',
			'theme_header_end'    => '#ececec',
			'theme_button_start'  => '#f7a200',
			'theme_button_end'    => '#f7a200',
			'theme_overlay_start' => '#000000',
			'theme_overlay_end'   => '#000000',
			'theme_backdrop_blur' => 1,
			'content_text_color'  => '#171717',
			'content_font_size'   => 16,
			'popup_title_line_1'  => 'ক্যাশ অন ডেলিভারিতে',
			'popup_title_line_2'  => 'অর্ডার করতে আপনার তথ্য দিন',
			'field_label_name'       => 'আপনার নাম',
			'field_placeholder_name' => 'আপনার নাম',
			'field_label_phone'       => 'ফোন নাম্বার',
			'field_placeholder_phone' => 'ফোন নাম্বার',
			'field_label_address'       => 'এড্রেস',
			'field_placeholder_address' => 'এড্রেস',
			'shipping_title'              => 'শিপিং মেথড',
			'shipping_label_dhaka'        => 'ঢাকা সিটির ভিতরে',
			'shipping_label_chattogram'   => 'চট্টগ্রাম সিটির ভিতরে',
			'shipping_label_outside'      => 'ঢাকা সিটির বাইরে',
			'coupon_placeholder_text'     => 'কুপন কোড',
				'coupon_apply_text'           => 'এপ্লাই',
				'order_bump_enabled'          => 0,
				'order_bump_product_id'       => 0,
				'order_bump_badge_text'       => 'SPECIAL OFFER!',
				'order_bump_title_text'       => 'Add {product} for just',
				'order_bump_note_text'        => '(এইটা ডেলিভারির সাথে পেয়ে যাবেন)',
				'delivery_charge_label'       => 'ডেলিভারি চার্জ',
			'shipping_charge_dhaka'       => 70.00,
			'shipping_charge_chattogram'  => 70.00,
			'shipping_charge_outside'     => 170.00,
			'custom_css'                  => '',
		);

		$opt = get_option( self::OPT_KEY, array() );
		if ( ! is_array( $opt ) ) $opt = array();
		return wp_parse_args( $opt, $defaults );
	}

	private function button_style_inline() : string {
		$s = $this->get_settings();
		$bg = sanitize_hex_color( $s['button_bg'] ) ?: '#0f172a';
		$tc = sanitize_hex_color( $s['button_text_color'] ) ?: '#ffffff';
		$radius = max(0, intval($s['button_radius']));
		$fs = max(10, intval($s['button_font_size']));
		$py = max(6, intval($s['button_padding_y']));
		$px = max(10, intval($s['button_padding_x']));

		return sprintf(
			'background:%s;color:%s;border-radius:%dpx;font-size:%dpx;padding:%dpx %dpx;border:0;cursor:pointer;display:inline-flex;align-items:center;gap:10px;justify-content:center;line-height:1;',
			esc_attr($bg), esc_attr($tc), $radius, $fs, $py, $px
		);
	}

	public function sanitize_settings( $input ) {
		if ( ! is_array( $input ) ) {
			$input = array();
		}

		$current = get_option( self::OPT_KEY, array() );
		$current = is_array( $current ) ? $current : array();
		$licensed = PCS_License::is_active();

		$out = array();
		$out['enable_on_shop'] = $licensed
			? ( ! empty( $input['enable_on_shop'] ) ? 1 : 0 )
			: ( ! empty( $current['enable_on_shop'] ) ? 1 : 0 );
		$out['enable_default_btns'] = $licensed
			? ( ! empty( $input['enable_default_btns'] ) ? 1 : 0 )
			: ( ! empty( $current['enable_default_btns'] ) ? 1 : 0 );

		$out['button_text']       = sanitize_text_field( $input['button_text'] ?? 'Buy Now' );
		$out['primary_color']     = sanitize_hex_color( $input['primary_color'] ?? '#f7a200' ) ?: '#f7a200';
		$out['button_bg']         = sanitize_hex_color( $input['button_bg'] ?? '#0f172a' ) ?: '#0f172a';
		$out['button_text_color'] = sanitize_hex_color( $input['button_text_color'] ?? '#ffffff' ) ?: '#ffffff';

		$out['button_radius']    = max( 0, min( 100, intval( $input['button_radius'] ?? 14 ) ) );
		$out['button_font_size'] = max( 10, min( 40, intval( $input['button_font_size'] ?? 15 ) ) );
		$out['button_padding_y'] = max( 6, min( 80, intval( $input['button_padding_y'] ?? 12 ) ) );
		$out['button_padding_x'] = max( 10, min( 120, intval( $input['button_padding_x'] ?? 18 ) ) );

		$out['fixed_place_order'] = ! empty( $input['fixed_place_order'] ) ? 1 : 0;
		$out['order_btn_text']    = sanitize_text_field( $input['order_btn_text'] ?? 'আপনার অর্ডার কনফার্ম করতে ক্লিক করুন' );
		$out['loading_animation'] = ! empty( $input['loading_animation'] ) ? 1 : 0;
			$out['theme_accent_color']  = sanitize_hex_color( $input['theme_accent_color'] ?? '#f7a200' ) ?: '#f7a200';
			$out['theme_header_start']  = sanitize_hex_color( $input['theme_header_start'] ?? '#ececec' ) ?: '#ececec';
			$out['theme_header_end']    = sanitize_hex_color( $input['theme_header_end'] ?? '#ececec' ) ?: '#ececec';
			$out['theme_button_start']  = sanitize_hex_color( $input['theme_button_start'] ?? '#f7a200' ) ?: '#f7a200';
			$out['theme_button_end']    = sanitize_hex_color( $input['theme_button_end'] ?? '#f7a200' ) ?: '#f7a200';
			$out['theme_overlay_start'] = sanitize_hex_color( $input['theme_overlay_start'] ?? '#000000' ) ?: '#000000';
			$out['theme_overlay_end']   = sanitize_hex_color( $input['theme_overlay_end'] ?? '#000000' ) ?: '#000000';
		$out['theme_backdrop_blur'] = max( 0, min( 3, intval( $input['theme_backdrop_blur'] ?? 1 ) ) );
		$out['content_text_color']  = sanitize_hex_color( $input['content_text_color'] ?? '#171717' ) ?: '#171717';
		$out['content_font_size']   = max( 12, min( 22, intval( $input['content_font_size'] ?? 16 ) ) );

		$out['popup_title_line_1'] = sanitize_text_field( $input['popup_title_line_1'] ?? 'ক্যাশ অন ডেলিভারিতে' );
		$out['popup_title_line_2'] = sanitize_text_field( $input['popup_title_line_2'] ?? 'অর্ডার করতে আপনার তথ্য দিন' );
		$out['field_label_name']       = sanitize_text_field( $input['field_label_name'] ?? 'আপনার নাম' );
		$out['field_placeholder_name'] = sanitize_text_field( $input['field_placeholder_name'] ?? 'আপনার নাম' );
		$out['field_label_phone']       = sanitize_text_field( $input['field_label_phone'] ?? 'ফোন নাম্বার' );
		$out['field_placeholder_phone'] = sanitize_text_field( $input['field_placeholder_phone'] ?? 'ফোন নাম্বার' );
		$out['field_label_address']       = sanitize_text_field( $input['field_label_address'] ?? 'এড্রেস' );
		$out['field_placeholder_address'] = sanitize_text_field( $input['field_placeholder_address'] ?? 'এড্রেস' );
		$out['shipping_title']            = sanitize_text_field( $input['shipping_title'] ?? 'শিপিং মেথড' );
		$out['shipping_label_dhaka']      = sanitize_text_field( $input['shipping_label_dhaka'] ?? 'ঢাকা সিটির ভিতরে' );
		$out['shipping_label_chattogram'] = sanitize_text_field( $input['shipping_label_chattogram'] ?? 'চট্টগ্রাম সিটির ভিতরে' );
			$out['shipping_label_outside']    = sanitize_text_field( $input['shipping_label_outside'] ?? 'ঢাকা সিটির বাইরে' );
			$out['coupon_placeholder_text']   = sanitize_text_field( $input['coupon_placeholder_text'] ?? 'কুপন কোড' );
			$out['coupon_apply_text']         = sanitize_text_field( $input['coupon_apply_text'] ?? 'এপ্লাই' );
			$out['order_bump_enabled'] = $licensed
				? ( ! empty( $input['order_bump_enabled'] ) ? 1 : 0 )
				: ( ! empty( $current['order_bump_enabled'] ) ? 1 : 0 );
			$out['order_bump_product_id']     = absint( $input['order_bump_product_id'] ?? 0 );
			$out['order_bump_badge_text']     = sanitize_text_field( $input['order_bump_badge_text'] ?? 'SPECIAL OFFER!' );
			$out['order_bump_title_text']     = sanitize_text_field( $input['order_bump_title_text'] ?? 'Add {product} for just' );
			$out['order_bump_note_text']      = sanitize_text_field( $input['order_bump_note_text'] ?? '(এইটা ডেলিভারির সাথে পেয়ে যাবেন)' );
			$out['delivery_charge_label']     = sanitize_text_field( $input['delivery_charge_label'] ?? 'ডেলিভারি চার্জ' );

		$out['shipping_charge_dhaka']      = $this->sanitize_price_value( $input['shipping_charge_dhaka'] ?? 70, 70 );
		$out['shipping_charge_chattogram'] = $this->sanitize_price_value( $input['shipping_charge_chattogram'] ?? 70, 70 );
			$out['shipping_charge_outside']    = $this->sanitize_price_value( $input['shipping_charge_outside'] ?? 170, 170 );

		$out['custom_css'] = isset( $input['custom_css'] )
			? substr( wp_strip_all_tags( (string) $input['custom_css'] ), 0, 50000 )
			: '';
		return $out;
	}

	private function sanitize_price_value( $value, $fallback = 0 ) : float {
		if ( is_string( $value ) ) {
			$value = trim( str_replace( ',', '', $value ) );
		}

		if ( ! is_numeric( $value ) ) {
			$value = preg_replace( '/[^0-9\.\-]/', '', (string) $value );
		}

		if ( '' === (string) $value || ! is_numeric( $value ) ) {
			$amount = (float) $fallback;
		} else {
			$amount = (float) $value;
		}

		if ( $amount < 0 ) {
			$amount = 0;
		}

		return round( $amount, 2 );
	}

	private function lowercase_popup_string( string $value ) : string {
		if ( function_exists( 'mb_strtolower' ) ) {
			return mb_strtolower( $value, 'UTF-8' );
		}
		return strtolower( $value );
	}

	private function normalize_popup_fee_label( string $label ) : string {
		$label = html_entity_decode( $label, ENT_QUOTES, 'UTF-8' );
		$label = wp_strip_all_tags( $label );
		$label = preg_replace( '/\s+/u', ' ', trim( $label ) );
		return $this->lowercase_popup_string( $label );
	}

	private function is_popup_delivery_like_fee_label( string $label ) : bool {
		$normalized = $this->normalize_popup_fee_label( $label );
		if ( '' === $normalized ) return false;

		$delivery_keywords = array( 'delivery', 'shipping', 'ডেলিভারি', 'শিপিং' );
		foreach ( $delivery_keywords as $keyword ) {
			if ( false !== strpos( $normalized, $keyword ) ) {
				return true;
			}
		}

		return false;
	}

	private function get_order_bump_product_options_for_admin() : array {
		$options = array();
		if ( ! class_exists( 'WooCommerce' ) || ! post_type_exists( 'product' ) ) {
			return $options;
		}

		$product_ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => 300,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);

		if ( empty( $product_ids ) || ! is_array( $product_ids ) ) {
			return $options;
		}

		foreach ( $product_ids as $product_id ) {
			$product_id = absint( $product_id );
			if ( ! $product_id ) continue;
			$product = wc_get_product( $product_id );
			if ( ! $product || ! $product->is_type( 'simple' ) ) continue;
			$label = sprintf( '%s (#%d)', wp_strip_all_tags( (string) $product->get_name() ), $product_id );
			$options[ $product_id ] = $label;
		}

		return $options;
	}

	private function is_popup_order_bump_cart_item( $cart_item ) : bool {
		if ( ! is_array( $cart_item ) ) return false;
		if ( ! array_key_exists( 'pcs_order_bump', $cart_item ) ) return false;

		$value = $cart_item['pcs_order_bump'];
		if ( is_bool( $value ) ) return $value;
		if ( is_numeric( $value ) ) return ( (int) $value ) === 1;
		return $this->is_truthy_value( (string) $value );
	}

	private function get_popup_order_bump_product() {
		if ( ! PCS_License::is_active() ) return null;
		$s = $this->get_settings();
		$enabled   = ! empty( $s['order_bump_enabled'] );
		$product_id = absint( $s['order_bump_product_id'] ?? 0 );
		if ( ! $enabled || ! $product_id ) return null;
		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_type( 'simple' ) ) return null;
		return $product;
	}

	private function get_popup_order_bump_cart_item_keys( int $product_id = 0 ) : array {
		$keys = array();
		if ( ! function_exists( 'WC' ) || ! WC() || ! WC()->cart ) return $keys;

		$product_id = absint( $product_id );
		foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
			if ( ! $this->is_popup_order_bump_cart_item( $cart_item ) ) continue;
			if ( $product_id > 0 ) {
				$item_product_id = isset( $cart_item['product_id'] ) ? absint( $cart_item['product_id'] ) : 0;
				if ( $item_product_id !== $product_id ) continue;
			}
			$keys[] = (string) $cart_item_key;
		}

		return $keys;
	}

	private function is_popup_order_bump_selected( int $product_id ) : bool {
		$product_id = absint( $product_id );
		if ( ! $product_id ) return false;
		return ! empty( $this->get_popup_order_bump_cart_item_keys( $product_id ) );
	}

	private function normalize_popup_cart_variation( array $variation ) : array {
		$normalized = array();
		foreach ( $variation as $key => $value ) {
			$attr_key = wc_clean( (string) $key );
			if ( '' === $attr_key ) continue;
			$normalized[ $attr_key ] = wc_clean( (string) $value );
		}
		ksort( $normalized );
		return $normalized;
	}

	private function find_existing_popup_cart_item_key( int $product_id, int $variation_id = 0, array $variation = array() ) : string {
		if ( ! function_exists( 'WC' ) || ! WC() || ! WC()->cart ) return '';

		$product_id   = absint( $product_id );
		$variation_id = absint( $variation_id );
		if ( ! $product_id ) return '';

		$target_variation = $this->normalize_popup_cart_variation( $variation );

		foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
			if ( ! is_array( $cart_item ) ) continue;
			if ( $this->is_popup_order_bump_cart_item( $cart_item ) ) continue;

			$item_product_id = isset( $cart_item['product_id'] ) ? absint( $cart_item['product_id'] ) : 0;
			if ( $item_product_id !== $product_id ) continue;

			$item_variation_id = isset( $cart_item['variation_id'] ) ? absint( $cart_item['variation_id'] ) : 0;
			if ( $variation_id > 0 || $item_variation_id > 0 ) {
				if ( $item_variation_id !== $variation_id ) continue;

				if ( ! empty( $target_variation ) ) {
					$item_variation = array();
					if ( isset( $cart_item['variation'] ) && is_array( $cart_item['variation'] ) ) {
						$item_variation = $this->normalize_popup_cart_variation( $cart_item['variation'] );
					}
					if ( $item_variation !== $target_variation ) continue;
				}
			}

			return (string) $cart_item_key;
		}

		return '';
	}

	/* ------------------------- Frontend ------------------------- */


	public function enqueue_scripts() {
		if ( ! class_exists( 'WooCommerce' ) || ! PCS_License::is_active() ) return;

		$css_file = PCS_POPUP_CHECKOUT_PATH . 'assets/style.css';
		$js_file  = PCS_POPUP_CHECKOUT_PATH . 'assets/script.js';
		$css_ver  = file_exists( $css_file ) ? (string) filemtime( $css_file ) : PCS_POPUP_CHECKOUT_VERSION;
		$js_ver   = file_exists( $js_file ) ? (string) filemtime( $js_file ) : PCS_POPUP_CHECKOUT_VERSION;

		wp_enqueue_style( 'pcs-popup-checkout-style', plugin_dir_url(__FILE__) . 'assets/style.css', array(), $css_ver );
		wp_enqueue_script( 'pcs-popup-checkout-script', plugin_dir_url(__FILE__) . 'assets/script.js', array('jquery'), $js_ver, true );

		$s = $this->get_settings();

		wp_localize_script( 'pcs-popup-checkout-script', 'pcsPopupCheckout', array(
			'ajax_url' => WC_AJAX::get_endpoint( 'pcs_popup_checkout_form' ),
			'nonce'    => wp_create_nonce( self::NONCE_ACTION ),
			'loading_animation' => ! empty( $s['loading_animation'] ) ? 1 : 0,
			'fixed_place_order' => ! empty( $s['fixed_place_order'] ) ? 1 : 0,
			'ui' => array(
				'coupon_placeholder' => sanitize_text_field( $s['coupon_placeholder_text'] ?? 'কুপন কোড' ),
				'coupon_apply'       => sanitize_text_field( $s['coupon_apply_text'] ?? 'এপ্লাই' ),
				'shipping_title'     => sanitize_text_field( $s['shipping_title'] ?? 'শিপিং মেথড' ),
			),
		) );

		// Make sure checkout scripts are available when popup content loads
		wp_enqueue_script( 'wc-checkout' );
		wp_enqueue_script( 'wc-cart-fragments' );
		wp_enqueue_script( 'wc-country-select' );
		wp_enqueue_script( 'wc-address-i18n' );
		wp_enqueue_script( 'wc-add-to-cart-variation' );
		wp_enqueue_script( 'wc-credit-card-form' );
	}

	public function render_modal_html() {
		if ( ! class_exists( 'WooCommerce' ) || ! PCS_License::is_active() ) return;
		$s = $this->get_settings();
		$title_line_1 = sanitize_text_field( $s['popup_title_line_1'] ?? 'ক্যাশ অন ডেলিভারিতে' );
		$title_line_2 = sanitize_text_field( $s['popup_title_line_2'] ?? 'অর্ডার করতে আপনার তথ্য দিন' );
		if ( '' === $title_line_1 ) $title_line_1 = 'ক্যাশ অন ডেলিভারিতে';
		?>
		<div id="pcs-popup-checkout-modal" class="pcs-modal" aria-hidden="true" style="display:none;">
			<div class="pcs-modal__backdrop" data-pcs-close="1"></div>
				<div class="pcs-modal__dialog" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e('Checkout', 'popup-checkout-subhan'); ?>">
					<button type="button" class="pcs-modal__close" aria-label="<?php esc_attr_e('Close', 'popup-checkout-subhan'); ?>" data-pcs-close="1">×</button>

					<div class="pcs-modal__header">
						<div class="pcs-modal__title">
							<?php echo esc_html( $title_line_1 ); ?>
							<?php if ( '' !== $title_line_2 ) : ?><br><?php echo esc_html( $title_line_2 ); ?><?php endif; ?>
						</div>
						<div class="pcs-modal__subtitle"></div>
					</div>

				<div id="pcs-popup-checkout-body" class="pcs-modal__body">
					<div class="pcs-skeleton">
						<div class="pcs-skeleton__line"></div>
						<div class="pcs-skeleton__line"></div>
						<div class="pcs-skeleton__line"></div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	public function output_custom_css() {
		if ( ! class_exists( 'WooCommerce' ) || ! PCS_License::is_active() ) return;
		$s = $this->get_settings();
		echo '<style id="pcs-popup-checkout-theme-css">' . $this->build_popup_theme_css( $s ) . '</style>';
		if ( $this->is_popup_thankyou_request() ) {
			echo '<style id="pcs-popup-order-received-inline-css">' . $this->build_popup_order_received_inline_css() . '</style>';
		}
		echo '<style id="pcs-popup-checkout-reference-lock-inline-css">' . $this->build_popup_reference_lock_css() . '</style>';
		echo '<style id="pcs-popup-checkout-primary-color-inline-css">' . $this->build_popup_primary_color_css( $s ) . '</style>';
		echo '<style id="pcs-popup-checkout-v2-inline-css">' . $this->build_popup_v2_css() . '</style>';
		if ( ! empty( $s['custom_css'] ) ) {
			$custom_css = substr( wp_strip_all_tags( (string) $s['custom_css'] ), 0, 50000 );
			echo '<style id="pcs-popup-checkout-custom-css">' . $custom_css . '</style>';
		}
	}

	private function build_popup_v2_css() : string {
		return <<<'CSS'
#pcs-popup-checkout-modal,
#pcs-popup-checkout-modal * {
	font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans Bengali", Arial, sans-serif !important;
	box-sizing: border-box !important;
}

#pcs-popup-checkout-modal .pcs-modal__backdrop {
	background: rgba(12, 14, 26, .52) !important;
	backdrop-filter: blur(4px) !important;
	-webkit-backdrop-filter: blur(4px) !important;
}

#pcs-popup-checkout-modal .pcs-modal__dialog {
	width: min(610px, calc(100% - 28px)) !important;
	max-width: 610px !important;
	max-height: min(94vh, 920px) !important;
	margin: 24px auto !important;
	border: 1px solid rgba(255,255,255,.7) !important;
	border-radius: 24px !important;
	background: #f7f8fb !important;
	box-shadow: 0 34px 90px rgba(9, 12, 30, .38) !important;
}

#pcs-popup-checkout-modal .pcs-modal__dialog::before,
#pcs-popup-checkout-modal .pcs-modal__dialog::after { content: none !important; }

#pcs-popup-checkout-modal .pcs-modal__header {
	position: sticky !important;
	top: 0 !important;
	z-index: 30 !important;
	min-height: 74px !important;
	display: flex !important;
	align-items: center !important;
	padding: 17px 60px 17px 20px !important;
	border-bottom: 1px solid rgba(20, 24, 45, .07) !important;
	background: linear-gradient(135deg, #ffffff 0%, #f3f1ff 100%) !important;
}

#pcs-popup-checkout-modal .pcs-modal__title {
	margin: 0 !important;
	color: #1c1e2f !important;
	font-size: 18px !important;
	font-weight: 800 !important;
	line-height: 1.3 !important;
	letter-spacing: -.01em !important;
}

#pcs-popup-checkout-modal .pcs-modal__close {
	position: absolute !important;
	right: 16px !important;
	top: 16px !important;
	z-index: 50 !important;
	width: 40px !important;
	height: 40px !important;
	display: inline-flex !important;
	align-items: center !important;
	justify-content: center !important;
	padding: 0 !important;
	border: 1px solid #e0e2eb !important;
	border-radius: 12px !important;
	background: #fff !important;
	color: #4e5367 !important;
	font-size: 25px !important;
	font-weight: 400 !important;
	line-height: 1 !important;
	box-shadow: 0 6px 14px rgba(22,26,48,.08) !important;
}

#pcs-popup-checkout-modal .pcs-modal__close:hover {
	background: #f1efff !important;
	border-color: #cfc9ff !important;
	color: #5847dc !important;
}

#pcs-popup-checkout-modal .pcs-modal__body {
	padding: 16px !important;
	background: #f7f8fb !important;
	overscroll-behavior: contain !important;
}

#pcs-popup-checkout-modal .woocommerce-billing-fields,
#pcs-popup-checkout-modal #order_review,
#pcs-popup-checkout-modal .woocommerce-checkout-payment,
#pcs-popup-checkout-modal #payment {
	margin: 0 0 12px !important;
	padding: 15px !important;
	border: 1px solid #e6e8f0 !important;
	border-radius: 16px !important;
	background: #fff !important;
	box-shadow: 0 8px 24px rgba(26,30,56,.045) !important;
}

#pcs-popup-checkout-modal .woocommerce form .form-row {
	margin-bottom: 11px !important;
}

#pcs-popup-checkout-modal .woocommerce form .form-row input.input-text,
#pcs-popup-checkout-modal .woocommerce form .form-row textarea,
#pcs-popup-checkout-modal .select2-container .select2-selection--single,
#pcs-popup-checkout-modal #coupon_code {
	min-height: 44px !important;
	padding: 10px 12px !important;
	border: 1px solid #d9dce6 !important;
	border-radius: 11px !important;
	background: #fbfbfd !important;
	color: #222536 !important;
	font-size: 14px !important;
	box-shadow: none !important;
}

#pcs-popup-checkout-modal .woocommerce form .form-row input.input-text:focus,
#pcs-popup-checkout-modal .woocommerce form .form-row textarea:focus,
#pcs-popup-checkout-modal #coupon_code:focus {
	border-color: var(--pcs-primary, #6557f5) !important;
	background: #fff !important;
	box-shadow: 0 0 0 3px rgba(101,87,245,.12) !important;
}

#pcs-popup-checkout-modal .pcs-shipping-methods__box,
#pcs-popup-checkout-modal #shipping_method li,
#pcs-popup-checkout-modal #payment ul.payment_methods > li {
	border-color: #e3e5ed !important;
	border-radius: 12px !important;
	background: #fbfbfd !important;
}

#pcs-popup-checkout-modal #shipping_method li.pcs-is-selected,
#pcs-popup-checkout-modal #payment ul.payment_methods > li:has(input:checked) {
	border-color: var(--pcs-primary, #6557f5) !important;
	background: #f5f3ff !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.cart_item td.product-name,
#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.cart_item td.product-total,
#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.cart_item td:first-child,
#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.cart_item td:last-child {
	background: #f7f8fb !important;
}

#pcs-popup-checkout-modal .pcs-totals-card {
	border: 1px solid #e0e2ea !important;
	border-radius: 12px !important;
	background: #f3f4f8 !important;
}

#pcs-popup-checkout-modal .checkout_coupon .button[name="apply_coupon"],
#pcs-popup-checkout-modal .woocommerce-checkout #place_order,
#pcs-popup-checkout-modal #payment #place_order {
	border: 0 !important;
	border-radius: 12px !important;
	background: var(--pcs-button-gradient, linear-gradient(135deg, #7564ff, #5040dd)) !important;
	color: #fff !important;
	font-weight: 800 !important;
	box-shadow: 0 12px 24px rgba(82,64,220,.22) !important;
}

#pcs-popup-checkout-modal .woocommerce-checkout #place_order:hover,
#pcs-popup-checkout-modal #payment #place_order:hover {
	transform: translateY(-1px) !important;
	filter: brightness(1.02) !important;
}

#pcs-popup-checkout-modal .pcs-error {
	padding: 18px !important;
	border: 1px solid #f0c6cb !important;
	border-radius: 14px !important;
	background: #fff5f6 !important;
	color: #a72b3a !important;
	font-size: 14px !important;
	font-weight: 650 !important;
	line-height: 1.5 !important;
	text-align: center !important;
}

body.pcs-modal-open { overflow: hidden !important; }

@media (max-width: 640px) {
	#pcs-popup-checkout-modal.pcs-open { align-items: flex-end !important; padding: 0 !important; }
	#pcs-popup-checkout-modal .pcs-modal__dialog {
		width: 100% !important;
		max-width: 100% !important;
		max-height: 96vh !important;
		margin: 0 !important;
		border-width: 1px 0 0 !important;
		border-radius: 22px 22px 0 0 !important;
	}
	#pcs-popup-checkout-modal .pcs-modal__header { min-height: 68px !important; padding: 14px 54px 14px 15px !important; }
	#pcs-popup-checkout-modal .pcs-modal__title { font-size: 16px !important; }
	#pcs-popup-checkout-modal .pcs-modal__close { right: 12px !important; top: 13px !important; width: 38px !important; height: 38px !important; }
	#pcs-popup-checkout-modal .pcs-modal__body { padding: 10px !important; }
	#pcs-popup-checkout-modal .woocommerce-billing-fields,
	#pcs-popup-checkout-modal #order_review,
	#pcs-popup-checkout-modal .woocommerce-checkout-payment,
	#pcs-popup-checkout-modal #payment { padding: 12px !important; border-radius: 14px !important; }
}
CSS;
	}

	private function build_popup_order_received_inline_css() : string {
		return <<<'CSS'
#content, .site-content {
	background: #edf1f4 !important;
	padding: 0 16px !important;
}

body.pcs-popup-order-received > .woocommerce,
body.pcs-popup-order-received .site-main > .woocommerce,
body.pcs-popup-order-received #content .woocommerce,
body.pcs-popup-order-received .entry-content > .woocommerce,
.entry-content > .woocommerce {
	width: min(760px, 100%) !important;
	max-width: 760px !important;
	margin: 50px auto !important;
	float: none !important;
	clear: both !important;
	display: block !important;
}

body.pcs-popup-order-received > .woocommerce,
body.pcs-popup-order-received .site-main > .woocommerce,
body.pcs-popup-order-received #content .woocommerce,
body.pcs-popup-order-received .entry-content > .woocommerce,
.entry-content > .woocommerce {
	padding: 30px !important;
	background: #ffffff !important;
	border: 1px solid #d6dde5 !important;
	border-radius: 14px !important;
	box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08) !important;
}

.woocommerce-order {
	width: 100% !important;
	max-width: 100% !important;
	margin: 0 !important;
	padding: 0 !important;
	background: transparent !important;
	border: 0 !important;
	box-shadow: none !important;
}

.woocommerce-notice--success.woocommerce-thankyou-order-received,
.woocommerce-order .woocommerce-thankyou-order-received {
	font-size: 32px !important;
	font-weight: 800 !important;
	color: #1f2937 !important;
	text-align: center !important;
	line-height: 1.1 !important;
	margin: 0 0 22px !important;
}

ul.woocommerce-order-overview.woocommerce-thankyou-order-details {
	display: grid !important;
	grid-template-columns: repeat(5, minmax(0, 1fr)) !important;
	gap: 0 !important;
	list-style: none !important;
	margin: 0 0 18px !important;
	padding: 14px 18px !important;
	background: #f2f5f8 !important;
	border: 1px solid #e0e7ef !important;
	border-radius: 6px !important;
}

ul.woocommerce-order-overview.woocommerce-thankyou-order-details li {
	margin: 0 !important;
	padding: 6px 12px !important;
	float: none !important;
	width: 100% !important;
	min-width: 0 !important;
	border-right: 1px solid #cfd8e3 !important;
	background: transparent !important;
	font-size: 12px !important;
	color: #374151 !important;
	text-transform: none !important;
}

ul.woocommerce-order-overview.woocommerce-thankyou-order-details li:last-child {
	border-right: 0 !important;
}

ul.woocommerce-order-overview.woocommerce-thankyou-order-details li strong {
	display: block !important;
	font-size: 16px !important;
	font-weight: 700 !important;
	line-height: 1.2 !important;
	color: #1f2937 !important;
	margin-top: 4px !important;
	word-break: break-word !important;
}

.woocommerce-order > p {
	margin: 0 0 16px !important;
	font-size: 14px !important;
	color: #374151 !important;
}

.woocommerce-order-details,
.woocommerce-customer-details {
	background: #f2f5f8 !important;
	border: 1px solid #e0e7ef !important;
	border-radius: 6px !important;
	padding: 24px 26px !important;
	margin-top: 18px !important;
}

.woocommerce-order-details h2,
.woocommerce-customer-details h2 {
	font-size: 34px !important;
	font-weight: 700 !important;
	margin: 0 0 16px !important;
	color: #1f2937 !important;
}

.woocommerce-order table.shop_table {
	border: 0 !important;
	border-radius: 0 !important;
	background: transparent !important;
	margin: 0 !important;
}

.woocommerce-order table.shop_table th {
	background: transparent !important;
	font-size: 14px !important;
	font-weight: 700 !important;
	padding: 6px 0 10px !important;
	border-bottom: 1px dashed #c7ced8 !important;
}

.woocommerce-order table.shop_table td {
	background: transparent !important;
	font-size: 14px !important;
	padding: 9px 0 !important;
	border-top: 0 !important;
}

.woocommerce-order table.shop_table tr.order_item td {
	border-bottom: 1px dashed #c7ced8 !important;
}

.woocommerce-order table.shop_table tfoot th,
.woocommerce-order table.shop_table tfoot td {
	font-size: 14px !important;
	border-top: 0 !important;
	padding-top: 8px !important;
	padding-bottom: 8px !important;
}

.woocommerce-customer-details address {
	border: 0 !important;
	border-radius: 0 !important;
	padding: 0 !important;
	background: transparent !important;
	font-size: 14px !important;
	line-height: 1.6 !important;
	color: #1f2937 !important;
}

	@media (max-width: 640px) {
		#content, .site-content {
			padding: 0 12px !important;
		}

	body.pcs-popup-order-received > .woocommerce,
	body.pcs-popup-order-received .site-main > .woocommerce,
	body.pcs-popup-order-received #content .woocommerce,
	body.pcs-popup-order-received .entry-content > .woocommerce,
	.entry-content > .woocommerce {
		width: 100% !important;
		max-width: 100% !important;
		margin: 24px auto !important;
	}

	body.pcs-popup-order-received > .woocommerce,
	body.pcs-popup-order-received .site-main > .woocommerce,
	body.pcs-popup-order-received #content .woocommerce,
	body.pcs-popup-order-received .entry-content > .woocommerce,
	.entry-content > .woocommerce {
		padding: 16px !important;
	}

	ul.woocommerce-order-overview.woocommerce-thankyou-order-details {
		padding: 10px 12px !important;
		grid-template-columns: 1fr !important;
	}

	ul.woocommerce-order-overview.woocommerce-thankyou-order-details li {
		border-right: 0 !important;
		border-bottom: 1px solid #d4dde8 !important;
		padding: 8px 0 !important;
	}

	ul.woocommerce-order-overview.woocommerce-thankyou-order-details li:last-child {
		border-bottom: 0 !important;
	}

	.woocommerce-notice--success.woocommerce-thankyou-order-received,
	.woocommerce-order .woocommerce-thankyou-order-received {
		font-size: 24px !important;
		margin-bottom: 14px !important;
	}

	.woocommerce-order-details,
	.woocommerce-customer-details {
		padding: 16px !important;
	}

	.woocommerce-order-details h2,
	.woocommerce-customer-details h2 {
		font-size: 26px !important;
	}
}
CSS;
	}

	private function hex_to_rgb_array( string $hex ) : array {
		$hex = ltrim( $hex, '#' );
		if ( strlen( $hex ) === 3 ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( strlen( $hex ) !== 6 || ! ctype_xdigit( $hex ) ) {
			return array( 2, 132, 199 );
		}
		return array(
			hexdec( substr( $hex, 0, 2 ) ),
			hexdec( substr( $hex, 2, 2 ) ),
			hexdec( substr( $hex, 4, 2 ) ),
		);
	}

	private function build_popup_theme_css( array $settings ) : string {
		$content_color = sanitize_hex_color( $settings['content_text_color'] ?? '#171717' ) ?: '#171717';
		$content_size  = max( 12, min( 22, intval( $settings['content_font_size'] ?? 16 ) ) );
		$total_size    = $content_size + 2;

		return sprintf(
			'#pcs-popup-checkout-modal .pcs-modal__title,
#pcs-popup-checkout-modal .woocommerce form .form-row#billing_first_name_field > label,
#pcs-popup-checkout-modal .woocommerce form .form-row#billing_phone_field > label,
#pcs-popup-checkout-modal .woocommerce form .form-row#billing_address_1_field > label,
#pcs-popup-checkout-modal #billing_first_name_field input.input-text,
#pcs-popup-checkout-modal #billing_phone_field input.input-text,
#pcs-popup-checkout-modal #billing_address_1_field input.input-text,
#pcs-popup-checkout-modal #billing_first_name_field input.input-text::placeholder,
#pcs-popup-checkout-modal #billing_phone_field input.input-text::placeholder,
#pcs-popup-checkout-modal #billing_address_1_field input.input-text::placeholder,
#pcs-popup-checkout-modal #order_review > .pcs-shipping-methods > .pcs-shipping-methods__title,
#pcs-popup-checkout-modal #shipping_method li label .pcs-shipping-label,
#pcs-popup-checkout-modal #shipping_method li label .pcs-shipping-price,
#pcs-popup-checkout-modal #coupon_code,
#pcs-popup-checkout-modal #coupon_code::placeholder,
#pcs-popup-checkout-modal #order_review table.shop_table td.product-name,
#pcs-popup-checkout-modal #order_review table.shop_table td.product-name *,
#pcs-popup-checkout-modal #order_review table.shop_table td.product-total,
#pcs-popup-checkout-modal #order_review table.shop_table td.product-total *,
#pcs-popup-checkout-modal #order_review table.shop_table tfoot th,
#pcs-popup-checkout-modal #order_review table.shop_table tfoot td,
#pcs-popup-checkout-modal #order_review table.shop_table tfoot td * {
	color: %1$s !important;
}

#pcs-popup-checkout-modal .woocommerce form .form-row#billing_first_name_field > label,
#pcs-popup-checkout-modal .woocommerce form .form-row#billing_phone_field > label,
#pcs-popup-checkout-modal .woocommerce form .form-row#billing_address_1_field > label,
#pcs-popup-checkout-modal #billing_first_name_field input.input-text,
#pcs-popup-checkout-modal #billing_phone_field input.input-text,
#pcs-popup-checkout-modal #billing_address_1_field input.input-text,
#pcs-popup-checkout-modal #shipping_method li label .pcs-shipping-label,
#pcs-popup-checkout-modal #shipping_method li label .pcs-shipping-price,
#pcs-popup-checkout-modal #coupon_code,
#pcs-popup-checkout-modal #order_review table.shop_table td.product-name,
#pcs-popup-checkout-modal #order_review table.shop_table td.product-name *,
#pcs-popup-checkout-modal #order_review table.shop_table td.product-total,
#pcs-popup-checkout-modal #order_review table.shop_table td.product-total *,
#pcs-popup-checkout-modal #order_review table.shop_table tfoot th,
#pcs-popup-checkout-modal #order_review table.shop_table tfoot td,
#pcs-popup-checkout-modal #order_review table.shop_table tfoot td * {
	font-size: %2$dpx !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tfoot tr.order-total th,
#pcs-popup-checkout-modal #order_review table.shop_table tfoot tr.order-total td,
#pcs-popup-checkout-modal #order_review table.shop_table tfoot tr.order-total td * {
	font-size: %3$dpx !important;
}',
			$content_color,
			$content_size,
			$total_size
		);
	}

	private function build_popup_primary_color_css( array $settings ) : string {
		$primary = sanitize_hex_color( $settings['primary_color'] ?? '' );
		if ( ! $primary ) {
			$primary = sanitize_hex_color( $settings['theme_accent_color'] ?? '#f7a200' ) ?: '#f7a200';
		}
		$button_start = sanitize_hex_color( $settings['theme_button_start'] ?? $primary ) ?: $primary;
		$button_end   = sanitize_hex_color( $settings['theme_button_end'] ?? $primary ) ?: $primary;

		return sprintf(
			'#pcs-popup-checkout-modal {
	--pcs-primary-color: %1$s !important;
	--pcs-primary: %1$s !important;
	--pcs-button-gradient: linear-gradient(135deg, %2$s, %3$s) !important;
}

#pcs-popup-checkout-modal .checkout_coupon .button[name="apply_coupon"],
#pcs-popup-checkout-modal .woocommerce-checkout #place_order,
#pcs-popup-checkout-modal #payment #place_order,
#pcs-popup-checkout-modal #order_review .pcs-order-bump__badge {
	background: %1$s !important;
	border-color: %1$s !important;
}

#pcs-popup-checkout-modal #shipping_method li input[type="radio"]:checked,
#pcs-popup-checkout-modal #payment ul.payment_methods > li > input[type="radio"]:checked,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li > input[type="radio"]:checked,
#pcs-popup-checkout-modal #payment .wc_payment_methods > li > input[type="radio"]:checked {
	border-color: %1$s !important;
}

#pcs-popup-checkout-modal #shipping_method li input[type="radio"]:checked::after,
#pcs-popup-checkout-modal #payment ul.payment_methods > li > input[type="radio"]:checked::after,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li > input[type="radio"]:checked::after,
#pcs-popup-checkout-modal #payment .wc_payment_methods > li > input[type="radio"]:checked::after {
	background: %1$s !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__price,
#pcs-popup-checkout-modal #order_review .pcs-order-bump__price .woocommerce-Price-amount,
#pcs-popup-checkout-modal #order_review .pcs-order-bump__price .amount {
	color: %1$s !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump {
	border-color: %1$s !important;
}',
			$primary,
			$button_start,
			$button_end
		);
	}

	private function build_popup_reference_lock_css() : string {
		return <<<'CSS'
#pcs-popup-checkout-modal .pcs-modal__dialog {
	width: 500px !important;
	max-width: calc(100% - 12px) !important;
	max-height: calc(100vh - 12px) !important;
	border: 1px solid #8a8a8a !important;
	border-radius: 20px !important;
	background: #efefef !important;
	box-shadow: none !important;
	outline: 0 !important;
}

#pcs-popup-checkout-modal .pcs-modal__dialog::before,
#pcs-popup-checkout-modal .pcs-modal__dialog::after {
	display: none !important;
	content: none !important;
}

#pcs-popup-checkout-modal .pcs-modal__header {
	padding: 10px 44px !important;
	text-align: center !important;
	background: #efefef !important;
	border-bottom: 1px solid #bdbdbd !important;
}

#pcs-popup-checkout-modal .pcs-modal__title {
	font-size: 18px !important;
	font-weight: 700 !important;
	line-height: 1.35 !important;
	color: #111111 !important;
}

#pcs-popup-checkout-modal .pcs-modal__subtitle { display: none !important; }

#pcs-popup-checkout-modal .pcs-modal__close {
	top: 6px !important;
	right: 10px !important;
	background: transparent !important;
	border: 0 !important;
	border-radius: 0 !important;
	box-shadow: none !important;
	font-size: 34px !important;
	color: #6b6b6b !important;
}

#pcs-popup-checkout-modal .pcs-modal__close::before { content: none !important; }

#pcs-popup-checkout-modal .pcs-modal__body {
	padding: 12px !important;
	background: #efefef !important;
}

#pcs-popup-checkout-modal .woocommerce-billing-fields > h3,
#pcs-popup-checkout-modal #order_review_heading {
	display: none !important;
}

#pcs-popup-checkout-modal .woocommerce form .form-row#billing_first_name_field,
#pcs-popup-checkout-modal .woocommerce form .form-row#billing_phone_field,
#pcs-popup-checkout-modal .woocommerce form .form-row#billing_address_1_field {
	display: flex !important;
	align-items: center !important;
	gap: 10px !important;
	margin: 0 0 10px 0 !important;
}

#pcs-popup-checkout-modal .woocommerce form .form-row#billing_first_name_field > label,
#pcs-popup-checkout-modal .woocommerce form .form-row#billing_phone_field > label,
#pcs-popup-checkout-modal .woocommerce form .form-row#billing_address_1_field > label {
	flex: 0 0 86px !important;
	max-width: 86px !important;
	margin: 0 !important;
	font-size: 12px !important;
	font-weight: 700 !important;
	color: #1b1b1b !important;
	line-height: 1.15 !important;
	white-space: nowrap !important;
}

#pcs-popup-checkout-modal #billing_first_name_field input.input-text,
#pcs-popup-checkout-modal #billing_phone_field input.input-text,
#pcs-popup-checkout-modal #billing_address_1_field input.input-text {
	height: 36px !important;
	padding: 0 10px 0 46px !important;
	border: 1px solid #c4c4c4 !important;
	border-radius: 4px !important;
	background: #ffffff !important;
	box-shadow: none !important;
	font-size: 13px !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.cart_item td {
	padding: 8px 10px !important;
	border: 0 !important;
	background: #f4f4f4 !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.cart_item + tr.cart_item td {
	border-top: 6px solid #efefef !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table td.product-total {
	white-space: nowrap !important;
	color: #e18b00 !important;
	font-weight: 700 !important;
	text-align: right !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table td.product-total .woocommerce-Price-amount,
#pcs-popup-checkout-modal #order_review table.shop_table td.product-total .amount {
	color: #e18b00 !important;
	font-weight: 700 !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product {
	display: flex !important;
	align-items: center !important;
	gap: 10px !important;
	width: 100% !important;
	position: relative !important;
	padding-left: 12px !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__thumb-wrap {
	position: relative !important;
	width: 34px !important;
	height: 34px !important;
	flex: 0 0 34px !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__thumb-wrap img,
#pcs-popup-checkout-modal #order_review .pcs-review-thumb {
	width: 34px !important;
	height: 34px !important;
	object-fit: cover !important;
	display: block !important;
	border-radius: 4px !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-thumb--placeholder {
	background: #d6d6d6 !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__qty {
	display: none !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__name {
	display: block !important;
	font-size: 13px !important;
	font-weight: 600 !important;
	line-height: 1.25 !important;
	color: #1b1b1b !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__meta {
	display: flex !important;
	flex-direction: column !important;
	gap: 5px !important;
	min-width: 0 !important;
	flex: 1 1 auto !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__actions {
	display: inline-flex !important;
	align-items: center !important;
	gap: 5px !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__btn {
	display: inline-flex !important;
	align-items: center !important;
	justify-content: center !important;
	width: auto !important;
	height: auto !important;
	padding: 0 1px !important;
	border: 0 !important;
	border-radius: 0 !important;
	background: transparent !important;
	color: #272727 !important;
	font-size: 20px !important;
	font-weight: 700 !important;
	line-height: 1 !important;
	cursor: pointer !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__btn--minus,
#pcs-popup-checkout-modal #order_review .pcs-review-product__btn--plus {
	min-width: 12px !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__btn--remove {
	width: 14px !important;
	height: 14px !important;
	border: 0 !important;
	background: transparent !important;
	color: #b2b2b2 !important;
	font-size: 18px !important;
	line-height: 1 !important;
	margin: 0 4px 0 0 !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__btn--remove-left {
	position: absolute !important;
	left: 0 !important;
	top: 1px !important;
	width: auto !important;
	height: auto !important;
	padding: 0 !important;
	margin: 0 !important;
	border: 0 !important;
	background: transparent !important;
	color: #adadad !important;
	font-size: 16px !important;
	line-height: 1 !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__qty-value {
	min-width: 16px !important;
	text-align: center !important;
	font-size: 14px !important;
	font-weight: 700 !important;
	color: #1f1f1f !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__actions.is-updating {
	opacity: 0.6 !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table td.product-total {
	display: table-cell !important;
	width: 1% !important;
	background: #f4f4f4 !important;
	text-align: right !important;
	white-space: nowrap !important;
	vertical-align: middle !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table td.product-name {
	background: #f4f4f4 !important;
}

/* Compact lock: remove extra bottom gap under product rows */
#pcs-popup-checkout-modal #order_review table.shop_table {
	border-collapse: separate !important;
	border-spacing: 0 6px !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.cart_item td.product-name,
#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.cart_item td.product-total {
	padding-top: 8px !important;
	padding-right: 9px !important;
	padding-bottom: 0 !important;
	padding-left: 9px !important;
	vertical-align: top !important;
	background: #f6f6f6 !important;
	border: 0 !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.cart_item + tr.cart_item td {
	border-top: 0 !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.cart_item td.product-name {
	border-radius: 8px 0 0 8px !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.cart_item td.product-total {
	text-align: right !important;
	border-radius: 0 8px 8px 0 !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product {
	margin: 0 !important;
	padding-bottom: 0 !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__meta {
	gap: 2px !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__subtotal-wrap {
	display: inline-flex !important;
	align-items: center !important;
	justify-content: flex-end !important;
	gap: 4px !important;
	white-space: nowrap !important;
}

#pcs-popup-checkout-modal #order_review .pcs-review-product__subtotal-amount,
#pcs-popup-checkout-modal #order_review .pcs-review-product__subtotal-amount * {
	color: #e18b00 !important;
	font-weight: 700 !important;
}

/* Fallback: if Woodmart checkout table template is still active, force compact rows */
#pcs-popup-checkout-modal #order_review td.wd-checkout-prod {
	display: flex !important;
	align-items: center !important;
	gap: 10px !important;
	padding: 8px 10px !important;
	border: 0 !important;
	background: #f4f4f4 !important;
}

#pcs-popup-checkout-modal #order_review td.wd-checkout-prod .wd-checkout-prod-img {
	width: 34px !important;
	max-width: 34px !important;
	flex: 0 0 34px !important;
	margin: 0 !important;
}

#pcs-popup-checkout-modal #order_review td.wd-checkout-prod .wd-checkout-prod-img img {
	width: 34px !important;
	height: 34px !important;
	object-fit: cover !important;
	border-radius: 4px !important;
}

#pcs-popup-checkout-modal #order_review td.wd-checkout-prod .wd-checkout-prod-cont {
	display: grid !important;
	grid-template-columns: minmax(0, 1fr) auto !important;
	align-items: center !important;
	gap: 8px !important;
	flex: 1 1 auto !important;
	width: 100% !important;
	min-width: 0 !important;
}

#pcs-popup-checkout-modal #order_review td.wd-checkout-prod .wd-checkout-prod-title,
#pcs-popup-checkout-modal #order_review td.wd-checkout-prod .wd-checkout-prod-title .cart-product-label {
	font-size: 13px !important;
	font-weight: 600 !important;
	line-height: 1.25 !important;
	color: #1b1b1b !important;
}

#pcs-popup-checkout-modal #order_review td.wd-checkout-prod .wd-checkout-prod-total,
#pcs-popup-checkout-modal #order_review td.wd-checkout-prod .wd-checkout-prod-total * {
	font-size: 13px !important;
	font-weight: 700 !important;
	color: #e18b00 !important;
	text-align: right !important;
	white-space: nowrap !important;
}

#pcs-popup-checkout-modal #order_review td.wd-checkout-prod .product-quantity,
#pcs-popup-checkout-modal #order_review td.wd-checkout-prod .quantity,
#pcs-popup-checkout-modal #order_review td.wd-checkout-prod .wd-product-detail,
#pcs-popup-checkout-modal #order_review td.wd-checkout-prod .wd-checkout-remove-btn-wrapp {
	display: none !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.pcs-order-bump-row td {
	padding: 10px 10px 8px !important;
	border: 0 !important;
	background: transparent !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump {
	display: block !important;
	width: 100% !important;
	padding: 10px 10px 30px 10px !important;
	border: 1px dashed #e2b964 !important;
	border-radius: 4px !important;
	background: rgb(249 235 6 / 9%) !important;
	box-sizing: border-box !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump.is-updating {
	opacity: 0.68 !important;
	pointer-events: none !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__badge {
	display: block !important;
	width: 100% !important;
	margin: 0 0 8px 0 !important;
	padding: 2px 8px !important;
	background: #f7a200 !important;
	color: #ffffff !important;
	font-size: 10px !important;
	font-weight: 700 !important;
	line-height: 1.25 !important;
	letter-spacing: 0.3px !important;
	text-align: center !important;
	text-transform: uppercase !important;
	border-radius: 1px !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__label {
	display: grid !important;
	grid-template-columns: 14px minmax(0, 1fr) !important;
	align-items: start !important;
	column-gap: 8px !important;
	margin: 0 !important;
	cursor: pointer !important;
	width: 100% !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__content {
	display: grid !important;
	grid-template-columns: 20px minmax(0, 1fr) !important;
	align-items: start !important;
	column-gap: 7px !important;
	width: 100% !important;
	min-width: 0 !important;
	grid-column: 2 !important;
	grid-row: 1 !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__toggle {
	-webkit-appearance: none !important;
	appearance: none !important;
	width: 12px !important;
	height: 12px !important;
	min-width: 12px !important;
	margin: 2px 0 0 0 !important;
	border: 1px solid #cfaa56 !important;
	border-radius: 2px !important;
	background: #ffffff !important;
	position: relative !important;
	cursor: pointer !important;
	box-shadow: none !important;
	grid-column: 1 !important;
	grid-row: 1 !important;
	align-self: start !important;
	justify-self: start !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__toggle:checked {
	background: #f7a200 !important;
	border-color: #f7a200 !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__toggle:checked::after {
	content: "" !important;
	position: absolute !important;
	left: 3px !important;
	top: 0 !important;
	width: 3px !important;
	height: 6px !important;
	border: solid #ffffff !important;
	border-width: 0 2px 2px 0 !important;
	transform: rotate(45deg) !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__toggle:focus-visible {
	outline: 2px solid rgba(247, 162, 0, 0.45) !important;
	outline-offset: 1px !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__thumb-wrap {
	display: inline-flex !important;
	width: 20px !important;
	height: 20px !important;
	align-items: center !important;
	justify-content: center !important;
	margin-top: 1px !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__thumb {
	display: block !important;
	width: 20px !important;
	height: 20px !important;
	object-fit: cover !important;
	border-radius: 3px !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__thumb--placeholder {
	background: #d9d9d9 !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__copy {
	display: block !important;
	min-width: 0 !important;
	line-height: 1.2 !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__title {
	display: block !important;
	font-size: 12px !important;
	font-weight: 600 !important;
	line-height: 1.2 !important;
	color: #262626 !important;
	min-width: 0 !important;
	white-space: normal !important;
	word-break: break-word !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__price {
	display: block !important;
	margin-top: 2px !important;
	text-align: left !important;
	white-space: normal !important;
	font-size: 13px !important;
	font-weight: 700 !important;
	line-height: 1.2 !important;
	color: #e08b00 !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__price .woocommerce-Price-amount,
#pcs-popup-checkout-modal #order_review .pcs-order-bump__price .amount {
	color: #e08b00 !important;
	font-weight: 700 !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__price del {
	display: none !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__price ins {
	text-decoration: none !important;
}

#pcs-popup-checkout-modal #order_review .pcs-order-bump__note {
	display: block !important;
	margin-top: 2px !important;
	font-size: 11px !important;
	line-height: 1.25 !important;
	color: #7d7d7d !important;
	white-space: normal !important;
	word-break: break-word !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tfoot {
	display: block !important;
	width: 100% !important;
	min-width: 100% !important;
	max-width: 100% !important;
	margin: 8px 0 0 !important;
	margin-left: 0 !important;
	margin-right: 0 !important;
	padding: 10px 12px !important;
	background: #dddddd !important;
	border-radius: 6px !important;
	box-sizing: border-box !important;
}

#pcs-popup-checkout-modal #order_review,
#pcs-popup-checkout-modal #order_review > table.shop_table,
#pcs-popup-checkout-modal #order_review table.shop_table {
	width: 100% !important;
	max-width: 100% !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tfoot tr {
	display: grid !important;
	grid-template-columns: minmax(0, 1fr) auto !important;
	align-items: center !important;
	width: 100% !important;
	margin: 0 !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tfoot th {
	text-align: left !important;
	padding-right: 10px !important;
}

#pcs-popup-checkout-modal #order_review table.shop_table tfoot td,
#pcs-popup-checkout-modal #order_review table.shop_table tfoot td * {
	text-align: right !important;
	justify-self: end !important;
}

#pcs-popup-checkout-modal .checkout_coupon .button[name="apply_coupon"],
#pcs-popup-checkout-modal .woocommerce-checkout #place_order,
#pcs-popup-checkout-modal #payment #place_order {
	background: #f7a200 !important;
	border-color: #dc9200 !important;
	box-shadow: none !important;
}

#pcs-popup-checkout-modal #payment .pcs-coupon-slot,
#pcs-popup-checkout-modal .woocommerce-checkout-payment .pcs-coupon-slot,
#pcs-popup-checkout-modal #order_review .pcs-coupon-slot {
	margin: 10px 0 8px !important;
}

#pcs-popup-checkout-modal #payment .pcs-coupon-slot form.checkout_coupon.woocommerce-form-coupon,
#pcs-popup-checkout-modal .woocommerce-checkout-payment .pcs-coupon-slot form.checkout_coupon.woocommerce-form-coupon,
#pcs-popup-checkout-modal #order_review .pcs-coupon-slot form.checkout_coupon.woocommerce-form-coupon {
	display: grid !important;
	grid-template-columns: minmax(0, 1fr) 128px !important;
	align-items: stretch !important;
	gap: 6px !important;
	margin: 0 !important;
	padding: 0 !important;
	border: 0 !important;
	background: transparent !important;
	width: 100% !important;
}

#pcs-popup-checkout-modal #payment .pcs-coupon-slot form.checkout_coupon .form-row,
#pcs-popup-checkout-modal .woocommerce-checkout-payment .pcs-coupon-slot form.checkout_coupon .form-row,
#pcs-popup-checkout-modal #order_review .pcs-coupon-slot form.checkout_coupon .form-row {
	margin: 0 !important;
	padding: 0 !important;
	float: none !important;
	width: auto !important;
	min-width: 0 !important;
}

#pcs-popup-checkout-modal #payment .pcs-coupon-slot form.checkout_coupon .form-row-first,
#pcs-popup-checkout-modal .woocommerce-checkout-payment .pcs-coupon-slot form.checkout_coupon .form-row-first,
#pcs-popup-checkout-modal #order_review .pcs-coupon-slot form.checkout_coupon .form-row-first {
	width: auto !important;
	min-width: 0 !important;
}

#pcs-popup-checkout-modal #payment .pcs-coupon-slot form.checkout_coupon .form-row-last,
#pcs-popup-checkout-modal .woocommerce-checkout-payment .pcs-coupon-slot form.checkout_coupon .form-row-last,
#pcs-popup-checkout-modal #order_review .pcs-coupon-slot form.checkout_coupon .form-row-last {
	width: 128px !important;
	min-width: 128px !important;
}

#pcs-popup-checkout-modal #payment .pcs-coupon-slot form.checkout_coupon #coupon_code,
#pcs-popup-checkout-modal .woocommerce-checkout-payment .pcs-coupon-slot form.checkout_coupon #coupon_code,
#pcs-popup-checkout-modal #order_review .pcs-coupon-slot form.checkout_coupon #coupon_code {
	width: 100% !important;
	min-width: 0 !important;
	display: block !important;
}

#pcs-popup-checkout-modal #payment .pcs-coupon-slot form.checkout_coupon .button[name="apply_coupon"],
#pcs-popup-checkout-modal .woocommerce-checkout-payment .pcs-coupon-slot form.checkout_coupon .button[name="apply_coupon"],
#pcs-popup-checkout-modal #order_review .pcs-coupon-slot form.checkout_coupon .button[name="apply_coupon"] {
	width: 100% !important;
}

#pcs-popup-checkout-modal #payment .pcs-coupon-slot,
#pcs-popup-checkout-modal .woocommerce-checkout-payment .pcs-coupon-slot {
	display: block !important;
	visibility: visible !important;
	opacity: 1 !important;
}

#pcs-popup-checkout-modal #order_review > .pcs-order-summary-title,
#pcs-popup-checkout-modal #payment > .pcs-payment-title,
#pcs-popup-checkout-modal .woocommerce-checkout-payment > .pcs-payment-title {
	margin: 8px 0 !important;
	padding: 0 !important;
	font-size: 13px !important;
	font-weight: 700 !important;
	line-height: 1.2 !important;
	color: #1b1b1b !important;
}

#pcs-popup-checkout-modal .woocommerce-additional-fields {
	margin: 0 !important;
	padding: 0 !important;
	border: 0 !important;
	background: transparent !important;
}

#pcs-popup-checkout-modal .woocommerce-additional-fields > h3 {
	display: none !important;
}

#pcs-popup-checkout-modal #order_comments_field,
#pcs-popup-checkout-modal .form-row.notes {
	display: block !important;
	visibility: visible !important;
	opacity: 1 !important;
}

#pcs-popup-checkout-modal #payment #order_comments_field,
#pcs-popup-checkout-modal .woocommerce-checkout-payment #order_comments_field {
	margin: 8px 0 !important;
}

#pcs-popup-checkout-modal #payment #order_comments_field > label,
#pcs-popup-checkout-modal .woocommerce-checkout-payment #order_comments_field > label {
	display: block !important;
	margin: 0 0 6px 0 !important;
	font-size: 13px !important;
	font-weight: 700 !important;
	color: #151515 !important;
}

#pcs-popup-checkout-modal #order_comments {
	height: 40px !important;
	min-height: 40px !important;
	max-height: 40px !important;
	resize: none !important;
}

/* White background lock + Arial typography request */
#pcs-popup-checkout-modal .pcs-modal__dialog,
#pcs-popup-checkout-modal .pcs-modal__header,
#pcs-popup-checkout-modal .pcs-modal__body,
#pcs-popup-checkout-modal #pcs-popup-checkout-body,
#pcs-popup-checkout-modal #pcs-popup-checkout-body .woocommerce,
#pcs-popup-checkout-modal #pcs-popup-checkout-body .woocommerce-checkout,
#pcs-popup-checkout-modal #order_review,
#pcs-popup-checkout-modal #order_review table.shop_table,
#pcs-popup-checkout-modal #order_review table.shop_table tbody tr.cart_item td,
#pcs-popup-checkout-modal #order_review table.shop_table td.product-name,
#pcs-popup-checkout-modal #order_review table.shop_table td.product-total,
#pcs-popup-checkout-modal #order_review table.shop_table tfoot,
#pcs-popup-checkout-modal #payment,
#pcs-popup-checkout-modal .woocommerce-checkout-payment,
#pcs-popup-checkout-modal .pcs-totals-card {
	background: #ffffff !important;
}

#pcs-popup-checkout-modal #pcs-popup-checkout-body p,
#pcs-popup-checkout-modal #pcs-popup-checkout-body span,
#pcs-popup-checkout-modal #pcs-popup-checkout-body a,
#pcs-popup-checkout-modal #pcs-popup-checkout-body label,
#pcs-popup-checkout-modal #pcs-popup-checkout-body strong,
#pcs-popup-checkout-modal #pcs-popup-checkout-body small,
#pcs-popup-checkout-modal #pcs-popup-checkout-body em,
#pcs-popup-checkout-modal #pcs-popup-checkout-body b,
#pcs-popup-checkout-modal #pcs-popup-checkout-body li,
#pcs-popup-checkout-modal #pcs-popup-checkout-body td,
#pcs-popup-checkout-modal #pcs-popup-checkout-body th,
#pcs-popup-checkout-modal #pcs-popup-checkout-body div,
#pcs-popup-checkout-modal #pcs-popup-checkout-body h1,
#pcs-popup-checkout-modal #pcs-popup-checkout-body h2,
#pcs-popup-checkout-modal #pcs-popup-checkout-body h3,
#pcs-popup-checkout-modal #pcs-popup-checkout-body h4,
#pcs-popup-checkout-modal #pcs-popup-checkout-body h5,
#pcs-popup-checkout-modal #pcs-popup-checkout-body h6,
#pcs-popup-checkout-modal #pcs-popup-checkout-body input,
#pcs-popup-checkout-modal #pcs-popup-checkout-body textarea,
#pcs-popup-checkout-modal #pcs-popup-checkout-body button,
#pcs-popup-checkout-modal #pcs-popup-checkout-body select,
#pcs-popup-checkout-modal #pcs-popup-checkout-body option {
	font-family: Arial, sans-serif !important;
}

/* Shipping block lock: previous style (white bg + border) */
#pcs-popup-checkout-modal .pcs-shipping-methods,
#pcs-popup-checkout-modal .pcs-shipping-methods--custom {
	margin: 2px 0 10px 0 !important;
	background: transparent !important;
}

#pcs-popup-checkout-modal .pcs-shipping-methods__title {
	margin: 0 0 6px 0 !important;
	padding: 0 !important;
	font-size: 14px !important;
	font-weight: 700 !important;
	line-height: 1.2 !important;
	color: #1a1a1a !important;
}

#pcs-popup-checkout-modal .pcs-shipping-methods__box {
	background: #ffffff !important;
	border: 1px solid #bfc2c5 !important;
	border-radius: 4px !important;
	padding: 0 !important;
	overflow: hidden !important;
}

#pcs-popup-checkout-modal .pcs-shipping-methods--custom #shipping_method,
#pcs-popup-checkout-modal #shipping_method,
#pcs-popup-checkout-modal ul#shipping_method.pcs-shipping-options {
	list-style: none !important;
	margin: 0 !important;
	padding: 4px 0 !important;
	border: 0px solid #c4c4c4 !important;
	background: #ffffff !important;
}

#pcs-popup-checkout-modal .pcs-shipping-methods--custom #shipping_method li,
#pcs-popup-checkout-modal #shipping_method li {
	margin: 0 !important;
	padding: 4px 10px !important;
	background: #ffffff !important;
	border: 0 !important;
	border-top: 0 !important;
	border-right: 0 !important;
	border-bottom: 0 !important;
	border-left: 0 !important;
}

#pcs-popup-checkout-modal #shipping_method li + li {
	border-top: 0 !important;
}

#pcs-popup-checkout-modal .pcs-shipping-methods--custom #shipping_method li + li > label,
#pcs-popup-checkout-modal #shipping_method li + li > label {
	border-top: 1px solid #c4c4c4 !important;
	box-sizing: border-box !important;
}

#pcs-popup-checkout-modal #shipping_method li input[type="radio"] {
	-webkit-appearance: none !important;
	appearance: none !important;
	position: relative !important;
	display: inline-block !important;
	vertical-align: middle !important;
	margin: 0 8px 0 0 !important;
	width: 16px !important;
	height: 16px !important;
	min-width: 16px !important;
	min-height: 16px !important;
	border: 1px solid #adadad !important;
	border-radius: 50% !important;
	background: #ffffff !important;
	box-shadow: none !important;
}

#pcs-popup-checkout-modal #shipping_method li input[type="radio"]:checked {
	border-color: #f2a100 !important;
	background: #ffffff !important;
	box-shadow: none !important;
}

#pcs-popup-checkout-modal #shipping_method li input[type="radio"]:checked::after {
	content: "" !important;
	position: absolute !important;
	top: 3px !important;
	left: 3px !important;
	width: 8px !important;
	height: 8px !important;
	border-radius: 50% !important;
	background: #f2a100 !important;
}

#pcs-popup-checkout-modal #shipping_method li label {
	display: flex !important;
	align-items: center !important;
	justify-content: space-between !important;
	gap: 10px !important;
	width: 100% !important;
	margin: 0 !important;
	padding: 10px 12px !important;
	background: #ffffff !important;
}

#pcs-popup-checkout-modal #shipping_method li label .pcs-shipping-label,
#pcs-popup-checkout-modal #shipping_method li label .pcs-shipping-price {
	background: transparent !important;
	font-size: 12px !important;
	line-height: 1.2 !important;
	color: #1b1b1b !important;
}

#pcs-popup-checkout-modal #shipping_method li label .pcs-shipping-label {
	font-weight: 700 !important;
	min-width: 0 !important;
}

#pcs-popup-checkout-modal #shipping_method li label .pcs-shipping-price {
	font-weight: 700 !important;
	white-space: nowrap !important;
	text-align: right !important;
}

/* Payment methods lock: remove gap/double borders and keep clean rows */
#pcs-popup-checkout-modal #payment,
#pcs-popup-checkout-modal .woocommerce-checkout-payment {
	background: #ffffff !important;
	border: 1px solid #c4c4c4 !important;
	border-radius: 6px !important;
	box-shadow: none !important;
	padding: 0 !important;
	margin: 8px 0 0 !important;
}

#pcs-popup-checkout-modal #payment ul.payment_methods,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods,
#pcs-popup-checkout-modal #payment .wc_payment_methods {
	margin: 0 !important;
	padding: 0 !important;
	list-style: none !important;
	border: 1px solid #c4c4c4 !important;
	border-radius: 6px !important;
	background: #ffffff !important;
	display: block !important;
	gap: 0 !important;
	overflow: hidden !important;
}

#pcs-popup-checkout-modal #payment ul.payment_methods > li,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li,
#pcs-popup-checkout-modal #payment .wc_payment_methods > li {
	list-style: none !important;
	margin: 0 !important;
	padding: 10px 12px !important;
	border: 0 !important;
	border-radius: 0 !important;
	outline: 0 !important;
	background: #ffffff !important;
	box-shadow: none !important;
	transform: none !important;
}

#pcs-popup-checkout-modal #payment ul.payment_methods > li + li,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li + li,
#pcs-popup-checkout-modal #payment .wc_payment_methods > li + li {
	border-top: 1px solid #d5d5d5 !important;
}

#pcs-popup-checkout-modal #payment ul.payment_methods > li:hover,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li:hover,
#pcs-popup-checkout-modal #payment .wc_payment_methods > li:hover,
#pcs-popup-checkout-modal #payment ul.payment_methods > li:focus-within,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li:focus-within,
#pcs-popup-checkout-modal #payment .wc_payment_methods > li:focus-within,
#pcs-popup-checkout-modal #payment ul.payment_methods > li.payment_method_chosen,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li.payment_method_chosen,
#pcs-popup-checkout-modal #payment .wc_payment_methods > li.payment_method_chosen,
#pcs-popup-checkout-modal #payment ul.payment_methods > li:has(> input[type="radio"]:checked),
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li:has(> input[type="radio"]:checked),
#pcs-popup-checkout-modal #payment .wc_payment_methods > li:has(> input[type="radio"]:checked) {
	background: #ffffff !important;
	border-color: transparent !important;
	box-shadow: none !important;
	transform: none !important;
}

#pcs-popup-checkout-modal #payment ul.payment_methods > li > label,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li > label,
#pcs-popup-checkout-modal #payment .wc_payment_methods > li > label {
	display: flex !important;
	align-items: center !important;
	gap: 8px !important;
	width: 100% !important;
	margin: 0 !important;
	padding: 0 !important;
	border: 0 !important;
	border-radius: 0 !important;
	outline: 0 !important;
	background: transparent !important;
	box-shadow: none !important;
}

#pcs-popup-checkout-modal #payment ul.payment_methods > li > label::before,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li > label::before,
#pcs-popup-checkout-modal #payment .wc_payment_methods > li > label::before,
#pcs-popup-checkout-modal #payment ul.payment_methods > li > label::after,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li > label::after,
#pcs-popup-checkout-modal #payment .wc_payment_methods > li > label::after {
	display: none !important;
	content: none !important;
}

#pcs-popup-checkout-modal #payment ul.payment_methods > li > input[type="radio"],
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li > input[type="radio"],
#pcs-popup-checkout-modal #payment .wc_payment_methods > li > input[type="radio"] {
	-webkit-appearance: none !important;
	appearance: none !important;
	position: relative !important;
	display: inline-block !important;
	vertical-align: middle !important;
	width: 16px !important;
	height: 16px !important;
	min-width: 16px !important;
	min-height: 16px !important;
	margin: 0 8px 0 0 !important;
	border: 1px solid #adadad !important;
	border-radius: 50% !important;
	background: #ffffff !important;
	outline: none !important;
	box-shadow: none !important;
}

#pcs-popup-checkout-modal #payment ul.payment_methods > li > input[type="radio"]:checked,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li > input[type="radio"]:checked,
#pcs-popup-checkout-modal #payment .wc_payment_methods > li > input[type="radio"]:checked {
	border-color: #f2a100 !important;
}

#pcs-popup-checkout-modal #payment ul.payment_methods > li > input[type="radio"]:checked::after,
#pcs-popup-checkout-modal .woocommerce-checkout-payment ul.payment_methods > li > input[type="radio"]:checked::after,
#pcs-popup-checkout-modal #payment .wc_payment_methods > li > input[type="radio"]:checked::after {
	content: "" !important;
	position: absolute !important;
	top: 3px !important;
	left: 3px !important;
	width: 8px !important;
	height: 8px !important;
	border-radius: 50% !important;
	background: #f2a100 !important;
}

#pcs-popup-checkout-modal #payment div.payment_box,
#pcs-popup-checkout-modal .woocommerce-checkout-payment div.payment_box {
	margin: 6px 0 0 !important;
	padding: 10px 12px !important;
	border: 1px solid #d5d5d5 !important;
	border-radius: 4px !important;
	background: #ffffff !important;
	box-shadow: none !important;
}

#pcs-popup-checkout-modal #payment div.payment_box p,
#pcs-popup-checkout-modal .woocommerce-checkout-payment div.payment_box p {
	margin: 0 !important;
}

#pcs-popup-checkout-modal #payment div.payment_box::before,
#pcs-popup-checkout-modal .woocommerce-checkout-payment div.payment_box::before {
	display: none !important;
	content: none !important;
}

#pcs-popup-checkout-modal #payment .form-row.place-order,
#pcs-popup-checkout-modal .woocommerce-checkout-payment .form-row.place-order {
	margin: 8px 0 0 !important;
	padding: 0 10px 10px !important;
	border: 0 !important;
	background: transparent !important;
}

/* Billing icon lock: keep icons visible on hover/focus */
#pcs-popup-checkout-modal #billing_first_name_field .woocommerce-input-wrapper,
#pcs-popup-checkout-modal #billing_phone_field .woocommerce-input-wrapper,
#pcs-popup-checkout-modal #billing_address_1_field .woocommerce-input-wrapper {
	position: relative !important;
	overflow: visible !important;
	isolation: isolate !important;
}

#pcs-popup-checkout-modal #billing_first_name_field .woocommerce-input-wrapper::before,
#pcs-popup-checkout-modal #billing_phone_field .woocommerce-input-wrapper::before,
#pcs-popup-checkout-modal #billing_address_1_field .woocommerce-input-wrapper::before,
#pcs-popup-checkout-modal #billing_first_name_field .woocommerce-input-wrapper:hover::before,
#pcs-popup-checkout-modal #billing_phone_field .woocommerce-input-wrapper:hover::before,
#pcs-popup-checkout-modal #billing_address_1_field .woocommerce-input-wrapper:hover::before,
#pcs-popup-checkout-modal #billing_first_name_field .woocommerce-input-wrapper:focus-within::before,
#pcs-popup-checkout-modal #billing_phone_field .woocommerce-input-wrapper:focus-within::before,
#pcs-popup-checkout-modal #billing_address_1_field .woocommerce-input-wrapper:focus-within::before {
	display: flex !important;
	opacity: 1 !important;
	visibility: visible !important;
	pointer-events: none !important;
	z-index: 3 !important;
}

#pcs-popup-checkout-modal #billing_first_name_field input.input-text,
#pcs-popup-checkout-modal #billing_phone_field input.input-text,
#pcs-popup-checkout-modal #billing_address_1_field input.input-text {
	position: relative !important;
	z-index: 1 !important;
	background: #ffffff !important;
	border: 1px solid #c4c4c4 !important;
}

#pcs-popup-checkout-modal #billing_first_name_field input.input-text:focus,
#pcs-popup-checkout-modal #billing_phone_field input.input-text:focus,
#pcs-popup-checkout-modal #billing_address_1_field input.input-text:focus,
#pcs-popup-checkout-modal #billing_first_name_field input.input-text:hover,
#pcs-popup-checkout-modal #billing_phone_field input.input-text:hover,
#pcs-popup-checkout-modal #billing_address_1_field input.input-text:hover {
	background: #ffffff !important;
	border-color: #b8b8b8 !important;
}

@media (max-width: 640px) {
	#pcs-popup-checkout-modal .pcs-modal__dialog {
		width: calc(100% - 4px) !important;
		max-width: calc(100% - 4px) !important;
	}

	#pcs-popup-checkout-modal .pcs-modal__title {
		font-size: 16px !important;
	}
}
CSS;
	}

	private function get_wc_ajax_action() : string {
		if ( empty( $_REQUEST['wc-ajax'] ) ) return '';
		$raw = wp_unslash( $_REQUEST['wc-ajax'] );
		if ( is_array( $raw ) ) return '';
		return sanitize_text_field( $raw );
	}

	public function maybe_disable_theme_checkout_overrides() {
		if ( ! PCS_License::is_active() ) return;
		if ( ! $this->is_popup_checkout_render_request() && ! $this->request_has_popup_context_flag() ) {
			return;
		}

		if ( class_exists( '\XTS\Modules\Checkout_Order_Table' ) && method_exists( '\XTS\Modules\Checkout_Order_Table', 'get_instance' ) ) {
			$instance = \XTS\Modules\Checkout_Order_Table::get_instance();
			if ( $instance ) {
				remove_action( 'woocommerce_review_order_before_cart_contents', array( $instance, 'checkout_table_content_replacement' ) );
			}
		}

		// Safety: if another callback hid native rows, restore default visibility.
		remove_filter( 'woocommerce_checkout_cart_item_visible', '__return_false' );
	}

	private function is_truthy_value( $value ) : bool {
		$normalized = strtolower( trim( (string) $value ) );
		return in_array( $normalized, array( '1', 'true', 'yes', 'on' ), true );
	}

	private function request_has_popup_context_flag() : bool {
		if ( isset( $_POST['pcs_popup_context'] ) && ! is_array( $_POST['pcs_popup_context'] ) ) {
			return $this->is_truthy_value( wp_unslash( $_POST['pcs_popup_context'] ) );
		}

		if ( isset( $_POST['post_data'] ) && ! is_array( $_POST['post_data'] ) ) {
			$parsed = array();
			parse_str( wp_unslash( $_POST['post_data'] ), $parsed );
			if ( isset( $parsed['pcs_popup_context'] ) ) {
				return $this->is_truthy_value( $parsed['pcs_popup_context'] );
			}
		}

		if ( isset( $_REQUEST['pcs_popup_context'] ) && ! is_array( $_REQUEST['pcs_popup_context'] ) ) {
			return $this->is_truthy_value( wp_unslash( $_REQUEST['pcs_popup_context'] ) );
		}

		return false;
	}

	private function is_popup_checkout_render_request() : bool {
		return ( defined( 'DOING_AJAX' ) && DOING_AJAX && $this->get_wc_ajax_action() === 'pcs_popup_checkout_form' );
	}

	private function is_popup_checkout_context() : bool {
		if ( ! PCS_License::is_active() ) return false;
		if ( $this->is_popup_checkout_render_request() ) return true;
		return $this->request_has_popup_context_flag();
	}

	private function get_popup_fallback_email( $phone = '' ) : string {
		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();
			if ( $user && ! empty( $user->user_email ) && is_email( $user->user_email ) ) {
				return $user->user_email;
			}
		}

		$digits = preg_replace( '/\D+/', '', (string) $phone );
		$suffix = $digits ? substr( $digits, -8 ) : wp_generate_password( 8, false, false );
		$admin_email = sanitize_email( (string) get_option( 'admin_email', '' ) );
		$email_domain = is_email( $admin_email ) ? substr( strrchr( $admin_email, '@' ), 1 ) : '';
		if ( '' === $email_domain ) {
			$email_domain = wp_parse_url( home_url(), PHP_URL_HOST );
		}
		$email_domain = preg_replace( '/[^a-z0-9\.\-]/i', '', (string) $email_domain );
		if ( '' === $email_domain ) {
			$email_domain = 'example.com';
		}
		$email  = 'guest-' . gmdate( 'YmdHis' ) . '-' . $suffix . '@' . $email_domain;
		return sanitize_email( $email );
	}

	private function get_popup_shipping_options() : array {
		$s = $this->get_settings();
		return array(
			'dhaka_city' => array(
				'label' => sanitize_text_field( $s['shipping_label_dhaka'] ?? 'ঢাকা সিটির ভিতরে' ),
				'cost'  => floatval( $s['shipping_charge_dhaka'] ?? 70 ),
			),
			'chattogram_city' => array(
				'label' => sanitize_text_field( $s['shipping_label_chattogram'] ?? 'চট্টগ্রাম সিটির ভিতরে' ),
				'cost'  => floatval( $s['shipping_charge_chattogram'] ?? 70 ),
			),
			'outside_city' => array(
				'label' => sanitize_text_field( $s['shipping_label_outside'] ?? 'ঢাকা সিটির বাইরে' ),
				'cost'  => floatval( $s['shipping_charge_outside'] ?? 170 ),
			),
		);
	}

	private function sanitize_popup_shipping_method_key( $value ) : string {
		$key = sanitize_key( (string) $value );
		$options = $this->get_popup_shipping_options();
		if ( isset( $options[ $key ] ) ) return $key;
		return '';
	}

	private function get_popup_selected_shipping_method() : string {
		$options = $this->get_popup_shipping_options();
		$keys    = array_keys( $options );
		$default = ! empty( $keys ) ? (string) $keys[0] : '';

		$candidates = array();

		if ( isset( $_POST['pcs_popup_shipping_method'] ) && ! is_array( $_POST['pcs_popup_shipping_method'] ) ) {
			$candidates[] = wp_unslash( $_POST['pcs_popup_shipping_method'] );
		}

		if ( isset( $_POST['post_data'] ) && ! is_array( $_POST['post_data'] ) ) {
			$parsed = array();
			parse_str( wp_unslash( $_POST['post_data'] ), $parsed );
			if ( isset( $parsed['pcs_popup_shipping_method'] ) ) {
				$candidates[] = $parsed['pcs_popup_shipping_method'];
			}
		}

		if ( isset( $_REQUEST['pcs_popup_shipping_method'] ) && ! is_array( $_REQUEST['pcs_popup_shipping_method'] ) ) {
			$candidates[] = wp_unslash( $_REQUEST['pcs_popup_shipping_method'] );
		}

		if ( function_exists( 'WC' ) && WC() && WC()->session ) {
			$session_value = WC()->session->get( 'pcs_popup_shipping_method' );
			if ( is_string( $session_value ) && '' !== $session_value ) {
				$candidates[] = $session_value;
			}
		}

		foreach ( $candidates as $candidate ) {
			$key = $this->sanitize_popup_shipping_method_key( $candidate );
			if ( '' !== $key ) return $key;
		}

		return $default;
	}

	public function capture_popup_shipping_selection( $posted_data ) {
		if ( ! is_string( $posted_data ) || '' === $posted_data ) return;

		$parsed = array();
		parse_str( $posted_data, $parsed );

		if ( empty( $parsed['pcs_popup_context'] ) ) return;
		if ( ! function_exists( 'WC' ) || ! WC() || ! WC()->session ) return;

		$selected = $this->sanitize_popup_shipping_method_key( $parsed['pcs_popup_shipping_method'] ?? '' );
		if ( '' === $selected ) {
			$selected = $this->get_popup_selected_shipping_method();
		}

		if ( '' !== $selected ) {
			WC()->session->set( 'pcs_popup_shipping_method', $selected );
		}
	}

	public function render_popup_shipping_methods() {
		if ( ! $this->is_popup_checkout_context() ) return;

		$s = $this->get_settings();
		$options  = $this->get_popup_shipping_options();
		$selected = $this->get_popup_selected_shipping_method();
		if ( '' === $selected ) return;
		$shipping_title = sanitize_text_field( $s['shipping_title'] ?? 'শিপিং মেথড' );
		if ( '' === $shipping_title ) $shipping_title = 'শিপিং মেথড';
		?>
		<div class="pcs-shipping-methods pcs-shipping-methods--custom">
			<h4 class="pcs-shipping-methods__title"><?php echo esc_html( $shipping_title ); ?></h4>
			<div class="pcs-shipping-methods__box">
				<ul id="shipping_method" class="pcs-shipping-options">
					<?php foreach ( $options as $key => $item ) : ?>
						<li>
							<label for="<?php echo esc_attr( 'pcs_popup_shipping_' . $key ); ?>">
								<input
									type="radio"
									name="pcs_popup_shipping_method"
									id="<?php echo esc_attr( 'pcs_popup_shipping_' . $key ); ?>"
									value="<?php echo esc_attr( $key ); ?>"
									<?php checked( $selected, $key ); ?>
								/>
								<span class="pcs-shipping-label"><?php echo esc_html( $item['label'] ); ?></span>
								<span class="pcs-shipping-price"><?php echo esc_html( sprintf( 'Tk %.2f', (float) $item['cost'] ) ); ?></span>
							</label>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
		<?php
	}

	public function apply_popup_shipping_fee( $cart ) {
		if ( ! $cart || ! is_a( $cart, 'WC_Cart' ) ) return;
		if ( is_admin() && ! wp_doing_ajax() ) return;
		if ( ! $this->is_popup_checkout_context() ) return;
		if ( $cart->is_empty() ) return;

		$options  = $this->get_popup_shipping_options();
		$selected = $this->get_popup_selected_shipping_method();
		if ( '' === $selected || ! isset( $options[ $selected ] ) ) return;

		$amount = floatval( $options[ $selected ]['cost'] ?? 0 );
		if ( $amount <= 0 ) return;

		$s = $this->get_settings();
		$fee_label = sanitize_text_field( $s['delivery_charge_label'] ?? 'ডেলিভারি চার্জ' );
		if ( '' === $fee_label ) $fee_label = 'ডেলিভারি চার্জ';
		$cart->add_fee( $fee_label, $amount, false );
	}

	public function output_popup_context_field() {
		if ( ! $this->is_popup_checkout_render_request() ) return;

		$base_country = '';
		$base_state   = '';
		if ( function_exists( 'WC' ) && WC() && isset( WC()->countries ) ) {
			$base_country = WC()->countries->get_base_country();
			$base_state   = WC()->countries->get_base_state();
		}

		echo '<input type="hidden" name="pcs_popup_context" value="1" />';
		echo '<input type="hidden" name="billing_email" value="' . esc_attr( $this->get_popup_fallback_email() ) . '" />';
		echo '<input type="hidden" name="billing_last_name" value="" />';
		echo '<input type="hidden" name="billing_city" value="N/A" />';
		echo '<input type="hidden" name="billing_postcode" value="0000" />';
		echo '<input type="hidden" name="billing_address_2" value="" />';

		if ( ! empty( $base_country ) ) {
			echo '<input type="hidden" name="billing_country" value="' . esc_attr( $base_country ) . '" />';
			echo '<input type="hidden" name="shipping_country" value="' . esc_attr( $base_country ) . '" />';
		}

		if ( ! empty( $base_state ) ) {
			echo '<input type="hidden" name="billing_state" value="' . esc_attr( $base_state ) . '" />';
			echo '<input type="hidden" name="shipping_state" value="' . esc_attr( $base_state ) . '" />';
		}
	}

	public function filter_popup_checkout_fields( $fields ) {
		if ( ! $this->is_popup_checkout_context() ) return $fields;
		$s = $this->get_settings();

		$billing_fields = isset( $fields['billing'] ) && is_array( $fields['billing'] ) ? $fields['billing'] : array();
		$order_fields   = isset( $fields['order'] ) && is_array( $fields['order'] ) ? $fields['order'] : array();

		$full_name = isset( $billing_fields['billing_first_name'] ) ? $billing_fields['billing_first_name'] : array();
		$address   = isset( $billing_fields['billing_address_1'] ) ? $billing_fields['billing_address_1'] : array();
		$phone     = isset( $billing_fields['billing_phone'] ) ? $billing_fields['billing_phone'] : array();

		$name_label       = sanitize_text_field( $s['field_label_name'] ?? 'আপনার নাম' );
		$name_placeholder = sanitize_text_field( $s['field_placeholder_name'] ?? $name_label );
		$phone_label       = sanitize_text_field( $s['field_label_phone'] ?? 'ফোন নাম্বার' );
		$phone_placeholder = sanitize_text_field( $s['field_placeholder_phone'] ?? $phone_label );
		$address_label       = sanitize_text_field( $s['field_label_address'] ?? 'এড্রেস' );
		$address_placeholder = sanitize_text_field( $s['field_placeholder_address'] ?? $address_label );

		if ( '' === $name_label ) $name_label = 'আপনার নাম';
		if ( '' === $name_placeholder ) $name_placeholder = $name_label;
		if ( '' === $phone_label ) $phone_label = 'ফোন নাম্বার';
		if ( '' === $phone_placeholder ) $phone_placeholder = $phone_label;
		if ( '' === $address_label ) $address_label = 'এড্রেস';
		if ( '' === $address_placeholder ) $address_placeholder = $address_label;

		$full_name['type']         = 'text';
		$full_name['label']        = $name_label;
		$full_name['placeholder']  = $name_placeholder;
		$full_name['required']     = true;
		$full_name['class']        = array( 'form-row-wide', 'pcs-row-name' );
		$full_name['priority']     = 10;
		$full_name['autocomplete'] = 'name';

		$phone['type']         = 'tel';
		$phone['label']        = $phone_label;
		$phone['placeholder']  = $phone_placeholder;
		$phone['required']     = true;
		$phone['class']        = array( 'form-row-wide', 'pcs-row-phone' );
		$phone['priority']     = 20;
		$phone['autocomplete'] = 'tel';

		$address['type']         = 'text';
		$address['label']        = $address_label;
		$address['placeholder']  = $address_placeholder;
		$address['required']     = true;
		$address['class']        = array( 'form-row-wide', 'pcs-row-address' );
		$address['priority']     = 30;
		$address['autocomplete'] = 'street-address';

		$fields['billing'] = array(
			'billing_first_name' => $full_name,
			'billing_phone'      => $phone,
			'billing_address_1'  => $address,
		);

		$fields['shipping'] = array();
		$fields['account']  = array();
		$fields['order']    = array();

		$order_note = array();
		if ( isset( $order_fields['order_comments'] ) && is_array( $order_fields['order_comments'] ) ) {
			$order_note = $order_fields['order_comments'];
		}

		if ( empty( $order_note ) ) {
			$order_note = array(
				'type'        => 'textarea',
				'class'       => array( 'form-row-wide', 'notes' ),
				'label'       => 'Order note',
				'placeholder' => 'Order note',
				'required'    => false,
				'priority'    => 10,
			);
		}

		$order_note['label']       = 'Order note';
		$order_note['placeholder'] = 'Order note';
		$order_note['required']    = false;
		$order_note['class']       = array( 'form-row-wide', 'notes' );
		$order_note['priority']    = 10;
		$fields['order']['order_comments'] = $order_note;

		return $fields;
	}

	public function normalize_popup_posted_data( $data ) {
		if ( ! $this->is_popup_checkout_context() ) return $data;

		$full_name = '';
		if ( isset( $data['billing_first_name'] ) ) {
			$full_name = wc_clean( $data['billing_first_name'] );
		}

		if ( empty( $data['billing_last_name'] ) && ! empty( $full_name ) ) {
			$data['billing_last_name'] = $full_name;
		}

			if ( empty( $data['billing_email'] ) ) {
				$data['billing_email'] = $this->get_popup_fallback_email( $data['billing_phone'] ?? '' );
			}

			if ( ! isset( $data['order_comments'] ) && isset( $_POST['order_comments'] ) && ! is_array( $_POST['order_comments'] ) ) {
				$data['order_comments'] = wc_clean( wp_unslash( $_POST['order_comments'] ) );
			}

		$base_country = '';
		$base_state   = '';
		if ( function_exists( 'WC' ) && WC() && isset( WC()->countries ) ) {
			$base_country = WC()->countries->get_base_country();
			$base_state   = WC()->countries->get_base_state();
		}

		if ( empty( $data['billing_country'] ) && ! empty( $base_country ) ) {
			$data['billing_country'] = $base_country;
		}
		if ( empty( $data['billing_state'] ) && ! empty( $base_state ) ) {
			$data['billing_state'] = $base_state;
		}
		if ( empty( $data['billing_city'] ) ) {
			$data['billing_city'] = 'N/A';
		}
		if ( empty( $data['billing_postcode'] ) ) {
			$data['billing_postcode'] = '0000';
		}

		$data['ship_to_different_address'] = 0;
		$data['shipping_first_name']       = $data['billing_first_name'] ?? '';
		$data['shipping_last_name']        = $data['billing_last_name'] ?? '';
		$data['shipping_address_1']        = $data['billing_address_1'] ?? '';
		$data['shipping_address_2']        = $data['billing_address_2'] ?? '';
		$data['shipping_city']             = $data['billing_city'] ?? 'N/A';
		$data['shipping_state']            = $data['billing_state'] ?? '';
		$data['shipping_postcode']         = $data['billing_postcode'] ?? '0000';
		$data['shipping_country']          = $data['billing_country'] ?? '';

		$selected_shipping = $this->sanitize_popup_shipping_method_key( $data['pcs_popup_shipping_method'] ?? '' );
		if ( '' === $selected_shipping ) {
			$selected_shipping = $this->get_popup_selected_shipping_method();
		}
		if ( '' !== $selected_shipping ) {
			$data['pcs_popup_shipping_method'] = $selected_shipping;
			if ( function_exists( 'WC' ) && WC() && WC()->session ) {
				WC()->session->set( 'pcs_popup_shipping_method', $selected_shipping );
			}
		}

		return $data;
	}

	public function filter_popup_shipping_address_requirement( $needs_shipping_address ) {
		if ( $this->is_popup_checkout_context() ) return false;
		return $needs_shipping_address;
	}

	public function filter_popup_cart_needs_shipping( $needs_shipping ) {
		if ( $this->is_popup_checkout_context() ) return false;
		return $needs_shipping;
	}

	public function filter_popup_checkout_fees( $fees, $cart = null ) {
		if ( ! $this->is_popup_checkout_context() ) return $fees;
		if ( ! is_array( $fees ) ) return $fees;

		$s = $this->get_settings();
		$popup_fee_label = sanitize_text_field( $s['delivery_charge_label'] ?? 'ডেলিভারি চার্জ' );
		if ( '' === $popup_fee_label ) {
			$popup_fee_label = 'ডেলিভারি চার্জ';
		}

		$popup_fee_label_normalized = $this->normalize_popup_fee_label( $popup_fee_label );
		$kept_popup_fee             = false;
		$filtered_fees              = array();

		foreach ( $fees as $fee_key => $fee_item ) {
			$fee_name = '';
			if ( is_object( $fee_item ) && isset( $fee_item->name ) ) {
				$fee_name = (string) $fee_item->name;
			} elseif ( is_array( $fee_item ) && isset( $fee_item['name'] ) ) {
				$fee_name = (string) $fee_item['name'];
			}

			$fee_name_normalized = $this->normalize_popup_fee_label( $fee_name );
			if ( '' !== $popup_fee_label_normalized && '' !== $fee_name_normalized && $fee_name_normalized === $popup_fee_label_normalized ) {
				if ( $kept_popup_fee ) {
					continue;
				}
				$kept_popup_fee = true;
				$filtered_fees[ $fee_key ] = $fee_item;
				continue;
			}

			if ( $this->is_popup_delivery_like_fee_label( $fee_name ) ) {
				continue;
			}

			$filtered_fees[ $fee_key ] = $fee_item;
		}

		return $filtered_fees;
	}

	public function filter_popup_order_notes_field( $enabled ) {
		if ( $this->is_popup_checkout_context() ) return true;
		return $enabled;
	}

	public function filter_popup_coupons_enabled( $enabled ) {
		if ( $this->is_popup_checkout_context() ) return true;
		return $enabled;
	}

	public function filter_popup_payment_gateways( $gateways ) {
		if ( ! $this->is_popup_checkout_context() ) return $gateways;
		if ( ! is_array( $gateways ) ) return $gateways;
		if ( isset( $gateways['cod'] ) ) {
			$ordered = array( 'cod' => $gateways['cod'] );
			foreach ( $gateways as $gateway_id => $gateway ) {
				if ( 'cod' === $gateway_id ) continue;
				$ordered[ $gateway_id ] = $gateway;
			}
			return $ordered;
		}
		return $gateways;
	}

	public function filter_popup_disable_woodmart_checkout_table( $condition ) {
		if ( $this->is_popup_checkout_context() ) {
			return false;
		}
		return $condition;
	}

	public function filter_popup_checkout_cart_item_name( $product_name, $cart_item, $cart_item_key ) {
		if ( ! $this->is_popup_checkout_context() ) return $product_name;
		if ( is_admin() && ! wp_doing_ajax() ) return $product_name;
		if ( ! $this->is_popup_checkout_render_request() && ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) ) {
			return $product_name;
		}

		$product = isset( $cart_item['data'] ) ? $cart_item['data'] : null;
		if ( ! $product || ! is_a( $product, 'WC_Product' ) ) return $product_name;

		$thumb_html = '';
		$image_id   = $product->get_image_id();
		if ( $image_id ) {
			$thumb_html = wp_get_attachment_image(
				$image_id,
				array( 34, 34 ),
				false,
				array(
					'class'   => 'pcs-review-thumb',
					'loading' => 'lazy',
					'alt'     => wp_strip_all_tags( $product->get_name() ),
					'style'   => 'width:34px;height:34px;object-fit:cover;border-radius:4px;display:block;',
				)
			);
		}
		if ( empty( $thumb_html ) ) {
			$thumb_html = '<span class="pcs-review-thumb pcs-review-thumb--placeholder" aria-hidden="true"></span>';
		}

		$name_text = wp_strip_all_tags( (string) $product->get_name() );
		$name_html = esc_html( $name_text );
		$qty       = isset( $cart_item['quantity'] ) ? max( 1, absint( $cart_item['quantity'] ) ) : 1;
		$key_attr  = esc_attr( (string) $cart_item_key );
		$remove_html = '<button type="button" class="pcs-review-product__btn pcs-review-product__btn--remove pcs-review-product__btn--remove-left" data-pcs-cart-action="remove" data-cart-item-key="' . $key_attr . '" aria-label="' . esc_attr__( 'Remove item', 'popup-checkout-subhan' ) . '">&times;</button>';

		$actions_html = '<span class="pcs-review-product__actions" data-cart-item-key="' . $key_attr . '">'
			. '<button type="button" class="pcs-review-product__btn pcs-review-product__btn--minus" data-pcs-cart-action="decrease" data-cart-item-key="' . $key_attr . '" aria-label="' . esc_attr__( 'Decrease quantity', 'popup-checkout-subhan' ) . '">-</button>'
			. '<span class="pcs-review-product__qty-value">' . esc_html( $qty ) . '</span>'
			. '<button type="button" class="pcs-review-product__btn pcs-review-product__btn--plus" data-pcs-cart-action="increase" data-cart-item-key="' . $key_attr . '" aria-label="' . esc_attr__( 'Increase quantity', 'popup-checkout-subhan' ) . '">+</button>'
			. '</span>';

		return '<span class="pcs-review-product">' . $remove_html . '<span class="pcs-review-product__thumb-wrap">' . $thumb_html . '<span class="pcs-review-product__qty">' . esc_html( $qty ) . '</span></span><span class="pcs-review-product__meta"><span class="pcs-review-product__name">' . $name_html . '</span>' . $actions_html . '</span></span>';
	}

	public function filter_popup_checkout_cart_item_subtotal( $subtotal, $cart_item, $cart_item_key ) {
		if ( ! $this->is_popup_checkout_context() ) return $subtotal;
		if ( is_admin() && ! wp_doing_ajax() ) return $subtotal;
		if ( ! $this->is_popup_checkout_render_request() && ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) ) {
			return $subtotal;
		}

		return '<span class="pcs-review-product__subtotal-wrap"><span class="pcs-review-product__subtotal-amount">' . $subtotal . '</span></span>';
	}

	public function filter_popup_checkout_cart_item_visible( $visible, $cart_item, $cart_item_key ) {
		if ( ! $this->is_popup_checkout_context() ) return $visible;
		if ( $this->is_popup_order_bump_cart_item( $cart_item ) ) return false;
		return $visible;
	}

	public function render_popup_order_bump_offer_row() {
		if ( ! $this->is_popup_checkout_context() ) return;
		$product = $this->get_popup_order_bump_product();
		if ( ! $product || ! is_a( $product, 'WC_Product' ) ) return;

		$product_id = absint( $product->get_id() );
		if ( ! $product_id ) return;

		$s = $this->get_settings();
		$badge_text = sanitize_text_field( $s['order_bump_badge_text'] ?? 'SPECIAL OFFER!' );
		$title_text = sanitize_text_field( $s['order_bump_title_text'] ?? 'Add {product} for just' );
		$note_text  = sanitize_text_field( $s['order_bump_note_text'] ?? '(এইটা ডেলিভারির সাথে পেয়ে যাবেন)' );
		if ( '' === $badge_text ) $badge_text = 'SPECIAL OFFER!';
		if ( '' === $title_text ) $title_text = 'Add {product} for just';

		$product_name = wp_strip_all_tags( (string) $product->get_name() );
		$title_text   = str_replace( '{product}', $product_name, $title_text );

		$display_price = wc_get_price_to_display( $product );
		$price_html    = wc_price( $display_price );
		$is_selected   = $this->is_popup_order_bump_selected( $product_id );

		$thumb_html = $product->get_image(
			array( 28, 28 ),
			array(
				'class'   => 'pcs-order-bump__thumb',
				'loading' => 'lazy',
				'alt'     => $product_name,
			)
		);
		if ( ! $thumb_html ) {
			$thumb_html = '<span class="pcs-order-bump__thumb pcs-order-bump__thumb--placeholder" aria-hidden="true"></span>';
		}
		?>
		<tr class="pcs-order-bump-row">
			<td colspan="2">
				<div class="pcs-order-bump" data-product-id="<?php echo esc_attr( $product_id ); ?>">
					<div class="pcs-order-bump__badge"><?php echo esc_html( $badge_text ); ?></div>
					<label class="pcs-order-bump__label" for="<?php echo esc_attr( 'pcs_order_bump_' . $product_id ); ?>">
						<input
							type="checkbox"
							class="pcs-order-bump__toggle"
							id="<?php echo esc_attr( 'pcs_order_bump_' . $product_id ); ?>"
							data-product-id="<?php echo esc_attr( $product_id ); ?>"
							<?php checked( $is_selected ); ?>
						/>
						<span class="pcs-order-bump__content">
							<span class="pcs-order-bump__thumb-wrap"><?php echo $thumb_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<span class="pcs-order-bump__copy">
								<span class="pcs-order-bump__title"><?php echo esc_html( $title_text ); ?></span>
								<span class="pcs-order-bump__price"><?php echo wp_kses_post( $price_html ); ?></span>
								<?php if ( '' !== $note_text ) : ?>
									<span class="pcs-order-bump__note"><?php echo esc_html( $note_text ); ?></span>
								<?php endif; ?>
							</span>
						</span>
					</label>
				</div>
			</td>
		</tr>
		<?php
	}

	public function filter_popup_registration_required( $required ) {
		if ( $this->is_popup_checkout_context() ) return false;
		return $required;
	}

	public function filter_popup_registration_enabled( $enabled ) {
		if ( $this->is_popup_checkout_context() ) return false;
		return $enabled;
	}

	public function mark_popup_order_meta( $order, $data ) {
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) return;
		if ( ! $this->is_popup_checkout_context() ) return;
		$order->update_meta_data( '_pcs_popup_checkout', '1' );
		$selected = $this->get_popup_selected_shipping_method();
		$options  = $this->get_popup_shipping_options();
		if ( '' !== $selected && isset( $options[ $selected ] ) ) {
			$order->update_meta_data( '_pcs_popup_shipping_method', $selected );
			$order->update_meta_data( '_pcs_popup_shipping_label', $options[ $selected ]['label'] );
			$order->update_meta_data( '_pcs_popup_shipping_cost', floatval( $options[ $selected ]['cost'] ) );
		}
	}

	public function mark_popup_order_meta_by_id( $order_id ) {
		if ( ! $this->is_popup_checkout_context() ) return;
		$order_id = absint( $order_id );
		if ( ! $order_id ) return;
		$order = wc_get_order( $order_id );
		if ( ! $order ) return;
		$order->update_meta_data( '_pcs_popup_checkout', '1' );
		$selected = $this->get_popup_selected_shipping_method();
		$options  = $this->get_popup_shipping_options();
		if ( '' !== $selected && isset( $options[ $selected ] ) ) {
			$order->update_meta_data( '_pcs_popup_shipping_method', $selected );
			$order->update_meta_data( '_pcs_popup_shipping_label', $options[ $selected ]['label'] );
			$order->update_meta_data( '_pcs_popup_shipping_cost', floatval( $options[ $selected ]['cost'] ) );
		}
		$order->save();
	}

	public function add_popup_flag_to_return_url( $return_url, $order ) {
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) return $return_url;
		if ( '1' !== (string) $order->get_meta( '_pcs_popup_checkout' ) ) return $return_url;
		return add_query_arg( 'pcs_popup', '1', $return_url );
	}

	private function get_current_order_received_order() {
		if ( ! function_exists( 'is_order_received_page' ) || ! is_order_received_page() ) return null;

		$order_id = absint( get_query_var( 'order-received' ) );

		if ( ! $order_id && isset( $_GET['order-received'] ) && ! is_array( $_GET['order-received'] ) ) {
			$order_id = absint( wp_unslash( $_GET['order-received'] ) );
		}

		if ( ! $order_id && isset( $_GET['key'] ) && ! is_array( $_GET['key'] ) ) {
			$order_key = wc_clean( wp_unslash( $_GET['key'] ) );
			if ( $order_key && function_exists( 'wc_get_order_id_by_order_key' ) ) {
				$order_id = absint( wc_get_order_id_by_order_key( $order_key ) );
			}
		}

		if ( ! $order_id ) return null;

		$order = wc_get_order( $order_id );
		if ( ! $order ) return null;

		return $order;
	}

	private function is_popup_order_received_page() : bool {
		if ( isset( $_GET['pcs_popup'] ) && ! is_array( $_GET['pcs_popup'] ) ) {
			if ( $this->is_truthy_value( wp_unslash( $_GET['pcs_popup'] ) ) ) return true;
		}

		if ( ! function_exists( 'is_order_received_page' ) || ! is_order_received_page() ) return false;

		$order = $this->get_current_order_received_order();
		if ( ! $order ) return false;

		return ( '1' === (string) $order->get_meta( '_pcs_popup_checkout' ) );
	}

	private function is_popup_thankyou_request() : bool {
		if ( isset( $_GET['pcs_popup'] ) && ! is_array( $_GET['pcs_popup'] ) ) {
			return $this->is_truthy_value( wp_unslash( $_GET['pcs_popup'] ) );
		}
		return $this->is_popup_order_received_page();
	}

	public function add_popup_order_body_class( $classes ) {
		if ( $this->is_popup_order_received_page() ) {
			$classes[] = 'pcs-popup-order-received';
		}
		return $classes;
	}

	// Default buttons are OFF by default (user wants Elementor widget)
	public function buy_now_button_single() {
		if ( ! PCS_License::is_active() ) return;
		$s = $this->get_settings();
		if ( empty($s['enable_default_btns']) ) return;
		global $product;
		if ( ! $product || ! is_a( $product, 'WC_Product' ) ) return;
		if ( ! $product->is_purchasable() || ! $product->is_in_stock() ) return;
		if ( ! $product->is_type( array( 'simple', 'variable' ) ) ) return;

		printf(
			'<button type="button" class="pcs-buy-now" data-product_id="%d" data-context="single" style="%s"><span class="pcs-btn__bolt">⚡</span><span class="pcs-btn__text">%s</span></button>',
			esc_attr( $product->get_id() ),
			esc_attr( $this->button_style_inline() ),
			esc_html( $s['button_text'] ?: 'Buy Now' )
		);
	}

	public function buy_now_button_loop() {
		if ( ! PCS_License::is_active() ) return;
		$s = $this->get_settings();
		if ( empty($s['enable_default_btns']) ) return;
		if ( empty($s['enable_on_shop']) ) return;

		global $product;
		if ( ! $product || ! is_a( $product, 'WC_Product' ) ) return;
		if ( ! $product->is_type( 'simple' ) || ! $product->is_purchasable() || ! $product->is_in_stock() ) return;
		printf(
			'<div class="pcs-loop-wrap"><button type="button" class="pcs-buy-now" data-product_id="%d" data-context="loop" style="%s"><span class="pcs-btn__bolt">⚡</span><span class="pcs-btn__text">%s</span></button></div>',
			esc_attr( $product->get_id() ),
			esc_attr( $this->button_style_inline() ),
			esc_html( $s['button_text'] ?: 'Buy Now' )
		);
	}

	/* ------------------------- AJAX (HTML response) ------------------------- */

	private function ajax_html_error( $message ) {
		echo '<div class="pcs-error" role="alert">' . esc_html( (string) $message ) . '</div>';
		wp_die();
	}

	public function ajax_popup_toggle_order_bump() {
		if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'WC' ) || ! WC() || ! WC()->cart ) {
			wp_send_json_error( array( 'message' => 'Cart unavailable.' ), 400 );
		}

		$nonce = '';
		if ( isset( $_POST['nonce'] ) && ! is_array( $_POST['nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );
		}
		if ( ! $nonce || ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			wp_send_json_error( array( 'message' => 'Security check failed.' ), 403 );
		}
		if ( ! PCS_License::is_active() ) {
			wp_send_json_error( array( 'message' => 'Please activate your Popup Checkout license.' ), 403 );
		}

		$product = $this->get_popup_order_bump_product();
		if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
			wp_send_json_error( array( 'message' => 'Order bump not configured.' ), 400 );
		}
		if ( ! $product->is_purchasable() || ! $product->is_in_stock() ) {
			wp_send_json_error( array( 'message' => 'Order bump product is unavailable.' ), 400 );
		}

		$configured_product_id = absint( $product->get_id() );
		$posted_product_id     = isset( $_POST['product_id'] ) && ! is_array( $_POST['product_id'] ) ? absint( wp_unslash( $_POST['product_id'] ) ) : 0;
		if ( $configured_product_id !== $posted_product_id ) {
			wp_send_json_error( array( 'message' => 'Invalid product.' ), 400 );
		}

		$enabled = false;
		if ( isset( $_POST['enabled'] ) && ! is_array( $_POST['enabled'] ) ) {
			$enabled = $this->is_truthy_value( wp_unslash( $_POST['enabled'] ) );
		}

		$existing_keys = $this->get_popup_order_bump_cart_item_keys( $configured_product_id );

		if ( $enabled ) {
			if ( empty( $existing_keys ) ) {
				$added_key = WC()->cart->add_to_cart(
					$configured_product_id,
					1,
					0,
					array(),
					array(
						'pcs_order_bump' => '1',
					)
				);
				if ( ! $added_key ) {
					wp_send_json_error( array( 'message' => 'Could not add bump product.' ), 400 );
				}
				$existing_keys = array( (string) $added_key );
			}

			$keep_key = array_shift( $existing_keys );
			if ( $keep_key ) {
				WC()->cart->set_quantity( $keep_key, 1, false );
			}
			foreach ( $existing_keys as $remove_key ) {
				WC()->cart->remove_cart_item( $remove_key );
			}
		} else {
			foreach ( $existing_keys as $remove_key ) {
				WC()->cart->remove_cart_item( $remove_key );
			}
		}

		WC()->cart->calculate_totals();

		wp_send_json_success(
			array(
				'selected'   => $this->is_popup_order_bump_selected( $configured_product_id ),
				'cart_count' => WC()->cart->get_cart_contents_count(),
			)
		);
	}

	public function ajax_popup_update_cart_item() {
		if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'WC' ) || ! WC() || ! WC()->cart ) {
			wp_send_json_error( array( 'message' => 'Cart unavailable.' ), 400 );
		}

		$nonce = '';
		if ( isset( $_POST['nonce'] ) && ! is_array( $_POST['nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );
		}
		if ( ! $nonce || ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			wp_send_json_error( array( 'message' => 'Security check failed.' ), 403 );
		}
		if ( ! PCS_License::is_active() ) {
			wp_send_json_error( array( 'message' => 'Please activate your Popup Checkout license.' ), 403 );
		}

		$cart_item_key = '';
		if ( isset( $_POST['cart_item_key'] ) && ! is_array( $_POST['cart_item_key'] ) ) {
			$cart_item_key = wc_clean( wp_unslash( $_POST['cart_item_key'] ) );
		}
		$pcs_action = '';
		if ( isset( $_POST['pcs_action'] ) && ! is_array( $_POST['pcs_action'] ) ) {
			$pcs_action = sanitize_key( wp_unslash( $_POST['pcs_action'] ) );
		}

		if ( '' === $cart_item_key || '' === $pcs_action ) {
			wp_send_json_error( array( 'message' => 'Invalid cart request.' ), 400 );
		}

		$cart_contents = WC()->cart->get_cart();
		if ( ! isset( $cart_contents[ $cart_item_key ] ) ) {
			wp_send_json_error( array( 'message' => 'Cart item not found.' ), 404 );
		}

		$item_product = isset( $cart_contents[ $cart_item_key ]['data'] ) && is_a( $cart_contents[ $cart_item_key ]['data'], 'WC_Product' )
			? $cart_contents[ $cart_item_key ]['data']
			: null;
		$current_qty = isset( $cart_contents[ $cart_item_key ]['quantity'] ) ? max( 1, absint( $cart_contents[ $cart_item_key ]['quantity'] ) ) : 1;
		$next_qty    = $current_qty;
		$updated     = true;

		if ( 'remove' === $pcs_action ) {
			WC()->cart->remove_cart_item( $cart_item_key );
			$next_qty = 0;
		} elseif ( 'increase' === $pcs_action ) {
			$next_qty = $current_qty + 1;
			$updated  = WC()->cart->set_quantity( $cart_item_key, $next_qty, false );
		} elseif ( 'decrease' === $pcs_action ) {
			$next_qty = max( 1, $current_qty - 1 );
			$updated  = WC()->cart->set_quantity( $cart_item_key, $next_qty, false );
		} elseif ( 'set' === $pcs_action ) {
			$posted_qty = isset( $_POST['qty'] ) && ! is_array( $_POST['qty'] ) ? absint( wp_unslash( $_POST['qty'] ) ) : $current_qty;
			$next_qty   = max( 1, $posted_qty );
			$updated    = WC()->cart->set_quantity( $cart_item_key, $next_qty, false );
		} else {
			wp_send_json_error( array( 'message' => 'Invalid action.' ), 400 );
		}

		if ( $item_product && $next_qty > 0 ) {
			$maximum = (int) $item_product->get_max_purchase_quantity();
			if ( ( $item_product->is_sold_individually() && $next_qty > 1 ) || ( $maximum > 0 && $next_qty > $maximum ) ) {
				WC()->cart->set_quantity( $cart_item_key, $current_qty, false );
				wp_send_json_error( array( 'message' => 'This quantity is not available for the product.' ), 400 );
			}
		}

		if ( false === $updated ) {
			wp_send_json_error( array( 'message' => 'The cart quantity could not be updated.' ), 400 );
		}

		WC()->cart->calculate_totals();

		wp_send_json_success(
			array(
				'cart_count' => WC()->cart->get_cart_contents_count(),
				'item_qty'   => $next_qty,
			)
		);
	}

	public function ajax_checkout_form() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			$this->ajax_html_error( __( 'WooCommerce is not active.', 'popup-checkout-subhan' ) );
		}

		$nonce = '';
		if ( isset( $_POST['nonce'] ) && ! is_array( $_POST['nonce'] ) ) {
			$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );
		}
		if ( '' === $nonce || ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			$this->ajax_html_error( __( 'Security check failed. Refresh the page and try again.', 'popup-checkout-subhan' ) );
		}
		if ( ! PCS_License::is_active() ) {
			$this->ajax_html_error( __( 'Please activate your Popup Checkout license.', 'popup-checkout-subhan' ) );
		}

		$product_id   = isset( $_POST['product_id'] ) && ! is_array( $_POST['product_id'] ) ? absint( wp_unslash( $_POST['product_id'] ) ) : 0;
		$variation_id = isset( $_POST['variation_id'] ) && ! is_array( $_POST['variation_id'] ) ? absint( wp_unslash( $_POST['variation_id'] ) ) : 0;
		$variation    = isset( $_POST['variation'] ) && is_array( $_POST['variation'] ) ? wp_unslash( $_POST['variation'] ) : array();

		$clean_variation = array();
		foreach ( $variation as $k => $v ) {
			$key = wc_clean( (string) $k );
			if ( '' === $key ) continue;
			$clean_variation[ $key ] = wc_clean( (string) $v );
		}

		if ( ! function_exists( 'WC' ) || ! WC() || ! WC()->cart ) {
			$this->ajax_html_error( __( 'The WooCommerce cart is unavailable. Refresh the page and try again.', 'popup-checkout-subhan' ) );
		}

		if ( ! $product_id ) {
			$this->ajax_html_error( __( 'Product not found.', 'popup-checkout-subhan' ) );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || ! is_a( $product, 'WC_Product' ) || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
			$this->ajax_html_error( __( 'This product is not available for purchase.', 'popup-checkout-subhan' ) );
		}

		if ( ! $product->is_type( array( 'simple', 'variable' ) ) ) {
			$this->ajax_html_error( __( 'This product type cannot use popup checkout.', 'popup-checkout-subhan' ) );
		}

		if ( $product->is_type( 'variable' ) && ! $variation_id ) {
			$this->ajax_html_error( __( 'Please choose the product options before opening checkout.', 'popup-checkout-subhan' ) );
		}

		if ( $product_id && $variation_id ) {
			$variation_product = wc_get_product( $variation_id );
			if (
				! $variation_product
				|| ! is_a( $variation_product, 'WC_Product_Variation' )
				|| absint( $variation_product->get_parent_id() ) !== $product_id
				|| ! $variation_product->is_purchasable()
				|| ! $variation_product->is_in_stock()
			) {
				$this->ajax_html_error( __( 'The selected product variation is unavailable.', 'popup-checkout-subhan' ) );
			}
		}

		// Always ensure clicked product exists in cart (without duplicate auto-add).
		try {
			$existing_key = $this->find_existing_popup_cart_item_key( $product_id, $variation_id, $clean_variation );
			if ( '' === $existing_key ) {
				$added_key = $variation_id
					? WC()->cart->add_to_cart( $product_id, 1, $variation_id, $clean_variation )
					: WC()->cart->add_to_cart( $product_id, 1 );
				if ( ! $added_key ) {
					$this->ajax_html_error( __( 'The product could not be added to the cart.', 'popup-checkout-subhan' ) );
				}
			}
		} catch ( Throwable $error ) {
			$this->ajax_html_error( __( 'The product could not be prepared for checkout.', 'popup-checkout-subhan' ) );
		}

		WC()->cart->calculate_totals();

		// Output HTML directly (avoids JSON break by notices)
		ob_start();
		echo '<div class="pcs-checkout-wrap">';
		echo do_shortcode('[woocommerce_checkout]');
		echo '</div>';
		$html = ob_get_clean();

		if ( empty($html) ) {
			$html = '<div class="pcs-error">Checkout form not loaded. Please ensure WooCommerce checkout page is configured.</div>';
		}

		echo $html;
		wp_die();
	}

	/* ------------------------- Admin UI ------------------------- */

	public function add_settings_page() {
		add_menu_page(
			'Popup Checkout by Borbila',
			'Popup Checkout',
			'manage_options',
			'pcs-popup-checkout',
			array( $this, 'settings_page_html' ),
			'dashicons-cart',
			58
		);
	}

	public function register_settings() {
		register_setting( 'pcs_popup_checkout_group', self::OPT_KEY, array( $this, 'sanitize_settings' ) );
	}

	public static function activate_plugin() {
		PCS_License::maybe_add_default();
		PCS_License::ensure_validation_schedule();

		if ( false === get_option( self::OPT_KEY, false ) ) {
			update_option( self::OPT_KEY, array(), false );
		}
	}

	public static function deactivate_plugin() {
		PCS_License::unschedule_validation();
	}

	public function woocommerce_dependency_notice() {
		if ( class_exists( 'WooCommerce' ) || ! current_user_can( 'activate_plugins' ) ) return;
		?>
		<div class="notice notice-error"><p><?php esc_html_e( 'Popup Checkout requires WooCommerce to be installed and active.', 'popup-checkout-subhan' ); ?></p></div>
		<?php
	}

	private function get_public_license_data( $license = null ) : array {
		$license = is_array( $license ) ? wp_parse_args( $license, PCS_License::get_default_license() ) : PCS_License::get_license();
		$is_active = PCS_License::is_active();

		return array(
			'is_active'        => $is_active,
			'status'           => sanitize_key( $license['status'] ),
			'status_label'     => $is_active ? __( 'Active', 'popup-checkout-subhan' ) : __( 'Inactive', 'popup-checkout-subhan' ),
			'masked_key'       => PCS_License::mask_license_key( $license['license_key'] ),
			'activated_domain' => '' !== $license['activated_domain'] ? sanitize_text_field( $license['activated_domain'] ) : __( 'Not activated', 'popup-checkout-subhan' ),
			'last_checked'     => '' !== $license['last_checked'] ? sanitize_text_field( $license['last_checked'] ) : __( 'Never', 'popup-checkout-subhan' ),
			'validity'         => __( 'Lifetime', 'popup-checkout-subhan' ),
		);
	}

	private function set_license_notice( $success, $message ) {
		set_transient(
			'pcs_license_notice_' . get_current_user_id(),
			array(
				'success' => (bool) $success,
				'message' => sanitize_text_field( (string) $message ),
			),
			MINUTE_IN_SECONDS
		);
	}

	private function pop_license_notice() : array {
		$key    = 'pcs_license_notice_' . get_current_user_id();
		$notice = get_transient( $key );
		delete_transient( $key );
		return is_array( $notice ) ? $notice : array();
	}

	private function get_posted_license_key() : string {
		if ( isset( $_POST['pcs_license_key'] ) && is_scalar( $_POST['pcs_license_key'] ) ) {
			return sanitize_text_field( wp_unslash( $_POST['pcs_license_key'] ) );
		}

		if ( isset( $_POST['pcs_license_key_encoded'] ) && is_scalar( $_POST['pcs_license_key_encoded'] ) ) {
			$encoded = sanitize_text_field( wp_unslash( $_POST['pcs_license_key_encoded'] ) );
			$decoded = base64_decode( $encoded, true );
			return false !== $decoded ? sanitize_text_field( $decoded ) : '';
		}

		return '';
	}

	public function handle_license_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage this license.', 'popup-checkout-subhan' ) );
		}

		check_admin_referer( 'pcs_license_action', 'pcs_license_action_nonce' );
		$operation = isset( $_POST['license_operation'] ) ? sanitize_key( wp_unslash( $_POST['license_operation'] ) ) : '';
		$result = 'activate' === $operation
			? PCS_License::activate_license( $this->get_posted_license_key() )
			: ( 'deactivate' === $operation ? PCS_License::deactivate_license() : array( 'success' => false, 'message' => __( 'Invalid license action.', 'popup-checkout-subhan' ) ) );

		$this->set_license_notice( ! empty( $result['success'] ), $result['message'] ?? __( 'License action failed.', 'popup-checkout-subhan' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=pcs-popup-checkout#tab-license' ) );
		exit;
	}

	private function verify_license_ajax_request() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to manage this license.', 'popup-checkout-subhan' ) ), 403 );
		}
		if ( ! check_ajax_referer( 'pcs_license_nonce', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed. Refresh the page and try again.', 'popup-checkout-subhan' ) ), 403 );
		}
	}

	public function ajax_activate_license() {
		$this->verify_license_ajax_request();
		$result  = PCS_License::activate_license( $this->get_posted_license_key() );
		$license = isset( $result['license'] ) && is_array( $result['license'] ) ? $result['license'] : PCS_License::get_license();
		$payload = array(
			'message' => sanitize_text_field( $result['message'] ?? '' ),
			'license' => $this->get_public_license_data( $license ),
		);

		if ( ! empty( $result['success'] ) ) {
			wp_send_json_success( $payload );
		}
		wp_send_json_error( $payload, 400 );
	}

	public function ajax_deactivate_license() {
		$this->verify_license_ajax_request();
		$result  = PCS_License::deactivate_license();
		$license = isset( $result['license'] ) && is_array( $result['license'] ) ? $result['license'] : PCS_License::get_license();
		$payload = array(
			'message' => sanitize_text_field( $result['message'] ?? '' ),
			'license' => $this->get_public_license_data( $license ),
		);

		if ( ! empty( $result['success'] ) ) {
			wp_send_json_success( $payload );
		}
		wp_send_json_error( $payload, 400 );
	}

	public function ajax_save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to save these settings.', 'popup-checkout-subhan' ) ), 403 );
		}
		if ( ! check_ajax_referer( 'pcs_save_settings_nonce', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Security check failed. Refresh the page and try again.', 'popup-checkout-subhan' ) ), 403 );
		}

		$encoded = isset( $_POST['payload'] ) && is_scalar( $_POST['payload'] ) ? (string) wp_unslash( $_POST['payload'] ) : '';
		if ( '' === $encoded || strlen( $encoded ) > 300000 ) {
			wp_send_json_error( array( 'message' => __( 'The settings payload is invalid.', 'popup-checkout-subhan' ) ), 400 );
		}

		$decoded = base64_decode( $encoded, true );
		$data    = false !== $decoded ? json_decode( $decoded, true ) : null;
		if ( ! is_array( $data ) ) {
			wp_send_json_error( array( 'message' => __( 'The settings payload could not be read.', 'popup-checkout-subhan' ) ), 400 );
		}

		$sanitized = $this->sanitize_settings( $data );
		update_option( self::OPT_KEY, $sanitized, false );
		$stored = get_option( self::OPT_KEY, array() );
		if ( ! is_array( $stored ) || serialize( $stored ) !== serialize( $sanitized ) ) {
			wp_send_json_error( array( 'message' => __( 'WordPress could not verify the saved settings.', 'popup-checkout-subhan' ) ), 500 );
		}

		wp_send_json_success(
			array(
				'message' => __( 'Settings saved successfully.', 'popup-checkout-subhan' ),
				'settings' => $sanitized,
			)
		);
	}

	public function admin_enqueue_assets( $hook ) {
		if ( $hook !== 'toplevel_page_pcs-popup-checkout' ) return;

		wp_enqueue_style(
			'pcs-popup-checkout-admin-style',
			plugin_dir_url(__FILE__) . 'assets/admin-style.css',
			array(),
			filemtime( plugin_dir_path(__FILE__) . 'assets/admin-style.css' )
		);
		wp_enqueue_script(
			'pcs-popup-checkout-admin-script',
			plugin_dir_url(__FILE__) . 'assets/admin-script.js',
			array('jquery'),
			filemtime( plugin_dir_path(__FILE__) . 'assets/admin-script.js' ),
			true
		);

		wp_localize_script(
			'pcs-popup-checkout-admin-script',
			'pcsPopupAdmin',
			array(
				'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
				'saveNonce'     => wp_create_nonce( 'pcs_save_settings_nonce' ),
				'licenseNonce'  => wp_create_nonce( 'pcs_license_nonce' ),
				'licenseActive' => PCS_License::is_active(),
				'getLicenseUrl' => 'https://borbila.com/my-account/licenses/',
				'messages'      => array(
					'licenseRequired' => __( 'Please activate your license to enable Popup Checkout features.', 'popup-checkout-subhan' ),
					'saveFailed'      => __( 'Settings could not be saved. Please try again.', 'popup-checkout-subhan' ),
					'networkError'    => __( 'The request was blocked or interrupted. Trying the safe fallback…', 'popup-checkout-subhan' ),
				),
			)
		);
	}

	public function admin_enqueue_codemirror( $hook ) {
		if ( $hook !== 'toplevel_page_pcs-popup-checkout' ) return;
		wp_enqueue_code_editor( array( 'type' => 'text/css' ) );
		wp_enqueue_script( 'wp-theme-plugin-editor' );
		wp_enqueue_style( 'wp-codemirror' );
		add_action( 'admin_footer', function() {
			?>
			<script>
			jQuery(function($){
				if (typeof wp !== 'undefined' && wp.codeEditor) {
					wp.codeEditor.initialize('pcs_custom_css', { type: 'text/css' });
				}
			});
			</script>
			<?php
		});
	}

	public function plugin_action_links( $links ) {
		$url = admin_url('admin.php?page=pcs-popup-checkout');
		$settings_link = '<a href="' . esc_url($url) . '">Settings</a>';
		$license_link = '<a href="' . esc_url( $url . '#tab-license' ) . '">License</a>';
		array_unshift( $links, $settings_link, $license_link );
		return $links;
	}

	public function settings_page_html() {
		if ( ! current_user_can('manage_options') ) return;
		$s = $this->get_settings();
		$order_bump_products = $this->get_order_bump_product_options_for_admin();
		$license = PCS_License::get_license();
		$license_active = PCS_License::is_active();
		$license_key_value = PCS_License::mask_license_key( $license['license_key'] );
		$license_notice = $this->pop_license_notice();
		?>
		<div class="pcs-admin <?php echo $license_active ? 'is-licensed' : 'is-unlicensed'; ?>">
			<header class="pcs-admin-top">
				<div class="pcs-admin-top__brand">
					<span class="pcs-admin-top__logo dashicons dashicons-cart" aria-hidden="true"></span>
					<div class="pcs-admin-top__left">
						<span class="pcs-admin-top__eyebrow">BORBILA COMMERCE TOOLS</span>
						<h1>Popup Checkout</h1>
						<p>Build a faster, cleaner checkout experience without sending customers to another page.</p>
					</div>
				</div>
				<div class="pcs-admin-top__right">
					<button type="button" class="pcs-license-chip <?php echo $license_active ? 'is-active' : 'is-inactive'; ?>" data-pcs-open-tab="license">
						<span class="dashicons <?php echo $license_active ? 'dashicons-yes-alt' : 'dashicons-lock'; ?>" aria-hidden="true"></span>
						<span id="pcs-header-license-label"><?php echo $license_active ? esc_html__( 'Licensed', 'popup-checkout-subhan' ) : esc_html__( 'License required', 'popup-checkout-subhan' ); ?></span>
					</button>
					<a href="https://borbila.com" target="_blank" rel="noopener" class="pcs-admin-top__link">
						<span class="dashicons dashicons-admin-site-alt3" aria-hidden="true"></span>
						<span>Borbila</span>
					</a>
				</div>
			</header>

			<div class="pcs-admin-workspace">
			<div class="pcs-tabs" role="tablist" aria-label="Popup Checkout Settings Sections">
				<div class="pcs-tabs__label">CUSTOMIZE</div>
				<button type="button" class="pcs-tab is-active" role="tab" aria-selected="true" data-tab="general">
					<span class="dashicons dashicons-admin-generic" aria-hidden="true"></span>
					<span><strong>General</strong><small>Core checkout controls</small></span>
				</button>
				<button type="button" class="pcs-tab" role="tab" aria-selected="false" data-tab="button-style">
					<span class="dashicons dashicons-button" aria-hidden="true"></span>
					<span><strong>Buy Now Button</strong><small>Text, size and colors</small></span>
				</button>
				<button type="button" class="pcs-tab" role="tab" aria-selected="false" data-tab="popup-design">
					<span class="dashicons dashicons-art" aria-hidden="true"></span>
					<span><strong>Popup Design</strong><small>Brand and content style</small></span>
				</button>
				<button type="button" class="pcs-tab" role="tab" aria-selected="false" data-tab="shipping">
					<span class="dashicons dashicons-location" aria-hidden="true"></span>
					<span><strong>Shipping</strong><small>Areas, labels and charges</small></span>
				</button>
				<button type="button" class="pcs-tab" role="tab" aria-selected="false" data-tab="order-bump">
					<span class="dashicons dashicons-cart" aria-hidden="true"></span>
					<span><strong>Order Bump</strong><small>One-click extra offer</small></span>
				</button>
				<button type="button" class="pcs-tab" role="tab" aria-selected="false" data-tab="custom-css">
					<span class="dashicons dashicons-editor-code" aria-hidden="true"></span>
					<span><strong>Custom CSS</strong><small>Advanced adjustments</small></span>
				</button>
				<button type="button" class="pcs-tab pcs-tab--license" role="tab" aria-selected="false" data-tab="license">
					<span class="dashicons dashicons-admin-network" aria-hidden="true"></span>
					<span><strong>License</strong><small id="pcs-sidebar-license-label"><?php echo $license_active ? esc_html__( 'Active · Lifetime', 'popup-checkout-subhan' ) : esc_html__( 'Activation required', 'popup-checkout-subhan' ); ?></small></span>
				</button>
			</div>

			<form method="post" action="options.php" class="pcs-admin__form" id="pcs-admin-settings-form" data-license-active="<?php echo $license_active ? 'yes' : 'no'; ?>">
				<?php settings_fields( 'pcs_popup_checkout_group' ); ?>
				<div class="pcs-license-warning <?php echo $license_active ? 'is-hidden' : ''; ?>" id="pcs-license-warning">
					<span class="dashicons dashicons-lock" aria-hidden="true"></span>
					<div><strong>Activate Popup Checkout</strong><span>Your design is safe, but storefront features stay paused until the license is active.</span></div>
					<button type="button" class="button" data-pcs-open-tab="license">Activate license</button>
				</div>

				<section class="pcs-tab-panel is-active" data-tab-panel="general">
					<div class="pcs-card">
						<div class="pcs-card__head">
							<span class="pcs-card__icon dashicons dashicons-admin-settings" aria-hidden="true"></span>
							<div>
								<h2>General Settings</h2>
								<p>Control plugin behavior and core checkout actions.</p>
							</div>
						</div>
						<div class="pcs-form-grid">
							<label class="pcs-field pcs-field--checkbox <?php echo ! $license_active ? 'is-license-locked' : ''; ?>" data-license-locked="yes">
								<span class="pcs-field__label">Enable default buttons (Woo templates)</span>
								<input type="checkbox" name="<?php echo esc_attr(self::OPT_KEY); ?>[enable_default_btns]" value="1" <?php checked( 1, $s['enable_default_btns'] ); ?> <?php disabled( ! $license_active ); ?>>
								<span class="pcs-field__lock dashicons dashicons-lock" aria-hidden="true"></span>
								<span class="pcs-field__hint">Keep this on if you want automatic buttons in theme product templates.</span>
							</label>
							<label class="pcs-field pcs-field--checkbox <?php echo ! $license_active ? 'is-license-locked' : ''; ?>" data-license-locked="yes">
								<span class="pcs-field__label">Show on Shop/Archive (default buttons)</span>
								<input type="checkbox" name="<?php echo esc_attr(self::OPT_KEY); ?>[enable_on_shop]" value="1" <?php checked( 1, $s['enable_on_shop'] ); ?> <?php disabled( ! $license_active ); ?>>
								<span class="pcs-field__lock dashicons dashicons-lock" aria-hidden="true"></span>
								<span class="pcs-field__hint">When enabled, default loop button appears on shop and archive pages.</span>
							</label>
							<label class="pcs-field pcs-field--checkbox">
								<span class="pcs-field__label">Loading animation</span>
								<input type="checkbox" name="<?php echo esc_attr(self::OPT_KEY); ?>[loading_animation]" value="1" <?php checked( 1, $s['loading_animation'] ); ?>>
								<span class="pcs-field__hint">Shows loader skeleton while popup checkout form loads.</span>
							</label>
							<label class="pcs-field pcs-field--checkbox">
								<span class="pcs-field__label">Fixed “Place order” button</span>
								<input type="checkbox" name="<?php echo esc_attr(self::OPT_KEY); ?>[fixed_place_order]" value="1" <?php checked( 1, $s['fixed_place_order'] ); ?>>
								<span class="pcs-field__hint">Keeps order button pinned for faster checkout completion.</span>
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Place order button text</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[order_btn_text]" value="<?php echo esc_attr($s['order_btn_text']); ?>">
							</label>
						</div>
					</div>
				</section>

				<section class="pcs-tab-panel" data-tab-panel="button-style">
					<div class="pcs-card">
						<div class="pcs-card__head">
							<span class="pcs-card__icon dashicons dashicons-button" aria-hidden="true"></span>
							<div>
								<h2>Button Style</h2>
								<p>Style your frontend Buy Now button consistently.</p>
							</div>
						</div>
						<div class="pcs-form-grid">
							<label class="pcs-field">
								<span class="pcs-field__label">Button text</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[button_text]" value="<?php echo esc_attr($s['button_text']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Button background</span>
								<input type="color" name="<?php echo esc_attr(self::OPT_KEY); ?>[button_bg]" value="<?php echo esc_attr($s['button_bg']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Button text color</span>
								<input type="color" name="<?php echo esc_attr(self::OPT_KEY); ?>[button_text_color]" value="<?php echo esc_attr($s['button_text_color']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Button radius (px)</span>
								<input type="number" min="0" name="<?php echo esc_attr(self::OPT_KEY); ?>[button_radius]" value="<?php echo esc_attr($s['button_radius']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Font size (px)</span>
								<input type="number" min="10" name="<?php echo esc_attr(self::OPT_KEY); ?>[button_font_size]" value="<?php echo esc_attr($s['button_font_size']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Padding Y (px)</span>
								<input type="number" min="6" name="<?php echo esc_attr(self::OPT_KEY); ?>[button_padding_y]" value="<?php echo esc_attr($s['button_padding_y']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Padding X (px)</span>
								<input type="number" min="10" name="<?php echo esc_attr(self::OPT_KEY); ?>[button_padding_x]" value="<?php echo esc_attr($s['button_padding_x']); ?>">
							</label>
						</div>
						<div class="pcs-preview">
							<span class="pcs-preview__label">Live Preview</span>
							<button type="button" class="pcs-preview__btn" style="<?php echo esc_attr($this->button_style_inline()); ?>">
								<span>⚡</span><span class="pcs-btn__text"><?php echo esc_html($s['button_text']); ?></span>
							</button>
						</div>
					</div>
				</section>

				<section class="pcs-tab-panel" data-tab-panel="popup-design">
					<div class="pcs-card">
						<div class="pcs-card__head">
							<span class="pcs-card__icon dashicons dashicons-admin-customizer" aria-hidden="true"></span>
							<div>
								<h2>Popup Design</h2>
								<p>Set global colors, typography, and title text for popup checkout.</p>
							</div>
						</div>
						<div class="pcs-form-grid">
							<label class="pcs-field">
								<span class="pcs-field__label">Primary color (main accent)</span>
								<input type="color" name="<?php echo esc_attr(self::OPT_KEY); ?>[primary_color]" value="<?php echo esc_attr( $s['primary_color'] ?? '#f7a200' ); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Popup content text color</span>
								<input type="color" name="<?php echo esc_attr(self::OPT_KEY); ?>[content_text_color]" value="<?php echo esc_attr($s['content_text_color']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Popup content font size (px)</span>
								<input type="number" min="12" max="22" name="<?php echo esc_attr(self::OPT_KEY); ?>[content_font_size]" value="<?php echo esc_attr($s['content_font_size']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Popup title line 1</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[popup_title_line_1]" value="<?php echo esc_attr($s['popup_title_line_1']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Popup title line 2</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[popup_title_line_2]" value="<?php echo esc_attr($s['popup_title_line_2']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Name label</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[field_label_name]" value="<?php echo esc_attr($s['field_label_name']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Name placeholder</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[field_placeholder_name]" value="<?php echo esc_attr($s['field_placeholder_name']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Phone label</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[field_label_phone]" value="<?php echo esc_attr($s['field_label_phone']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Phone placeholder</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[field_placeholder_phone]" value="<?php echo esc_attr($s['field_placeholder_phone']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Address label</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[field_label_address]" value="<?php echo esc_attr($s['field_label_address']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Address placeholder</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[field_placeholder_address]" value="<?php echo esc_attr($s['field_placeholder_address']); ?>">
							</label>
						</div>

						<details class="pcs-accordion" id="pcs-theme-colors">
							<summary>
								<span>Advanced Design Colors</span>
								<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
							</summary>
							<div class="pcs-form-grid">
								<label class="pcs-field">
									<span class="pcs-field__label">Accent color</span>
									<input type="color" name="<?php echo esc_attr(self::OPT_KEY); ?>[theme_accent_color]" value="<?php echo esc_attr($s['theme_accent_color']); ?>">
								</label>
								<label class="pcs-field">
									<span class="pcs-field__label">Header gradient start</span>
									<input type="color" name="<?php echo esc_attr(self::OPT_KEY); ?>[theme_header_start]" value="<?php echo esc_attr($s['theme_header_start']); ?>">
								</label>
								<label class="pcs-field">
									<span class="pcs-field__label">Header gradient end</span>
									<input type="color" name="<?php echo esc_attr(self::OPT_KEY); ?>[theme_header_end]" value="<?php echo esc_attr($s['theme_header_end']); ?>">
								</label>
								<label class="pcs-field">
									<span class="pcs-field__label">Button gradient start</span>
									<input type="color" name="<?php echo esc_attr(self::OPT_KEY); ?>[theme_button_start]" value="<?php echo esc_attr($s['theme_button_start']); ?>">
								</label>
								<label class="pcs-field">
									<span class="pcs-field__label">Button gradient end</span>
									<input type="color" name="<?php echo esc_attr(self::OPT_KEY); ?>[theme_button_end]" value="<?php echo esc_attr($s['theme_button_end']); ?>">
								</label>
								<label class="pcs-field">
									<span class="pcs-field__label">Overlay start</span>
									<input type="color" name="<?php echo esc_attr(self::OPT_KEY); ?>[theme_overlay_start]" value="<?php echo esc_attr($s['theme_overlay_start']); ?>">
								</label>
								<label class="pcs-field">
									<span class="pcs-field__label">Overlay end</span>
									<input type="color" name="<?php echo esc_attr(self::OPT_KEY); ?>[theme_overlay_end]" value="<?php echo esc_attr($s['theme_overlay_end']); ?>">
								</label>
								<label class="pcs-field">
									<span class="pcs-field__label">Backdrop blur (px)</span>
									<input type="number" min="0" max="3" name="<?php echo esc_attr(self::OPT_KEY); ?>[theme_backdrop_blur]" value="<?php echo esc_attr($s['theme_backdrop_blur']); ?>">
								</label>
							</div>
						</details>
					</div>
				</section>

				<section class="pcs-tab-panel" data-tab-panel="shipping" id="pcs-content-shipping-settings">
					<div class="pcs-card">
						<div class="pcs-card__head">
							<span class="pcs-card__icon dashicons dashicons-location-alt" aria-hidden="true"></span>
							<div>
								<h2>Shipping Settings</h2>
								<p>Configure shipping labels, charges, and coupon input labels for popup checkout.</p>
							</div>
						</div>
						<div class="pcs-form-grid">
							<label class="pcs-field">
								<span class="pcs-field__label">Shipping section title</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[shipping_title]" value="<?php echo esc_attr($s['shipping_title']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Delivery charge label</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[delivery_charge_label]" value="<?php echo esc_attr($s['delivery_charge_label']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Shipping charge: Dhaka city (Tk)</span>
								<input type="number" min="0" step="0.01" name="<?php echo esc_attr(self::OPT_KEY); ?>[shipping_charge_dhaka]" value="<?php echo esc_attr($s['shipping_charge_dhaka']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Shipping charge: Chattogram city (Tk)</span>
								<input type="number" min="0" step="0.01" name="<?php echo esc_attr(self::OPT_KEY); ?>[shipping_charge_chattogram]" value="<?php echo esc_attr($s['shipping_charge_chattogram']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Shipping charge: Outside city (Tk)</span>
								<input type="number" min="0" step="0.01" name="<?php echo esc_attr(self::OPT_KEY); ?>[shipping_charge_outside]" value="<?php echo esc_attr($s['shipping_charge_outside']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Coupon placeholder</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[coupon_placeholder_text]" value="<?php echo esc_attr($s['coupon_placeholder_text']); ?>">
							</label>
							<label class="pcs-field">
								<span class="pcs-field__label">Coupon button text</span>
								<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[coupon_apply_text]" value="<?php echo esc_attr($s['coupon_apply_text']); ?>">
							</label>
						</div>

						<details class="pcs-accordion">
							<summary>
								<span>Advanced Shipping Labels</span>
								<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
							</summary>
							<div class="pcs-form-grid">
								<label class="pcs-field">
									<span class="pcs-field__label">Shipping label: Dhaka city</span>
									<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[shipping_label_dhaka]" value="<?php echo esc_attr($s['shipping_label_dhaka']); ?>">
								</label>
								<label class="pcs-field">
									<span class="pcs-field__label">Shipping label: Chattogram city</span>
									<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[shipping_label_chattogram]" value="<?php echo esc_attr($s['shipping_label_chattogram']); ?>">
								</label>
								<label class="pcs-field">
									<span class="pcs-field__label">Shipping label: Outside city</span>
									<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[shipping_label_outside]" value="<?php echo esc_attr($s['shipping_label_outside']); ?>">
								</label>
							</div>
						</details>
					</div>
				</section>

				<section class="pcs-tab-panel" data-tab-panel="order-bump">
					<div class="pcs-card">
						<div class="pcs-card__head">
							<span class="pcs-card__icon dashicons dashicons-cart" aria-hidden="true"></span>
							<div>
								<h2>Order Bump</h2>
								<p>Setup one-click add-on offer card inside popup checkout.</p>
							</div>
						</div>
						<div class="pcs-form-grid">
							<label class="pcs-field pcs-field--checkbox <?php echo ! $license_active ? 'is-license-locked' : ''; ?>" data-license-locked="yes">
								<span class="pcs-field__label">Enable order bump</span>
								<input type="checkbox" name="<?php echo esc_attr(self::OPT_KEY); ?>[order_bump_enabled]" value="1" <?php checked( ! empty( $s['order_bump_enabled'] ) ); ?> <?php disabled( ! $license_active ); ?>>
								<span class="pcs-field__lock dashicons dashicons-lock" aria-hidden="true"></span>
							</label>
							<label class="pcs-field pcs-field--full">
								<span class="pcs-field__label">Order bump product (simple product)</span>
								<select name="<?php echo esc_attr(self::OPT_KEY); ?>[order_bump_product_id]">
									<option value="0"><?php esc_html_e( 'Select product', 'popup-checkout-subhan' ); ?></option>
									<?php foreach ( $order_bump_products as $product_id => $product_label ) : ?>
										<option value="<?php echo esc_attr( $product_id ); ?>" <?php selected( absint( $s['order_bump_product_id'] ?? 0 ), absint( $product_id ) ); ?>>
											<?php echo esc_html( $product_label ); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</label>
						</div>

						<details class="pcs-accordion" open>
							<summary>
								<span>Offer Copy Settings</span>
								<span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span>
							</summary>
							<div class="pcs-form-grid">
								<label class="pcs-field">
									<span class="pcs-field__label">Order bump badge text</span>
									<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[order_bump_badge_text]" value="<?php echo esc_attr($s['order_bump_badge_text'] ?? 'SPECIAL OFFER!'); ?>">
								</label>
								<label class="pcs-field">
									<span class="pcs-field__label">Order bump title text ({product} supported)</span>
									<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[order_bump_title_text]" value="<?php echo esc_attr($s['order_bump_title_text'] ?? 'Add {product} for just'); ?>">
								</label>
								<label class="pcs-field pcs-field--full">
									<span class="pcs-field__label">Order bump note text</span>
									<input type="text" name="<?php echo esc_attr(self::OPT_KEY); ?>[order_bump_note_text]" value="<?php echo esc_attr($s['order_bump_note_text'] ?? '(এইটা ডেলিভারির সাথে পেয়ে যাবেন)'); ?>">
								</label>
							</div>
						</details>
					</div>
				</section>

				<section class="pcs-tab-panel" data-tab-panel="custom-css" id="pcs-custom-css">
					<div class="pcs-card">
						<div class="pcs-card__head">
							<span class="pcs-card__icon dashicons dashicons-editor-code" aria-hidden="true"></span>
							<div>
								<h2>Custom CSS</h2>
								<p>Add custom styles for popup checkout. This is loaded after plugin default styles.</p>
							</div>
						</div>
						<label class="pcs-field pcs-field--full">
							<span class="pcs-field__label">Custom CSS Editor</span>
							<textarea id="pcs_custom_css" name="<?php echo esc_attr(self::OPT_KEY); ?>[custom_css]" rows="12" spellcheck="false"><?php echo esc_textarea($s['custom_css']); ?></textarea>
						</label>
					</div>
				</section>

				<section class="pcs-tab-panel" data-tab-panel="license">
					<div class="pcs-card pcs-license-card">
						<div class="pcs-card__head pcs-license-card__head">
							<span class="pcs-card__icon dashicons dashicons-admin-network" aria-hidden="true"></span>
							<div>
								<span class="pcs-section-eyebrow">BORBILA LICENSING</span>
								<h2>Activate Popup Checkout</h2>
								<p>Verify this website securely and unlock the storefront checkout experience.</p>
							</div>
							<span class="pcs-license-status <?php echo $license_active ? 'is-active' : 'is-inactive'; ?>" id="pcs-license-status">
								<span class="dashicons <?php echo $license_active ? 'dashicons-yes-alt' : 'dashicons-lock'; ?>" aria-hidden="true"></span>
								<span id="pcs-license-status-label"><?php echo $license_active ? esc_html__( 'Active', 'popup-checkout-subhan' ) : esc_html__( 'Inactive', 'popup-checkout-subhan' ); ?></span>
							</span>
						</div>

						<div class="pcs-license-hero <?php echo $license_active ? 'is-active' : 'is-inactive'; ?>" id="pcs-license-hero">
							<span class="pcs-license-hero__icon dashicons <?php echo $license_active ? 'dashicons-shield-alt' : 'dashicons-lock'; ?>" aria-hidden="true"></span>
							<div>
								<strong id="pcs-license-hero-title"><?php echo $license_active ? esc_html__( 'Your license is active', 'popup-checkout-subhan' ) : esc_html__( 'License activation required', 'popup-checkout-subhan' ); ?></strong>
								<span id="pcs-license-hero-copy"><?php echo $license_active ? esc_html__( 'Popup Checkout is enabled for this website.', 'popup-checkout-subhan' ) : esc_html__( 'Enter your Borbila license key to enable customer-facing features.', 'popup-checkout-subhan' ); ?></span>
							</div>
						</div>

						<div class="pcs-license-entry">
							<label for="pcs-license-key">License key</label>
							<div class="pcs-license-entry__row">
								<input type="text" id="pcs-license-key" name="pcs_license_key" form="pcs-license-form" value="<?php echo esc_attr( $license_key_value ); ?>" placeholder="BRB-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false">
								<button type="submit" name="license_operation" value="activate" form="pcs-license-form" class="button button-primary pcs-license-button" id="pcs-activate-license">
									<span class="dashicons dashicons-unlock" aria-hidden="true"></span> Activate
								</button>
								<button type="submit" name="license_operation" value="deactivate" form="pcs-license-form" class="button pcs-license-button pcs-license-button--danger" id="pcs-deactivate-license" <?php disabled( ! $license_active ); ?>>
									Deactivate
								</button>
							</div>
							<div class="pcs-license-result <?php echo ! empty( $license_notice ) ? ( ! empty( $license_notice['success'] ) ? 'is-visible is-success' : 'is-visible is-error' ) : ''; ?>" id="pcs-license-result" role="status" aria-live="polite"><?php echo ! empty( $license_notice['message'] ) ? esc_html( $license_notice['message'] ) : ''; ?></div>
						</div>

						<div class="pcs-license-meta">
							<div><span>Website</span><strong id="pcs-license-domain"><?php echo '' !== $license['activated_domain'] ? esc_html( $license['activated_domain'] ) : esc_html( PCS_License::get_domain() ); ?></strong></div>
							<div><span>Template ID</span><strong><?php echo esc_html( PCS_License::TEMPLATE_ID ); ?></strong></div>
							<div><span>Validity</span><strong>Lifetime</strong></div>
							<div><span>Last checked</span><strong id="pcs-license-last-checked"><?php echo '' !== $license['last_checked'] ? esc_html( $license['last_checked'] ) : esc_html__( 'Never', 'popup-checkout-subhan' ); ?></strong></div>
						</div>

						<div class="pcs-license-footer">
							<span>Need a license for this website?</span>
							<a href="https://borbila.com/my-account/licenses/" target="_blank" rel="noopener" class="button">Get License <span class="dashicons dashicons-external" aria-hidden="true"></span></a>
						</div>
					</div>
				</section>

				<div class="pcs-save-bar">
					<div class="pcs-save-bar__meta">
						<span class="dashicons dashicons-yes-alt" aria-hidden="true"></span>
						<span class="pcs-save-status" aria-live="polite">Changes are not saved yet.</span>
					</div>
					<?php submit_button( 'Save Changes', 'primary', 'submit', false, array( 'class' => 'button button-primary button-hero pcs-save-btn', 'id' => 'pcs-save-btn' ) ); ?>
				</div>
			</form>
			<form id="pcs-license-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="pcs-hidden-form">
				<input type="hidden" name="action" value="pcs_license_action">
				<?php wp_nonce_field( 'pcs_license_action', 'pcs_license_action_nonce' ); ?>
			</form>
			</div>
		</div>
		<?php
	}

	public function filter_order_button_text( $text ) {
		if ( PCS_License::is_active() && $this->is_popup_checkout_context() ) {
			$s = $this->get_settings();
			$btn_text = sanitize_text_field( $s['order_btn_text'] ?? '' );
			if ( '' !== $btn_text ) return $btn_text;
			return 'আপনার অর্ডার কনফার্ম করতে ক্লিক করুন';
		}
		return $text;
	}

	/* ------------------------- Elementor ------------------------- */

	public function register_elementor_category( $elements_manager ) {
		// safe: older Elementor uses different args, keep simple
		if ( method_exists( $elements_manager, 'add_category' ) ) {
			$elements_manager->add_category(
				'pcs-subhan',
				array(
					'title' => __( 'Borbila Widgets', 'popup-checkout-subhan' ),
					'icon'  => 'fa fa-plug',
				)
			);
		}
	}

	public function register_elementor_widget( $widgets_manager ) {
		if ( ! did_action('elementor/loaded') || ! PCS_License::is_active() ) return;
		require_once plugin_dir_path(__FILE__) . 'includes/elementor-widget.php';
		$widgets_manager->register( new \PCS_Popup_Checkout_Elementor_Widget() );
	}

	public function render_button_html( $product_id = 0, $text = '' ) : string {
		if ( ! PCS_License::is_active() ) return '';
		$s = $this->get_settings();
		$pid = absint( $product_id );
		if ( ! $pid ) $pid = (int) get_the_ID();
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $pid ) : null;
		if ( ! $product || ! is_a( $product, 'WC_Product' ) || ! $product->is_purchasable() || ! $product->is_in_stock() ) return '';
		$label = $text ? $text : ( $s['button_text'] ?: 'Buy Now' );

		return sprintf(
			'<button type="button" class="pcs-buy-now" data-product_id="%d" data-context="widget" style="%s"><span class="pcs-btn__bolt">⚡</span><span class="pcs-btn__text">%s</span></button>',
			esc_attr($pid),
			esc_attr($this->button_style_inline()),
			esc_html($label)
		);
	}

	public function add_plugin_row_meta( $links, $file ) {
		if ( plugin_basename(__FILE__) !== $file ) return $links;
		$links[] = '<a href="https://borbila.com/product/popup-checkout-for-woocommerce/" target="_blank" rel="noopener">Plugin Details</a>';
		$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=pcs-popup-checkout#tab-license' ) ) . '">License</a>';
		return $links;
	}

}

endif;

register_activation_hook( PCS_POPUP_CHECKOUT_FILE, array( 'PCS_Popup_Checkout_WC', 'activate_plugin' ) );
register_deactivation_hook( PCS_POPUP_CHECKOUT_FILE, array( 'PCS_Popup_Checkout_WC', 'deactivate_plugin' ) );

// Boot
global $pcs_popup_checkout_wc;
$pcs_popup_checkout_wc = new PCS_Popup_Checkout_WC();
