<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class PCS_Popup_Checkout_Elementor_Widget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'pcs_popup_checkout_subhan';
	}

	public function get_title() {
		return __( 'Popup Checkout (Borbila)', 'popup-checkout-subhan' );
	}

	public function get_icon() {
		return 'eicon-cart';
	}

	public function get_categories() {
		return array( 'pcs-subhan', 'general' );
	}

	public function get_keywords() {
		return array( 'woocommerce', 'checkout', 'popup', 'buy now', 'borbila' );
	}

	protected function register_controls() {

		/* =========================
		 * Content
		 * ========================= */
		$this->start_controls_section(
			'content_section',
			array(
				'label' => __( 'Content', 'popup-checkout-subhan' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'button_text',
			array(
				'label'       => __( 'Button Text', 'popup-checkout-subhan' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => __( 'Leave empty to use plugin default', 'popup-checkout-subhan' ),
			)
		);

		$this->add_control(
			'product_id',
			array(
				'label'       => __( 'Product ID (optional)', 'popup-checkout-subhan' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 0,
				'description' => __( 'Leave 0 to use current post/product ID (works in loop/single/archive).', 'popup-checkout-subhan' ),
			)
		);

		$this->add_control(
			'full_width',
			array(
				'label'        => __( 'Full Width', 'popup-checkout-subhan' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'popup-checkout-subhan' ),
				'label_off'    => __( 'No', 'popup-checkout-subhan' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'align',
			array(
				'label'   => __( 'Alignment', 'popup-checkout-subhan' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'options' => array(
					'left'   => array( 'title' => __( 'Left', 'popup-checkout-subhan' ), 'icon' => 'eicon-text-align-left' ),
					'center' => array( 'title' => __( 'Center', 'popup-checkout-subhan' ), 'icon' => 'eicon-text-align-center' ),
					'right'  => array( 'title' => __( 'Right', 'popup-checkout-subhan' ), 'icon' => 'eicon-text-align-right' ),
				),
				'default' => 'left',
				'toggle'  => true,
			)
		);

		$this->end_controls_section();

		/* =========================
		 * Style: Button
		 * ========================= */
		$this->start_controls_section(
			'style_button_section',
			array(
				'label' => __( 'Button', 'popup-checkout-subhan' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'btn_width',
			array(
				'label' => __( 'Width', 'popup-checkout-subhan' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array( 'min' => 10, 'max' => 100 ),
					'px' => array( 'min' => 80, 'max' => 900 ),
				),
				'selectors' => array(
					'{{WRAPPER}} .pcs-buy-now' => 'width: {{SIZE}}{{UNIT}};',
				),
				'condition' => array(
					'full_width!' => 'yes',
				),
			)
		);

		$this->add_control(
			'btn_display_full',
			array(
				'label' => __( 'Full Width Style', 'popup-checkout-subhan' ),
				'type'  => \Elementor\Controls_Manager::HEADING,
				'condition' => array(
					'full_width' => 'yes',
				),
			)
		);

		$this->add_control(
			'btn_full_width_css',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => __( 'When Full Width is ON, button will be 100% width.', 'popup-checkout-subhan' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				'condition' => array(
					'full_width' => 'yes',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'btn_typography',
				'label'    => __( 'Typography', 'popup-checkout-subhan' ),
				'selector' => '{{WRAPPER}} .pcs-buy-now',
			)
		);

		$this->start_controls_tabs( 'btn_tabs' );

		// Normal
		$this->start_controls_tab(
			'btn_tab_normal',
			array(
				'label' => __( 'Normal', 'popup-checkout-subhan' ),
			)
		);

		$this->add_control(
			'btn_text_color',
			array(
				'label' => __( 'Text Color', 'popup-checkout-subhan' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .pcs-buy-now' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'btn_bg_color',
			array(
				'label' => __( 'Background Color', 'popup-checkout-subhan' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .pcs-buy-now' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'btn_border',
				'selector' => '{{WRAPPER}} .pcs-buy-now',
			)
		);

		$this->add_responsive_control(
			'btn_radius',
			array(
				'label'      => __( 'Border Radius', 'popup-checkout-subhan' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .pcs-buy-now' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'btn_padding',
			array(
				'label'      => __( 'Padding', 'popup-checkout-subhan' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .pcs-buy-now' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'btn_margin',
			array(
				'label'      => __( 'Margin', 'popup-checkout-subhan' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .pcs-widget-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'btn_shadow',
				'selector' => '{{WRAPPER}} .pcs-buy-now',
			)
		);

		$this->end_controls_tab();

		// Hover
		$this->start_controls_tab(
			'btn_tab_hover',
			array(
				'label' => __( 'Hover', 'popup-checkout-subhan' ),
			)
		);

		$this->add_control(
			'btn_hover_text_color',
			array(
				'label' => __( 'Text Color', 'popup-checkout-subhan' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .pcs-buy-now:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'btn_hover_bg_color',
			array(
				'label' => __( 'Background Color', 'popup-checkout-subhan' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .pcs-buy-now:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'btn_hover_border_color',
			array(
				'label' => __( 'Border Color', 'popup-checkout-subhan' ),
				'type'  => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .pcs-buy-now:hover' => 'border-color: {{VALUE}};',
				),
				'condition' => array(
					'btn_border_border!' => '',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'btn_hover_shadow',
				'selector' => '{{WRAPPER}} .pcs-buy-now:hover',
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {
		if ( ! class_exists('WooCommerce') ) {
			echo '<div>WooCommerce not active.</div>';
			return;
		}
		if ( ! class_exists( 'PCS_License' ) || ! PCS_License::is_active() ) {
			if ( current_user_can( 'manage_options' ) ) {
				echo '<div class="pcs-elementor-license-notice">' . esc_html__( 'Activate the Popup Checkout license to use this widget.', 'popup-checkout-subhan' ) . '</div>';
			}
			return;
		}

		global $pcs_popup_checkout_wc;

		$settings = $this->get_settings_for_display();
		$pid  = ! empty($settings['product_id']) ? absint($settings['product_id']) : 0;
		$text = ! empty($settings['button_text']) ? sanitize_text_field($settings['button_text']) : '';
		$full = ( isset($settings['full_width']) && $settings['full_width'] === 'yes' );
		$align = $settings['align'] ?? 'left';

		// Wrapper alignment
		$align_css = 'text-align:left;';
		if ($align === 'center') $align_css = 'text-align:center;';
		if ($align === 'right')  $align_css = 'text-align:right;';

		// If user didn’t set product id, fallback to current ID
		if ( ! $pid ) $pid = (int) get_the_ID();

		// Build button HTML (no inline style, so Elementor controls can fully style it)
		$label = $text;
		if ( empty($label) ) {
			// plugin default
			if ( isset($pcs_popup_checkout_wc) && method_exists($pcs_popup_checkout_wc, 'get_settings') ) {
				$plugin_settings = $pcs_popup_checkout_wc->get_settings();
				$label = $plugin_settings['button_text'] ?? 'Buy Now';
			} else {
				$label = 'Buy Now';
			}
		}

		$btn_style = $full ? 'width:100%;' : ''; // width control is also available; this just enforces full width option
		echo '<div class="pcs-widget-wrap" style="'.esc_attr($align_css).'">';
		echo '<button type="button" class="pcs-buy-now" data-product_id="'.esc_attr($pid).'" data-context="widget" style="'.esc_attr($btn_style).'">';
		echo '<span class="pcs-btn__bolt" aria-hidden="true">⚡</span>';
		echo '<span class="pcs-btn__text">'.esc_html($label).'</span>';
		echo '</button>';
		echo '</div>';
	}
}
