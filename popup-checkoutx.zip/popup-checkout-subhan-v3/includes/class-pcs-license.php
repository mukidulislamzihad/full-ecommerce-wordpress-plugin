<?php
/**
 * Borbila license client for Popup Checkout.
 *
 * @package Borbila_Popup_Checkout
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles local license state and Borbila license API requests.
 */
class PCS_License {

	const OPTION_NAME = 'pcs_popup_checkout_license';
	const TEMPLATE_ID = 'popup-checkout-for-woocommerce';
	const API_BASE_URL = 'https://borbila.com/wp-json/borbila-license/v1';
	const CRON_HOOK = 'pcs_popup_checkout_license_daily_validation';
	const MASTER_SENTINEL = 'PCS-MASTER-ACTIVE';
	const MASTER_KEY_HASH = 'cd9fecc95a533bfd7ed1b62a34a6105f4cb74e5495c20c986a1a7121c9a8f484';

	/** Register daily validation hooks. */
	public static function register_hooks() {
		add_action( 'admin_init', array( __CLASS__, 'ensure_validation_schedule' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'validate_stored_license' ) );
	}

	/** Ensure the recurring validation event exists. */
	public static function ensure_validation_schedule() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
		}
	}

	/** Remove the recurring event when the plugin is deactivated. */
	public static function unschedule_validation() {
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	/** Return the default local license record. */
	public static function get_default_license() {
		return array(
			'license_key'      => '',
			'template_id'      => self::TEMPLATE_ID,
			'source'           => '',
			'status'           => 'inactive',
			'message'          => '',
			'activated_domain' => '',
			'last_checked'     => '',
		);
	}

	/** Create or upgrade the local option without autoloading it. */
	public static function maybe_add_default() {
		$stored = get_option( self::OPTION_NAME, null );

		if ( ! is_array( $stored ) ) {
			update_option( self::OPTION_NAME, self::get_default_license(), false );
			return;
		}

		$merged = wp_parse_args( $stored, self::get_default_license() );
		if ( $merged !== $stored ) {
			update_option( self::OPTION_NAME, $merged, false );
		}
	}

	/** Return normalized license data. */
	public static function get_license() {
		$license = get_option( self::OPTION_NAME, array() );
		$license = is_array( $license ) ? wp_parse_args( $license, self::get_default_license() ) : self::get_default_license();
		$key     = self::sanitize_license_key( $license['license_key'] );
		$source  = sanitize_key( $license['source'] );
		$status  = sanitize_key( $license['status'] );

		if ( ! in_array( $source, array( 'master', 'server' ), true ) ) {
			$source = '' !== $key && self::MASTER_SENTINEL !== $key ? 'server' : '';
		}

		return array(
			'license_key'      => $key,
			'template_id'      => self::TEMPLATE_ID,
			'source'           => $source,
			'status'           => '' !== $status ? $status : 'inactive',
			'message'          => sanitize_text_field( $license['message'] ),
			'activated_domain' => self::normalize_domain( $license['activated_domain'] ),
			'last_checked'     => sanitize_text_field( $license['last_checked'] ),
		);
	}

	/** Whether Popup Checkout is licensed for this website. */
	public static function is_active() {
		$license = self::get_license();
		if ( 'active' !== $license['status'] ) {
			return false;
		}

		if ( 'master' === $license['source'] ) {
			return self::MASTER_SENTINEL === $license['license_key'];
		}

		return 'server' === $license['source'] && '' !== $license['license_key'];
	}

	/** Return a safe masked key for the admin UI. */
	public static function mask_license_key( $license_key ) {
		$license_key = self::sanitize_license_key( $license_key );
		if ( '' === $license_key ) {
			return '';
		}
		if ( self::MASTER_SENTINEL === $license_key ) {
			return 'Master license · ••••1426';
		}

		$parts = array_values( array_filter( explode( '-', $license_key ), 'strlen' ) );
		if ( count( $parts ) >= 2 ) {
			return $parts[0] . '-••••-••••-' . $parts[ count( $parts ) - 1 ];
		}

		$prefix = substr( $license_key, 0, min( 4, strlen( $license_key ) ) );
		$suffix = strlen( $license_key ) > 4 ? substr( $license_key, -4 ) : '';
		return $prefix . '-••••••••' . ( '' !== $suffix ? '-' . $suffix : '' );
	}

	/** Activate a server license or the local master license. */
	public static function activate_license( $submitted_key ) {
		$current       = self::get_license();
		$submitted_key = trim( sanitize_text_field( (string) $submitted_key ) );
		$license_key   = false !== strpos( $submitted_key, '•' ) ? $current['license_key'] : self::sanitize_license_key( $submitted_key );

		if ( '' === $license_key ) {
			return self::activation_error( __( 'License key is required.', 'popup-checkout-subhan' ) );
		}

		if ( self::MASTER_SENTINEL === $license_key && 'master' === $current['source'] ) {
			self::activate_master_license();
			return array(
				'success' => true,
				'message' => __( 'Master license is valid.', 'popup-checkout-subhan' ),
				'license' => self::get_license(),
			);
		}

		if ( self::is_master_license_key( $license_key ) ) {
			self::activate_master_license();
			return array(
				'success' => true,
				'message' => __( 'Master license activated instantly.', 'popup-checkout-subhan' ),
				'license' => self::get_license(),
			);
		}

		if ( self::MASTER_SENTINEL === $license_key ) {
			return self::activation_error( __( 'Enter a valid Borbila license key.', 'popup-checkout-subhan' ) );
		}

		$result = self::request( 'activate', $license_key );
		if ( $result['success'] ) {
			self::save_license(
				array(
					'license_key'      => $license_key,
					'source'           => 'server',
					'status'           => 'active',
					'message'          => $result['message'],
					'activated_domain' => self::get_domain(),
					'last_checked'     => current_time( 'mysql' ),
				)
			);

			return array(
				'success' => true,
				'message' => '' !== $result['message'] ? $result['message'] : __( 'License activated successfully.', 'popup-checkout-subhan' ),
				'license' => self::get_license(),
			);
		}

		if ( $result['connection_error'] && self::is_active() ) {
			self::save_license(
				array(
					'message'      => $result['message'],
					'last_checked' => current_time( 'mysql' ),
				)
			);
		} else {
			self::save_license(
				array(
					'license_key'      => $license_key,
					'source'           => 'server',
					'status'           => $result['connection_error'] ? 'inactive' : 'invalid',
					'message'          => $result['message'],
					'activated_domain' => '',
					'last_checked'     => current_time( 'mysql' ),
				)
			);
		}

		return array(
			'success' => false,
			'message' => $result['message'],
			'license' => self::get_license(),
		);
	}

	/** Deactivate the current license. */
	public static function deactivate_license() {
		$license = self::get_license();

		if ( 'master' === $license['source'] ) {
			self::clear_license( __( 'Master license deactivated.', 'popup-checkout-subhan' ) );
			return array(
				'success' => true,
				'message' => __( 'Master license deactivated.', 'popup-checkout-subhan' ),
				'license' => self::get_license(),
			);
		}

		if ( '' === $license['license_key'] ) {
			self::clear_license( __( 'License removed successfully.', 'popup-checkout-subhan' ) );
			return array(
				'success' => true,
				'message' => __( 'License removed successfully.', 'popup-checkout-subhan' ),
				'license' => self::get_license(),
			);
		}

		$result = self::request( 'deactivate', $license['license_key'] );
		if ( $result['connection_error'] ) {
			return array(
				'success' => false,
				'message' => $result['message'],
				'license' => self::get_license(),
			);
		}

		$message = $result['success']
			? __( 'License deactivated successfully.', 'popup-checkout-subhan' )
			: __( 'License was removed from this website.', 'popup-checkout-subhan' );
		self::clear_license( $message );

		return array(
			'success' => true,
			'message' => $message,
			'license' => self::get_license(),
		);
	}

	/** Validate a stored license without disabling it on network failures. */
	public static function validate_stored_license() {
		$license = self::get_license();
		if ( 'master' === $license['source'] ) {
			self::activate_master_license();
			return;
		}
		if ( '' === $license['license_key'] ) {
			return;
		}

		$result = self::request( 'check', $license['license_key'] );
		if ( $result['connection_error'] ) {
			self::save_license(
				array(
					'message'      => $result['message'],
					'last_checked' => current_time( 'mysql' ),
				)
			);
			return;
		}

		self::save_license(
			array(
				'source'           => 'server',
				'status'           => $result['success'] ? 'active' : 'invalid',
				'message'          => $result['message'],
				'activated_domain' => $result['success'] ? self::get_domain() : '',
				'last_checked'     => current_time( 'mysql' ),
			)
		);
	}

	/** Get the normalized current site domain. */
	public static function get_domain() {
		return self::normalize_domain( home_url() );
	}

	/** Send a secure JSON request to the Borbila API. */
	private static function request( $action, $license_key ) {
		if ( ! in_array( $action, array( 'activate', 'check', 'deactivate' ), true ) ) {
			return array(
				'success'          => false,
				'connection_error' => false,
				'message'          => __( 'Invalid license action.', 'popup-checkout-subhan' ),
			);
		}

		$response = wp_remote_post(
			trailingslashit( self::API_BASE_URL ) . $action,
			array(
				'timeout'     => 20,
				'redirection' => 3,
				'sslverify'   => true,
				'headers'     => array(
					'Accept'       => 'application/json',
					'Content-Type' => 'application/json',
				),
				'body'        => wp_json_encode(
					array(
						'license_key' => self::sanitize_license_key( $license_key ),
						'template_id' => self::TEMPLATE_ID,
						'domain'      => self::get_domain(),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success'          => false,
				'connection_error' => true,
				'message'          => __( 'Could not connect to the Borbila license server. Please try again.', 'popup-checkout-subhan' ),
			);
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $data ) || ! array_key_exists( 'success', $data ) ) {
			return array(
				'success'          => false,
				'connection_error' => true,
				'message'          => __( 'The license server returned an invalid response. Please try again.', 'popup-checkout-subhan' ),
			);
		}

		$success = self::value_is_true( $data['success'] );
		$message = isset( $data['message'] ) && is_scalar( $data['message'] )
			? sanitize_text_field( (string) $data['message'] )
			: ( $success ? __( 'License verified.', 'popup-checkout-subhan' ) : __( 'License validation failed.', 'popup-checkout-subhan' ) );

		return array(
			'success'          => $success,
			'connection_error' => false,
			'message'          => $message,
		);
	}

	/** Return a consistent activation error response. */
	private static function activation_error( $message ) {
		return array(
			'success' => false,
			'message' => $message,
			'license' => self::get_license(),
		);
	}

	/** Activate master access without storing the supplied master key. */
	private static function activate_master_license() {
		self::save_license(
			array(
				'license_key'      => self::MASTER_SENTINEL,
				'source'           => 'master',
				'status'           => 'active',
				'message'          => __( 'Master license valid.', 'popup-checkout-subhan' ),
				'activated_domain' => self::get_domain(),
				'last_checked'     => current_time( 'mysql' ),
			)
		);
	}

	/** Clear local license state. */
	private static function clear_license( $message ) {
		self::save_license(
			array(
				'license_key'      => '',
				'source'           => '',
				'status'           => 'inactive',
				'message'          => $message,
				'activated_domain' => '',
				'last_checked'     => current_time( 'mysql' ),
			)
		);
	}

	/** Save normalized license values with autoload disabled. */
	private static function save_license( $license ) {
		$current = self::get_license();
		$license = wp_parse_args( $license, $current );
		$source  = sanitize_key( $license['source'] );

		update_option(
			self::OPTION_NAME,
			array(
				'license_key'      => self::sanitize_license_key( $license['license_key'] ),
				'template_id'      => self::TEMPLATE_ID,
				'source'           => in_array( $source, array( 'master', 'server' ), true ) ? $source : '',
				'status'           => sanitize_key( $license['status'] ),
				'message'          => sanitize_text_field( $license['message'] ),
				'activated_domain' => self::normalize_domain( $license['activated_domain'] ),
				'last_checked'     => sanitize_text_field( $license['last_checked'] ),
			),
			false
		);
	}

	/** Check the submitted key using its hash. */
	private static function is_master_license_key( $license_key ) {
		return hash_equals( self::MASTER_KEY_HASH, hash( 'sha256', self::sanitize_license_key( $license_key ) ) );
	}

	/** Normalize license keys exactly once before storage or requests. */
	private static function sanitize_license_key( $license_key ) {
		$license_key = strtoupper( trim( sanitize_text_field( (string) $license_key ) ) );
		$license_key = preg_replace( '/[^A-Z0-9\-]/', '', $license_key );
		return substr( (string) $license_key, 0, 64 );
	}

	/** Normalize a URL or host to the API domain format. */
	private static function normalize_domain( $value ) {
		$value  = strtolower( trim( (string) $value ) );
		$parsed = false !== strpos( $value, '://' ) ? $value : 'https://' . ltrim( $value, '/' );
		$domain = wp_parse_url( $parsed, PHP_URL_HOST );

		if ( ! is_string( $domain ) || '' === $domain ) {
			$domain = preg_replace( '#^https?://#i', '', $value );
			$domain = strtok( (string) $domain, '/:' );
		}

		$domain = preg_replace( '/^www\./i', '', strtolower( trim( (string) $domain ) ) );
		return sanitize_text_field( (string) $domain );
	}

	/** Interpret flexible API booleans without treating "false" as truthy. */
	private static function value_is_true( $value ) {
		if ( true === $value || 1 === $value ) {
			return true;
		}
		return in_array( strtolower( trim( (string) $value ) ), array( '1', 'true', 'yes' ), true );
	}
}
