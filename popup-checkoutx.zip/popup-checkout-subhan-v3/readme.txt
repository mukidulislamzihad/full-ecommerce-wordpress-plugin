=== Popup Checkout for WooCommerce ===
Contributors: borbila
Tags: woocommerce, popup checkout, buy now, order bump, elementor
Requires at least: 6.2
Requires PHP: 7.4
Requires Plugins: woocommerce
Tested up to: 7.0
Stable tag: 2.0.0
License: GPLv2 or later

Fast, mobile-friendly WooCommerce popup checkout with flexible styling, custom delivery charges, coupons, order bump offers and Elementor support.

== Features ==

* Buy Now buttons for supported WooCommerce product templates
* Elementor Popup Checkout widget
* Mobile bottom-sheet and desktop modal checkout
* Custom Dhaka, Chattogram and outside-city delivery charges
* Coupon and order bump controls
* Custom checkout labels, colors and CSS
* Borbila lifetime license activation

== Changelog ==

= 2.0.0 =
* Redesigned the WordPress admin dashboard and storefront popup.
* Added Borbila server licensing and secure master-license activation.
* Added license locks for customer-facing feature toggles.
* Added resilient AJAX settings save with native WordPress fallback.
* Fixed Chattogram shipping settings not appearing in the popup.
* Fixed variable and unavailable products silently opening an incorrect checkout.
* Fixed cart quantity updates exceeding stock or sold-individually limits.
* Fixed stale and over-aggressive frontend asset caching behavior.
* Added safer error messages, request cancellation and modal focus handling.
* Added WooCommerce dependency notice and recurring license validation.

= 1.1.0 =
* Initial Popup Checkout release.
