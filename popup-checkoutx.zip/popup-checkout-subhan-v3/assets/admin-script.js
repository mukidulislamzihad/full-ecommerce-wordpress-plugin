jQuery(function($){
  'use strict';

  const $root = $('.pcs-admin');
  if (!$root.length) return;

  const config = window.pcsPopupAdmin || {};
  const messages = config.messages || {};
  const $tabs = $root.find('.pcs-tab');
  const $panels = $root.find('.pcs-tab-panel');
  const $form = $('#pcs-admin-settings-form');
  const $saveBtn = $form.find('.pcs-save-btn');
  const $saveStatus = $form.find('.pcs-save-status');
  const $licenseForm = $('#pcs-license-form');
  const $licenseInput = $('#pcs-license-key');
  const $licenseResult = $('#pcs-license-result');
  let nativeSettingsSubmit = false;

  const hashToTab = {
    'pcs-theme-colors': 'popup-design',
    'pcs-content-shipping-settings': 'shipping',
    'pcs-custom-css': 'custom-css',
    'license': 'license'
  };

  function activateTab(tab, syncHash){
    tab = tab || 'general';
    const $tab = $tabs.filter('[data-tab="' + tab + '"]').first();
    const $panel = $panels.filter('[data-tab-panel="' + tab + '"]').first();
    if (!$tab.length || !$panel.length) return;

    $tabs.removeClass('is-active').attr('aria-selected', 'false');
    $panels.removeClass('is-active');
    $tab.addClass('is-active').attr('aria-selected', 'true');
    $panel.addClass('is-active');
    $form.toggleClass('is-license-tab', tab === 'license');

    if (syncHash && window.history && window.history.replaceState) {
      window.history.replaceState(null, document.title, '#tab-' + tab);
    }
  }

  function getInitialTab(){
    const hash = (window.location.hash || '').replace('#', '').trim();
    if (!hash) return 'general';
    if (hash.indexOf('tab-') === 0) return hash.replace('tab-', '') || 'general';
    if (hashToTab[hash]) return hashToTab[hash];
    const $targetInPanel = $('#' + hash).closest('.pcs-tab-panel');
    return $targetInPanel.length ? ($targetInPanel.data('tab-panel') || 'general') : 'general';
  }

  function encodeBase64(value){
    const input = String(value || '');
    if (window.TextEncoder) {
      const bytes = new TextEncoder().encode(input);
      let binary = '';
      for (let i = 0; i < bytes.length; i += 8192) {
        binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
      }
      return window.btoa(binary);
    }
    return window.btoa(unescape(encodeURIComponent(input)));
  }

  function syncCodeEditors(){
    $('.CodeMirror').each(function(){
      if (this.CodeMirror && typeof this.CodeMirror.save === 'function') this.CodeMirror.save();
    });
  }

  function collectSettings(){
    syncCodeEditors();
    const settings = {};
    $form.serializeArray().forEach(function(item){
      const match = item.name.match(/^pcs_popup_checkout_settings\[([^\]]+)\]$/);
      if (match) settings[match[1]] = item.value;
    });
    return settings;
  }

  function setSaveState(state, copy){
    $form.toggleClass('is-saving', state === 'saving');
    $saveBtn.prop('disabled', state === 'saving');
    $saveStatus.removeClass('is-success is-error')
      .toggleClass('is-success', state === 'success')
      .toggleClass('is-error', state === 'error')
      .text(copy || '');
  }

  function showLockMessage(){
    const copy = messages.licenseRequired || 'Please activate your license to enable Popup Checkout features.';
    let $toast = $('#pcs-license-lock-toast');
    if (!$toast.length) $toast = $('<div id="pcs-license-lock-toast" class="pcs-lock-toast" role="status"></div>').appendTo('body');
    $toast.html('<span class="dashicons dashicons-lock"></span><span>' + $('<div>').text(copy).html() + '</span><button type="button">Activate</button>').addClass('is-visible');
    $toast.find('button').on('click', function(){
      activateTab('license', true);
      $toast.removeClass('is-visible');
      window.scrollTo({top: Math.max(0, $root.offset().top - 40), behavior: 'smooth'});
    });
    window.clearTimeout(showLockMessage.timer);
    showLockMessage.timer = window.setTimeout(function(){ $toast.removeClass('is-visible'); }, 4200);
  }

  function setLicenseResult(message, success){
    $licenseResult.removeClass('is-visible is-success is-error')
      .addClass('is-visible ' + (success ? 'is-success' : 'is-error'))
      .text(message || '');
  }

  function updateLicenseUi(license){
    const active = !!(license && license.is_active);
    $root.toggleClass('is-licensed', active).toggleClass('is-unlicensed', !active);
    $form.attr('data-license-active', active ? 'yes' : 'no');
    $('.pcs-license-chip').toggleClass('is-active', active).toggleClass('is-inactive', !active);
    $('#pcs-header-license-label').text(active ? 'Licensed' : 'License required');
    $('#pcs-sidebar-license-label').text(active ? 'Active · Lifetime' : 'Activation required');
    $('#pcs-license-status').toggleClass('is-active', active).toggleClass('is-inactive', !active);
    $('#pcs-license-status-label').text(active ? 'Active' : 'Inactive');
    $('#pcs-license-hero').toggleClass('is-active', active).toggleClass('is-inactive', !active);
    $('#pcs-license-hero-title').text(active ? 'Your license is active' : 'License activation required');
    $('#pcs-license-hero-copy').text(active ? 'Popup Checkout is enabled for this website.' : 'Enter your Borbila license key to enable customer-facing features.');
    $('#pcs-license-warning').toggleClass('is-hidden', active);
    $('#pcs-deactivate-license').prop('disabled', !active);

    $('[data-license-locked]').each(function(){
      $(this).toggleClass('is-license-locked', !active);
      $(this).find('input[type="checkbox"]').prop('disabled', !active);
    });

    if (license) {
      if (license.masked_key) $licenseInput.val(license.masked_key);
      if (license.activated_domain) $('#pcs-license-domain').text(license.activated_domain);
      if (license.last_checked) $('#pcs-license-last-checked').text(license.last_checked);
    }
  }

  function prepareLicenseFallback(operation){
    $licenseForm.find('.pcs-license-fallback-field').remove();
    $licenseInput.removeAttr('name');
    $('<input>', {type: 'hidden', name: 'pcs_license_key_encoded', value: encodeBase64($licenseInput.val()), class: 'pcs-license-fallback-field'}).appendTo($licenseForm);
    $('<input>', {type: 'hidden', name: 'license_operation', value: operation, class: 'pcs-license-fallback-field'}).appendTo($licenseForm);
  }

  $tabs.on('click', function(){ activateTab($(this).data('tab') || 'general', true); });
  $root.on('click', '[data-pcs-open-tab]', function(){ activateTab($(this).data('pcs-open-tab') || 'license', true); });
  activateTab(getInitialTab(), false);

  $root.on('click', '[data-license-locked="yes"]', function(e){
    if ($form.attr('data-license-active') === 'yes') return;
    e.preventDefault();
    showLockMessage();
  });

  const initialHash = (window.location.hash || '').replace('#', '').trim();
  if (initialHash && initialHash.indexOf('tab-') !== 0) {
    const el = document.getElementById(initialHash);
    if (el && el.tagName && el.tagName.toLowerCase() === 'details') el.open = true;
  }

  if ($form.length) {
    const params = new URLSearchParams(window.location.search);
    if (params.get('settings-updated') === 'true') setSaveState('success', 'Settings saved successfully.');

    $form.on('input change', 'input, select, textarea', function(){
      if (!$form.hasClass('is-saving') && !$(this).is('#pcs-license-key')) setSaveState('dirty', 'Unsaved changes. Click Save Changes.');
    });

    $form.on('submit', function(e){
      if (nativeSettingsSubmit || !config.ajaxUrl || !config.saveNonce) return;
      e.preventDefault();
      setSaveState('saving', 'Saving changes…');

      let payload;
      try {
        payload = encodeBase64(JSON.stringify(collectSettings()));
      } catch (error) {
        setSaveState('error', messages.saveFailed || 'Settings could not be saved.');
        return;
      }

      $.ajax({
        url: config.ajaxUrl,
        method: 'POST',
        dataType: 'json',
        data: {action: 'pcs_save_settings', nonce: config.saveNonce, payload: payload}
      }).done(function(response){
        if (response && response.success) {
          setSaveState('success', (response.data && response.data.message) || 'Settings saved successfully.');
          return;
        }
        setSaveState('error', (response && response.data && response.data.message) || messages.saveFailed || 'Settings could not be saved.');
      }).fail(function(xhr){
        const response = xhr && xhr.responseJSON;
        if (response && response.data && response.data.message) {
          setSaveState('error', response.data.message);
          return;
        }
        setSaveState('saving', messages.networkError || 'Trying the safe fallback…');
        nativeSettingsSubmit = true;
        window.setTimeout(function(){ $form.trigger('submit'); }, 120);
      });
    });

    $(window).on('pageshow', function(){
      if (!nativeSettingsSubmit) {
        $form.removeClass('is-saving');
        $saveBtn.prop('disabled', false);
      }
    });
  }

  $('#pcs-activate-license, #pcs-deactivate-license').on('click', function(e){
    const operation = this.id === 'pcs-deactivate-license' ? 'deactivate' : 'activate';
    if (!config.ajaxUrl || !config.licenseNonce) {
      prepareLicenseFallback(operation);
      return;
    }

    e.preventDefault();
    const $button = $(this);
    const originalText = $button.html();
    $button.prop('disabled', true).addClass('is-loading');
    setLicenseResult(operation === 'activate' ? 'Checking your license…' : 'Deactivating license…', true);

    $.ajax({
      url: config.ajaxUrl,
      method: 'POST',
      dataType: 'json',
      data: {action: operation === 'activate' ? 'pcs_activate_license' : 'pcs_deactivate_license', nonce: config.licenseNonce, pcs_license_key: $licenseInput.val()}
    }).done(function(response){
      const data = response && response.data ? response.data : {};
      setLicenseResult(data.message || 'License updated.', !!(response && response.success));
      if (data.license) updateLicenseUi(data.license);
    }).fail(function(xhr){
      const response = xhr && xhr.responseJSON;
      if (response && response.data) {
        const data = response.data;
        setLicenseResult(data.message || 'License action failed.', false);
        if (data.license) updateLicenseUi(data.license);
        return;
      }
      prepareLicenseFallback(operation);
      $licenseForm.trigger('submit');
    }).always(function(){
      $button.removeClass('is-loading').html(originalText);
      if (operation === 'activate' || $form.attr('data-license-active') === 'yes') $button.prop('disabled', false);
    });
  });

  function updateButtonPreview(){
    const prefix = 'pcs_popup_checkout_settings';
    const text = $('[name="' + prefix + '[button_text]"]').val() || 'Buy Now';
    const bg = $('[name="' + prefix + '[button_bg]"]').val() || '#0f172a';
    const color = $('[name="' + prefix + '[button_text_color]"]').val() || '#ffffff';
    const radius = parseInt($('[name="' + prefix + '[button_radius]"]').val() || 14, 10);
    const fontSize = parseInt($('[name="' + prefix + '[button_font_size]"]').val() || 15, 10);
    const py = parseInt($('[name="' + prefix + '[button_padding_y]"]').val() || 12, 10);
    const px = parseInt($('[name="' + prefix + '[button_padding_x]"]').val() || 18, 10);
    $('.pcs-preview__btn').css({background: bg, color: color, borderRadius: radius + 'px', fontSize: fontSize + 'px', padding: py + 'px ' + px + 'px'}).find('.pcs-btn__text').text(text);
  }

  $form.on('input change', '[name^="pcs_popup_checkout_settings[button_"]', updateButtonPreview);
});
