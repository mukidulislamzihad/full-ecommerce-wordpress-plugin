jQuery(function($){
  const $modal = $('#pcs-popup-checkout-modal');
  const $body = $('#pcs-popup-checkout-body');
  const ui = (typeof pcsPopupCheckout !== 'undefined' && pcsPopupCheckout.ui) ? pcsPopupCheckout.ui : {};
  const couponPlaceholder = ui.coupon_placeholder || 'কুপন কোড';
  const couponApplyText = ui.coupon_apply || 'এপ্লাই';
  const shippingTitle = ui.shipping_title || 'শিপিং মেথড';
  let activeCheckoutRequest = null;
  let lastTrigger = null;

  function getWcAjaxEndpoint(endpoint){
    if (typeof wc_checkout_params !== 'undefined' && wc_checkout_params.wc_ajax_url) {
      return wc_checkout_params.wc_ajax_url.toString().replace('%%endpoint%%', endpoint);
    }
    if (typeof pcsPopupCheckout !== 'undefined' && pcsPopupCheckout.ajax_url) {
      return pcsPopupCheckout.ajax_url.toString().replace('pcs_popup_checkout_form', endpoint);
    }
    return '';
  }

  function updatePopupCartItem(cartItemKey, action){
    const url = getWcAjaxEndpoint('pcs_popup_update_cart_item');
    if (!url || !cartItemKey || !action) {
      return $.Deferred().reject().promise();
    }

    return $.ajax({
      type: 'POST',
      url: url,
      data: {
        nonce: pcsPopupCheckout.nonce,
        cart_item_key: cartItemKey,
        pcs_action: action
      }
    });
  }

  function togglePopupOrderBump(productId, enabled){
    const url = getWcAjaxEndpoint('pcs_popup_toggle_order_bump');
    if (!url || !productId) {
      return $.Deferred().reject().promise();
    }

    return $.ajax({
      type: 'POST',
      url: url,
      data: {
        nonce: pcsPopupCheckout.nonce,
        product_id: productId,
        enabled: enabled ? '1' : '0'
      }
    });
  }

  function openModal(trigger){
    lastTrigger = trigger || document.activeElement;
    $modal.show().attr('aria-hidden','false').addClass('pcs-open');
    $('body').addClass('pcs-modal-open');
    window.setTimeout(function(){ $modal.find('.pcs-modal__close').trigger('focus'); }, 30);
  }
  function closeModal(){
    if (activeCheckoutRequest && typeof activeCheckoutRequest.abort === 'function') {
      activeCheckoutRequest.abort();
      activeCheckoutRequest = null;
    }
    $modal.removeClass('pcs-open').attr('aria-hidden','true');
    setTimeout(()=>{ $modal.hide(); }, 150);
    $('body').removeClass('pcs-modal-open');
    if (lastTrigger && typeof lastTrigger.focus === 'function') lastTrigger.focus();
  }

  function skeleton(){
    return `
      <div class="pcs-skeleton">
        <div class="pcs-skeleton__line"></div>
        <div class="pcs-skeleton__line"></div>
        <div class="pcs-skeleton__line"></div>
      </div>
    `;
  }

  function ensurePopupContextField($scope){
    const $form = $scope.find('form.checkout');
    if (!$form.length) return;

    if (!$form.find('input[name="pcs_popup_context"]').length) {
      $form.append('<input type="hidden" name="pcs_popup_context" value="1" />');
    }
  }

  function initPopupCheckout($scope){
    ensurePopupContextField($scope);
    $(document.body).trigger('init_checkout');
    $(document.body).trigger('update_checkout');
  }

  function setImportantStyles(el, styles){
    if (!el || !el.style || !styles) return;
    Object.keys(styles).forEach(function(prop){
      el.style.setProperty(prop, styles[prop], 'important');
    });
  }

  function applyPopupTypographyAndWhiteBg($scope){
    const $root = ($scope && $scope.length) ? $scope : $('#pcs-popup-checkout-modal');
    if (!$root.length) return;

    const textSelector = [
      'p','span','a','label','strong','small','em','b','li','td','th','div',
      'h1','h2','h3','h4','h5','h6','input','textarea','button','select','option'
    ].join(',');

    const nodes = $root.find(textSelector).toArray();

    // Pass 1: cache original computed size once so repeated updates stay stable.
    nodes.forEach(function(node){
      if (node.classList && node.classList.contains('woocommerce-input-wrapper')) return;
      if (node.hasAttribute('data-pcs-font-base')) return;
      const computedSize = parseFloat(window.getComputedStyle(node).fontSize || '');
      if (!Number.isFinite(computedSize) || computedSize <= 0) return;
      node.setAttribute('data-pcs-font-base', String(computedSize));
    });

    // Pass 2: apply Arial + exact -1px from cached base.
    nodes.forEach(function(node){
      if (node.classList && node.classList.contains('woocommerce-input-wrapper')) return;
      const baseSize = parseFloat(node.getAttribute('data-pcs-font-base') || '');
      if (!Number.isFinite(baseSize) || baseSize <= 0) return;
      const targetSize = Math.max(9, baseSize - 1);
      node.style.setProperty('font-family', 'Arial, sans-serif', 'important');
      node.style.setProperty('font-size', targetSize + 'px', 'important');
    });

    // Exact lock requested: product name + product prices at 13px.
    $root.find(
      '#order_review .pcs-review-product__name, ' +
      '#order_review .pcs-review-product__subtotal-amount, ' +
      '#order_review .pcs-review-product__subtotal-amount *, ' +
      '#order_review table.shop_table td.product-total, ' +
      '#order_review table.shop_table td.product-total *, ' +
      '#order_review .pcs-order-bump__price, ' +
      '#order_review .pcs-order-bump__price *'
    ).each(function(){
      this.style.setProperty('font-size', '13px', 'important');
    });

    // Shipping label + price size lock.
    $root.find(
      '#shipping_method .pcs-shipping-label, ' +
      '#shipping_method .pcs-shipping-price'
    ).each(function(){
      this.style.setProperty('font-size', '14px', 'important');
    });

    // Billing left labels lock (name/phone/address) compact so labels stay in one line.
    $root.find(
      '#billing_first_name_field > label, ' +
      '#billing_phone_field > label, ' +
      '#billing_address_1_field > label, ' +
      '#billing_first_name_field > label.required_field, ' +
      '#billing_phone_field > label.required_field, ' +
      '#billing_address_1_field > label.required_field, ' +
      '#billing_first_name_field > label .required_field, ' +
      '#billing_phone_field > label .required_field, ' +
      '#billing_address_1_field > label .required_field'
    ).each(function(){
      this.style.setProperty('font-size', '12px', 'important');
      this.style.setProperty('line-height', '1.15', 'important');
      this.style.setProperty('white-space', 'nowrap', 'important');
    });

    $root.find(
      '.woocommerce, .woocommerce-checkout, .woocommerce-checkout-review-order, #order_review, #payment, .woocommerce-checkout-payment, ' +
      'table.shop_table, .pcs-totals-card'
    ).each(function(){
      setImportantStyles(this, { 'background-color': '#ffffff' });
    });
  }

  function applyProductRowSoftCard($scope){
    const $root = ($scope && $scope.length) ? $scope : $('#pcs-popup-checkout-modal');
    if (!$root.length) return;

    $root.find('#order_review table.shop_table').each(function(){
      setImportantStyles(this, {
        'border-collapse': 'separate',
        'border-spacing': '0 6px'
      });
    });

    $root.find('#order_review table.shop_table tbody tr.cart_item td.product-name').each(function(){
      setImportantStyles(this, {
        'background-color': '#f6f6f6',
        'border': '0',
        'border-radius': '8px 0 0 8px'
      });
    });

    $root.find('#order_review table.shop_table tbody tr.cart_item td.product-total').each(function(){
      setImportantStyles(this, {
        'background-color': '#f6f6f6',
        'border': '0',
        'border-radius': '0 8px 8px 0',
        'text-align': 'right'
      });
    });

    $root.find('#order_review table.shop_table tbody tr.cart_item + tr.cart_item td').each(function(){
      setImportantStyles(this, { 'border-top': '0' });
    });
  }

  function syncShippingSelectionUI($scope){
    const $root = ($scope && $scope.length) ? $scope : $('#pcs-popup-checkout-modal');
    if (!$root.length) return;

    const $items = $root.find('#shipping_method li');
    if (!$items.length) return;

    $items.removeClass('pcs-is-selected');
    $root.find('#shipping_method li input[type="radio"]:checked').each(function(){
      $(this).closest('li').addClass('pcs-is-selected');
    });
  }

  function enforceTotalsFullWidth($scope){
    const $orderReview = $scope.find('#order_review').first();
    if (!$orderReview.length) return;

    const $table = $orderReview.find('table.shop_table, table.woocommerce-checkout-review-order-table').first();
    if (!$table.length) return;

    setImportantStyles($orderReview.get(0), {
      width: '100%',
      'max-width': '100%'
    });
    setImportantStyles($table.get(0), {
      width: '100%',
      'max-width': '100%'
    });

    const $tfoot = $table.find('tfoot').first();
    if (!$tfoot.length) return;

    setImportantStyles($tfoot.get(0), {
      display: 'block',
      width: '100%',
      'min-width': '100%',
      'max-width': '100%',
      'margin-left': '0',
      'margin-right': '0',
      'box-sizing': 'border-box'
    });

    $tfoot.find('tr').each(function(){
      setImportantStyles(this, {
        display: 'grid',
        'grid-template-columns': 'minmax(0, 1fr) auto',
        'align-items': 'center',
        width: '100%',
        margin: '0'
      });
    });

    $tfoot.find('th').each(function(){
      setImportantStyles(this, {
        'text-align': 'left',
        'padding-right': '10px'
      });
    });

    $tfoot.find('td').each(function(){
      setImportantStyles(this, {
        'text-align': 'right',
        'justify-self': 'end'
      });

      $(this).find('*').each(function(){
        setImportantStyles(this, {
          'text-align': 'right'
        });
      });
    });
  }

  function renderPopupTotalsCard($scope){
    const $orderReview = $scope.find('#order_review').first();
    if (!$orderReview.length) return;

    // Prevent duplicate cards on repeated checkout refreshes.
    $('#pcs-popup-checkout-body .pcs-totals-card').remove();

    const $table = $orderReview.find('table.shop_table, table.woocommerce-checkout-review-order-table').first();
    if (!$table.length) {
      return;
    }

    const $tfoot = $table.find('tfoot').first();
    if (!$tfoot.length) {
      return;
    }

    const rows = [];
    $tfoot.find('tr').each(function(){
      const $tr = $(this);
      if ($tr.hasClass('pcs-shipping-row--hidden')) return;

      const $th = $tr.children('th').first();
      const $td = $tr.children('td').last();
      const labelHtml = $th.length ? $th.html() : (($tr.children('td').first().html() || ''));
      const valueHtml = $td.length ? $td.html() : '';

      if (!labelHtml && !valueHtml) return;

      rows.push({
        labelHtml: labelHtml,
        valueHtml: valueHtml,
        isTotal: $tr.hasClass('order-total')
      });
    });

    if (!rows.length) return;

    const $tableWrap = $table.closest('.woocommerce-checkout-review-order-table');
    const $insertAfter = $tableWrap.length ? $tableWrap : $table;
    const $card = $('<div class="pcs-totals-card"></div>');
    $insertAfter.after($card);

    $card.empty();
    rows.forEach(function(row){
      const $row = $('<div class="pcs-totals-card__row"></div>');
      if (row.isTotal) $row.addClass('pcs-totals-card__row--total');

      const $label = $('<div class="pcs-totals-card__label"></div>').html(row.labelHtml);
      const $value = $('<div class="pcs-totals-card__value"></div>').html(row.valueHtml);
      $row.append($label, $value);
      $card.append($row);
    });

    setImportantStyles($card.get(0), {
      display: 'block',
      width: '100%',
      'max-width': '100%',
      margin: '8px 0 0 0',
      padding: '10px 12px',
      'border-radius': '6px',
      'background-color': '#dddddd',
      'box-sizing': 'border-box'
    });

    $card.find('.pcs-totals-card__row').each(function(){
      setImportantStyles(this, {
        display: 'grid',
        'grid-template-columns': 'minmax(0, 1fr) auto',
        'align-items': 'center',
        gap: '8px',
        margin: '0'
      });
    });

    $card.find('.pcs-totals-card__label').each(function(){
      setImportantStyles(this, {
        'text-align': 'left',
        'font-size': '14px',
        'font-weight': '500',
        color: '#161616'
      });
    });

    $card.find('.pcs-totals-card__value, .pcs-totals-card__value *').each(function(){
      setImportantStyles(this, {
        'text-align': 'right',
        'font-size': '14px',
        'font-weight': '700',
        color: '#161616'
      });
    });

    $card.find('.pcs-totals-card__row--total .pcs-totals-card__label').each(function(){
      setImportantStyles(this, {
        'font-size': '17px',
        'font-weight': '800'
      });
    });

    $card.find('.pcs-totals-card__row--total .pcs-totals-card__value, .pcs-totals-card__row--total .pcs-totals-card__value *').each(function(){
      setImportantStyles(this, {
        'font-size': '17px',
        'font-weight': '800'
      });
    });

    setImportantStyles($tfoot.get(0), {
      display: 'none'
    });
  }

  function normalizePopupCheckoutUI($scope){
    const $checkout = $scope.find('form.checkout.woocommerce-checkout, form.checkout');
    if (!$checkout.length) return;
    const $checkoutForm = $checkout.first();

    // Remove default "Have a coupon?" toggle in popup and keep only direct coupon form.
    $scope.find('.woocommerce-form-coupon-toggle').remove();

    const $orderReview = $scope.find('#order_review').first();
    const $payment = $scope.find('#payment').first();
    const $placeOrderRow = $scope.find('.form-row.place-order').first();
    let $couponSlot = $scope.find('.pcs-coupon-slot').first();
    let $couponForm = $scope.find('form.checkout_coupon.woocommerce-form-coupon').first();
    if (!$couponForm.length && $checkoutForm.length) {
      $couponForm = $(
        '<form class="checkout_coupon woocommerce-form-coupon" method="post" data-pcs-fallback-coupon="1">' +
          '<p class="form-row form-row-first">' +
            '<input type="text" name="coupon_code" class="input-text" placeholder="" id="coupon_code" value="" />' +
          '</p>' +
          '<p class="form-row form-row-last">' +
            '<button type="submit" class="button" name="apply_coupon" value="' + couponApplyText + '">' + couponApplyText + '</button>' +
          '</p>' +
          '<div class="clear"></div>' +
        '</form>'
      );
      $checkoutForm.append($couponForm);
    }

    if ($couponForm.length) {
      if (!$couponSlot.length) {
        $couponSlot = $('<div class="pcs-coupon-slot"></div>');
      }

      if ($placeOrderRow.length) {
        $couponSlot.insertBefore($placeOrderRow);
      } else if ($payment.length) {
        $payment.append($couponSlot);
      } else if ($orderReview.length) {
        const $table = $orderReview.children('table.shop_table').first();
        if ($table.length) {
          $couponSlot.insertAfter($table);
        } else {
          $orderReview.append($couponSlot);
        }
      } else if ($checkoutForm.length) {
        $checkoutForm.append($couponSlot);
      }

      $couponForm.appendTo($couponSlot);
      $couponForm.attr('style', '').css('display', 'flex');
      $couponForm.find('#coupon_code').attr('placeholder', couponPlaceholder);
      const $applyBtn = $couponForm.find('button[name="apply_coupon"]');
      $applyBtn.text(couponApplyText).val(couponApplyText);
    }

    // Remove english headings from Woo template in popup.
    $scope.find('.woocommerce-billing-fields > h3').remove();
    $scope.find('.woocommerce-additional-fields > h3').remove();
    $scope.find('#order_review_heading').remove();

    // If shipping methods exist, move them to a dedicated top section like the reference UI.
    const hasCustomShipping = $scope.find('.pcs-shipping-methods--custom').length > 0;
    const $shippingMethods = $scope.find('#shipping_method').first();
    if (!hasCustomShipping && $shippingMethods.length && $orderReview.length) {
      let $shippingSection = $orderReview.children('.pcs-shipping-methods');
      if (!$shippingSection.length) {
        $shippingSection = $(
          '<div class="pcs-shipping-methods">' +
            '<h4 class="pcs-shipping-methods__title">' + shippingTitle + '</h4>' +
            '<div class="pcs-shipping-methods__box"></div>' +
          '</div>'
        );

        const $couponSlot = $orderReview.children('.pcs-coupon-slot').first();
        if ($couponSlot.length) {
          $shippingSection.insertBefore($couponSlot);
        } else {
          $orderReview.prepend($shippingSection);
        }
      }

      $shippingSection.find('.pcs-shipping-methods__box').append($shippingMethods);
      $scope.find('#order_review table.shop_table tfoot tr.shipping').addClass('pcs-shipping-row--hidden');
    }

    // Insert compact section headings used by the reference design.
    const $reviewTable = $orderReview.length ? $orderReview.children('table.shop_table').first() : $();
    if ($orderReview.length && $reviewTable.length && !$orderReview.children('.pcs-order-summary-title').length) {
      $('<h4 class="pcs-order-summary-title">Order Summary</h4>').insertBefore($reviewTable);
    }
    if ($payment.length && !$payment.children('.pcs-payment-title').length) {
      $('<h4 class="pcs-payment-title">Payment Method</h4>').prependTo($payment);
    }

    // Match label language in totals.
    if ($orderReview.length) {
      $orderReview.find('table.shop_table tfoot tr.cart-subtotal th, table.woocommerce-checkout-review-order-table tfoot tr.cart-subtotal th').text('সাব টোটাল');
      $orderReview.find('table.shop_table tfoot tr.order-total th, table.woocommerce-checkout-review-order-table tfoot tr.order-total th').text('সর্বমোট');
      enforceTotalsFullWidth($scope);
      renderPopupTotalsCard($scope);
    }

    // Keep order note in payment action area, above the place-order button.
    let $orderNote = $scope.find('#order_comments_field').first();
    if (!$orderNote.length && $payment.length) {
      $orderNote = $(
        '<p class="form-row form-row-wide notes" id="order_comments_field" data-pcs-fallback-note="1">' +
          '<label for="order_comments">Order note</label>' +
          '<span class="woocommerce-input-wrapper">' +
            '<textarea name="order_comments" class="input-text" id="order_comments" placeholder="Order note" rows="2"></textarea>' +
          '</span>' +
        '</p>'
      );
    }

    if ($orderNote.length) {
      if ($placeOrderRow.length) {
        if ($couponSlot.length) {
          $orderNote.insertAfter($couponSlot);
        } else {
          $orderNote.insertBefore($placeOrderRow);
        }
      } else if ($payment.length) {
        $payment.append($orderNote);
      } else if ($orderReview.length) {
        $orderReview.append($orderNote);
      } else if ($checkoutForm.length) {
        $checkoutForm.append($orderNote);
      }
    }

    applyPopupTypographyAndWhiteBg($modal);
    applyProductRowSoftCard($modal);
    syncShippingSelectionUI($scope);
  }

  function getVariationPayload($trigger){
    let $form = $trigger && $trigger.length ? $trigger.closest('form.variations_form') : $();
    if (!$form.length) $form = $('form.variations_form').first();
    if (!$form.length) return { variation_id: 0, variation: {}, hasAttrs: false };

    const variation_id = parseInt($form.find('input.variation_id').val() || 0, 10);
    const variation = {};
    let hasAttrs = false;

    $form.find('select[name^="attribute_"]').each(function(){
      hasAttrs = true;
      variation[$(this).attr('name')] = $(this).val() || '';
    });

    return { variation_id, variation, hasAttrs };
  }

  function mustSelectVariation(vp){
    if (!vp.hasAttrs) return false;
    for (const k in vp.variation){
      if (!vp.variation[k]) return true;
    }
    return !vp.variation_id;
  }

  function renderCheckoutError(request){
    let message = 'Checkout could not be loaded. Please refresh the page and try again.';
    if (request && request.responseText) {
      const $response = $('<div>').html(request.responseText);
      const responseMessage = $response.find('.pcs-error').first().text().trim();
      if (responseMessage) message = responseMessage;
    }
    $body.empty().append($('<div class="pcs-error" role="alert"></div>').text(message));
  }

  async function loadCheckout(productId, context, $trigger){
    if (activeCheckoutRequest && typeof activeCheckoutRequest.abort === 'function') activeCheckoutRequest.abort();
    $body.html(skeleton());

    if (pcsPopupCheckout && pcsPopupCheckout.fixed_place_order) {
      $modal.addClass('pcs-fixed-place-order');
    } else {
      $modal.removeClass('pcs-fixed-place-order');
    }

    const isSingleOrWidget = (context === 'single' || context === 'widget');

    let payload = { product_id: productId, nonce: pcsPopupCheckout.nonce };

    // On single product, support variation selection if exists
    if (isSingleOrWidget && $('form.variations_form').length) {
      const vp = getVariationPayload($trigger);
      if (mustSelectVariation(vp)) {
        closeModal();
        alert('Please choose product options first.');
        return;
      }
      payload.variation_id = vp.variation_id || 0;
      payload.variation = vp.variation || {};
    }

    try{
      activeCheckoutRequest = $.ajax({
        url: pcsPopupCheckout.ajax_url,
        method: 'POST',
        data: payload
      });
      const html = await activeCheckoutRequest;
      activeCheckoutRequest = null;

      // Inject HTML
      $body.html(html);
	  if ($body.find('.pcs-error').length) return;

      // Normalize DOM blocks before Woo JS updates in popup.
      normalizePopupCheckoutUI($body);

      // Initialize Woo checkout + payment methods for dynamically loaded popup form
      initPopupCheckout($body);
      setTimeout(()=> normalizePopupCheckoutUI($body), 80);
    } catch(e){
      activeCheckoutRequest = null;
      if (e && e.statusText === 'abort') return;
      renderCheckoutError(e);
    }
  }

  $(document).on('click', '.pcs-buy-now', function(e){
    e.preventDefault();

    const productId = parseInt($(this).data('product_id') || 0, 10);
    const context = $(this).data('context') || 'widget';
    if (!productId) {
      alert('Product not found on this page.');
      return;
    }

    const $trigger = $(this);
    openModal(this);
    loadCheckout(productId, context, $trigger);
  });

  $(document).on('click', '[data-pcs-close="1"]', function(){ closeModal(); });
  $(document).on('keydown', function(e){
    if (e.key === 'Escape' && $modal.is(':visible')) closeModal();
    if (e.key !== 'Tab' || !$modal.is(':visible')) return;
    const $focusable = $modal.find('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])').filter(':visible');
    if (!$focusable.length) return;
    const first = $focusable.get(0);
    const last = $focusable.get($focusable.length - 1);
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });

  $(document.body).on('updated_checkout', function(){
    ensurePopupContextField($body);
    normalizePopupCheckoutUI($body);
  });

  $(document).on('change', '#pcs-popup-checkout-body input[name="pcs_popup_shipping_method"]', function(){
    syncShippingSelectionUI($(this).closest('#pcs-popup-checkout-body'));
    $(document.body).trigger('update_checkout');
  });

  $(document).on('change', '#pcs-popup-checkout-body .pcs-order-bump__toggle', function(){
    const $toggle = $(this);
    const productId = parseInt($toggle.data('product-id') || $toggle.closest('.pcs-order-bump').data('product-id') || 0, 10);
    if (!productId || $toggle.prop('disabled')) return;

    const enabled = $toggle.is(':checked');
    const $bump = $toggle.closest('.pcs-order-bump');
    const fallbackChecked = !enabled;

    $toggle.prop('disabled', true);
    $bump.addClass('is-updating');

    togglePopupOrderBump(productId, enabled)
      .done(function(resp){
        if (!resp || !resp.success) {
          $toggle.prop('checked', fallbackChecked);
          return;
        }
        if (resp.data && Object.prototype.hasOwnProperty.call(resp.data, 'selected')) {
          $toggle.prop('checked', !!resp.data.selected);
        }
        $(document.body).trigger('update_checkout');
      })
      .fail(function(){
        $toggle.prop('checked', fallbackChecked);
      })
      .always(function(){
        $toggle.prop('disabled', false);
        $bump.removeClass('is-updating');
      });
  });

  $(document).on('click', '#pcs-popup-checkout-body .pcs-review-product__btn[data-pcs-cart-action]', function(e){
    e.preventDefault();
    const $btn = $(this);
    const action = ($btn.data('pcs-cart-action') || '').toString();
    const cartItemKey = ($btn.data('cart-item-key') || '').toString();
    const $actions = $btn.closest('.pcs-review-product__actions');
    const hasActionGroup = $actions.length > 0;

    if (!action || !cartItemKey) return;
    if (hasActionGroup && $actions.hasClass('is-updating')) return;
    if (!hasActionGroup && $btn.prop('disabled')) return;

    if (hasActionGroup) {
      $actions.addClass('is-updating');
      $actions.find('.pcs-review-product__btn').prop('disabled', true);
    } else {
      $btn.prop('disabled', true).addClass('is-updating');
    }

    updatePopupCartItem(cartItemKey, action)
      .done(function(resp){
        if (!resp || !resp.success) return;
        $(document.body).trigger('update_checkout');
      })
      .always(function(){
        if (hasActionGroup) {
          $actions.removeClass('is-updating');
          $actions.find('.pcs-review-product__btn').prop('disabled', false);
        } else {
          $btn.prop('disabled', false).removeClass('is-updating');
        }
      });
  });

  // Fallback coupon apply for themes/plugins that don't render native checkout coupon form.
  $(document).on('submit', '#pcs-popup-checkout-body form.checkout_coupon.woocommerce-form-coupon[data-pcs-fallback-coupon="1"]', function(e){
    e.preventDefault();
    const $form = $(this);
    const $input = $form.find('input[name="coupon_code"]');
    const code = ($input.val() || '').trim();
    if (!code) return;

    if (typeof wc_checkout_params === 'undefined' || !wc_checkout_params.wc_ajax_url) {
      $(document.body).trigger('update_checkout');
      return;
    }

    const endpoint = wc_checkout_params.wc_ajax_url.toString().replace('%%endpoint%%', 'apply_coupon');
    const nonce = wc_checkout_params.apply_coupon_nonce || '';
    const $btn = $form.find('button[name="apply_coupon"]');
    $btn.prop('disabled', true);

    $.ajax({
      type: 'POST',
      url: endpoint,
      data: {
        coupon_code: code,
        security: nonce
      }
    }).always(function(){
      $btn.prop('disabled', false);
      $(document.body).trigger('update_checkout');
    });
  });
});
