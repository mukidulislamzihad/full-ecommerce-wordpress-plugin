(function () {
  'use strict';
  var app = document.getElementById('pl-app');
  if (!app || typeof PL === 'undefined') return;

  var S = { items: [], sales: [], tab: 'dashboard', range: 'month', q: '', cur: PL.currency || '৳' };
  var E = null; // item being edited in the drawer

  /* ---------- helpers ---------- */
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function num(v) { var n = parseFloat(v); return isFinite(n) ? n : 0; }
  function r2(n) { return Math.round(n * 100) / 100; }
  function money(n) {
    n = num(n);
    var s = Math.abs(n).toLocaleString('en-IN', { maximumFractionDigits: 2 });
    return (n < 0 ? '−' : '') + S.cur + ' ' + s;
  }
  function pct(n) { return (Math.round(n * 10) / 10) + '%'; }
  function ymd(d) {
    var m = d.getMonth() + 1, day = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (day < 10 ? '0' : '') + day;
  }
  function toast(msg, type) {
    var t = document.createElement('div');
    t.className = 'pl-toast' + (type === 'err' ? ' err' : '');
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 2600);
  }
  function api(op, data) {
    var fd = new FormData();
    fd.append('action', 'pl_api');
    fd.append('nonce', PL.nonce);
    fd.append('op', op);
    fd.append('data', JSON.stringify(data || {}));
    return fetch(PL.ajax, { method: 'POST', credentials: 'same-origin', body: fd })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j.success) throw new Error(typeof j.data === 'string' ? j.data : 'Something went wrong');
        return j.data;
      });
  }
  function load() {
    return api('load').then(function (d) { S.items = d.items; S.sales = d.sales; });
  }

  /* ---------- money maths ---------- */
  function landed(it) {
    var qty = Math.max(0.0001, num(it.batch_qty) || 1);
    var total = num(it.unit_cost);
    (it.costs || []).forEach(function (c) {
      total += c.type === 'batch' ? num(c.amount) / qty : num(c.amount);
    });
    return r2(total);
  }
  function itemById(id) {
    for (var i = 0; i < S.items.length; i++) if (S.items[i].id === id) return S.items[i];
    return null;
  }
  function saleCalc(s) {
    var revenue = s.qty * s.unit_price;
    var cost = s.qty * s.unit_cost + s.extra_cost;
    return { revenue: revenue, cost: cost, profit: revenue - cost };
  }
  function rangeStart() {
    var t = PL.today;
    if (S.range === 'month') return t.slice(0, 7) + '-01';
    if (S.range === 'year') return t.slice(0, 4) + '-01-01';
    if (S.range === '30') {
      var d = new Date(t + 'T00:00:00');
      d.setDate(d.getDate() - 29);
      return ymd(d);
    }
    return '0000-00-00';
  }
  function marginPill(margin, profit) {
    var cls = profit > 0 ? 'good' : profit < 0 ? 'bad' : 'flat';
    return '<span class="pl-pill ' + cls + '">' + pct(margin) + '</span>';
  }

  /* ---------- layout ---------- */
  function head() {
    var tabs = [['dashboard', 'Dashboard'], ['products', 'Products & pricing'], ['sales', 'Sales']];
    return '<div class="pl-head"><div><h1 class="pl-title">Profit Ledger</h1>' +
      '<div class="pl-sub">Cost, price and profit for every product</div></div>' +
      '<div class="pl-tabs" role="tablist">' + tabs.map(function (t) {
        return '<button class="pl-tab' + (S.tab === t[0] ? ' is-on' : '') + '" data-act="tab" data-v="' + t[0] + '">' + t[1] + '</button>';
      }).join('') + '</div></div>';
  }

  function render() {
    var body = S.tab === 'dashboard' ? dashboard() : S.tab === 'products' ? products() : sales();
    app.innerHTML = head() + body;
    if (S.tab === 'sales') updateSalePreview();
  }

  /* ---------- dashboard ---------- */
  function dashboard() {
    var start = rangeStart();
    var rows = S.sales.filter(function (s) { return s.sale_date >= start; });
    var rev = 0, cost = 0, byDay = {}, byItem = {};
    rows.forEach(function (s) {
      var c = saleCalc(s);
      rev += c.revenue; cost += c.cost;
      byDay[s.sale_date] = (byDay[s.sale_date] || 0) + c.profit;
      var b = byItem[s.item_id] || (byItem[s.item_id] = { qty: 0, rev: 0, profit: 0 });
      b.qty += s.qty; b.rev += c.revenue; b.profit += c.profit;
    });
    var profit = rev - cost, margin = rev > 0 ? profit / rev * 100 : 0;
    var days = Object.keys(byDay).sort().slice(-30).map(function (d) { return [d, byDay[d]]; });

    var ranges = [['month', 'This month'], ['30', 'Last 30 days'], ['year', 'This year'], ['all', 'All time']];
    var rangeSel = '<select data-act="range" style="width:auto">' + ranges.map(function (r) {
      return '<option value="' + r[0] + '"' + (S.range === r[0] ? ' selected' : '') + '>' + r[1] + '</option>';
    }).join('') + '</select>';
    var curInput = '<label class="pl-hint" style="display:flex;align-items:center;gap:6px">Currency <input type="text" data-act="currency" value="' + esc(S.cur) + '" style="width:64px"></label>';

    if (!S.items.length) {
      return '<div class="pl-card"><div class="pl-empty"><b>Start with your first product</b>Add its purchase cost and extra costs to find the right selling price.' +
        '<br><button class="pl-btn primary" data-act="new-item">Add product</button></div></div>';
    }

    var kpis = '<div class="pl-kpis">' +
      '<div class="pl-kpi main' + (profit < 0 ? ' is-loss' : '') + '"><span>' + (profit < 0 ? 'Net loss' : 'Net profit') + '</span><b>' + money(profit) + '</b></div>' +
      '<div class="pl-kpi"><span>Revenue</span><b>' + money(rev) + '</b></div>' +
      '<div class="pl-kpi"><span>Total cost</span><b>' + money(cost) + '</b></div>' +
      '<div class="pl-kpi"><span>Profit margin</span><b class="' + (profit < 0 ? 't-loss' : 't-profit') + '">' + pct(margin) + '</b></div></div>';

    var ranking = Object.keys(byItem).map(function (id) {
      var it = itemById(+id), b = byItem[id];
      return { name: it ? it.name : 'Deleted product', b: b };
    }).sort(function (a, b) { return b.b.profit - a.b.profit; });

    var table = ranking.length ? '<div class="pl-wrapx"><table class="pl-table"><thead><tr><th>Product</th><th class="num">Sold</th><th class="num">Revenue</th><th class="num">Profit / loss</th><th class="num">Margin</th></tr></thead><tbody>' +
      ranking.map(function (r) {
        var m = r.b.rev > 0 ? r.b.profit / r.b.rev * 100 : 0;
        return '<tr><td class="pl-name">' + esc(r.name) + '</td><td class="num">' + r.b.qty + '</td><td class="num">' + money(r.b.rev) + '</td>' +
          '<td class="num ' + (r.b.profit < 0 ? 't-loss' : 't-profit') + '"><b>' + money(r.b.profit) + '</b></td><td class="num">' + marginPill(m, r.b.profit) + '</td></tr>';
      }).join('') + '</tbody></table></div>' :
      '<div class="pl-empty"><b>No sales in this period</b>Log a sale to see profit and loss here.<br><button class="pl-btn primary" data-act="tab" data-v="sales">Add a sale</button></div>';

    // products currently priced below cost
    var under = S.items.filter(function (it) { return it.sell_price > 0 && it.sell_price < landed(it); });
    var warn = under.length ? '<div class="pl-card" style="margin-top:14px;border-color:#f0c4c4;background:#fff8f8"><h3 class="t-loss">Priced below cost</h3>' +
      under.map(function (it) {
        return '<div style="display:flex;justify-content:space-between;padding:6px 0"><span class="pl-name">' + esc(it.name) + '</span><span class="t-loss">sells ' + money(it.sell_price) + ', costs ' + money(landed(it)) + '</span></div>';
      }).join('') + '</div>' : '';

    return '<div class="pl-toolbar"><div>' + rangeSel + '</div>' + curInput + '</div>' + kpis +
      '<div class="pl-grid2"><div class="pl-card"><h3>Profit by product</h3>' + table + '</div>' +
      '<div class="pl-card"><h3>Daily profit</h3>' + chart(days) + '</div></div>' + warn;
  }

  function chart(days) {
    if (!days.length) return '<div class="pl-empty">No data yet</div>';
    var W = 600, H = 190, n = days.length;
    var hasNeg = days.some(function (d) { return d[1] < 0; });
    var max = Math.max.apply(null, days.map(function (d) { return Math.abs(d[1]); }).concat([1]));
    var y0 = hasNeg ? H / 2 : H - 24;
    var scale = hasNeg ? (H / 2 - 22) / max : (H - 44) / max;
    var slot = (W - 20) / n, bw = Math.min(30, Math.max(4, slot - 6));
    var bars = days.map(function (d, i) {
      var h = Math.max(2, Math.abs(d[1]) * scale);
      var x = 10 + i * slot + (slot - bw) / 2;
      var y = d[1] >= 0 ? y0 - h : y0;
      return '<rect class="' + (d[1] >= 0 ? 'bar-p' : 'bar-l') + '" x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + h.toFixed(1) + '" rx="3"><title>' + esc(d[0]) + ': ' + esc(money(d[1])) + '</title></rect>';
    }).join('');
    return '<svg class="pl-chart" viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" role="img" aria-label="Daily profit">' +
      '<line x1="0" x2="' + W + '" y1="' + y0 + '" y2="' + y0 + '"/>' + bars +
      '<text x="10" y="' + (H - 4) + '">' + esc(days[0][0]) + '</text>' +
      '<text x="' + (W - 10) + '" y="' + (H - 4) + '" text-anchor="end">' + esc(days[n - 1][0]) + '</text></svg>';
  }

  /* ---------- products ---------- */
  function products() {
    var q = S.q.toLowerCase();
    var list = S.items.filter(function (it) { return !q || it.name.toLowerCase().indexOf(q) > -1; });
    var toolbar = '<div class="pl-toolbar"><input class="grow" type="text" placeholder="Search products" data-act="search" value="' + esc(S.q) + '">' +
      '<button class="pl-btn primary" data-act="new-item">Add product</button></div>';
    if (!S.items.length) {
      return '<div class="pl-card"><div class="pl-empty"><b>No products yet</b>Add a product, enter what you paid and every extra cost, and the plugin suggests a price.' +
        '<br><button class="pl-btn primary" data-act="new-item">Add product</button></div></div>';
    }
    var rows = list.map(function (it) {
      var c = landed(it), p = it.sell_price, profit = p - c, m = p > 0 ? profit / p * 100 : 0;
      return '<tr><td class="pl-name">' + esc(it.name) + (it.product_id ? '<small>Linked to shop product #' + it.product_id + '</small>' : '') + '</td>' +
        '<td class="num">' + money(c) + '</td><td class="num">' + (p ? money(p) : '<span class="pl-hint">not set</span>') + '</td>' +
        '<td class="num ' + (profit < 0 ? 't-loss' : 't-profit') + '"><b>' + (p ? money(profit) : '–') + '</b></td>' +
        '<td class="num">' + (p ? marginPill(m, profit) : '') + '</td>' +
        '<td><div class="pl-actions"><button class="pl-btn sm" data-act="edit-item" data-id="' + it.id + '">Edit</button>' +
        '<button class="pl-btn sm danger" data-act="del-item" data-id="' + it.id + '">Delete</button></div></td></tr>';
    }).join('');
    return toolbar + '<div class="pl-card"><div class="pl-wrapx"><table class="pl-table"><thead><tr><th>Product</th><th class="num">Cost / unit</th><th class="num">Selling price</th><th class="num">Profit / unit</th><th class="num">Margin</th><th></th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="6" class="pl-empty">No product matches your search</td></tr>') + '</tbody></table></div></div>';
  }

  /* ---------- product editor (drawer) ---------- */
  function newItem() {
    return { id: 0, name: '', product_id: 0, batch_qty: 1, unit_cost: '', costs: [{ label: 'Shipping', amount: '', type: 'batch' }], sell_price: '', target_margin: 25, note: '' };
  }
  function openEditor(it) {
    E = it ? JSON.parse(JSON.stringify(it)) : newItem();
    closeDrawer();
    var wrap = document.createElement('div');
    wrap.id = 'pl-drawer-root';
    wrap.innerHTML = '<div class="pl-scrim" data-act="close"></div>' +
      '<aside class="pl-drawer pl-app" role="dialog" aria-modal="true" aria-label="Product">' +
      '<div class="pl-drawer-h"><h2>' + (E.id ? 'Edit product' : 'Add product') + '</h2><button class="pl-x" data-act="close" aria-label="Close">×</button></div>' +
      '<div class="pl-drawer-b">' + editorBody() + '</div>' +
      '<div class="pl-drawer-f"><button class="pl-btn" data-act="close">Cancel</button>' +
      '<button class="pl-btn" data-act="save-push" id="pl-push" style="display:none">Save & update shop price</button>' +
      '<button class="pl-btn primary" data-act="save">Save product</button></div></aside>';
    document.body.appendChild(wrap);
    refreshCalc();
    var f = wrap.querySelector('[data-f="name"]');
    if (f) f.focus();
  }
  function closeDrawer() {
    var d = document.getElementById('pl-drawer-root');
    if (d) d.remove();
  }
  function editorBody() {
    var wc = PL.wc ? '<div class="pl-field"><label>Link to shop product (optional)</label><div id="pl-link">' + linkHtml() + '</div></div>' : '';
    return '<div class="pl-sec"><h4>Product</h4>' +
      '<div class="pl-field"><label>Name</label><input type="text" data-f="name" value="' + esc(E.name) + '" placeholder="e.g. Cotton panjabi"></div>' + wc + '</div>' +

      '<div class="pl-sec"><h4>What it costs you</h4>' +
      '<div class="pl-row c2"><div class="pl-field"><label>Purchase price per unit</label><input type="number" min="0" step="any" data-f="unit_cost" value="' + esc(E.unit_cost) + '"></div>' +
      '<div class="pl-field"><label>Units bought in this batch</label><input type="number" min="1" step="any" data-f="batch_qty" value="' + esc(E.batch_qty) + '"></div></div>' +
      '<div class="pl-hint" style="margin-bottom:10px">Extra costs: choose “per unit” for costs on each piece, or “whole batch” and the plugin splits it across the units.</div>' +
      '<div id="pl-costs">' + costRows() + '</div>' +
      '<button class="pl-btn sm" data-act="add-cost">Add extra cost</button>' +
      '<datalist id="pl-labels"><option value="Shipping"><option value="Customs / duty"><option value="Packaging"><option value="Local transport"><option value="Labeling"><option value="Ads"><option value="Payment fee"></datalist></div>' +

      '<div class="pl-sec"><h4>Set your price</h4>' +
      '<div class="pl-field"><label>Profit margin you want: <b id="pl-mv"></b></label><input class="pl-range" type="range" min="0" max="80" step="1" data-f="target_margin" value="' + esc(E.target_margin) + '"></div>' +
      '<div class="pl-suggest" id="pl-sug"></div>' +
      '<div class="pl-field" style="margin-top:12px"><label>Selling price</label><input type="number" min="0" step="any" data-f="sell_price" value="' + esc(E.sell_price) + '"></div>' +
      '<div id="pl-stack"></div><div class="pl-results" id="pl-res"></div></div>' +

      '<div class="pl-sec"><h4>Note</h4><textarea rows="2" data-f="note" placeholder="Supplier, invoice number, anything useful">' + esc(E.note) + '</textarea></div>';
  }
  function linkHtml() {
    if (E.product_id) {
      return '<div class="pl-linked"><span>Linked: ' + esc(E._pname || ('shop product #' + E.product_id)) + '</span><button class="pl-btn sm ghost" data-act="unlink">Remove</button></div>';
    }
    return '<input type="text" id="pl-wcq" placeholder="Search your shop products"><div id="pl-wcres"></div>';
  }
  function costRows() {
    if (!E.costs.length) return '<div class="pl-hint" style="margin-bottom:8px">No extra costs added.</div>';
    return E.costs.map(function (c, i) {
      return '<div class="pl-cost-row"><input type="text" list="pl-labels" placeholder="Cost name" data-ci="' + i + '" data-cf="label" value="' + esc(c.label) + '">' +
        '<input type="number" min="0" step="any" placeholder="Amount" data-ci="' + i + '" data-cf="amount" value="' + esc(c.amount) + '">' +
        '<select data-ci="' + i + '" data-cf="type"><option value="unit"' + (c.type === 'unit' ? ' selected' : '') + '>per unit</option><option value="batch"' + (c.type === 'batch' ? ' selected' : '') + '>whole batch</option></select>' +
        '<button class="pl-x" data-act="del-cost" data-i="' + i + '" aria-label="Remove cost">×</button></div>';
    }).join('');
  }

  // live recalculation inside the drawer
  function refreshCalc() {
    var root = document.getElementById('pl-drawer-root');
    if (!root || !E) return;
    var qty = Math.max(0.0001, num(E.batch_qty) || 1);
    var buy = num(E.unit_cost);
    var extras = (E.costs || []).map(function (c) {
      return { label: c.label || 'Extra', v: c.type === 'batch' ? num(c.amount) / qty : num(c.amount) };
    }).filter(function (x) { return x.v > 0; });
    var cost = r2(buy + extras.reduce(function (a, x) { return a + x.v; }, 0));
    var price = num(E.sell_price), profit = price - cost, margin = price > 0 ? profit / price * 100 : 0;
    var tm = num(E.target_margin);
    var suggested = tm < 100 && cost > 0 ? r2(cost / (1 - tm / 100)) : 0;

    root.querySelector('#pl-mv').textContent = tm + '%';
    root.querySelector('#pl-sug').innerHTML = cost > 0 ?
      'Cost per unit <b>' + money(cost) + '</b> · price for ' + tm + '% margin <b>' + money(suggested) + '</b> <button class="pl-btn sm" data-act="use-suggested" data-v="' + suggested + '">Use this price</button>' :
      'Enter the purchase price to see a suggested price.';

    var total = Math.max(cost, price, 0.01);
    var segs = '';
    if (buy > 0) segs += '<div class="pl-seg buy" style="width:' + (buy / total * 100) + '%" title="Purchase ' + esc(money(buy)) + '"></div>';
    extras.forEach(function (x) {
      segs += '<div class="pl-seg ext" style="width:' + (x.v / total * 100) + '%" title="' + esc(x.label) + ' ' + esc(money(x.v)) + '"></div>';
    });
    if (price > cost) segs += '<div class="pl-seg win" style="width:' + ((price - cost) / total * 100) + '%" title="Profit"></div>';
    var mark = price > 0 && price < cost ? '<div class="pl-mark" style="left:calc(' + (price / total * 100) + '% - 1px)" title="Selling price"></div>' : '';
    root.querySelector('#pl-stack').innerHTML = '<div class="pl-stack">' + segs + mark + '</div>' +
      '<div class="pl-legend"><span><i style="background:var(--cost)"></i>Purchase</span><span><i style="background:var(--extra)"></i>Extra costs</span><span><i style="background:var(--profit)"></i>Profit</span></div>' +
      (price > 0 && price < cost ? '<div class="pl-loss-note">The black line is your selling price. It is ' + money(cost - price) + ' below cost, so each sale loses money.</div>' : '');

    var cls = price <= 0 ? '' : profit > 0 ? 'good' : profit < 0 ? 'bad' : '';
    var batchProfit = profit * qty;
    root.querySelector('#pl-res').innerHTML =
      '<div class="pl-res"><span>Cost per unit</span><b>' + money(cost) + '</b></div>' +
      '<div class="pl-res ' + cls + '"><span>' + (profit < 0 ? 'Loss per unit' : 'Profit per unit') + '</span><b>' + (price > 0 ? money(profit) : '–') + '</b></div>' +
      '<div class="pl-res ' + cls + '"><span>Margin · whole batch</span><b>' + (price > 0 ? pct(margin) + ' · ' + money(batchProfit) : '–') + '</b></div>';

    var push = root.querySelector('#pl-push');
    if (push) push.style.display = PL.wc && E.product_id ? '' : 'none';
  }

  function saveItem(push) {
    if (!E.name.trim()) { toast('Enter a product name', 'err'); return; }
    var payload = {
      id: E.id, name: E.name.trim(), product_id: E.product_id,
      batch_qty: num(E.batch_qty) || 1, unit_cost: num(E.unit_cost),
      costs: E.costs.map(function (c) { return { label: c.label, amount: num(c.amount), type: c.type }; }),
      sell_price: num(E.sell_price), target_margin: num(E.target_margin), note: E.note
    };
    api('save_item', payload).then(function (saved) {
      if (push && saved.product_id) {
        return api('push_price', { product_id: saved.product_id, price: saved.sell_price }).then(function () { return 'Saved and shop price updated'; });
      }
      return 'Product saved';
    }).then(function (msg) {
      return load().then(function () { closeDrawer(); render(); toast(msg); });
    }).catch(function (e) { toast(e.message, 'err'); });
  }

  /* ---------- sales ---------- */
  function sales() {
    if (!S.items.length) {
      return '<div class="pl-card"><div class="pl-empty"><b>Add a product first</b>Sales use the product’s cost, so add at least one product.<br><button class="pl-btn primary" data-act="tab" data-v="products">Go to products</button></div></div>';
    }
    var opts = S.items.map(function (it) { return '<option value="' + it.id + '">' + esc(it.name) + '</option>'; }).join('');
    var first = S.items[0];
    var form = '<div class="pl-card" style="margin-bottom:14px"><h3>Add a sale</h3><div id="pl-sf">' +
      '<div class="pl-row c3"><div class="pl-field"><label>Product</label><select id="sf-item">' + opts + '</select></div>' +
      '<div class="pl-field"><label>Quantity</label><input type="number" id="sf-qty" min="0" step="any" value="1"></div>' +
      '<div class="pl-field"><label>Selling price per unit</label><input type="number" id="sf-price" min="0" step="any" value="' + (first.sell_price || '') + '"></div></div>' +
      '<div class="pl-row c3"><div class="pl-field"><label>Order costs (delivery, fees)</label><input type="number" id="sf-extra" min="0" step="any" value="0"></div>' +
      '<div class="pl-field"><label>Date</label><input type="date" id="sf-date" value="' + PL.today + '"></div>' +
      '<div class="pl-field"><label>Note</label><input type="text" id="sf-note" placeholder="Order number, customer"></div></div>' +
      '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><div id="sf-prev" class="pl-hint"></div><button class="pl-btn primary" data-act="add-sale">Add sale</button></div></div></div>';

    var rows = S.sales.slice(0, 200).map(function (s) {
      var it = itemById(s.item_id), c = saleCalc(s);
      return '<tr><td>' + esc(s.sale_date) + '</td><td class="pl-name">' + esc(it ? it.name : 'Deleted product') + (s.note ? '<small>' + esc(s.note) + '</small>' : '') + '</td>' +
        '<td class="num">' + s.qty + '</td><td class="num">' + money(s.unit_price) + '</td><td class="num">' + money(c.cost) + '</td>' +
        '<td class="num ' + (c.profit < 0 ? 't-loss' : 't-profit') + '"><b>' + money(c.profit) + '</b></td>' +
        '<td><div class="pl-actions"><button class="pl-btn sm danger" data-act="del-sale" data-id="' + s.id + '">Delete</button></div></td></tr>';
    }).join('');
    var table = S.sales.length ? '<div class="pl-card"><div class="pl-wrapx"><table class="pl-table"><thead><tr><th>Date</th><th>Product</th><th class="num">Qty</th><th class="num">Price</th><th class="num">Total cost</th><th class="num">Profit / loss</th><th></th></tr></thead><tbody>' + rows + '</tbody></table></div></div>' :
      '<div class="pl-card"><div class="pl-empty"><b>No sales yet</b>Your first sale will show profit or loss right here.</div></div>';
    return form + table;
  }
  function updateSalePreview() {
    var sel = document.getElementById('sf-item');
    if (!sel) return;
    var it = itemById(+sel.value);
    if (!it) return;
    var qty = num(document.getElementById('sf-qty').value), price = num(document.getElementById('sf-price').value), extra = num(document.getElementById('sf-extra').value);
    var profit = qty * (price - landed(it)) - extra;
    document.getElementById('sf-prev').innerHTML = 'Cost per unit ' + money(landed(it)) + ' · this sale ' +
      '<b class="' + (profit < 0 ? 't-loss' : 't-profit') + '">' + (profit < 0 ? 'loses ' : 'earns ') + money(Math.abs(profit)) + '</b>';
  }

  /* ---------- events ---------- */
  var searchTimer;
  document.addEventListener('click', function (e) {
    var el = e.target.closest('[data-act]');
    if (!el) return;
    var act = el.getAttribute('data-act');
    if (el.tagName === 'INPUT' || el.tagName === 'SELECT') return;
    var id = +el.getAttribute('data-id');
    switch (act) {
      case 'tab': S.tab = el.getAttribute('data-v'); render(); break;
      case 'new-item': openEditor(null); break;
      case 'edit-item': openEditor(itemById(id)); break;
      case 'del-item':
        if (confirm('Delete this product and its sales history?')) {
          api('delete_item', { id: id }).then(load).then(render).then(function () { toast('Product deleted'); }).catch(function (x) { toast(x.message, 'err'); });
        }
        break;
      case 'close': closeDrawer(); E = null; break;
      case 'save': saveItem(false); break;
      case 'save-push': saveItem(true); break;
      case 'add-cost':
        E.costs.push({ label: '', amount: '', type: 'unit' });
        document.getElementById('pl-costs').innerHTML = costRows();
        refreshCalc();
        break;
      case 'del-cost':
        E.costs.splice(+el.getAttribute('data-i'), 1);
        document.getElementById('pl-costs').innerHTML = costRows();
        refreshCalc();
        break;
      case 'use-suggested':
        E.sell_price = el.getAttribute('data-v');
        document.querySelector('#pl-drawer-root [data-f="sell_price"]').value = E.sell_price;
        refreshCalc();
        break;
      case 'unlink':
        E.product_id = 0; E._pname = '';
        document.getElementById('pl-link').innerHTML = linkHtml();
        refreshCalc();
        break;
      case 'pick-product':
        E.product_id = id; E._pname = el.getAttribute('data-n');
        if (!E.name.trim()) {
          E.name = el.getAttribute('data-n');
          document.querySelector('#pl-drawer-root [data-f="name"]').value = E.name;
        }
        if (!num(E.sell_price) && num(el.getAttribute('data-p'))) {
          E.sell_price = el.getAttribute('data-p');
          document.querySelector('#pl-drawer-root [data-f="sell_price"]').value = E.sell_price;
        }
        document.getElementById('pl-link').innerHTML = linkHtml();
        refreshCalc();
        break;
      case 'add-sale':
        api('save_sale', {
          item_id: +document.getElementById('sf-item').value,
          qty: num(document.getElementById('sf-qty').value),
          unit_price: num(document.getElementById('sf-price').value),
          extra_cost: num(document.getElementById('sf-extra').value),
          sale_date: document.getElementById('sf-date').value,
          note: document.getElementById('sf-note').value
        }).then(load).then(render).then(function () { toast('Sale added'); }).catch(function (x) { toast(x.message, 'err'); });
        break;
      case 'del-sale':
        if (confirm('Delete this sale?')) {
          api('delete_sale', { id: id }).then(load).then(render).then(function () { toast('Sale deleted'); }).catch(function (x) { toast(x.message, 'err'); });
        }
        break;
    }
  });

  document.addEventListener('input', function (e) {
    var t = e.target;
    // drawer fields
    if (E && t.closest && t.closest('#pl-drawer-root')) {
      var f = t.getAttribute('data-f');
      if (f) { E[f] = t.value; refreshCalc(); return; }
      var ci = t.getAttribute('data-ci');
      if (ci !== null) { E.costs[+ci][t.getAttribute('data-cf')] = t.value; refreshCalc(); return; }
      if (t.id === 'pl-wcq') {
        clearTimeout(searchTimer);
        searchTimer = setTimeout(function () {
          api('search_products', { q: t.value }).then(function (list) {
            document.getElementById('pl-wcres').innerHTML = list.length ? '<div class="pl-suggest-list">' + list.map(function (p) {
              return '<button data-act="pick-product" data-id="' + p.id + '" data-n="' + esc(p.name) + '" data-p="' + p.price + '"><span>' + esc(p.name) + '</span><span class="pl-hint">' + (p.price ? money(p.price) : '') + '</span></button>';
            }).join('') + '</div>' : '<div class="pl-hint" style="margin-top:6px">No matching product</div>';
          }).catch(function () {});
        }, 250);
      }
      return;
    }
    // search on products tab
    if (t.getAttribute('data-act') === 'search') {
      S.q = t.value;
      var pos = t.selectionStart;
      render();
      var again = app.querySelector('[data-act="search"]');
      if (again) { again.focus(); again.setSelectionRange(pos, pos); }
      return;
    }
    // sale form live preview
    if (t.id && t.id.indexOf('sf-') === 0) updateSalePreview();
  });

  document.addEventListener('change', function (e) {
    var t = e.target;
    if (E && t.closest && t.closest('#pl-drawer-root')) {
      var ci = t.getAttribute('data-ci');
      if (ci !== null) { E.costs[+ci][t.getAttribute('data-cf')] = t.value; refreshCalc(); }
      return;
    }
    var act = t.getAttribute && t.getAttribute('data-act');
    if (act === 'range') { S.range = t.value; render(); }
    if (act === 'currency') {
      S.cur = t.value.trim() || '৳';
      api('save_currency', { currency: S.cur }).then(function () { render(); toast('Currency saved'); });
    }
    if (t.id === 'sf-item') {
      var it = itemById(+t.value);
      if (it) document.getElementById('sf-price').value = it.sell_price || '';
      updateSalePreview();
    }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && document.getElementById('pl-drawer-root')) { closeDrawer(); E = null; }
  });

  /* ---------- boot ---------- */
  load().then(render).catch(function (e) {
    app.innerHTML = '<div class="pl-card"><div class="pl-empty"><b>Could not load data</b>' + esc(e.message) + '</div></div>';
  });
})();
