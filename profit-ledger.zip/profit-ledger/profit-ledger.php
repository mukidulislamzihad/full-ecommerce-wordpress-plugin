<?php
/**
 * Plugin Name: Profit Ledger
 * Description: Product cost, pricing and profit/loss tracking in one place. Add purchase cost and every extra cost, decide the selling price, and see profit or loss.
 * Version: 1.0.0
 * Author: You
 * Text Domain: profit-ledger
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PL_VERSION', '1.0.0' );
define( 'PL_URL', plugin_dir_url( __FILE__ ) );

function pl_tables() {
	global $wpdb;
	return array(
		'items' => $wpdb->prefix . 'pl_items',
		'sales' => $wpdb->prefix . 'pl_sales',
	);
}

register_activation_hook( __FILE__, 'pl_activate' );
function pl_activate() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$t       = pl_tables();
	$charset = $wpdb->get_charset_collate();

	dbDelta( "CREATE TABLE {$t['items']} (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		name varchar(255) NOT NULL,
		product_id bigint(20) unsigned NOT NULL DEFAULT 0,
		batch_qty decimal(14,2) NOT NULL DEFAULT 1,
		unit_cost decimal(14,2) NOT NULL DEFAULT 0,
		costs longtext NULL,
		sell_price decimal(14,2) NOT NULL DEFAULT 0,
		target_margin decimal(6,2) NOT NULL DEFAULT 20,
		note text NULL,
		created_at datetime NOT NULL,
		PRIMARY KEY  (id)
	) $charset;" );

	dbDelta( "CREATE TABLE {$t['sales']} (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		item_id bigint(20) unsigned NOT NULL,
		qty decimal(14,2) NOT NULL DEFAULT 1,
		unit_price decimal(14,2) NOT NULL DEFAULT 0,
		unit_cost decimal(14,2) NOT NULL DEFAULT 0,
		extra_cost decimal(14,2) NOT NULL DEFAULT 0,
		sale_date date NOT NULL,
		note varchar(255) NULL,
		PRIMARY KEY  (id),
		KEY item_id (item_id)
	) $charset;" );

	add_option( 'pl_currency', '৳' );
}

add_action( 'admin_menu', function () {
	add_menu_page(
		'Profit Ledger',
		'Profit Ledger',
		'manage_options',
		'profit-ledger',
		'pl_render_page',
		'dashicons-chart-area',
		56
	);
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'toplevel_page_profit-ledger' !== $hook ) {
		return;
	}
	wp_enqueue_style( 'pl-admin', PL_URL . 'assets/admin.css', array(), PL_VERSION );
	wp_enqueue_script( 'pl-admin', PL_URL . 'assets/admin.js', array(), PL_VERSION, true );
	wp_localize_script( 'pl-admin', 'PL', array(
		'ajax'     => admin_url( 'admin-ajax.php' ),
		'nonce'    => wp_create_nonce( 'pl_nonce' ),
		'currency' => get_option( 'pl_currency', '৳' ),
		'wc'       => class_exists( 'WooCommerce' ),
		'today'    => current_time( 'Y-m-d' ),
	) );
} );

function pl_render_page() {
	echo '<div class="wrap pl-wrap"><div id="pl-app" class="pl-app"><div class="pl-loading">Loading…</div></div></div>';
}

/* ---------- helpers ---------- */

function pl_num( $v ) {
	return round( (float) $v, 2 );
}

/**
 * Landed cost per unit = purchase cost + per-unit extras + (batch extras / batch qty)
 */
function pl_landed_cost( $item ) {
	$qty   = max( 0.0001, (float) $item['batch_qty'] );
	$total = (float) $item['unit_cost'];
	foreach ( (array) $item['costs'] as $c ) {
		$amt = (float) $c['amount'];
		$total += ( 'batch' === $c['type'] ) ? $amt / $qty : $amt;
	}
	return round( $total, 2 );
}

function pl_format_item( $row ) {
	$row['id']            = (int) $row['id'];
	$row['product_id']    = (int) $row['product_id'];
	$row['batch_qty']     = (float) $row['batch_qty'];
	$row['unit_cost']     = (float) $row['unit_cost'];
	$row['sell_price']    = (float) $row['sell_price'];
	$row['target_margin'] = (float) $row['target_margin'];
	$decoded              = json_decode( (string) $row['costs'], true );
	$row['costs']         = is_array( $decoded ) ? $decoded : array();
	return $row;
}

function pl_format_sale( $row ) {
	$row['id']         = (int) $row['id'];
	$row['item_id']    = (int) $row['item_id'];
	$row['qty']        = (float) $row['qty'];
	$row['unit_price'] = (float) $row['unit_price'];
	$row['unit_cost']  = (float) $row['unit_cost'];
	$row['extra_cost'] = (float) $row['extra_cost'];
	return $row;
}

/* ---------- API ---------- */

add_action( 'wp_ajax_pl_api', 'pl_api' );
function pl_api() {
	check_ajax_referer( 'pl_nonce', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'Not allowed', 403 );
	}

	global $wpdb;
	$t    = pl_tables();
	$op   = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
	$data = array();
	if ( isset( $_POST['data'] ) ) {
		$decoded = json_decode( wp_unslash( $_POST['data'] ), true );
		$data    = is_array( $decoded ) ? $decoded : array();
	}

	switch ( $op ) {

		case 'load':
			$items = $wpdb->get_results( "SELECT * FROM {$t['items']} ORDER BY id DESC", ARRAY_A );
			$sales = $wpdb->get_results( "SELECT * FROM {$t['sales']} ORDER BY sale_date DESC, id DESC", ARRAY_A );
			wp_send_json_success( array(
				'items' => array_map( 'pl_format_item', (array) $items ),
				'sales' => array_map( 'pl_format_sale', (array) $sales ),
			) );
			break;

		case 'save_item':
			$costs = array();
			foreach ( (array) ( $data['costs'] ?? array() ) as $c ) {
				$label = sanitize_text_field( $c['label'] ?? '' );
				$amt   = pl_num( $c['amount'] ?? 0 );
				if ( '' === $label && 0.0 === $amt ) {
					continue;
				}
				$costs[] = array(
					'label'  => $label,
					'amount' => $amt,
					'type'   => ( isset( $c['type'] ) && 'batch' === $c['type'] ) ? 'batch' : 'unit',
				);
			}
			$name = sanitize_text_field( $data['name'] ?? '' );
			if ( '' === $name ) {
				wp_send_json_error( 'Product name is required.' );
			}
			$row = array(
				'name'          => $name,
				'product_id'    => absint( $data['product_id'] ?? 0 ),
				'batch_qty'     => max( 1, pl_num( $data['batch_qty'] ?? 1 ) ),
				'unit_cost'     => pl_num( $data['unit_cost'] ?? 0 ),
				'costs'         => wp_json_encode( $costs ),
				'sell_price'    => pl_num( $data['sell_price'] ?? 0 ),
				'target_margin' => pl_num( $data['target_margin'] ?? 20 ),
				'note'          => sanitize_textarea_field( $data['note'] ?? '' ),
			);
			$id = absint( $data['id'] ?? 0 );
			if ( $id ) {
				$wpdb->update( $t['items'], $row, array( 'id' => $id ) );
			} else {
				$row['created_at'] = current_time( 'mysql' );
				$wpdb->insert( $t['items'], $row );
				$id = (int) $wpdb->insert_id;
			}
			$saved = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['items']} WHERE id = %d", $id ), ARRAY_A );
			wp_send_json_success( pl_format_item( $saved ) );
			break;

		case 'delete_item':
			$id = absint( $data['id'] ?? 0 );
			$wpdb->delete( $t['items'], array( 'id' => $id ) );
			$wpdb->delete( $t['sales'], array( 'item_id' => $id ) );
			wp_send_json_success( true );
			break;

		case 'save_sale':
			$item_id = absint( $data['item_id'] ?? 0 );
			$item    = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['items']} WHERE id = %d", $item_id ), ARRAY_A );
			if ( ! $item ) {
				wp_send_json_error( 'Choose a product first.' );
			}
			$item = pl_format_item( $item );
			$date = sanitize_text_field( $data['sale_date'] ?? '' );
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
				$date = current_time( 'Y-m-d' );
			}
			$wpdb->insert( $t['sales'], array(
				'item_id'    => $item_id,
				'qty'        => max( 0.01, pl_num( $data['qty'] ?? 1 ) ),
				'unit_price' => pl_num( $data['unit_price'] ?? $item['sell_price'] ),
				'unit_cost'  => pl_landed_cost( $item ), // snapshot: later cost edits do not rewrite history
				'extra_cost' => pl_num( $data['extra_cost'] ?? 0 ),
				'sale_date'  => $date,
				'note'       => sanitize_text_field( $data['note'] ?? '' ),
			) );
			$saved = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['sales']} WHERE id = %d", $wpdb->insert_id ), ARRAY_A );
			wp_send_json_success( pl_format_sale( $saved ) );
			break;

		case 'delete_sale':
			$wpdb->delete( $t['sales'], array( 'id' => absint( $data['id'] ?? 0 ) ) );
			wp_send_json_success( true );
			break;

		case 'save_currency':
			update_option( 'pl_currency', sanitize_text_field( $data['currency'] ?? '৳' ) );
			wp_send_json_success( true );
			break;

		case 'search_products':
			if ( ! class_exists( 'WooCommerce' ) ) {
				wp_send_json_success( array() );
			}
			$posts = get_posts( array(
				'post_type'   => 'product',
				's'           => sanitize_text_field( $data['q'] ?? '' ),
				'numberposts' => 8,
				'post_status' => array( 'publish', 'draft', 'private' ),
			) );
			$out = array();
			foreach ( $posts as $p ) {
				$price = get_post_meta( $p->ID, '_regular_price', true );
				$out[] = array(
					'id'    => $p->ID,
					'name'  => $p->post_title,
					'price' => (float) $price,
				);
			}
			wp_send_json_success( $out );
			break;

		case 'push_price':
			if ( ! function_exists( 'wc_get_product' ) ) {
				wp_send_json_error( 'WooCommerce is not active.' );
			}
			$product = wc_get_product( absint( $data['product_id'] ?? 0 ) );
			if ( ! $product ) {
				wp_send_json_error( 'Linked product not found.' );
			}
			$product->set_regular_price( (string) pl_num( $data['price'] ?? 0 ) );
			$product->save();
			wp_send_json_success( true );
			break;
	}

	wp_send_json_error( 'Unknown action' );
}
