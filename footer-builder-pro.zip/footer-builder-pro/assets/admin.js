jQuery(function($){
 $('.fbp-color').wpColorPicker();
 $(document).on('click','.fbp-del',function(){$(this).closest('.fbp-row').remove()});
 $(document).on('click','.fbp-add',function(){var k=$(this).data('k'),h=$('#fbp-t-'+k).html().replace(/__i__/g,Date.now());$('.fbp-rep[data-k="'+k+'"]').append(h)});
 $(document).on('click','.fbp-pick',function(){var i=$(this).prev('input'),f=wp.media({multiple:false});f.on('select',function(){i.val(f.state().get('selection').first().toJSON().url)});f.open()});
 $('.fbp-copy').on('click',function(){navigator.clipboard&&navigator.clipboard.writeText('[fbp_footer]');$(this).text('Copied')});
});
