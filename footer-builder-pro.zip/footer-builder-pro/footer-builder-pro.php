<?php
/*
Plugin Name: Footer Builder Pro
Description: SunFry style footer. Shortcode [fbp_footer] ba Elementor Shortcode widget diye use korun. Full admin customizable, 320px mobile ready.
Version: 1.0.0
Text Domain: fbp
*/
if(!defined('ABSPATH'))exit;
define('FBP_URL',plugin_dir_url(__FILE__));define('FBP_VER','1.0.0');
final class FBP{
const OPT='fbp_settings';
static function init(){
 add_action('admin_menu',function(){add_menu_page('Footer Builder','Footer Builder','manage_options','fbp',[__CLASS__,'page'],'dashicons-align-center',59);});
 add_action('admin_init',function(){register_setting('fbp_group',self::OPT,['sanitize_callback'=>[__CLASS__,'san']]);});
 add_action('admin_enqueue_scripts',function($h){if($h!=='toplevel_page_fbp')return;wp_enqueue_media();wp_enqueue_style('wp-color-picker');wp_enqueue_style('fbp-a',FBP_URL.'assets/admin.css',[],FBP_VER);wp_enqueue_script('fbp-a',FBP_URL.'assets/admin.js',['jquery','wp-color-picker'],FBP_VER,true);});
 add_action('wp_enqueue_scripts',function(){$s=self::get();wp_enqueue_style('fbp',FBP_URL.'assets/front.css',[],FBP_VER);if($s['custom_css'])wp_add_inline_style('fbp',$s['custom_css']);});
 add_shortcode('fbp_footer',[__CLASS__,'render']);
}
static function rows($s){$r=[];foreach(explode(';',$s) as $x){$a=array_map('trim',explode('|',$x))+['','','',''];if($a[0])$r[]=['a'=>$a[0],'b'=>$a[1],'c'=>$a[2]];}return $r;}
static function d(){return [
 'logo_img'=>'','logo_text'=>'SunFry','logo_h'=>44,
 'about'=>'Sun fry আপনার বিশ্বস্ত অনলাইন গ্রোসারি ও অর্গানিক ফুড স্টোর। আমরা মানসম্মত, খাঁটি ও দৈনন্দিন প্রয়োজনীয় খাদ্যপণ্য সহজে আপনার দোরগোড়ায় পৌঁছে দিতে প্রতিশ্রুতিবদ্ধ।',
 'phone'=>'09638955596','hours'=>'9:00 AM – 11:00 PM','email'=>'support@falaqfood.com',
 'feat'=>self::rows('headset|২৪/৭ লাইভ চ্যাট|যেকোনো সময় ইনস্ট্যান্ট সহায়তা পেতে আমাদের সাথে যোগাযোগ করুন।;lock|নিরাপদ পেমেন্ট|নির্ভরযোগ্য ও নিরাপদ পেমেন্ট ব্যবস্থার নিশ্চয়তা।;truck|দ্রুত ডেলিভারি|বিশ্বস্ত ডেলিভারি সার্ভিসের মাধ্যমে দ্রুত পৌঁছে যায়।;leaf|উচ্চ মানের প্রোডাক্ট|প্রাকৃতিক উপাদানে তৈরি বিশুদ্ধ ও কার্যকর পণ্য।'),
 't1'=>'Customer Service','l1'=>self::rows('Contact Us|/contact-us/;Track Order|/track-order/;Return & Exchange|/return-exchange/;Shipping Information|/shipping-information/;Privacy Policy|/privacy-policy/'),
 't2'=>'Useful Links','l2'=>self::rows('All Products|/shop/;About Us|/about-us/;Corporate Deals|/corporate-deals/;FAQ|/faq/;Terms & Conditions|/terms-conditions/'),
 't3'=>'Follow Us','sub'=>'Stay connected with us','fb'=>'#','x'=>'#','yt'=>'#','ig'=>'#','tk'=>'','wa'=>'',
 'pay_t'=>'We Accept','pay_img'=>'',
 'copy'=>'© {year} FalaqFood','by'=>'Design by','by_name'=>'Zihad','by_url'=>'',
 'accent'=>'','card'=>'','bar_text'=>'','text'=>'','bg'=>'','full'=>1,'custom_css'=>''];}
static function get(){$o=get_option(self::OPT);return wp_parse_args(is_array($o)?$o:[],self::d());}
static function san($in){$o=[];
 foreach(['logo_text','phone','hours','email','t1','t2','t3','sub','pay_t','copy','by','by_name'] as $k)$o[$k]=sanitize_text_field($in[$k]??'');
 $o['about']=sanitize_textarea_field($in['about']??'');
 foreach(['logo_img','pay_img','by_url','fb','x','yt','ig','tk','wa'] as $k)$o[$k]=esc_url_raw($in[$k]??'');
 foreach(['accent','card','bar_text','text','bg'] as $k)$o[$k]=sanitize_hex_color($in[$k]??'')?:'';
 $o['logo_h']=max(16,min(200,intval($in['logo_h']??44)));$o['full']=empty($in['full'])?0:1;$o['custom_css']=wp_strip_all_tags($in['custom_css']??'');
 foreach(['feat','l1','l2'] as $k){$o[$k]=[];foreach((array)($in[$k]??[]) as $r){if(empty($r['a']))continue;$o[$k][]=['a'=>sanitize_text_field($r['a']),'b'=>$k==='feat'?sanitize_text_field($r['b']??''):esc_url_raw($r['b']??''),'c'=>sanitize_text_field($r['c']??'')];}}
 return $o;}
static function ic($n){$p=[
'headset'=>'<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/><path d="M19 20c0 1.5-2 2-5 2"/>',
'lock'=>'<rect x="5" y="11" width="14" height="10" rx="2" fill="currentColor"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
'truck'=>'<path d="M2 6h11v10H2zM13 9h4l4 3v4h-8"/><circle cx="7" cy="17.5" r="1.8" fill="#fff"/><circle cx="17" cy="17.5" r="1.8" fill="#fff"/>',
'leaf'=>'<path d="M12 21v-9M12 12C12 7 9 5 5 5c0 4 2 7 7 7zM12 14c0-4 3-6 7-6 0 4-2 6-7 6z" fill="currentColor"/>',
'gift'=>'<rect x="3" y="8" width="18" height="4"/><path d="M5 12v9h14v-9M12 8v13M12 8c-3 0-5-1-4-3s4 0 4 3zm0 0c3 0 5-1 4-3s-4 0-4 3z"/>',
'shield'=>'<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/>',
'refresh'=>'<path d="M20 11a8 8 0 0 0-14-4L4 9M4 4v5h5M4 13a8 8 0 0 0 14 4l2-2M20 20v-5h-5"/>',
'star'=>'<path d="m12 3 2.7 5.6 6.1.8-4.4 4.3 1 6.1L12 17l-5.4 2.8 1-6.1L3.2 9.4l6.1-.8z"/>',
'phone'=>'<path d="M6.6 3h3l1.5 4-2 1.5a11 11 0 0 0 5.4 5.4l1.5-2 4 1.5v3A2.5 2.5 0 0 1 17 19 14 14 0 0 1 5 7a2.5 2.5 0 0 1 1.600-4z" fill="currentColor"/>',
'mail'=>'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
'chev'=>'<path d="m9 6 6 6-6 6"/>'];
 return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.($p[$n]??$p['star']).'</svg>';}
static function soc($n){$p=[
'fb'=>'<path d="M14 8h3V4h-3a4 4 0 0 0-4 4v2H7v4h3v8h4v-8h3l1-4h-4V8.500c0-.3.2-.5.5-.5z" fill="currentColor" stroke="none"/>',
'x'=>'<path d="M17.800 3h3l-6.600 7.500L22 21h-6l-4.700-6.100L5.900 21h-3l7-8L2 3h6.200l4.200 5.600zM16.700 19.200h1.700L7.400 4.700H5.600z" fill="currentColor" stroke="none"/>',
'yt'=>'<rect x="3" y="6" width="18" height="12" rx="3.500" fill="currentColor" stroke="none"/><path d="m10.500 9.500 4 2.500-4 2.500z" fill="#e0211f" stroke="none"/>',
'ig'=>'<rect x="4" y="4" width="16" height="16" rx="4.500"/><circle cx="12" cy="12" r="3.500"/><circle cx="16.800" cy="7.200" r=".8" fill="currentColor"/>',
'tk'=>'<path d="M14 3v11.500a3.500 3.500 0 1 1-3.500-3.500M14 3c.3 2.500 1.800 4 4.500 4.200" />',
'wa'=>'<path d="M4 20l1.200-4.200A8 8 0 1 1 8.400 18.900z"/><path d="M9 9c0 3 3 6 6 6l1-1.500-2-1-1 .7c-.8-.4-1.600-1.200-2-2l.7-1-1-2z" fill="currentColor" stroke="none"/>'];
 return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.$p[$n].'</svg>';}
static function u($u){if(!$u)return '#';return $u[0]==='/'?home_url($u):$u;}
static function links($a){$h='';foreach((array)$a as $r)$h.='<a href="'.esc_url(self::u($r['b'])).'">'.self::ic('chev').'<span>'.esc_html($r['a']).'</span></a>';return $h;}
static function render(){
 $s=self::get();$v='';foreach(['accent'=>'--a','card'=>'--cd','bar_text'=>'--bt','text'=>'--tx','bg'=>'--bg'] as $k=>$c)if(!empty($s[$k]))$v.=$c.':'.$s[$k].';';
 $v.='--lh:'.intval($s['logo_h']).'px;';
 $logo=$s['logo_img']?'<img src="'.esc_url($s['logo_img']).'" alt="'.esc_attr($s['logo_text']).'">':'<b class="fbp-lt">'.esc_html($s['logo_text']).'</b>';
 $h='<footer class="fbp'.($s['full']?' fbp-full':'').'" style="'.esc_attr($v).'">';
 if($s['feat']){$h.='<div class="fbp-fs"><div class="fbp-w fbp-feat">';foreach($s['feat'] as $f)$h.='<div class="fbp-fc"><span class="fbp-fi">'.self::ic($f['c']).'</span><div><h5>'.esc_html($f['a']).'</h5><p>'.esc_html($f['b']).'</p></div></div>';$h.='</div></div>';}
 $h.='<div class="fbp-w fbp-main"><div class="fbp-col fbp-brand"><a class="fbp-logo" href="'.esc_url(home_url('/')).'">'.$logo.'</a>';
 if($s['about'])$h.='<p class="fbp-about">'.esc_html($s['about']).'</p>';
 if($s['phone'])$h.='<a class="fbp-ct" href="tel:'.esc_attr(preg_replace('/[^0-9+]/','',$s['phone'])).'">'.self::ic('phone').'<span><b>'.esc_html($s['phone']).'</b>'.($s['hours']?'<small>'.esc_html($s['hours']).'</small>':'').'</span></a>';
 if($s['email'])$h.='<a class="fbp-ct" href="mailto:'.esc_attr($s['email']).'">'.self::ic('mail').'<span><b>'.esc_html($s['email']).'</b></span></a>';
 $h.='</div>';
 foreach([[1,'t1','l1'],[2,'t2','l2']] as $c)$h.='<div class="fbp-col fbp-lc"><h4>'.esc_html($s[$c[1]]).'</h4><nav>'.self::links($s[$c[2]]).'</nav></div>';
 $so='';foreach(['fb'=>'Facebook','x'=>'X','yt'=>'YouTube','ig'=>'Instagram','tk'=>'TikTok','wa'=>'WhatsApp'] as $k=>$n)if($s[$k])$so.='<a class="fbp-s fbp-s-'.$k.'" href="'.esc_url($s[$k]).'" target="_blank" rel="noopener" aria-label="'.$n.'">'.self::soc($k).'</a>';
 $h.='<div class="fbp-col fbp-fol"><h4>'.esc_html($s['t3']).'</h4>'.($s['sub']?'<p class="fbp-sub">'.esc_html($s['sub']).'</p>':'').($so?'<div class="fbp-so">'.$so.'</div>':'').($s['pay_img']?'<h6>'.esc_html($s['pay_t']).'</h6><img class="fbp-pay" src="'.esc_url($s['pay_img']).'" alt="'.esc_attr($s['pay_t']).'">':'').'</div></div>';
 $by=$s['by_name']?esc_html($s['by']).' '.($s['by_url']?'<a href="'.esc_url($s['by_url']).'" target="_blank" rel="noopener">':'<span>').'<b>'.esc_html($s['by_name']).'</b>'.($s['by_url']?'</a>':'</span>'):esc_html($s['by']);
 $h.='<div class="fbp-bot"><div class="fbp-w fbp-bw"><span>'.esc_html(str_replace('{year}',date('Y'),$s['copy'])).'</span><span>'.$by.'</span></div></div></footer>';
 return $h;}
/* admin */
static function fld($k,$l,$t='text',$help=''){$s=self::get();$v=$s[$k]??'';$n=self::OPT."[$k]";echo '<div class="fbp-f"><label>'.esc_html($l).'</label>';
 if($t==='media')echo '<div class="fbp-media"><input type="text" name="'.$n.'" value="'.esc_attr($v).'"><button type="button" class="button fbp-pick">Choose</button>'.($v?'<img src="'.esc_url($v).'" alt="">':'').'</div>';
 elseif($t==='color')echo '<input type="text" class="fbp-color" name="'.$n.'" value="'.esc_attr($v).'">';
 elseif($t==='check')echo '<label class="fbp-sw"><input type="checkbox" name="'.$n.'" value="1" '.checked($v,1,false).'></label>';
 elseif($t==='area')echo '<textarea name="'.$n.'" rows="4">'.esc_textarea($v).'</textarea>';
 elseif($t==='num')echo '<input type="number" name="'.$n.'" value="'.esc_attr($v).'" min="16" max="200">';
 else echo '<input type="text" name="'.$n.'" value="'.esc_attr($v).'">';
 if($help)echo '<p>'.esc_html($help).'</p>';echo '</div>';}
static function row($k,$i,$r,$feat){$n=self::OPT."[$k][$i]";$r=$r+['a'=>'','b'=>'','c'=>''];
 echo '<div class="fbp-row">';
 if($feat){echo '<select name="'.$n.'[c]">';foreach(['headset','lock','truck','leaf','gift','shield','refresh','star'] as $o)echo '<option value="'.$o.'"'.selected($r['c'],$o,false).'>'.$o.'</option>';echo '</select><input name="'.$n.'[a]" placeholder="Title" value="'.esc_attr($r['a']).'"><input name="'.$n.'[b]" placeholder="Description" value="'.esc_attr($r['b']).'">';}
 else echo '<input name="'.$n.'[a]" placeholder="Label" value="'.esc_attr($r['a']).'"><input name="'.$n.'[b]" placeholder="URL (/page/ or https://…)" value="'.esc_attr($r['b']).'">';
 echo '<button type="button" class="fbp-del">×</button></div>';}
static function rep($k,$t,$feat=false){$s=self::get();echo '<div class="fbp-rep" data-k="'.$k.'">';foreach((array)$s[$k] as $i=>$r)self::row($k,$i,$r,$feat);echo '</div><button type="button" class="button fbp-add" data-k="'.$k.'">+ Add</button><template id="fbp-t-'.$k.'">';self::row($k,'__i__',[],$feat);echo '</template>';}
static function page(){?>
<div class="wrap fbp-admin"><h1>Footer Builder Pro</h1><p>Shortcode: <code>[fbp_footer]</code> <button type="button" class="button fbp-copy">Copy</button> &nbsp; Elementor → Shortcode widget → paste.</p>
<form method="post" action="options.php"><?php settings_fields('fbp_group');?>
<div class="fbp-card"><h3>Top Feature Cards</h3><?php self::rep('feat','',true);?></div>
<div class="fbp-card"><h3>Brand Column</h3><?php self::fld('logo_img','Logo image','media','Khali rakhle text logo.');self::fld('logo_text','Logo text');self::fld('logo_h','Logo height (px)','num');self::fld('about','About text','area');self::fld('phone','Phone');self::fld('hours','Opening hours');self::fld('email','Email');?></div>
<div class="fbp-card"><h3>Column 2</h3><?php self::fld('t1','Title');self::rep('l1','');?></div>
<div class="fbp-card"><h3>Column 3</h3><?php self::fld('t2','Title');self::rep('l2','');?></div>
<div class="fbp-card"><h3>Column 4 - Follow & Payment</h3><?php self::fld('t3','Title');self::fld('sub','Sub text');foreach(['fb'=>'Facebook','x'=>'X (Twitter)','yt'=>'YouTube','ig'=>'Instagram','tk'=>'TikTok','wa'=>'WhatsApp'] as $k=>$n)self::fld($k,$n.' URL','text','Khali = dekhabe na');self::fld('pay_t','Payment title');self::fld('pay_img','Payment methods image','media','Apnar payment logo-r ek ta image upload korun.');?></div>
<div class="fbp-card"><h3>Bottom Bar</h3><?php self::fld('copy','Copyright text','text','{year} = auto year');self::fld('by','Credit text');self::fld('by_name','Credit name (bold)');self::fld('by_url','Credit link');?></div>
<div class="fbp-card"><h3>Colors & Layout</h3><?php self::fld('accent','Accent (line, bottom bar, titles)','color');self::fld('card','Feature card background','color');self::fld('bar_text','Bottom bar text','color');self::fld('text','Text color','color');self::fld('bg','Footer background','color');self::fld('full','Full width','check');?></div>
<div class="fbp-card"><h3>Custom CSS</h3><p>Selectors: <code>.fbp</code> <code>.fbp-main</code> <code>.fbp-bot</code> <code>.fbp-fc</code></p><textarea name="fbp_settings[custom_css]" rows="10" spellcheck="false"><?php echo esc_textarea(self::get()['custom_css']);?></textarea></div>
<?php submit_button('Save Changes','primary large');?></form></div><?php }
}
FBP::init();
