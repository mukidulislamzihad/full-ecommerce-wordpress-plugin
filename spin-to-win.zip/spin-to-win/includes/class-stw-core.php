<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class STW_Core {

	const CPT = 'stw_campaign';

	static function boot() {
		add_action( 'init', array( __CLASS__, 'register_cpt' ) );
	}

	static function register_cpt() {
		register_post_type( self::CPT, array(
			'public'     => false,
			'show_ui'    => false,
			'rewrite'    => false,
			'query_var'  => false,
			'supports'   => array( 'title' ),
		) );
	}

	static function maybe_upgrade() {
		if ( get_option( 'stw_db_version' ) !== STW_VERSION ) {
			self::activate();
		}
	}

	static function activate() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();

		dbDelta( "CREATE TABLE {$wpdb->prefix}stw_leads (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  campaign_id bigint(20) unsigned NOT NULL DEFAULT 0,
  email varchar(190) NOT NULL DEFAULT '',
  phone varchar(40) NOT NULL DEFAULT '',
  prize varchar(190) NOT NULL DEFAULT '',
  coupon varchar(60) NOT NULL DEFAULT '',
  ip varchar(64) NOT NULL DEFAULT '',
  consent tinyint(1) NOT NULL DEFAULT 0,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY campaign_id (campaign_id),
  KEY email (email),
  KEY ip (ip)
) $c;" );

		dbDelta( "CREATE TABLE {$wpdb->prefix}stw_events (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  campaign_id bigint(20) unsigned NOT NULL DEFAULT 0,
  event varchar(20) NOT NULL DEFAULT '',
  created_at datetime NOT NULL,
  PRIMARY KEY  (id),
  KEY camp_event (campaign_id,event),
  KEY created_at (created_at)
) $c;" );

		update_option( 'stw_db_version', STW_VERSION );
		self::register_cpt();
		if ( ! self::get_campaigns() ) {
			self::save_campaign( 0, 'Spin to Win', self::defaults() );
		}
	}

	/* ---------- Defaults ---------- */

	static function fonts() {
		return array(
			'inherit'   => 'Theme default',
			'system-ui' => 'Apple / System style',
			'Arial'     => 'Arial',
			'Georgia'   => 'Georgia',
			'Verdana'   => 'Verdana',
			'Tahoma'    => 'Tahoma',
			'Trebuchet MS' => 'Trebuchet MS',
			'Courier New'  => 'Courier New',
			'Impact'    => 'Impact',
		);
	}

	static function defaults() {
		$p = '#e63946';
		$s = '#1d3557';
		return array(
			'status'            => 'active',
			'heading'           => 'Spin to Win!',
			'subheading'        => 'Try your luck and win an exclusive discount.',
			'button_text'       => 'SPIN NOW',
			'win_title'         => 'Congratulations!',
			'win_text'          => 'You won {prize}. Use this code at checkout:',
			'lose_title'        => 'Oh no!',
			'lose_text'         => 'Better luck next time. Thanks for playing!',
			'already_text'      => 'You have already played. Thanks for visiting!',
			'expiry_text'       => 'Valid until {date}',
			'copy_text'         => 'Copy',
			'copied_text'       => 'Copied!',
			'shop_button'       => 'Start Shopping',
			'no_thanks'         => 'No thanks',
			'show_no_thanks'    => 1,
			'tab_text'          => '🎁 Spin & Win',
			'err_email'         => 'Please enter a valid email address.',
			'err_phone'         => 'Please enter a valid phone number.',
			'err_consent'       => 'Please accept the consent checkbox.',
			'err_generic'       => 'Something went wrong. Please try again.',
			'collect_email'     => 'required',
			'collect_phone'     => 'off',
			'email_placeholder' => 'Your email address',
			'phone_placeholder' => 'Your phone number',
			'consent_on'        => 1,
			'consent_text'      => 'I agree to receive promotional messages and accept the privacy policy.',
			'colors'            => array(
				'primary'     => $p,
				'secondary'   => $s,
				'text'        => '#ffffff',
				'bg'          => '#ffffff',
				'button'      => $p,
				'button_text' => '#ffffff',
				'overlay'     => '#000000',
				'heading'     => $p,
				'subtext'     => '#555555',
				'body_text'   => '#222222',
				'panel_from'  => $s,
				'panel_to'    => $p,
				'pointer'     => '#f4c430',
				'ring'        => '#ffffff',
				'peg'         => '#f4c430',
				'hub'         => '#ffffff',
				'input_bg'    => '#ffffff',
				'input_text'  => '#222222',
				'input_border'=> '#e2e2e2',
				'error'       => '#c62828',
				'close'       => '#333333',
				'tab_bg'      => $p,
				'tab_text'    => '#ffffff',
				'nt_bg'       => '#eeeeee',
				'nt_text'     => '#555555',
			),
			'style'             => array(
				'font'         => 'inherit',
				'max_width'    => 860,
				'radius'       => 22,
				'btn_radius'   => 12,
				'input_radius' => 12,
				'heading_size' => 32,
				'sub_size'     => 16,
				'btn_size'     => 17,
				'wheel_size'   => 370,
				'wheel_side'   => 'left',
				'spin_time'    => 5,
				'shadow'       => 1,
				'glass'        => 0,
				'show_close'   => 0,
			),
			'custom_css'        => '',
			'segments'          => array(
				array( 'label' => '10% OFF',       'type' => 'coupon', 'dtype' => 'percent',       'amount' => 10, 'weight' => 20, 'color' => $p ),
				array( 'label' => 'Try Again',     'type' => 'none',   'dtype' => 'percent',       'amount' => 0,  'weight' => 25, 'color' => $s ),
				array( 'label' => '15% OFF',       'type' => 'coupon', 'dtype' => 'percent',       'amount' => 15, 'weight' => 10, 'color' => $p ),
				array( 'label' => 'Free Shipping', 'type' => 'coupon', 'dtype' => 'free_shipping', 'amount' => 0,  'weight' => 10, 'color' => $s ),
				array( 'label' => '5% OFF',        'type' => 'coupon', 'dtype' => 'percent',       'amount' => 5,  'weight' => 25, 'color' => $p ),
				array( 'label' => 'No Luck',       'type' => 'none',   'dtype' => 'percent',       'amount' => 0,  'weight' => 10, 'color' => $s ),
			),
			'trigger_delay'     => 5,
			'trigger_scroll'    => 0,
			'trigger_exit'      => 1,
			'devices'           => array( 'desktop', 'tablet', 'mobile' ),
			'pages'             => 'all',
			'page_ids'          => '',
			'exclude_ids'       => '',
			'hide_logged_in'    => 0,
			'closed_days'       => 1,
			'reopen_tab'        => 1,
			'tab_position'      => 'left',
			'coupon_prefix'     => 'SPIN-',
			'coupon_expiry'     => 7,
			'coupon_min'        => '',
			'coupon_individual' => 0,
			'coupon_restrict_email' => 0,
			'email_coupon'      => 1,
			'email_subject'     => 'Your discount code from {site}',
			'email_body'        => "Hi,\n\nCongratulations! You won {prize}.\nYour coupon code: {code}\n{expiry}\n\nThanks,\n{site}",
			'antispam'          => 'email',
			'ip_max'            => 3,
			'cookie_days'       => 30,
		);
	}

	static function settings() {
		return wp_parse_args( get_option( 'stw_settings', array() ), array(
			'trust_proxy'         => 0,
			'delete_on_uninstall' => 0,
		) );
	}

	/* ---------- Sanitizing ---------- */

	static function sanitize( $in ) {
		$d = self::defaults();
		$o = array();

		$text = array( 'heading', 'subheading', 'button_text', 'win_title', 'win_text', 'lose_title', 'lose_text', 'already_text', 'expiry_text', 'copy_text', 'copied_text', 'shop_button', 'no_thanks', 'tab_text', 'err_email', 'err_phone', 'err_consent', 'err_generic', 'email_placeholder', 'phone_placeholder', 'consent_text', 'email_subject' );
		foreach ( $text as $k ) {
			$o[ $k ] = isset( $in[ $k ] ) ? sanitize_text_field( $in[ $k ] ) : $d[ $k ];
		}
		$o['email_body'] = isset( $in['email_body'] ) ? sanitize_textarea_field( $in['email_body'] ) : $d['email_body'];
		$o['coupon_prefix'] = strtoupper( preg_replace( '/[^A-Za-z0-9_-]/', '', isset( $in['coupon_prefix'] ) ? (string) $in['coupon_prefix'] : '' ) );
		$o['status'] = ( isset( $in['status'] ) && 'active' === $in['status'] ) ? 'active' : 'inactive';

		foreach ( array( 'show_no_thanks', 'consent_on', 'hide_logged_in', 'reopen_tab', 'coupon_individual', 'coupon_restrict_email', 'email_coupon', 'trigger_exit' ) as $k ) {
			$o[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
		}

		$pick = function ( $k, $allowed, $def ) use ( $in ) {
			$v = isset( $in[ $k ] ) ? $in[ $k ] : $def;
			return in_array( $v, $allowed, true ) ? $v : $def;
		};
		$o['collect_email'] = $pick( 'collect_email', array( 'required', 'optional', 'off' ), 'required' );
		$o['collect_phone'] = $pick( 'collect_phone', array( 'required', 'optional', 'off' ), 'off' );
		$o['antispam']      = $pick( 'antispam', array( 'cookie', 'email', 'ip' ), 'email' );
		$o['pages']         = $pick( 'pages', array( 'all', 'home', 'shop', 'include' ), 'all' );
		$o['tab_position']  = $pick( 'tab_position', array( 'left', 'right' ), 'left' );

		$num = function ( $k, $min, $max ) use ( $in, $d ) {
			return ( isset( $in[ $k ] ) && is_numeric( $in[ $k ] ) ) ? max( $min, min( $max, (int) $in[ $k ] ) ) : $d[ $k ];
		};
		$o['trigger_delay']  = $num( 'trigger_delay', 0, 600 );
		$o['trigger_scroll'] = $num( 'trigger_scroll', 0, 100 );
		$o['closed_days']    = $num( 'closed_days', 0, 365 );
		$o['coupon_expiry']  = $num( 'coupon_expiry', 0, 365 );
		$o['ip_max']         = $num( 'ip_max', 0, 1000 );
		$o['cookie_days']    = $num( 'cookie_days', 1, 365 );

		$min = isset( $in['coupon_min'] ) ? trim( (string) $in['coupon_min'] ) : '';
		$o['coupon_min'] = is_numeric( $min ) ? (string) max( 0, (float) $min ) : '';

		foreach ( array( 'page_ids', 'exclude_ids' ) as $k ) {
			$ids = isset( $in[ $k ] ) ? array_filter( array_map( 'absint', explode( ',', (string) $in[ $k ] ) ) ) : array();
			$o[ $k ] = implode( ',', $ids );
		}

		$o['devices'] = array_values( array_intersect( array( 'desktop', 'tablet', 'mobile' ), isset( $in['devices'] ) ? (array) $in['devices'] : array() ) );

		$cin = ( isset( $in['colors'] ) && is_array( $in['colors'] ) ) ? $in['colors'] : array();
		$o['colors'] = array();
		foreach ( $d['colors'] as $k => $v ) {
			$c = isset( $cin[ $k ] ) ? sanitize_hex_color( $cin[ $k ] ) : '';
			$o['colors'][ $k ] = $c ? $c : $v;
		}

		$sin = ( isset( $in['style'] ) && is_array( $in['style'] ) ) ? $in['style'] : array();
		$ds  = $d['style'];
		$rng = array( 'max_width' => array( 400, 1200 ), 'radius' => array( 0, 60 ), 'btn_radius' => array( 0, 60 ), 'input_radius' => array( 0, 60 ), 'heading_size' => array( 14, 80 ), 'sub_size' => array( 10, 40 ), 'btn_size' => array( 10, 40 ), 'wheel_size' => array( 200, 600 ), 'spin_time' => array( 2, 15 ) );
		$o['style'] = array();
		foreach ( $rng as $k => $r ) {
			$o['style'][ $k ] = ( isset( $sin[ $k ] ) && is_numeric( $sin[ $k ] ) ) ? max( $r[0], min( $r[1], (int) $sin[ $k ] ) ) : $ds[ $k ];
		}
		$fonts = array_keys( self::fonts() );
		$o['style']['font']       = ( isset( $sin['font'] ) && in_array( $sin['font'], $fonts, true ) ) ? $sin['font'] : 'inherit';
		$o['style']['wheel_side'] = ( isset( $sin['wheel_side'] ) && 'right' === $sin['wheel_side'] ) ? 'right' : 'left';
		$o['style']['shadow']     = empty( $sin['shadow'] ) ? 0 : 1;
		$o['style']['glass']      = empty( $sin['glass'] ) ? 0 : 1;
		$o['style']['show_close'] = empty( $sin['show_close'] ) ? 0 : 1;

		$o['custom_css'] = isset( $in['custom_css'] ) ? str_ireplace( '</style', '', wp_strip_all_tags( (string) $in['custom_css'] ) ) : '';

		$segs = array();
		$raw  = ( isset( $in['segments'] ) && is_array( $in['segments'] ) ) ? $in['segments'] : array();
		foreach ( $raw as $s ) {
			if ( count( $segs ) >= 12 ) {
				break;
			}
			if ( ! is_array( $s ) ) {
				continue;
			}
			$label = sanitize_text_field( isset( $s['label'] ) ? $s['label'] : '' );
			if ( '' === $label ) {
				continue;
			}
			$col = isset( $s['color'] ) ? sanitize_hex_color( $s['color'] ) : '';
			if ( ! $col ) {
				$col = ( count( $segs ) % 2 ) ? $o['colors']['secondary'] : $o['colors']['primary'];
			}
			$dt = ( isset( $s['dtype'] ) && in_array( $s['dtype'], array( 'percent', 'fixed_cart', 'free_shipping' ), true ) ) ? $s['dtype'] : 'percent';
			$segs[] = array(
				'label'  => $label,
				'type'   => ( isset( $s['type'] ) && 'none' === $s['type'] ) ? 'none' : 'coupon',
				'dtype'  => $dt,
				'amount' => ( isset( $s['amount'] ) && is_numeric( $s['amount'] ) ) ? max( 0, (float) $s['amount'] ) : 0,
				'weight' => ( isset( $s['weight'] ) && is_numeric( $s['weight'] ) ) ? max( 0, (float) $s['weight'] ) : 0,
				'color'  => $col,
			);
		}
		if ( count( $segs ) < 2 ) {
			$segs = $d['segments'];
		}
		if ( array_sum( wp_list_pluck( $segs, 'weight' ) ) <= 0 ) {
			foreach ( $segs as $i => $s ) {
				$segs[ $i ]['weight'] = 1;
			}
		}
		$o['segments'] = $segs;

		return $o;
	}

	/* ---------- Campaigns ---------- */

	static function get_campaign( $id ) {
		$p = get_post( absint( $id ) );
		if ( ! $p || self::CPT !== $p->post_type || 'publish' !== $p->post_status ) {
			return null;
		}
		$d   = self::defaults();
		$cfg = get_post_meta( $p->ID, '_stw_config', true );
		$cfg = is_array( $cfg ) ? array_merge( $d, $cfg ) : $d;
		$cfg['colors'] = array_merge( $d['colors'], (array) $cfg['colors'] );
		$cfg['style']  = array_merge( $d['style'], isset( $cfg['style'] ) ? (array) $cfg['style'] : array() );
		$cfg['id']   = $p->ID;
		$cfg['name'] = $p->post_title;
		return $cfg;
	}

	static function get_campaigns() {
		$out = array();
		$ps  = get_posts( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'modified', 'order' => 'DESC' ) );
		foreach ( $ps as $p ) {
			$c = self::get_campaign( $p->ID );
			if ( $c ) {
				$out[] = $c;
			}
		}
		return $out;
	}

	static function save_campaign( $id, $name, $cfg ) {
		$name = '' !== trim( $name ) ? $name : __( 'Untitled campaign', 'spin-to-win' );
		if ( $id ) {
			wp_update_post( array( 'ID' => $id, 'post_title' => $name, 'post_modified' => current_time( 'mysql' ), 'post_modified_gmt' => current_time( 'mysql', 1 ) ) );
		} else {
			$id = wp_insert_post( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'post_title' => $name ) );
		}
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_stw_config', $cfg );
		}
		return $id;
	}

	static function delete_campaign( $id ) {
		global $wpdb;
		$id = absint( $id );
		$p  = get_post( $id );
		if ( ! $p || self::CPT !== $p->post_type ) {
			return;
		}
		wp_delete_post( $id, true );
		$wpdb->delete( $wpdb->prefix . 'stw_leads', array( 'campaign_id' => $id ) );
		$wpdb->delete( $wpdb->prefix . 'stw_events', array( 'campaign_id' => $id ) );
	}

	/* ---------- Tracking ---------- */

	static function log_event( $cid, $event ) {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'stw_events', array(
			'campaign_id' => absint( $cid ),
			'event'       => $event,
			'created_at'  => wp_date( 'Y-m-d H:i:s' ),
		) );
	}

	static function counts( $days = 0, $cid = 0 ) {
		global $wpdb;
		$t = $wpdb->prefix . 'stw_events';
		$w = array( '1=1' );
		$a = array();
		if ( $days > 0 ) {
			$w[] = 'created_at >= %s';
			$a[] = wp_date( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS * $days );
		}
		if ( $cid ) {
			$w[] = 'campaign_id = %d';
			$a[] = $cid;
		}
		$sql = "SELECT campaign_id, event, COUNT(*) n FROM $t WHERE " . implode( ' AND ', $w ) . ' GROUP BY campaign_id, event';
		if ( $a ) {
			$sql = $wpdb->prepare( $sql, $a );
		}
		$out = array();
		foreach ( (array) $wpdb->get_results( $sql, ARRAY_A ) as $r ) {
			$out[ (int) $r['campaign_id'] ][ $r['event'] ] = (int) $r['n'];
		}
		return $out;
	}

	static function redeemed( $cid ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT SUM(CAST(u.meta_value AS UNSIGNED)) FROM {$wpdb->postmeta} c JOIN {$wpdb->postmeta} u ON u.post_id = c.post_id AND u.meta_key = 'usage_count' WHERE c.meta_key = '_stw_campaign' AND c.meta_value = %d",
			$cid
		) );
	}

	static function ip() {
		$s  = self::settings();
		$ip = '';
		if ( ! empty( $s['trust_proxy'] ) ) {
			foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR' ) as $h ) {
				if ( ! empty( $_SERVER[ $h ] ) ) {
					$parts = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $h ] ) ) );
					$ip    = trim( $parts[0] );
					break;
				}
			}
		}
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		}
		return $ip;
	}
}
