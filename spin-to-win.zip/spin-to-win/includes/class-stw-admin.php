<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class STW_Admin {

	static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_stw_save_campaign', array( __CLASS__, 'save_campaign' ) );
		add_action( 'admin_post_stw_campaign_action', array( __CLASS__, 'campaign_action' ) );
		add_action( 'admin_post_stw_leads_bulk', array( __CLASS__, 'leads_bulk' ) );
		add_action( 'admin_post_stw_export', array( __CLASS__, 'export' ) );
		add_action( 'admin_post_stw_save_settings', array( __CLASS__, 'save_settings' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( STW_FILE ), array( __CLASS__, 'action_links' ) );
	}

	static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=stw' ) ) . '">' . esc_html__( 'Campaigns', 'spin-to-win' ) . '</a>' );
		return $links;
	}

	static function menu() {
		$cap = 'manage_options';
		add_menu_page( 'Spin to Win', 'Spin to Win', $cap, 'stw', array( __CLASS__, 'page_campaigns' ), 'dashicons-tickets-alt', 58 );
		add_submenu_page( 'stw', 'Campaigns', 'Campaigns', $cap, 'stw', array( __CLASS__, 'page_campaigns' ) );
		add_submenu_page( 'stw', 'Add / Edit Campaign', 'Add New', $cap, 'stw-edit', array( __CLASS__, 'page_edit' ) );
		add_submenu_page( 'stw', 'Leads', 'Leads', $cap, 'stw-leads', array( __CLASS__, 'page_leads' ) );
		add_submenu_page( 'stw', 'Analytics', 'Analytics', $cap, 'stw-analytics', array( __CLASS__, 'page_analytics' ) );
		add_submenu_page( 'stw', 'Settings', 'Settings', $cap, 'stw-settings', array( __CLASS__, 'page_settings' ) );
	}

	static function assets( $hook ) {
		if ( false === strpos( $hook, 'stw' ) ) {
			return;
		}
		wp_enqueue_style( 'stw-admin', STW_URL . 'assets/css/admin.css', array(), filemtime( STW_DIR . 'assets/css/admin.css' ) );
		wp_enqueue_script( 'stw-wheel', STW_URL . 'assets/js/wheel.js', array(), filemtime( STW_DIR . 'assets/js/wheel.js' ), true );
		wp_enqueue_script( 'stw-admin', STW_URL . 'assets/js/admin.js', array( 'jquery', 'stw-wheel' ), filemtime( STW_DIR . 'assets/js/admin.js' ), true );
	}

	/* ---------- small helpers ---------- */

	static function url( $page, $args = array() ) {
		return add_query_arg( $args, admin_url( 'admin.php?page=' . $page ) );
	}

	static function guard() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'spin-to-win' ) );
		}
	}

	static function notices() {
		$m = isset( $_GET['stw_msg'] ) ? sanitize_key( $_GET['stw_msg'] ) : '';
		$map = array(
			'saved'     => __( 'Saved.', 'spin-to-win' ),
			'deleted'   => __( 'Deleted.', 'spin-to-win' ),
			'duplicated'=> __( 'Campaign duplicated (it starts as inactive).', 'spin-to-win' ),
			'toggled'   => __( 'Campaign status updated.', 'spin-to-win' ),
		);
		if ( isset( $map[ $m ] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $map[ $m ] ) . '</p></div>';
		}
		if ( ! class_exists( 'WooCommerce' ) ) {
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'WooCommerce is not active. The wheel and lead capture work, but coupon prizes cannot be generated until WooCommerce is activated.', 'spin-to-win' ) . '</p></div>';
		}
	}

	private static function r( $label, $html, $help = '' ) {
		echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td>' . $html . ( $help ? '<p class="description">' . esc_html( $help ) . '</p>' : '' ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	private static function t( $n, $v, $type = 'text', $extra = '' ) {
		return '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $n ) . '" value="' . esc_attr( $v ) . '" class="regular-text" ' . $extra . '>';
	}

	private static function num( $n, $v, $min = 0, $max = 999 ) {
		return '<input type="number" name="' . esc_attr( $n ) . '" value="' . esc_attr( $v ) . '" min="' . (int) $min . '" max="' . (int) $max . '" class="small-text">';
	}

	private static function chk( $n, $v, $label ) {
		return '<label><input type="checkbox" name="' . esc_attr( $n ) . '" value="1" ' . checked( (int) $v, 1, false ) . '> ' . esc_html( $label ) . '</label>';
	}

	private static function sel( $n, $v, $opts ) {
		$h = '<select name="' . esc_attr( $n ) . '">';
		foreach ( $opts as $k => $l ) {
			$h .= '<option value="' . esc_attr( $k ) . '" ' . selected( (string) $v, (string) $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		return $h . '</select>';
	}

	private static function color( $n, $v ) {
		return '<input type="color" name="' . esc_attr( $n ) . '" value="' . esc_attr( $v ) . '">';
	}

	/* ---------- Campaigns list ---------- */

	static function page_campaigns() {
		self::guard();
		$cs     = STW_Core::get_campaigns();
		$counts = STW_Core::counts();
		echo '<div class="wrap stw-wrap"><h1 class="wp-heading-inline">Spin to Win</h1> <a class="page-title-action" href="' . esc_url( self::url( 'stw-edit' ) ) . '">' . esc_html__( 'Add New', 'spin-to-win' ) . '</a><hr class="wp-header-end">';
		self::notices();
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Campaign', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Status', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Views', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Spins', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Coupons won', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Redeemed', 'spin-to-win' ) . '</th><th></th></tr></thead><tbody>';
		if ( ! $cs ) {
			echo '<tr><td colspan="7">' . esc_html__( 'No campaigns yet.', 'spin-to-win' ) . '</td></tr>';
		}
		foreach ( $cs as $c ) {
			$id = $c['id'];
			$n  = isset( $counts[ $id ] ) ? $counts[ $id ] : array();
			$on = 'active' === $c['status'];
			$a  = function ( $do ) use ( $id ) {
				return wp_nonce_url( admin_url( 'admin-post.php?action=stw_campaign_action&do=' . $do . '&id=' . $id ), 'stw_' . $do . '_' . $id );
			};
			echo '<tr><td><strong><a href="' . esc_url( self::url( 'stw-edit', array( 'id' => $id ) ) ) . '">' . esc_html( $c['name'] ) . '</a></strong></td>';
			echo '<td><a href="' . esc_url( $a( 'toggle' ) ) . '" class="stw-pill ' . ( $on ? 'on' : 'off' ) . '">' . ( $on ? esc_html__( 'Active', 'spin-to-win' ) : esc_html__( 'Inactive', 'spin-to-win' ) ) . '</a></td>';
			echo '<td>' . (int) ( $n['impression'] ?? 0 ) . '</td><td>' . (int) ( $n['spin'] ?? 0 ) . '</td><td>' . (int) ( $n['win'] ?? 0 ) . '</td><td>' . (int) STW_Core::redeemed( $id ) . '</td>';
			echo '<td class="stw-actions"><a href="' . esc_url( self::url( 'stw-edit', array( 'id' => $id ) ) ) . '">' . esc_html__( 'Edit', 'spin-to-win' ) . '</a> | <a href="' . esc_url( $a( 'duplicate' ) ) . '">' . esc_html__( 'Duplicate', 'spin-to-win' ) . '</a> | <a href="' . esc_url( $a( 'delete' ) ) . '" class="stw-del" style="color:#b32d2e">' . esc_html__( 'Delete', 'spin-to-win' ) . '</a></td></tr>';
		}
		echo '</tbody></table>';
		echo '<p class="description">' . esc_html__( 'If more than one active campaign matches a page, the oldest one is shown. Use "Display Rules" to target different pages.', 'spin-to-win' ) . '</p></div>';
	}

	static function campaign_action() {
		self::guard();
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		$do = isset( $_GET['do'] ) ? sanitize_key( $_GET['do'] ) : '';
		check_admin_referer( 'stw_' . $do . '_' . $id );
		$msg = 'saved';
		$c   = STW_Core::get_campaign( $id );
		if ( $c ) {
			if ( 'delete' === $do ) {
				STW_Core::delete_campaign( $id );
				$msg = 'deleted';
			} elseif ( 'duplicate' === $do ) {
				$cfg           = $c;
				$cfg['status'] = 'inactive';
				unset( $cfg['id'], $cfg['name'] );
				STW_Core::save_campaign( 0, $c['name'] . ' (copy)', $cfg );
				$msg = 'duplicated';
			} elseif ( 'toggle' === $do ) {
				$cfg           = $c;
				$cfg['status'] = 'active' === $c['status'] ? 'inactive' : 'active';
				unset( $cfg['id'], $cfg['name'] );
				STW_Core::save_campaign( $id, $c['name'], $cfg );
				$msg = 'toggled';
			}
		}
		wp_safe_redirect( self::url( 'stw', array( 'stw_msg' => $msg ) ) );
		exit;
	}

	/* ---------- Edit campaign ---------- */

	private static function seg_row( $s ) {
		$s = wp_parse_args( $s, array( 'label' => '', 'type' => 'coupon', 'dtype' => 'percent', 'amount' => 10, 'weight' => 10, 'color' => '#e63946' ) );
		$h  = '<div class="stw-seg">';
		$h .= '<span class="stw-seg-no"></span>';
		$h .= '<input type="text" data-n="label" value="' . esc_attr( $s['label'] ) . '" placeholder="' . esc_attr__( 'Label on wheel', 'spin-to-win' ) . '">';
		$h .= '<select data-n="type"><option value="coupon" ' . selected( $s['type'], 'coupon', false ) . '>' . esc_html__( 'Gives coupon', 'spin-to-win' ) . '</option><option value="none" ' . selected( $s['type'], 'none', false ) . '>' . esc_html__( 'No prize', 'spin-to-win' ) . '</option></select>';
		$h .= '<select data-n="dtype"><option value="percent" ' . selected( $s['dtype'], 'percent', false ) . '>' . esc_html__( '% discount', 'spin-to-win' ) . '</option><option value="fixed_cart" ' . selected( $s['dtype'], 'fixed_cart', false ) . '>' . esc_html__( 'Fixed amount', 'spin-to-win' ) . '</option><option value="free_shipping" ' . selected( $s['dtype'], 'free_shipping', false ) . '>' . esc_html__( 'Free shipping', 'spin-to-win' ) . '</option></select>';
		$h .= '<input type="number" data-n="amount" step="any" min="0" value="' . esc_attr( $s['amount'] ) . '" title="' . esc_attr__( 'Discount amount', 'spin-to-win' ) . '">';
		$h .= '<span class="stw-w"><input type="number" data-n="weight" step="any" min="0" value="' . esc_attr( $s['weight'] ) . '" title="' . esc_attr__( 'Chance weight', 'spin-to-win' ) . '"><em class="stw-pct"></em></span>';
		$h .= '<input type="color" data-n="color" value="' . esc_attr( $s['color'] ) . '">';
		$h .= '<button type="button" class="button-link stw-rm" title="' . esc_attr__( 'Remove', 'spin-to-win' ) . '">&times;</button>';
		return $h . '</div>';
	}

	static function page_edit() {
		self::guard();
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		$c  = $id ? STW_Core::get_campaign( $id ) : null;
		if ( ! $c ) {
			$id = 0;
			$c  = array_merge( STW_Core::defaults(), array( 'id' => 0, 'name' => '' ) );
		}
		$col  = $c['colors'];
		$tabs = array(
			't-content' => __( 'Content', 'spin-to-win' ),
			't-wheel'   => __( 'Wheel & Prizes', 'spin-to-win' ),
			't-design'  => __( 'Design', 'spin-to-win' ),
			't-leads'   => __( 'Lead Capture', 'spin-to-win' ),
			't-rules'   => __( 'Display Rules', 'spin-to-win' ),
			't-coupon'  => __( 'Coupon & Security', 'spin-to-win' ),
		);
		$modes = array( 'required' => __( 'Required', 'spin-to-win' ), 'optional' => __( 'Optional', 'spin-to-win' ), 'off' => __( 'Do not ask', 'spin-to-win' ) );

		echo '<div class="wrap stw-wrap"><h1>' . ( $id ? esc_html__( 'Edit campaign', 'spin-to-win' ) : esc_html__( 'New campaign', 'spin-to-win' ) ) . '</h1>';
		self::notices();
		echo '<form id="stw-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="stw_save_campaign"><input type="hidden" name="id" value="' . (int) $id . '">';
		wp_nonce_field( 'stw_save_campaign' );
		echo '<div class="stw-grid"><div class="stw-main">';
		echo '<h2 class="nav-tab-wrapper stw-tabs">';
		foreach ( $tabs as $k => $l ) {
			echo '<a href="#' . esc_attr( $k ) . '" class="nav-tab">' . esc_html( $l ) . '</a>';
		}
		echo '</h2>';

		// --- Content
		echo '<div class="stw-panel" id="t-content"><table class="form-table">';
		self::r( __( 'Campaign name', 'spin-to-win' ), self::t( 'name', $c['name'] ), __( 'Only you see this.', 'spin-to-win' ) );
		self::r( __( 'Status', 'spin-to-win' ), self::sel( 'status', $c['status'], array( 'active' => __( 'Active', 'spin-to-win' ), 'inactive' => __( 'Inactive', 'spin-to-win' ) ) ) );
		self::r( __( 'Heading', 'spin-to-win' ), self::t( 'heading', $c['heading'] ) );
		self::r( __( 'Sub-heading', 'spin-to-win' ), self::t( 'subheading', $c['subheading'] ) );
		self::r( __( 'Spin button text', 'spin-to-win' ), self::t( 'button_text', $c['button_text'] ) );
		self::r( __( 'Win title', 'spin-to-win' ), self::t( 'win_title', $c['win_title'] ) );
		self::r( __( 'Win message', 'spin-to-win' ), self::t( 'win_text', $c['win_text'] ), __( 'Use {prize} for the prize name.', 'spin-to-win' ) );
		self::r( __( 'Coupon expiry text', 'spin-to-win' ), self::t( 'expiry_text', $c['expiry_text'] ), __( 'Use {date} for the expiry date.', 'spin-to-win' ) );
		self::r( __( 'Lose title', 'spin-to-win' ), self::t( 'lose_title', $c['lose_title'] ) );
		self::r( __( 'Lose message', 'spin-to-win' ), self::t( 'lose_text', $c['lose_text'] ) );
		self::r( __( '"Already played" message', 'spin-to-win' ), self::t( 'already_text', $c['already_text'] ) );
		self::r( __( 'Copy / Copied labels', 'spin-to-win' ), self::t( 'copy_text', $c['copy_text'], 'text', 'style="width:140px"' ) . ' ' . self::t( 'copied_text', $c['copied_text'], 'text', 'style="width:140px"' ) );
		self::r( __( 'Result button text', 'spin-to-win' ), self::t( 'shop_button', $c['shop_button'] ) );
		self::r( __( '"No thanks" link', 'spin-to-win' ), self::chk( 'show_no_thanks', $c['show_no_thanks'], __( 'Show', 'spin-to-win' ) ) . '<br>' . self::t( 'no_thanks', $c['no_thanks'] ) );
		self::r( __( 'Error messages', 'spin-to-win' ), self::t( 'err_email', $c['err_email'] ) . '<br>' . self::t( 'err_phone', $c['err_phone'] ) . '<br>' . self::t( 'err_consent', $c['err_consent'] ) . '<br>' . self::t( 'err_generic', $c['err_generic'] ), __( 'Email, phone, consent, general.', 'spin-to-win' ) );
		echo '</table></div>';

		// --- Wheel
		echo '<div class="stw-panel" id="t-wheel"><p class="description">' . esc_html__( 'Add 2–12 slices. "Chance weight" is relative: 20 vs 10 means twice as likely. Slices are always drawn the same size; the spin result is decided by the server so it cannot be cheated.', 'spin-to-win' ) . '</p>';
		echo '<div class="stw-seg stw-seg-head"><span></span><span>' . esc_html__( 'Label', 'spin-to-win' ) . '</span><span>' . esc_html__( 'Prize', 'spin-to-win' ) . '</span><span>' . esc_html__( 'Type', 'spin-to-win' ) . '</span><span>' . esc_html__( 'Amount', 'spin-to-win' ) . '</span><span>' . esc_html__( 'Chance', 'spin-to-win' ) . '</span><span>' . esc_html__( 'Color', 'spin-to-win' ) . '</span><span></span></div>';
		echo '<div id="stw-segs">';
		foreach ( $c['segments'] as $s ) {
			echo self::seg_row( $s ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div><p><button type="button" class="button" id="stw-add">' . esc_html__( '+ Add slice', 'spin-to-win' ) . '</button></p>';
		echo '<script type="text/template" id="stw-seg-tpl">' . self::seg_row( array() ) . '</script></div>'; // phpcs:ignore WordPress.Security.EscapeOutput

		// --- Design
		echo '<div class="stw-panel" id="t-design"><table class="form-table">';
		$cl = array(
			'heading'      => __( 'Heading color', 'spin-to-win' ),
			'subtext'      => __( 'Sub-heading color', 'spin-to-win' ),
			'body_text'    => __( 'Body / coupon code text', 'spin-to-win' ),
			'bg'           => __( 'Popup background', 'spin-to-win' ),
			'panel_from'   => __( 'Wheel panel gradient – start', 'spin-to-win' ),
			'panel_to'     => __( 'Wheel panel gradient – end', 'spin-to-win' ),
			'text'         => __( 'Wheel text color', 'spin-to-win' ),
			'ring'         => __( 'Wheel outer ring', 'spin-to-win' ),
			'peg'          => __( 'Wheel pegs (dots)', 'spin-to-win' ),
			'hub'          => __( 'Wheel center', 'spin-to-win' ),
			'pointer'      => __( 'Wheel pointer', 'spin-to-win' ),
			'button'       => __( 'Button color', 'spin-to-win' ),
			'button_text'  => __( 'Button text color', 'spin-to-win' ),
			'input_bg'     => __( 'Input background', 'spin-to-win' ),
			'input_text'   => __( 'Input text', 'spin-to-win' ),
			'input_border' => __( 'Input border', 'spin-to-win' ),
			'error'        => __( 'Error text', 'spin-to-win' ),
			'close'        => __( 'Close (×) button', 'spin-to-win' ),
			'overlay'      => __( 'Overlay color (70% opacity)', 'spin-to-win' ),
			'tab_bg'       => __( 'Reopen tab background', 'spin-to-win' ),
			'tab_text'     => __( 'Reopen tab text', 'spin-to-win' ),
			'nt_bg'        => __( '"No thanks" button background', 'spin-to-win' ),
			'nt_text'      => __( '"No thanks" button text', 'spin-to-win' ),
		);
		$th = array( 'glass' => 'Apple Glass', 'classic' => 'Classic Red', 'neon' => 'Neon Dark', 'gold' => 'Gold Luxury', 'fresh' => 'Fresh Green' );
		$tb = '';
		foreach ( $th as $k => $l ) {
			$tb .= '<button type="button" class="button stw-theme" data-theme="' . esc_attr( $k ) . '">' . esc_html( $l ) . '</button> ';
		}
		self::r( __( 'Theme', 'spin-to-win' ), $tb, __( 'Click a theme, then press Save. You can still change any color after.', 'spin-to-win' ) );
		foreach ( $cl as $k => $l ) {
			self::r( $l, self::color( 'colors[' . $k . ']', $col[ $k ] ) );
		}
		$st = $c['style'];
		$nm = array(
			'max_width'    => array( __( 'Popup width (px)', 'spin-to-win' ), 400, 1200 ),
			'wheel_size'   => array( __( 'Wheel size (px)', 'spin-to-win' ), 200, 600 ),
			'radius'       => array( __( 'Popup corner radius (px)', 'spin-to-win' ), 0, 60 ),
			'btn_radius'   => array( __( 'Button corner radius (px)', 'spin-to-win' ), 0, 60 ),
			'input_radius' => array( __( 'Input corner radius (px)', 'spin-to-win' ), 0, 60 ),
			'heading_size' => array( __( 'Heading font size (px)', 'spin-to-win' ), 14, 80 ),
			'sub_size'     => array( __( 'Sub-heading font size (px)', 'spin-to-win' ), 10, 40 ),
			'btn_size'     => array( __( 'Button font size (px)', 'spin-to-win' ), 10, 40 ),
			'spin_time'    => array( __( 'Spin duration (seconds)', 'spin-to-win' ), 2, 15 ),
		);
		foreach ( $nm as $k => $m ) {
			self::r( $m[0], '<input type="number" class="small-text" name="style[' . esc_attr( $k ) . ']" value="' . esc_attr( $st[ $k ] ) . '" min="' . (int) $m[1] . '" max="' . (int) $m[2] . '">' );
		}
		self::r( __( 'Font', 'spin-to-win' ), self::sel( 'style[font]', $st['font'], STW_Core::fonts() ) );
		self::r( __( 'Wheel position', 'spin-to-win' ), self::sel( 'style[wheel_side]', $st['wheel_side'], array( 'left' => __( 'Left', 'spin-to-win' ), 'right' => __( 'Right', 'spin-to-win' ) ) ) );
		self::r( __( 'Glass effect', 'spin-to-win' ), '<label><input type="checkbox" name="style[glass]" value="1" ' . checked( ! empty( $st['glass'] ), true, false ) . '> ' . esc_html__( 'Apple-style frosted glass popup, inputs, buttons and reopen tab', 'spin-to-win' ) . '</label>' );
		self::r( __( 'Close (×) button', 'spin-to-win' ), '<label><input type="checkbox" name="style[show_close]" value="1" ' . checked( ! empty( $st['show_close'] ), true, false ) . '> ' . esc_html__( 'Show the × button', 'spin-to-win' ) . '</label>' );
		self::r( __( 'Popup shadow', 'spin-to-win' ), '<label><input type="checkbox" name="style[shadow]" value="1" ' . checked( ! empty( $st['shadow'] ), true, false ) . '> ' . esc_html__( 'Enable', 'spin-to-win' ) . '</label>' );
		self::r( __( 'Custom CSS', 'spin-to-win' ), '<textarea name="custom_css" rows="8" class="large-text code" placeholder=".stw-modal{...}">' . esc_textarea( isset( $c['custom_css'] ) ? $c['custom_css'] : '' ) . '</textarea>', __( 'Added after the plugin styles. Classes: .stw-overlay .stw-modal .stw-wheel-col .stw-form-col .stw-h .stw-sub .stw-in .stw-btn .stw-tab', 'spin-to-win' ) );
		self::r( __( 'Reopen tab', 'spin-to-win' ), self::chk( 'reopen_tab', $c['reopen_tab'], __( 'Show a small tab after the popup is closed', 'spin-to-win' ) ) . '<br>' . self::t( 'tab_text', $c['tab_text'] ) . '<br>' . self::sel( 'tab_position', $c['tab_position'], array( 'left' => __( 'Bottom left', 'spin-to-win' ), 'right' => __( 'Bottom right', 'spin-to-win' ) ) ) );
		echo '</table></div>';

		// --- Lead capture
		echo '<div class="stw-panel" id="t-leads"><table class="form-table">';
		self::r( __( 'Email', 'spin-to-win' ), self::sel( 'collect_email', $c['collect_email'], $modes ) . '<br>' . self::t( 'email_placeholder', $c['email_placeholder'] ) );
		self::r( __( 'Phone', 'spin-to-win' ), self::sel( 'collect_phone', $c['collect_phone'], $modes ) . '<br>' . self::t( 'phone_placeholder', $c['phone_placeholder'] ) );
		self::r( __( 'Consent checkbox (GDPR)', 'spin-to-win' ), self::chk( 'consent_on', $c['consent_on'], __( 'Require consent before spinning', 'spin-to-win' ) ) . '<br>' . self::t( 'consent_text', $c['consent_text'] ), __( 'Consent is stored with every lead.', 'spin-to-win' ) );
		echo '</table></div>';

		// --- Rules
		$dev = array( 'desktop' => __( 'Desktop', 'spin-to-win' ), 'tablet' => __( 'Tablet', 'spin-to-win' ), 'mobile' => __( 'Mobile', 'spin-to-win' ) );
		$dh  = '';
		foreach ( $dev as $k => $l ) {
			$dh .= '<label style="margin-right:14px"><input type="checkbox" name="devices[]" value="' . esc_attr( $k ) . '" ' . checked( in_array( $k, $c['devices'], true ), true, false ) . '> ' . esc_html( $l ) . '</label>';
		}
		echo '<div class="stw-panel" id="t-rules"><table class="form-table">';
		self::r( __( 'Show after (seconds)', 'spin-to-win' ), self::num( 'trigger_delay', $c['trigger_delay'], 0, 600 ), __( '0 = off.', 'spin-to-win' ) );
		self::r( __( 'Show after scrolling (%)', 'spin-to-win' ), self::num( 'trigger_scroll', $c['trigger_scroll'], 0, 100 ), __( '0 = off.', 'spin-to-win' ) );
		self::r( __( 'Exit intent', 'spin-to-win' ), self::chk( 'trigger_exit', $c['trigger_exit'], __( 'Show when the visitor is about to leave', 'spin-to-win' ) ), __( 'Desktop: mouse leaves the top of the window. Mobile: a quick scroll-up after reading. The popup shows once, on whichever trigger happens first. If all triggers are off it appears after 3 seconds.', 'spin-to-win' ) );
		self::r( __( 'Devices', 'spin-to-win' ), $dh );
		self::r( __( 'Pages', 'spin-to-win' ), self::sel( 'pages', $c['pages'], array( 'all' => __( 'All pages', 'spin-to-win' ), 'home' => __( 'Home page only', 'spin-to-win' ), 'shop' => __( 'WooCommerce shop / product pages', 'spin-to-win' ), 'include' => __( 'Only specific page IDs', 'spin-to-win' ) ) ) . '<br>' . self::t( 'page_ids', $c['page_ids'], 'text', 'placeholder="12, 45, 78"' ), __( 'Page IDs are used only for "Only specific page IDs". The popup never shows on cart or checkout.', 'spin-to-win' ) );
		self::r( __( 'Exclude page IDs', 'spin-to-win' ), self::t( 'exclude_ids', $c['exclude_ids'], 'text', 'placeholder="12, 45"' ) );
		self::r( __( 'Logged-in users', 'spin-to-win' ), self::chk( 'hide_logged_in', $c['hide_logged_in'], __( 'Hide from logged-in users', 'spin-to-win' ) ) );
		self::r( __( 'After closing, hide for (days)', 'spin-to-win' ), self::num( 'closed_days', $c['closed_days'], 0, 365 ), __( '0 = show again on the next page load.', 'spin-to-win' ) );
		echo '</table></div>';

		// --- Coupon & security
		echo '<div class="stw-panel" id="t-coupon"><table class="form-table">';
		self::r( __( 'Coupon prefix', 'spin-to-win' ), self::t( 'coupon_prefix', $c['coupon_prefix'], 'text', 'style="width:140px"' ) );
		self::r( __( 'Coupon valid for (days)', 'spin-to-win' ), self::num( 'coupon_expiry', $c['coupon_expiry'], 0, 365 ), __( '0 = never expires.', 'spin-to-win' ) );
		self::r( __( 'Minimum spend', 'spin-to-win' ), self::t( 'coupon_min', $c['coupon_min'], 'text', 'style="width:140px"' ), __( 'Leave empty for no minimum.', 'spin-to-win' ) );
		self::r( __( 'Coupon options', 'spin-to-win' ), self::chk( 'coupon_individual', $c['coupon_individual'], __( 'Individual use only (cannot combine with other coupons)', 'spin-to-win' ) ) . '<br>' . self::chk( 'coupon_restrict_email', $c['coupon_restrict_email'], __( 'Restrict to the email used (customer must check out with the same email)', 'spin-to-win' ) ), __( 'Every coupon is unique and single-use.', 'spin-to-win' ) );
		self::r( __( 'Email the coupon', 'spin-to-win' ), self::chk( 'email_coupon', $c['email_coupon'], __( 'Email the code to the winner', 'spin-to-win' ) ) . '<br>' . self::t( 'email_subject', $c['email_subject'] ) . '<br><textarea name="email_body" rows="6" class="large-text">' . esc_textarea( $c['email_body'] ) . '</textarea>', __( 'Placeholders: {prize} {code} {expiry} {site}', 'spin-to-win' ) );
		self::r( __( 'One spin per…', 'spin-to-win' ), self::sel( 'antispam', $c['antispam'], array( 'cookie' => __( 'Browser (cookie) only', 'spin-to-win' ), 'email' => __( 'Browser + email/phone (recommended)', 'spin-to-win' ), 'ip' => __( 'Browser + email/phone + IP address', 'spin-to-win' ) ) ), __( 'Many mobile networks share one IP between lots of people, so IP limits can block real customers. Keep the IP limit generous if you use it.', 'spin-to-win' ) );
		self::r( __( 'Max spins per IP', 'spin-to-win' ), self::num( 'ip_max', $c['ip_max'], 0, 1000 ), __( 'Used only in IP mode. 0 = unlimited.', 'spin-to-win' ) );
		self::r( __( 'Remember a played visitor for (days)', 'spin-to-win' ), self::num( 'cookie_days', $c['cookie_days'], 1, 365 ) );
		echo '</table></div>';

		echo '</div>'; // .stw-main

		// --- Preview sidebar
		echo '<div class="stw-side"><div class="stw-card"><h3>' . esc_html__( 'Wheel preview', 'spin-to-win' ) . '</h3><div class="stw-prev"><div class="stw-wheel" id="stw-preview"></div></div><p><button type="button" class="button" id="stw-test">' . esc_html__( 'Test spin', 'spin-to-win' ) . '</button></p></div>';
		echo '<p class="submit"><button type="submit" class="button button-primary button-large">' . esc_html__( 'Save campaign', 'spin-to-win' ) . '</button></p></div>';
		echo '</div></form></div>';
	}

	static function save_campaign() {
		self::guard();
		check_admin_referer( 'stw_save_campaign' );
		$post = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification
		$id   = isset( $post['id'] ) ? absint( $post['id'] ) : 0;
		$name = isset( $post['name'] ) ? sanitize_text_field( $post['name'] ) : '';
		$cfg  = STW_Core::sanitize( $post );
		$id   = STW_Core::save_campaign( $id, $name, $cfg );
		wp_safe_redirect( self::url( 'stw-edit', array( 'id' => $id, 'stw_msg' => 'saved' ) ) );
		exit;
	}

	/* ---------- Leads ---------- */

	private static function leads_where( $cid, $s ) {
		global $wpdb;
		$w = array( '1=1' );
		$a = array();
		if ( $cid ) {
			$w[] = 'campaign_id = %d';
			$a[] = $cid;
		}
		if ( '' !== $s ) {
			$like = '%' . $wpdb->esc_like( $s ) . '%';
			$w[]  = '(email LIKE %s OR phone LIKE %s OR coupon LIKE %s)';
			array_push( $a, $like, $like, $like );
		}
		return array( implode( ' AND ', $w ), $a );
	}

	static function page_leads() {
		self::guard();
		global $wpdb;
		$t     = $wpdb->prefix . 'stw_leads';
		$cid   = isset( $_GET['campaign'] ) ? absint( $_GET['campaign'] ) : 0;
		$s     = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$paged = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 );
		$per   = 20;
		list( $where, $args ) = self::leads_where( $cid, $s );

		$count_sql = "SELECT COUNT(*) FROM $t WHERE $where";
		$total     = (int) $wpdb->get_var( $args ? $wpdb->prepare( $count_sql, $args ) : $count_sql );
		$sql       = "SELECT * FROM $t WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d";
		$rows      = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $args, array( $per, ( $paged - 1 ) * $per ) ) ) );
		$names     = array();
		foreach ( STW_Core::get_campaigns() as $c ) {
			$names[ $c['id'] ] = $c['name'];
		}

		echo '<div class="wrap stw-wrap"><h1>' . esc_html__( 'Leads', 'spin-to-win' ) . ' <span class="title-count">(' . (int) $total . ')</span></h1>';
		echo '<form method="get" class="stw-filter"><input type="hidden" name="page" value="stw-leads"><select name="campaign"><option value="0">' . esc_html__( 'All campaigns', 'spin-to-win' ) . '</option>';
		foreach ( $names as $k => $n ) {
			echo '<option value="' . (int) $k . '" ' . selected( $cid, $k, false ) . '>' . esc_html( $n ) . '</option>';
		}
		echo '</select> <input type="search" name="s" value="' . esc_attr( $s ) . '" placeholder="' . esc_attr__( 'Search email, phone, coupon', 'spin-to-win' ) . '"> <button class="button">' . esc_html__( 'Filter', 'spin-to-win' ) . '</button> ';
		$exp = wp_nonce_url( admin_url( 'admin-post.php?action=stw_export&campaign=' . $cid . '&s=' . rawurlencode( $s ) ), 'stw_export' );
		echo '<a class="button" href="' . esc_url( $exp ) . '">' . esc_html__( 'Export CSV', 'spin-to-win' ) . '</a></form>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="stw_leads_bulk">';
		wp_nonce_field( 'stw_leads_bulk' );
		echo '<p><button class="button" onclick="return confirm(\'' . esc_js( __( 'Delete the selected leads?', 'spin-to-win' ) ) . '\')">' . esc_html__( 'Delete selected', 'spin-to-win' ) . '</button></p>';
		echo '<table class="widefat striped"><thead><tr><td class="check-column"><input type="checkbox" id="stw-all"></td><th>' . esc_html__( 'Date', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Campaign', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Email', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Phone', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Prize', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Coupon', 'spin-to-win' ) . '</th><th>IP</th><th>' . esc_html__( 'Consent', 'spin-to-win' ) . '</th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="9">' . esc_html__( 'No leads found.', 'spin-to-win' ) . '</td></tr>';
		}
		foreach ( $rows as $r ) {
			echo '<tr><th class="check-column"><input type="checkbox" name="ids[]" value="' . (int) $r->id . '"></th><td>' . esc_html( $r->created_at ) . '</td><td>' . esc_html( isset( $names[ $r->campaign_id ] ) ? $names[ $r->campaign_id ] : '#' . $r->campaign_id ) . '</td><td>' . esc_html( $r->email ) . '</td><td>' . esc_html( $r->phone ) . '</td><td>' . esc_html( $r->prize ) . '</td><td><code>' . esc_html( $r->coupon ) . '</code></td><td>' . esc_html( $r->ip ) . '</td><td>' . ( $r->consent ? '✓' : '—' ) . '</td></tr>';
		}
		echo '</tbody></table></form>';
		$pages = (int) ceil( $total / $per );
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $paged, 'total' => $pages ) ) ) . '</div></div>';
		}
		echo '</div>';
	}

	static function leads_bulk() {
		self::guard();
		check_admin_referer( 'stw_leads_bulk' );
		global $wpdb;
		$ids = isset( $_POST['ids'] ) ? array_filter( array_map( 'absint', (array) $_POST['ids'] ) ) : array();
		if ( $ids ) {
			$wpdb->query( "DELETE FROM {$wpdb->prefix}stw_leads WHERE id IN (" . implode( ',', $ids ) . ')' ); // phpcs:ignore WordPress.DB.PreparedSQL
		}
		wp_safe_redirect( self::url( 'stw-leads', array( 'stw_msg' => 'deleted' ) ) );
		exit;
	}

	static function export() {
		self::guard();
		check_admin_referer( 'stw_export' );
		global $wpdb;
		$t   = $wpdb->prefix . 'stw_leads';
		$cid = isset( $_GET['campaign'] ) ? absint( $_GET['campaign'] ) : 0;
		$s   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		list( $where, $args ) = self::leads_where( $cid, $s );
		$sql  = "SELECT * FROM $t WHERE $where ORDER BY id DESC";
		$rows = $wpdb->get_results( $args ? $wpdb->prepare( $sql, $args ) : $sql, ARRAY_A );
		$names = array();
		foreach ( STW_Core::get_campaigns() as $c ) {
			$names[ $c['id'] ] = $c['name'];
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=spin-to-win-leads-' . gmdate( 'Y-m-d' ) . '.csv' );
		echo "\xEF\xBB\xBF"; // UTF-8 BOM so Excel reads Bangla correctly
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'Date', 'Campaign', 'Email', 'Phone', 'Prize', 'Coupon', 'IP', 'Consent' ) );
		$safe = function ( $v ) {
			$v = (string) $v;
			return ( '' !== $v && in_array( $v[0], array( '=', '+', '-', '@' ), true ) ) ? "'" . $v : $v;
		};
		foreach ( $rows as $r ) {
			fputcsv( $out, array_map( $safe, array( $r['created_at'], isset( $names[ $r['campaign_id'] ] ) ? $names[ $r['campaign_id'] ] : $r['campaign_id'], $r['email'], $r['phone'], $r['prize'], $r['coupon'], $r['ip'], $r['consent'] ? 'yes' : 'no' ) ) );
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}

	/* ---------- Analytics ---------- */

	static function page_analytics() {
		self::guard();
		global $wpdb;
		$days = isset( $_GET['days'] ) ? absint( $_GET['days'] ) : 30;
		if ( ! in_array( $days, array( 7, 30, 90, 0 ), true ) ) {
			$days = 30;
		}
		$counts = STW_Core::counts( $days );
		echo '<div class="wrap stw-wrap"><h1>' . esc_html__( 'Analytics', 'spin-to-win' ) . '</h1><form method="get" class="stw-filter"><input type="hidden" name="page" value="stw-analytics"><select name="days" onchange="this.form.submit()">';
		foreach ( array( 7 => __( 'Last 7 days', 'spin-to-win' ), 30 => __( 'Last 30 days', 'spin-to-win' ), 90 => __( 'Last 90 days', 'spin-to-win' ), 0 => __( 'All time', 'spin-to-win' ) ) as $k => $l ) {
			echo '<option value="' . (int) $k . '" ' . selected( $days, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></form>';

		$tot = array( 'impression' => 0, 'spin' => 0, 'win' => 0, 'red' => 0 );
		$rows = '';
		foreach ( STW_Core::get_campaigns() as $c ) {
			$n   = isset( $counts[ $c['id'] ] ) ? $counts[ $c['id'] ] : array();
			$imp = (int) ( $n['impression'] ?? 0 );
			$sp  = (int) ( $n['spin'] ?? 0 );
			$win = (int) ( $n['win'] ?? 0 );
			$red = STW_Core::redeemed( $c['id'] );
			$tot['impression'] += $imp;
			$tot['spin']       += $sp;
			$tot['win']        += $win;
			$tot['red']        += $red;
			$rows .= '<tr><td>' . esc_html( $c['name'] ) . '</td><td>' . $imp . '</td><td>' . $sp . '</td><td>' . ( $imp ? round( $sp / $imp * 100, 1 ) . '%' : '—' ) . '</td><td>' . $win . '</td><td>' . $red . '</td></tr>';
		}
		$conv = $tot['impression'] ? round( $tot['spin'] / $tot['impression'] * 100, 1 ) . '%' : '—';
		echo '<div class="stw-stats">';
		foreach ( array( __( 'Popup views', 'spin-to-win' ) => $tot['impression'], __( 'Spins (leads)', 'spin-to-win' ) => $tot['spin'], __( 'Conversion', 'spin-to-win' ) => $conv, __( 'Coupons won', 'spin-to-win' ) => $tot['win'], __( 'Coupons redeemed (all time)', 'spin-to-win' ) => $tot['red'] ) as $l => $v ) {
			echo '<div class="stw-stat"><b>' . esc_html( $v ) . '</b><span>' . esc_html( $l ) . '</span></div>';
		}
		echo '</div>';
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Campaign', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Views', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Spins', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Conversion', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Coupons won', 'spin-to-win' ) . '</th><th>' . esc_html__( 'Redeemed', 'spin-to-win' ) . '</th></tr></thead><tbody>' . $rows . '</tbody></table>'; // phpcs:ignore WordPress.Security.EscapeOutput

		// daily chart (last 14 days)
		$t     = $wpdb->prefix . 'stw_events';
		$since = wp_date( 'Y-m-d 00:00:00', time() - DAY_IN_SECONDS * 13 );
		$res   = $wpdb->get_results( $wpdb->prepare( "SELECT DATE(created_at) d, event, COUNT(*) n FROM $t WHERE created_at >= %s GROUP BY d, event", $since ), ARRAY_A );
		$by    = array();
		foreach ( (array) $res as $r ) {
			$by[ $r['d'] ][ $r['event'] ] = (int) $r['n'];
		}
		$max  = 1;
		$days14 = array();
		for ( $i = 13; $i >= 0; $i-- ) {
			$d = wp_date( 'Y-m-d', time() - DAY_IN_SECONDS * $i );
			$days14[ $d ] = array( (int) ( $by[ $d ]['impression'] ?? 0 ), (int) ( $by[ $d ]['spin'] ?? 0 ) );
			$max = max( $max, $days14[ $d ][0] );
		}
		echo '<h2>' . esc_html__( 'Last 14 days', 'spin-to-win' ) . ' <small>(<span class="stw-key v"></span>' . esc_html__( 'views', 'spin-to-win' ) . ' <span class="stw-key s"></span>' . esc_html__( 'spins', 'spin-to-win' ) . ')</small></h2><div class="stw-chart">';
		foreach ( $days14 as $d => $v ) {
			echo '<div class="stw-col" title="' . esc_attr( $d . ' — ' . $v[0] . ' views, ' . $v[1] . ' spins' ) . '"><div class="bars"><i class="v" style="height:' . (int) round( $v[0] / $max * 100 ) . '%"></i><i class="s" style="height:' . (int) round( $v[1] / $max * 100 ) . '%"></i></div><span>' . esc_html( substr( $d, 8 ) ) . '</span></div>';
		}
		echo '</div></div>';
	}

	/* ---------- Settings ---------- */

	static function page_settings() {
		self::guard();
		$s = STW_Core::settings();
		echo '<div class="wrap stw-wrap"><h1>' . esc_html__( 'Settings', 'spin-to-win' ) . '</h1>';
		if ( isset( $_GET['stw_msg'] ) ) {
			self::notices();
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="stw_save_settings">';
		wp_nonce_field( 'stw_save_settings' );
		echo '<table class="form-table">';
		self::r( __( 'Visitor IP detection', 'spin-to-win' ), self::chk( 'trust_proxy', $s['trust_proxy'], __( 'Trust Cloudflare / proxy IP headers', 'spin-to-win' ) ), __( 'Enable only if your site is behind Cloudflare or a proxy; otherwise visitors could fake their IP.', 'spin-to-win' ) );
		self::r( __( 'Uninstall', 'spin-to-win' ), self::chk( 'delete_on_uninstall', $s['delete_on_uninstall'], __( 'Delete all campaigns, leads and stats when the plugin is deleted', 'spin-to-win' ) ) );
		echo '</table><p class="submit"><button class="button button-primary">' . esc_html__( 'Save settings', 'spin-to-win' ) . '</button></p></form></div>';
	}

	static function save_settings() {
		self::guard();
		check_admin_referer( 'stw_save_settings' );
		update_option( 'stw_settings', array(
			'trust_proxy'         => empty( $_POST['trust_proxy'] ) ? 0 : 1,
			'delete_on_uninstall' => empty( $_POST['delete_on_uninstall'] ) ? 0 : 1,
		) );
		wp_safe_redirect( self::url( 'stw-settings', array( 'stw_msg' => 'saved' ) ) );
		exit;
	}
}
