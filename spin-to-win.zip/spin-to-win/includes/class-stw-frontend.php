<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class STW_Frontend {

	static $campaign = null;

	static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'wp_ajax_stw_spin', array( __CLASS__, 'ajax_spin' ) );
		add_action( 'wp_ajax_nopriv_stw_spin', array( __CLASS__, 'ajax_spin' ) );
		add_action( 'wp_ajax_stw_track', array( __CLASS__, 'ajax_track' ) );
		add_action( 'wp_ajax_nopriv_stw_track', array( __CLASS__, 'ajax_track' ) );
	}

	/* ---------- Display rules (server side) ---------- */

	static function matches( $c ) {
		if ( 'active' !== $c['status'] ) {
			return false;
		}
		if ( $c['hide_logged_in'] && is_user_logged_in() ) {
			return false;
		}
		if ( function_exists( 'is_checkout' ) && ( is_checkout() || ( function_exists( 'is_cart' ) && is_cart() ) ) ) {
			return false;
		}
		$id = (int) get_queried_object_id();
		$ex = array_filter( array_map( 'absint', explode( ',', $c['exclude_ids'] ) ) );
		if ( $id && in_array( $id, $ex, true ) ) {
			return false;
		}
		switch ( $c['pages'] ) {
			case 'home':
				return is_front_page() || is_home();
			case 'shop':
				return function_exists( 'is_woocommerce' ) && is_woocommerce();
			case 'include':
				$in = array_filter( array_map( 'absint', explode( ',', $c['page_ids'] ) ) );
				return $id && in_array( $id, $in, true );
		}
		return true;
	}

	static function hex_rgb( $hex ) {
		$hex = ltrim( $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		return hexdec( substr( $hex, 0, 2 ) ) . ',' . hexdec( substr( $hex, 2, 2 ) ) . ',' . hexdec( substr( $hex, 4, 2 ) );
	}

	static function enqueue() {
		if ( is_admin() || is_customize_preview() ) {
			return;
		}
		foreach ( STW_Core::get_campaigns() as $c ) {
			if ( self::matches( $c ) ) {
				self::$campaign = $c;
				break;
			}
		}
		if ( ! self::$campaign ) {
			return;
		}
		$c   = self::$campaign;
		$col = $c['colors'];

		$st  = $c['style'];
		$ff  = 'inherit' === $st['font'] ? 'inherit' : ( 'system-ui' === $st['font'] ? 'system-ui,-apple-system,"SF Pro Display","Segoe UI",sans-serif' : '"' . $st['font'] . '",sans-serif' );
		$vars = array(
			'primary' => $col['primary'], 'secondary' => $col['secondary'], 'text' => $col['text'], 'bg' => $col['bg'],
			'btn' => $col['button'], 'btn-text' => $col['button_text'], 'heading' => $col['heading'], 'subtext' => $col['subtext'],
			'body' => $col['body_text'], 'from' => $col['panel_from'], 'to' => $col['panel_to'], 'pointer' => $col['pointer'],
			'in-bg' => $col['input_bg'], 'in-text' => $col['input_text'], 'in-border' => $col['input_border'], 'error' => $col['error'],
			'nt-bg' => $col['nt_bg'], 'nt-text' => $col['nt_text'], 'close' => $col['close'], 'tab-bg' => $col['tab_bg'], 'tab-text' => $col['tab_text'],
			'font' => $ff, 'maxw' => $st['max_width'] . 'px', 'radius' => $st['radius'] . 'px', 'btn-radius' => $st['btn_radius'] . 'px',
			'in-radius' => $st['input_radius'] . 'px', 'h-size' => $st['heading_size'] . 'px', 'sub-size' => $st['sub_size'] . 'px',
			'btn-size' => $st['btn_size'] . 'px', 'wheel-w' => $st['wheel_size'] . 'px',
			'shadow' => $st['shadow'] ? '0 24px 70px rgba(0,0,0,.45)' : 'none',
			'overlay' => 'rgba(' . self::hex_rgb( $col['overlay'] ) . ',.7)',
		);
		$css = ':root{';
		foreach ( $vars as $k => $v ) {
			$css .= '--stw-' . $k . ':' . $v . ';';
		}
		$css .= '}';
		if ( empty( $st['show_close'] ) ) {
			$css .= '.stw-overlay .stw-close{display:none!important}';
		}
		if ( ! empty( $st['glass'] ) ) {
			$bg = self::hex_rgb( $col['bg'] );
			$css .= '.stw-modal{background:rgba(' . $bg . ',.72)!important;-webkit-backdrop-filter:blur(28px) saturate(180%);backdrop-filter:blur(28px) saturate(180%);border:1px solid rgba(255,255,255,.55)}'
				. '.stw-wheel-col{background:linear-gradient(160deg,rgba(' . self::hex_rgb( $col['panel_from'] ) . ',.55),rgba(' . self::hex_rgb( $col['panel_to'] ) . ',.55))!important}'
				. '.stw-overlay .stw-in{background:rgba(255,255,255,.55)!important;-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,.7)!important;box-shadow:inset 0 1px 2px rgba(0,0,0,.06)!important}'
				. '.stw-overlay .stw-btn{background:linear-gradient(180deg,rgba(255,255,255,.35),rgba(255,255,255,0) 55%),var(--stw-btn)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.6),0 6px 16px rgba(0,0,0,.2)!important;border:1px solid rgba(255,255,255,.45)!important}'
				. '.stw-overlay .stw-nothanks{background:rgba(' . self::hex_rgb( $col['nt_bg'] ) . ',.6)!important;-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,.6)!important}'
				. '.stw-overlay .stw-close{background:rgba(255,255,255,.55)!important;-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px)}'
				. '.stw-tab{background:rgba(' . self::hex_rgb( $col['tab_bg'] ) . ',.55)!important;-webkit-backdrop-filter:blur(20px) saturate(180%);backdrop-filter:blur(20px) saturate(180%);border:1px solid rgba(255,255,255,.6)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.7),0 8px 24px rgba(0,0,0,.18)!important}';
		}
		if ( 'right' === $st['wheel_side'] ) {
			$css .= '@media(min-width:681px){.stw-modal{flex-direction:row-reverse}}';
		}
		if ( ! empty( $c['custom_css'] ) ) {
			$css .= $c['custom_css'];
		}
		wp_enqueue_style( 'stw-front', STW_URL . 'assets/css/frontend.css', array(), filemtime( STW_DIR . 'assets/css/frontend.css' ) );
		wp_add_inline_style( 'stw-front', $css );
		wp_enqueue_script( 'stw-wheel', STW_URL . 'assets/js/wheel.js', array(), filemtime( STW_DIR . 'assets/js/wheel.js' ), true );
		wp_enqueue_script( 'stw-front', STW_URL . 'assets/js/frontend.js', array( 'stw-wheel' ), filemtime( STW_DIR . 'assets/js/frontend.js' ), true );

		$keys = array( 'id', 'heading', 'subheading', 'button_text', 'win_title', 'win_text', 'lose_title', 'lose_text', 'already_text', 'copy_text', 'copied_text', 'shop_button', 'no_thanks', 'show_no_thanks', 'tab_text', 'tab_position', 'reopen_tab', 'err_email', 'err_phone', 'err_consent', 'err_generic', 'collect_email', 'collect_phone', 'email_placeholder', 'phone_placeholder', 'consent_on', 'consent_text', 'trigger_delay', 'trigger_scroll', 'trigger_exit', 'closed_days', 'cookie_days' );
		$cfg  = array();
		foreach ( $keys as $k ) {
			$cfg[ $k ] = $c[ $k ];
		}
		$cfg['segments'] = array();
		foreach ( $c['segments'] as $s ) {
			$cfg['segments'][] = array( 'label' => $s['label'], 'color' => $s['color'] );
		}
		wp_localize_script( 'stw-front', 'STW_DATA', array(
			'ajax'    => admin_url( 'admin-ajax.php' ),
			'devices' => $c['devices'],
			'colors'  => array( 'text' => $col['text'], 'ring' => $col['ring'], 'peg' => $col['peg'], 'hub' => $col['hub'], 'time' => $c['style']['spin_time'] ),
			'c'       => $cfg,
		) );
	}

	/* ---------- AJAX ---------- */

	static function fail( $msg, $extra = array() ) {
		wp_send_json_error( array_merge( array( 'message' => $msg ), $extra ) );
	}

	static function ajax_track() {
		$cid = isset( $_POST['campaign'] ) ? absint( $_POST['campaign'] ) : 0;
		if ( $cid && STW_Core::get_campaign( $cid ) ) {
			STW_Core::log_event( $cid, 'impression' );
		}
		wp_send_json_success();
	}

	static function ajax_spin() {
		global $wpdb;
		$cid = isset( $_POST['campaign'] ) ? absint( $_POST['campaign'] ) : 0;
		$c   = STW_Core::get_campaign( $cid );
		if ( ! $c || 'active' !== $c['status'] ) {
			self::fail( __( 'This campaign is not available.', 'spin-to-win' ) );
		}
		if ( ! empty( $_POST['stw_website'] ) ) { // honeypot
			self::fail( $c['err_generic'] );
		}

		$raw_email = isset( $_POST['email'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['email'] ) ) ) : '';
		$raw_phone = isset( $_POST['phone'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['phone'] ) ) ) : '';
		$email     = '';
		$phone     = '';

		if ( 'off' !== $c['collect_email'] ) {
			if ( '' === $raw_email ? 'required' === $c['collect_email'] : ! is_email( $raw_email ) ) {
				self::fail( $c['err_email'] );
			}
			$email = strtolower( sanitize_email( $raw_email ) );
		}
		if ( 'off' !== $c['collect_phone'] ) {
			$digits = strlen( preg_replace( '/\D/', '', $raw_phone ) );
			if ( '' === $raw_phone ? 'required' === $c['collect_phone'] : ( $digits < 7 || $digits > 15 ) ) {
				self::fail( $c['err_phone'] );
			}
			$phone = preg_replace( '/[^0-9+]/', '', $raw_phone );
		}
		$consent = empty( $_POST['consent'] ) ? 0 : 1;
		if ( $c['consent_on'] && ! $consent ) {
			self::fail( $c['err_consent'] );
		}

		/* ---- anti-spam ---- */
		$ip    = STW_Core::ip();
		$t     = $wpdb->prefix . 'stw_leads';
		$lock  = 'stw_lock_' . md5( $cid . '|' . $email . '|' . $phone . '|' . $ip );
		$dup   = ! empty( $_COOKIE[ 'stw_done_' . $cid ] ) || get_transient( $lock );

		if ( ! $dup && 'cookie' !== $c['antispam'] ) {
			if ( $email && $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE campaign_id = %d AND email = %s LIMIT 1", $cid, $email ) ) ) {
				$dup = true;
			}
			if ( ! $dup && $phone && $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE campaign_id = %d AND phone = %s LIMIT 1", $cid, $phone ) ) ) {
				$dup = true;
			}
		}
		if ( ! $dup && 'ip' === $c['antispam'] && $ip && $c['ip_max'] > 0 ) {
			$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE campaign_id = %d AND ip = %s", $cid, $ip ) );
			if ( $n >= $c['ip_max'] ) {
				$dup = true;
			}
		}
		if ( $dup ) {
			self::fail( $c['already_text'], array( 'already' => true ) );
		}
		set_transient( $lock, 1, 15 );

		/* ---- pick a segment (weighted, server-side) ---- */
		$segs  = $c['segments'];
		$total = 0;
		foreach ( $segs as $s ) {
			$total += max( 0, (float) $s['weight'] );
		}
		$r   = ( random_int( 0, 999999 ) / 1000000 ) * $total;
		$acc = 0;
		$idx = 0;
		foreach ( $segs as $i => $s ) {
			$acc += max( 0, (float) $s['weight'] );
			if ( $r < $acc ) {
				$idx = $i;
				break;
			}
		}
		$seg = $segs[ $idx ];

		/* ---- coupon ---- */
		$code   = '';
		$expiry = '';
		if ( 'coupon' === $seg['type'] && class_exists( 'WC_Coupon' ) ) {
			$code = self::make_coupon( $c, $seg, $email );
			if ( $code && $c['coupon_expiry'] > 0 ) {
				$date   = date_i18n( get_option( 'date_format' ), time() + DAY_IN_SECONDS * $c['coupon_expiry'] );
				$expiry = str_replace( '{date}', $date, $c['expiry_text'] );
			}
		}
		$win = '' !== $code;

		/* ---- store lead + events ---- */
		$wpdb->insert( $t, array(
			'campaign_id' => $cid,
			'email'       => $email,
			'phone'       => $phone,
			'prize'       => $seg['label'],
			'coupon'      => $code,
			'ip'          => $ip,
			'consent'     => $consent,
			'created_at'  => wp_date( 'Y-m-d H:i:s' ),
		) );
		STW_Core::log_event( $cid, 'spin' );
		if ( $win ) {
			STW_Core::log_event( $cid, 'win' );
		}

		/* ---- email the coupon ---- */
		if ( $win && $email && $c['email_coupon'] ) {
			$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
			$rep  = array( '{prize}' => $seg['label'], '{code}' => $code, '{expiry}' => $expiry, '{site}' => $site );
			$to = $email;
			$sj = strtr( $c['email_subject'], $rep );
			$bd = strtr( $c['email_body'], $rep );
			add_action( 'shutdown', function () use ( $to, $sj, $bd ) {
				if ( function_exists( 'fastcgi_finish_request' ) ) {
					fastcgi_finish_request();
				}
				wp_mail( $to, $sj, $bd );
			}, 1 );
		}

		wp_send_json_success( array(
			'index'  => $idx,
			'win'    => $win,
			'prize'  => $seg['label'],
			'code'   => $code,
			'expiry' => $expiry,
		) );
	}

	static function make_coupon( $c, $seg, $email ) {
		$code = '';
		for ( $i = 0; $i < 10; $i++ ) {
			$code = strtoupper( $c['coupon_prefix'] . wp_generate_password( 6, false, false ) );
			if ( ! wc_get_coupon_id_by_code( $code ) ) {
				break;
			}
		}
		$cp = new WC_Coupon();
		$cp->set_code( $code );
		$cp->set_discount_type( 'fixed_cart' === $seg['dtype'] ? 'fixed_cart' : 'percent' );
		$cp->set_amount( 'free_shipping' === $seg['dtype'] ? 0 : (float) $seg['amount'] );
		if ( 'free_shipping' === $seg['dtype'] ) {
			$cp->set_free_shipping( true );
		}
		$cp->set_usage_limit( 1 );
		$cp->set_usage_limit_per_user( 1 );
		if ( $c['coupon_expiry'] > 0 ) {
			$cp->set_date_expires( time() + DAY_IN_SECONDS * $c['coupon_expiry'] );
		}
		if ( '' !== $c['coupon_min'] ) {
			$cp->set_minimum_amount( $c['coupon_min'] );
		}
		$cp->set_individual_use( (bool) $c['coupon_individual'] );
		if ( $c['coupon_restrict_email'] && $email ) {
			$cp->set_email_restrictions( array( $email ) );
		}
		$cp->set_description( 'Spin to Win – ' . $c['name'] );
		$id = $cp->save();
		if ( ! $id ) {
			return '';
		}
		update_post_meta( $id, '_stw_campaign', $c['id'] );
		return $code;
	}
}
