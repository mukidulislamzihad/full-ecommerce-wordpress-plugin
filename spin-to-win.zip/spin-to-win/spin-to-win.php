<?php
/**
 * Plugin Name: Spin to Win – Gamified Discount Wheel
 * Description: Gamified spin-the-wheel popup for WordPress + WooCommerce. Capture emails/phones, auto-generate unique coupons, exit-intent, display rules, leads and analytics – everything customizable from the admin panel.
 * Version: 1.1.0
 * Author: Your Store
 * Text Domain: spin-to-win
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'STW_VERSION', '1.1.0' );
define( 'STW_FILE', __FILE__ );
define( 'STW_DIR', plugin_dir_path( __FILE__ ) );
define( 'STW_URL', plugin_dir_url( __FILE__ ) );

require_once STW_DIR . 'includes/class-stw-core.php';
require_once STW_DIR . 'includes/class-stw-frontend.php';
require_once STW_DIR . 'includes/class-stw-admin.php';

register_activation_hook( __FILE__, array( 'STW_Core', 'activate' ) );

add_action( 'before_woocommerce_init', function () {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', STW_FILE, true );
	}
} );

add_action( 'plugins_loaded', function () {
	load_plugin_textdomain( 'spin-to-win', false, dirname( plugin_basename( STW_FILE ) ) . '/languages' );
	STW_Core::boot();
	STW_Core::maybe_upgrade();
	STW_Frontend::init();
	if ( is_admin() ) {
		STW_Admin::init();
	}
} );
