=== Spin to Win – Gamified Discount Wheel ===
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later

Spin-the-wheel popup for WordPress + WooCommerce with lead capture, unique coupons, exit-intent, display rules, leads export and analytics.

== Description ==
Manage everything under "Spin to Win" in the WordPress admin: campaigns, wheel slices and chances, colors, texts, lead capture, display rules, coupon settings, leads and analytics.
