<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
$settings = get_option( 'stw_settings', array() );
if ( ! empty( $settings['delete_on_uninstall'] ) ) {
	global $wpdb;
	$ids = get_posts( array( 'post_type' => 'stw_campaign', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ) );
	foreach ( $ids as $id ) {
		wp_delete_post( $id, true );
	}
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}stw_leads" );
	$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}stw_events" );
	delete_option( 'stw_settings' );
	delete_option( 'stw_db_version' );
}
