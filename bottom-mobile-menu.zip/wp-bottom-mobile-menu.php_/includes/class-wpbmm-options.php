<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPBMM_Options {

    public function is_enabled() {
        return '0' !== (string) get_option( 'wpbmm_enabled', '1' );
    }

    public function get_style_presets() {
        return array(
            'classic'  => array(
                'label'       => 'Classic Line',
                'description' => 'Clean look exactly like a modern app bottom bar.',
                'defaults'    => array(
                    'wpbmm_menu_bg'           => '#ffffff',
                    'wpbmm_menu_bg_alt'       => '#ffffff',
                    'wpbmm_menu_border'       => '#dbeafe',
                    'wpbmm_icon_bg'           => '#eff6ff',
                    'wpbmm_icon_color'        => '#64748b',
                    'wpbmm_icon_active_bg'    => '#2563eb',
                    'wpbmm_icon_active_color' => '#2563eb',
                    'wpbmm_text_color'        => '#64748b',
                    'wpbmm_text_active_color' => '#2563eb',
                    'wpbmm_radius'            => '14',
                    'wpbmm_icon_size'         => '18',
                    'wpbmm_text_size'         => '13',
                    'wpbmm_icon_padding'      => '0',
                    'wpbmm_menu_padding_y'    => '10',
                    'wpbmm_item_gap'          => '4',
                    'wpbmm_font_family'       => 'inter',
                    'wpbmm_font_weight'       => '500',
                    'wpbmm_menu_max_width'    => '980',
                ),
            ),
            'outline'  => array(
                'label'       => 'Outline',
                'description' => 'Bordered menu with soft highlight for active item.',
                'defaults'    => array(
                    'wpbmm_menu_bg'           => '#ffffff',
                    'wpbmm_menu_bg_alt'       => '#f8fafc',
                    'wpbmm_menu_border'       => '#cbd5e1',
                    'wpbmm_icon_bg'           => '#ffffff',
                    'wpbmm_icon_color'        => '#475569',
                    'wpbmm_icon_active_bg'    => '#2563eb',
                    'wpbmm_icon_active_color' => '#2563eb',
                    'wpbmm_text_color'        => '#475569',
                    'wpbmm_text_active_color' => '#1d4ed8',
                    'wpbmm_radius'            => '24',
                    'wpbmm_icon_size'         => '18',
                    'wpbmm_text_size'         => '12',
                    'wpbmm_icon_padding'      => '0',
                    'wpbmm_menu_padding_y'    => '10',
                    'wpbmm_item_gap'          => '5',
                    'wpbmm_font_family'       => 'manrope',
                    'wpbmm_font_weight'       => '600',
                    'wpbmm_menu_max_width'    => '660',
                ),
            ),
            'floating' => array(
                'label'       => 'Floating Soft',
                'description' => 'Premium floating card style with rounded controls.',
                'defaults'    => array(
                    'wpbmm_menu_bg'           => '#ffffff',
                    'wpbmm_menu_bg_alt'       => '#f1f5f9',
                    'wpbmm_menu_border'       => '#e2e8f0',
                    'wpbmm_icon_bg'           => '#e2e8f0',
                    'wpbmm_icon_color'        => '#334155',
                    'wpbmm_icon_active_bg'    => '#2563eb',
                    'wpbmm_icon_active_color' => '#ffffff',
                    'wpbmm_text_color'        => '#475569',
                    'wpbmm_text_active_color' => '#1e3a8a',
                    'wpbmm_radius'            => '28',
                    'wpbmm_icon_size'         => '17',
                    'wpbmm_text_size'         => '12',
                    'wpbmm_icon_padding'      => '8',
                    'wpbmm_menu_padding_y'    => '9',
                    'wpbmm_item_gap'          => '4',
                    'wpbmm_font_family'       => 'manrope',
                    'wpbmm_font_weight'       => '600',
                    'wpbmm_menu_max_width'    => '700',
                ),
            ),
            'capsule'  => array(
                'label'       => 'Capsule',
                'description' => 'Rounded capsule tabs with warm accent and smooth depth.',
                'defaults'    => array(
                    'wpbmm_menu_bg'           => '#fff7ed',
                    'wpbmm_menu_bg_alt'       => '#ffedd5',
                    'wpbmm_menu_border'       => '#fdba74',
                    'wpbmm_icon_bg'           => '#ea580c',
                    'wpbmm_icon_color'        => '#ffffff',
                    'wpbmm_icon_active_bg'    => '#c2410c',
                    'wpbmm_icon_active_color' => '#ffffff',
                    'wpbmm_text_color'        => '#7c2d12',
                    'wpbmm_text_active_color' => '#431407',
                    'wpbmm_radius'            => '26',
                    'wpbmm_icon_size'         => '18',
                    'wpbmm_text_size'         => '12',
                    'wpbmm_icon_padding'      => '10',
                    'wpbmm_menu_padding_y'    => '9',
                    'wpbmm_item_gap'          => '5',
                    'wpbmm_font_family'       => 'poppins',
                    'wpbmm_font_weight'       => '600',
                    'wpbmm_menu_max_width'    => '700',
                ),
            ),
            'neon'     => array(
                'label'       => 'Neon Pulse',
                'description' => 'High contrast glow style for a bold premium look.',
                'defaults'    => array(
                    'wpbmm_menu_bg'           => '#0b1120',
                    'wpbmm_menu_bg_alt'       => '#111827',
                    'wpbmm_menu_border'       => '#06b6d4',
                    'wpbmm_icon_bg'           => '#22c55e',
                    'wpbmm_icon_color'        => '#052e16',
                    'wpbmm_icon_active_bg'    => '#06b6d4',
                    'wpbmm_icon_active_color' => '#042f2e',
                    'wpbmm_text_color'        => '#cbd5e1',
                    'wpbmm_text_active_color' => '#ecfeff',
                    'wpbmm_radius'            => '24',
                    'wpbmm_icon_size'         => '18',
                    'wpbmm_text_size'         => '12',
                    'wpbmm_icon_padding'      => '9',
                    'wpbmm_menu_padding_y'    => '9',
                    'wpbmm_item_gap'          => '5',
                    'wpbmm_font_family'       => 'manrope',
                    'wpbmm_font_weight'       => '600',
                    'wpbmm_menu_max_width'    => '660',
                ),
            ),
            'spotlight' => array(
                'label'       => 'Center Spotlight',
                'description' => 'Five-item menu with a raised circular Home button.',
                'defaults'    => array(
                    'wpbmm_menu_bg'                    => '#ffffff',
                    'wpbmm_menu_bg_alt'                => '#ffffff',
                    'wpbmm_menu_border'                => '#e5e7eb',
                    'wpbmm_icon_bg'                    => '#ffffff',
                    'wpbmm_icon_color'                 => '#ad0d2f',
                    'wpbmm_icon_active_bg'             => '#ad0d2f',
                    'wpbmm_icon_active_color'          => '#ffffff',
                    'wpbmm_text_color'                 => '#ad0d2f',
                    'wpbmm_text_active_color'          => '#ad0d2f',
                    'wpbmm_radius'                     => '16',
                    'wpbmm_icon_size'                  => '24',
                    'wpbmm_text_size'                  => '11',
                    'wpbmm_icon_padding'               => '0',
                    'wpbmm_menu_padding_y'             => '7',
                    'wpbmm_item_gap'                   => '6',
                    'wpbmm_font_family'                => 'system',
                    'wpbmm_font_weight'                => '600',
                    'wpbmm_menu_max_width'             => '360',
                    'wpbmm_spotlight_menu_bg'          => '#ffffff',
                    'wpbmm_spotlight_icon_color'       => '#ad0d2f',
                    'wpbmm_spotlight_text_color'       => '#ad0d2f',
                    'wpbmm_spotlight_center_bg'        => '#ad0d2f',
                    'wpbmm_spotlight_center_color'     => '#ffffff',
                ),
            ),
        );
    }

    public function get_font_choices() {
        return array(
            'inter'   => array(
                'label' => 'Inter',
                'stack' => '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
            ),
            'poppins' => array(
                'label' => 'Poppins',
                'stack' => '"Poppins", "Segoe UI", sans-serif',
            ),
            'manrope' => array(
                'label' => 'Manrope',
                'stack' => '"Manrope", "Segoe UI", sans-serif',
            ),
            'system'  => array(
                'label' => 'System UI',
                'stack' => 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
            ),
        );
    }

    public function get_standard_preset_item_defaults() {
        return array(
            'classic' => array(
                array( 'icon' => 'fa-solid fa-house', 'label' => 'Home' ),
                array( 'icon' => 'fa-solid fa-magnifying-glass', 'label' => 'Search' ),
                array( 'icon' => 'fa-solid fa-bag-shopping', 'label' => 'Cart' ),
                array( 'icon' => 'fa-regular fa-circle-user', 'label' => 'Account' ),
            ),
            'outline' => array(
                array( 'icon' => 'fa-solid fa-house', 'label' => 'Home' ),
                array( 'icon' => 'fa-regular fa-compass', 'label' => 'Browse' ),
                array( 'icon' => 'fa-solid fa-phone', 'label' => 'Call' ),
                array( 'icon' => 'fa-regular fa-circle-user', 'label' => 'Account' ),
            ),
            'floating' => array(
                array( 'icon' => 'fa-solid fa-house', 'label' => 'Home' ),
                array( 'icon' => 'fa-solid fa-store', 'label' => 'Shop' ),
                array( 'icon' => 'fa-solid fa-bag-shopping', 'label' => 'Cart' ),
                array( 'icon' => 'fa-regular fa-circle-user', 'label' => 'Account' ),
            ),
            'capsule' => array(
                array( 'icon' => 'fa-solid fa-house', 'label' => 'Home' ),
                array( 'icon' => 'fa-solid fa-tag', 'label' => 'Deals' ),
                array( 'icon' => 'fa-solid fa-bag-shopping', 'label' => 'Cart' ),
                array( 'icon' => 'fa-regular fa-circle-user', 'label' => 'Profile' ),
            ),
            'neon' => array(
                array( 'icon' => 'fa-solid fa-house', 'label' => 'Home' ),
                array( 'icon' => 'fa-solid fa-bars-staggered', 'label' => 'Menu' ),
                array( 'icon' => 'fa-regular fa-bell', 'label' => 'Alerts' ),
                array( 'icon' => 'fa-regular fa-circle-user', 'label' => 'Account' ),
            ),
        );
    }

    public function sanitize_url_option( $value ) {
        $value = trim( (string) $value );

        if ( '' === $value ) {
            return '';
        }

        if ( '#' === $value ) {
            return '#';
        }

        return esc_url_raw( $value );
    }

    public function sanitize_color_option( $value ) {
        $value = trim( (string) $value );

        if ( '' === $value ) {
            return '';
        }

        $color = sanitize_hex_color( $value );

        return $color ? $color : '';
    }

    public function sanitize_text_option( $value ) {
        return sanitize_text_field( $value );
    }

    public function sanitize_icon_class_option( $value ) {
        $value = sanitize_text_field( $value );
        $value = preg_replace( '/[^a-zA-Z0-9\-\s]/', '', $value );
        $value = preg_replace( '/\s+/', ' ', trim( $value ) );

        return $value;
    }

    public function sanitize_font_family( $value ) {
        $choices = $this->get_font_choices();

        return isset( $choices[ $value ] ) ? $value : 'inter';
    }

    public function sanitize_checkbox( $value ) {
        return empty( $value ) ? '0' : '1';
    }

    public function sanitize_int_option( $value, $min, $max, $default ) {
        if ( ! is_numeric( $value ) ) {
            return (int) $default;
        }

        $value = (int) $value;

        if ( $value < $min ) {
            return (int) $min;
        }

        if ( $value > $max ) {
            return (int) $max;
        }

        return $value;
    }

    public function sanitize_color_value( $value, $fallback ) {
        $sanitized = sanitize_hex_color( (string) $value );

        return $sanitized ? $sanitized : $fallback;
    }

    public function get_active_preset_key() {
        $preset  = get_option( 'wpbmm_style_preset', 'classic' );
        $presets = $this->get_style_presets();

        if ( ! isset( $presets[ $preset ] ) ) {
            return 'classic';
        }

        return $preset;
    }

    public function get_option_with_preset_default( $option_name, $preset = null ) {
        if ( null === $preset ) {
            $preset = $this->get_active_preset_key();
        }

        $stored = get_option( $option_name, null );

        if ( false !== $stored && null !== $stored && '' !== $stored ) {
            return $stored;
        }

        $presets = $this->get_style_presets();

        if ( isset( $presets[ $preset ]['defaults'][ $option_name ] ) ) {
            return $presets[ $preset ]['defaults'][ $option_name ];
        }

        if ( isset( $presets['classic']['defaults'][ $option_name ] ) ) {
            return $presets['classic']['defaults'][ $option_name ];
        }

        return '';
    }

    public function get_show_labels() {
        return '0' !== (string) get_option( 'wpbmm_show_labels', '1' );
    }

    public function get_link_option( $option_name, $fallback ) {
        $value = trim( (string) get_option( $option_name, '' ) );

        if ( '' === $value ) {
            return $fallback;
        }

        if ( '#' === $value ) {
            return '#';
        }

        $value = esc_url_raw( $value );

        return '' === $value ? $fallback : $value;
    }

    public function get_cart_link_option( $option_name, $fallback ) {
        $value = trim( (string) get_option( $option_name, '' ) );

        if ( '' === $value ) {
            return $fallback;
        }

        if ( '#' === $value ) {
            return '#';
        }

        $normalized = strtolower( trim( $value ) );
        $normalized = trim( $normalized, "[] \t\n\r\0\x0B" );

        // Legacy invalid values that point to broken pages.
        $invalid_tokens = array(
            'woocommerce_cart',
            'woocommerce cart',
            'wc_cart',
            'wc_get_cart_url()',
        );

        if ( in_array( $normalized, $invalid_tokens, true ) ) {
            return $fallback;
        }

        if ( ! preg_match( '#^(https?:)?//#i', $value ) && '/' !== substr( $value, 0, 1 ) ) {
            // Convert plain slugs to absolute site URLs.
            $value = home_url( '/' . trim( $value, '/' ) . '/' );
        }

        $sanitized = esc_url_raw( $value );

        if ( '' === $sanitized ) {
            return $fallback;
        }

        $path = wp_parse_url( $sanitized, PHP_URL_PATH );

        if ( is_string( $path ) ) {
            $slug = trim( strtolower( $path ), '/' );

            if ( in_array( $slug, array( 'woocommerce_cart', 'wc_cart' ), true ) ) {
                return $fallback;
            }
        }

        return $sanitized;
    }

    public function get_text_with_default( $option_name, $fallback ) {
        $value = sanitize_text_field( (string) get_option( $option_name, '' ) );

        return '' === $value ? $fallback : $value;
    }

    public function get_icon_with_default( $option_name, $fallback ) {
        $value = $this->sanitize_icon_class_option( (string) get_option( $option_name, '' ) );

        return '' === $value ? $fallback : $value;
    }

    public function get_menu_items() {
        if ( 'spotlight' === $this->get_active_preset_key() ) {
            return $this->get_spotlight_menu_items();
        }

        $cart_default    = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' );
        $account_default = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/my-account/' );
        $browse_default  = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
        $browse_label    = $this->get_text_with_default( 'wpbmm_label_chat', 'Browse' );
        $browse_icon     = $this->get_icon_with_default( 'wpbmm_icon_chat', 'fa-regular fa-compass' );
        $browse_link     = $this->get_link_option( 'wpbmm_link_5', $browse_default );
        $home_icon       = $this->get_icon_with_default( 'wpbmm_icon_home', 'fa-solid fa-house' );
        $cart_icon       = $this->get_icon_with_default( 'wpbmm_icon_cart', 'fa-solid fa-bag-shopping' );
        $account_icon    = $this->get_icon_with_default( 'wpbmm_icon_account', 'fa-regular fa-circle-user' );

        if ( 'WhatsApp' === $browse_label ) {
            $browse_label = 'Browse';
        }

        if ( in_array( $browse_icon, array( 'fa-brands fa-whatsapp', 'fa-solid fa-border-all' ), true ) ) {
            $browse_icon = 'fa-regular fa-compass';
        }

        if ( false !== strpos( $browse_link, 'wa.me' ) ) {
            $browse_link = $browse_default;
        }

        if ( 'fa-regular fa-house' === $home_icon || 'fa-regular fa-home' === $home_icon ) {
            $home_icon = 'fa-solid fa-house';
        }

        if ( 'fa-solid fa-cart-shopping' === $cart_icon ) {
            $cart_icon = 'fa-solid fa-bag-shopping';
        }

        if ( in_array( $account_icon, array( 'fa-solid fa-user', 'fa-regular fa-user' ), true ) ) {
            $account_icon = 'fa-regular fa-circle-user';
        }

        $items = array(
            array(
                'key'      => 'home',
                'icon'     => $home_icon,
                'label'    => $this->get_text_with_default( 'wpbmm_label_home', 'Home' ),
                'link'     => $this->get_link_option( 'wpbmm_link_3', home_url( '/' ) ),
            ),
            array(
                'key'      => 'browse',
                'icon'     => $browse_icon,
                'label'    => $browse_label,
                'link'     => $browse_link,
            ),
            array(
                'key'      => 'cart',
                'icon'     => $cart_icon,
                'label'    => $this->get_text_with_default( 'wpbmm_label_cart', 'Cart' ),
                'link'     => $this->get_cart_link_option( 'wpbmm_link_2', $cart_default ),
            ),
            array(
                'key'      => 'account',
                'icon'     => $account_icon,
                'label'    => $this->get_text_with_default( 'wpbmm_label_account', 'Account' ),
                'link'     => $this->get_link_option( 'wpbmm_link_4', $account_default ),
            ),
        );

        $preset_defaults = $this->get_standard_preset_item_defaults();
        $item_defaults   = isset( $preset_defaults[ $this->get_active_preset_key() ] ) ? $preset_defaults[ $this->get_active_preset_key() ] : $preset_defaults['classic'];
        $preset_prefix   = 'wpbmm_' . $this->get_active_preset_key() . '_';

        foreach ( $items as $index => &$item ) {
            $slot          = $index + 1;
            $default_item  = isset( $item_defaults[ $index ] ) ? $item_defaults[ $index ] : array();
            $default_icon  = isset( $default_item['icon'] ) ? $default_item['icon'] : $item['icon'];
            $default_label = isset( $default_item['label'] ) ? $default_item['label'] : $item['label'];

            $item['icon']  = $this->get_icon_with_default( $preset_prefix . 'icon_' . $slot, $default_icon );
            $item['label'] = $this->get_text_with_default( $preset_prefix . 'label_' . $slot, $default_label );
            $item['link']  = $this->get_link_option( $preset_prefix . 'link_' . $slot, $item['link'] );
        }
        unset( $item );

        return $items;
    }

    public function get_spotlight_menu_items() {
        $shop_default = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
        $category_label  = $this->get_text_with_default( 'wpbmm_spotlight_label_category', 'ক্যাটাগরি' );
        $whatsapp_label  = $this->get_text_with_default( 'wpbmm_spotlight_label_whatsapp', 'হোয়াটসঅ্যাপ' );
        $home_label      = $this->get_text_with_default( 'wpbmm_spotlight_label_home', 'হোম' );
        $messenger_label = $this->get_text_with_default( 'wpbmm_spotlight_label_messenger', 'মেসেঞ্জার' );
        $track_label     = $this->get_text_with_default( 'wpbmm_spotlight_label_track', 'অর্ডার ট্র্যাক' );
        $category_icon   = $this->get_icon_with_default( 'wpbmm_spotlight_icon_category', 'fa-solid fa-border-all' );
        $track_icon      = $this->get_icon_with_default( 'wpbmm_spotlight_icon_track', 'fa-solid fa-truck' );

        if ( 'Categories' === $category_label ) {
            $category_label = 'ক্যাটাগরি';
        }
        if ( 'WhatsApp' === $whatsapp_label ) {
            $whatsapp_label = 'হোয়াটসঅ্যাপ';
        }
        if ( 'Home' === $home_label ) {
            $home_label = 'হোম';
        }
        if ( 'Messenger' === $messenger_label ) {
            $messenger_label = 'মেসেঞ্জার';
        }
        if ( in_array( $track_label, array( 'Track', 'Track order' ), true ) ) {
            $track_label = 'অর্ডার ট্র্যাক';
        }
        if ( 'fa-solid fa-table-cells-large' === $category_icon ) {
            $category_icon = 'fa-solid fa-border-all';
        }
        if ( 'fa-solid fa-truck-fast' === $track_icon ) {
            $track_icon = 'fa-solid fa-truck';
        }

        return array(
            array(
                'key'   => 'category',
                'icon'  => $category_icon,
                'label' => $category_label,
                'link'  => $this->get_link_option( 'wpbmm_spotlight_link_category', $shop_default ),
            ),
            array(
                'key'   => 'whatsapp',
                'icon'  => $this->get_icon_with_default( 'wpbmm_spotlight_icon_whatsapp', 'fa-brands fa-whatsapp' ),
                'label' => $whatsapp_label,
                'link'  => $this->get_link_option( 'wpbmm_spotlight_link_whatsapp', '#' ),
            ),
            array(
                'key'   => 'home',
                'icon'  => $this->get_icon_with_default( 'wpbmm_spotlight_icon_home', 'fa-solid fa-house' ),
                'label' => $home_label,
                'link'  => $this->get_link_option( 'wpbmm_spotlight_link_home', home_url( '/' ) ),
            ),
            array(
                'key'   => 'messenger',
                'icon'  => $this->get_icon_with_default( 'wpbmm_spotlight_icon_messenger', 'fa-brands fa-facebook-messenger' ),
                'label' => $messenger_label,
                'link'  => $this->get_link_option( 'wpbmm_spotlight_link_messenger', '#' ),
            ),
            array(
                'key'   => 'track',
                'icon'  => $track_icon,
                'label' => $track_label,
                'link'  => $this->get_link_option( 'wpbmm_spotlight_link_track', home_url( '/order-tracking/' ) ),
            ),
        );
    }

    public function is_item_active( $key ) {
        if ( 'home' === $key ) {
            return is_front_page() || is_home();
        }

        if ( in_array( $key, array( 'browse', 'category' ), true ) ) {
            if ( function_exists( 'is_shop' ) && is_shop() ) {
                return true;
            }

            if ( function_exists( 'is_product_category' ) && is_product_category() ) {
                return true;
            }

            if ( function_exists( 'is_product_tag' ) && is_product_tag() ) {
                return true;
            }

            if ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() ) {
                return true;
            }

            if ( function_exists( 'is_product' ) && is_product() ) {
                return true;
            }

            return is_post_type_archive( 'product' );
        }

        if ( 'cart' === $key && function_exists( 'is_cart' ) ) {
            return is_cart();
        }

        if ( 'account' === $key && function_exists( 'is_account_page' ) ) {
            return is_account_page();
        }

        return false;
    }

    public function get_style_values() {
        $preset = $this->get_active_preset_key();

        $menu_bg           = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_menu_bg', $preset ), '#ffffff' );
        $menu_bg_alt       = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_menu_bg_alt', $preset ), '#ffffff' );
        $menu_border       = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_menu_border', $preset ), '#dbeafe' );
        $icon_bg           = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_icon_bg', $preset ), '#eff6ff' );
        $icon_color        = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_icon_color', $preset ), '#64748b' );
        $icon_active_bg    = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_icon_active_bg', $preset ), '#2563eb' );
        $icon_active_color = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_icon_active_color', $preset ), '#2563eb' );
        $text_color        = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_text_color', $preset ), '#64748b' );
        $text_active_color = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_text_active_color', $preset ), '#2563eb' );

        if ( 'spotlight' === $preset ) {
            $menu_bg           = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_spotlight_menu_bg', $preset ), '#ffffff' );
            $menu_bg_alt       = $menu_bg;
            $icon_color        = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_spotlight_icon_color', $preset ), '#ad0d2f' );
            $icon_active_bg    = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_spotlight_center_bg', $preset ), '#ad0d2f' );
            $icon_active_color = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_spotlight_center_color', $preset ), '#ffffff' );
            $text_color        = $this->sanitize_color_value( $this->get_option_with_preset_default( 'wpbmm_spotlight_text_color', $preset ), '#ad0d2f' );
            $text_active_color = $text_color;

            // Move installations that still have the former preset red to the reference palette.
            $icon_color        = '#a50f2d' === strtolower( $icon_color ) ? '#ad0d2f' : $icon_color;
            $icon_active_bg    = '#a50f2d' === strtolower( $icon_active_bg ) ? '#ad0d2f' : $icon_active_bg;
            $text_color        = '#a50f2d' === strtolower( $text_color ) ? '#ad0d2f' : $text_color;
            $text_active_color = $text_color;
        } else {
            $preset_color_fields = array(
                'menu_bg'      => 'menu_bg',
                'icon_color'   => 'icon_color',
                'text_color'   => 'text_color',
                'active_bg'    => 'icon_active_bg',
                'active_color' => 'icon_active_color',
            );

            foreach ( $preset_color_fields as $custom_suffix => $style_key ) {
                $stored_color = get_option( 'wpbmm_' . $preset . '_' . $custom_suffix, '' );

                if ( '' === $stored_color ) {
                    continue;
                }

                $sanitized_color = $this->sanitize_color_value( $stored_color, '' );

                if ( '' === $sanitized_color ) {
                    continue;
                }

                if ( 'menu_bg' === $style_key ) {
                    $menu_bg = $sanitized_color;
                    $menu_bg_alt = $sanitized_color;
                } elseif ( 'icon_color' === $style_key ) {
                    $icon_color = $sanitized_color;
                } elseif ( 'text_color' === $style_key ) {
                    $text_color = $sanitized_color;
                    $text_active_color = $sanitized_color;
                } elseif ( 'icon_active_bg' === $style_key ) {
                    $icon_active_bg = $sanitized_color;
                } elseif ( 'icon_active_color' === $style_key ) {
                    $icon_active_color = $sanitized_color;
                }
            }
        }

        $font_choices = $this->get_font_choices();
        $font_key     = $this->sanitize_font_family( $this->get_option_with_preset_default( 'wpbmm_font_family', $preset ) );
        $text_size    = $this->sanitize_int_option( $this->get_option_with_preset_default( 'wpbmm_text_size', $preset ), 9, 22, 13 );
        $preset_font  = sanitize_key( (string) get_option( 'wpbmm_' . $preset . '_font_family', '' ) );
        $preset_size  = get_option( 'wpbmm_' . $preset . '_font_size', '' );

        $radius         = $this->sanitize_int_option( $this->get_option_with_preset_default( 'wpbmm_radius', $preset ), 0, 48, 14 );
        $icon_size      = $this->sanitize_int_option( $this->get_option_with_preset_default( 'wpbmm_icon_size', $preset ), 12, 48, 18 );
        $menu_padding_y = $this->sanitize_int_option( $this->get_option_with_preset_default( 'wpbmm_menu_padding_y', $preset ), 4, 24, 10 );
        $item_gap       = $this->sanitize_int_option( $this->get_option_with_preset_default( 'wpbmm_item_gap', $preset ), 0, 20, 4 );
        $font_weight    = $this->sanitize_int_option( $this->get_option_with_preset_default( 'wpbmm_font_weight', $preset ), 400, 800, 500 );
        $menu_max_width = $this->sanitize_int_option( $this->get_option_with_preset_default( 'wpbmm_menu_max_width', $preset ), 320, 1200, 980 );

        if ( 'spotlight' === $preset ) {
            // The reference layout has a fixed visual scale; only its editor typography override is variable.
            $radius         = 16;
            $icon_size      = 24;
            $menu_padding_y = 7;
            $item_gap       = 6;
            $font_weight    = 600;
            $menu_max_width = 360;
            $text_size      = 11;
        }

        if ( '' !== $preset_font ) {
            $font_key = $this->sanitize_font_family( $preset_font );
        }

        if ( '' !== $preset_size ) {
            $text_size = $this->sanitize_int_option( $preset_size, 9, 22, $text_size );
        }

        return array(
            'preset'            => $preset,
            'menu_bg'           => $menu_bg,
            'menu_bg_alt'       => $menu_bg_alt,
            'menu_border'       => $menu_border,
            'icon_bg'           => $icon_bg,
            'icon_color'        => $icon_color,
            'icon_active_bg'    => $icon_active_bg,
            'icon_active_color' => $icon_active_color,
            'text_color'        => $text_color,
            'text_active_color' => $text_active_color,
            'radius'            => $radius,
            'icon_size'         => $icon_size,
            'text_size'         => $text_size,
            'icon_padding'      => $this->sanitize_int_option( $this->get_option_with_preset_default( 'wpbmm_icon_padding', $preset ), 0, 20, 0 ),
            'menu_padding_y'    => $menu_padding_y,
            'item_gap'          => $item_gap,
            'font_weight'       => $font_weight,
            'menu_max_width'    => $menu_max_width,
            'font_key'          => $font_key,
            'font_stack'        => $font_choices[ $font_key ]['stack'],
            'show_labels'       => $this->get_show_labels(),
            'icon_shadow'       => $this->hex_to_rgba( $icon_bg, 0.20 ),
            'active_shadow'     => $this->hex_to_rgba( $icon_active_bg, 0.28 ),
            'neon_border'       => $this->hex_to_rgba( $menu_border, 0.35 ),
            'neon_icon_1'       => $this->hex_to_rgba( $icon_bg, 0.50 ),
            'neon_icon_2'       => $this->hex_to_rgba( $icon_bg, 0.28 ),
            'neon_active_1'     => $this->hex_to_rgba( $icon_active_bg, 0.50 ),
            'neon_active_2'     => $this->hex_to_rgba( $icon_active_bg, 0.35 ),
        );
    }

    public function hex_to_rgba( $hex, $alpha ) {
        $hex = ltrim( $this->sanitize_color_value( $hex, '#000000' ), '#' );

        if ( 3 === strlen( $hex ) ) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }

        $int = hexdec( $hex );

        $r = ( $int >> 16 ) & 255;
        $g = ( $int >> 8 ) & 255;
        $b = $int & 255;

        $alpha = max( 0, min( 1, (float) $alpha ) );

        return sprintf( 'rgba(%d, %d, %d, %.3f)', $r, $g, $b, $alpha );
    }
}
