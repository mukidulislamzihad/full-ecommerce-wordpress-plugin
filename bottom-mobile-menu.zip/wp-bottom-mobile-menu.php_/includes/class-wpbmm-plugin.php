<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPBMM_Plugin {

    /** @var WPBMM_Options */
    private $options;

    /** @var WPBMM_License */
    private $license;

    /** @var WPBMM_Frontend */
    private $frontend;

    /** @var WPBMM_Admin */
    private $admin;

    public function __construct() {
        $this->options  = new WPBMM_Options();
        $this->license  = new WPBMM_License();
        $this->frontend = new WPBMM_Frontend( $this->options, $this->license );
        $this->admin    = new WPBMM_Admin( $this->options, $this->license );
    }

    public function register_hooks() {
        $this->license->register_hooks();
        $this->frontend->register_hooks();
        $this->admin->register_hooks();

        add_filter( 'plugin_action_links_' . plugin_basename( WPBMM_FILE ), array( $this, 'add_settings_link' ) );
        add_filter( 'the_content', array( $this, 'repair_legacy_cart_shortcode_content' ), 5 );
    }

    public function add_settings_link( $links ) {
        $settings_link = '<a href="admin.php?page=wpbmm-settings">Settings</a>';
        array_unshift( $links, $settings_link );

        return $links;
    }

    public function repair_legacy_cart_shortcode_content( $content ) {
        if ( is_admin() || ! function_exists( 'is_cart' ) || ! is_cart() ) {
            return $content;
        }

        if ( ! is_main_query() || ! in_the_loop() ) {
            return $content;
        }

        $plain = html_entity_decode( wp_strip_all_tags( (string) $content ), ENT_QUOTES, 'UTF-8' );
        $plain = preg_replace( '/\x{00a0}/u', ' ', $plain );
        $plain = trim( (string) $plain );

        if ( preg_match( '/^\[?\s*woocommerce_cart\s*\]?$/i', $plain ) ) {
            return '[woocommerce_cart]';
        }

        return $content;
    }
}
