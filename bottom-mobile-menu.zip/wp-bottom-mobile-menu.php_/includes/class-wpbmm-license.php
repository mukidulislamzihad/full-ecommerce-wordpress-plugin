<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPBMM_License {

    const OPTION_KEY          = 'wpbmm_license_key';
    const OPTION_SOURCE       = 'wpbmm_license_source';
    const OPTION_STATUS       = 'wpbmm_license_status';
    const OPTION_MESSAGE      = 'wpbmm_license_message';
    const OPTION_LAST_CHECKED = 'wpbmm_license_last_checked';
    const OPTION_LAST_SUCCESS = 'wpbmm_license_last_success';
    const CRON_HOOK           = 'wpbmm_license_daily_validation';

    public function register_hooks() {
        add_action( 'admin_post_wpbmm_license_action', array( $this, 'handle_admin_action' ) );
        add_action( self::CRON_HOOK, array( $this, 'validate_stored_license' ) );
        add_action( 'admin_init', array( $this, 'ensure_validation_schedule' ) );
    }

    public function ensure_validation_schedule() {
        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON_HOOK );
        }
    }

    public function is_active() {
        return 'active' === (string) get_option( self::OPTION_STATUS, 'inactive' )
            && '' !== $this->get_stored_key();
    }

    public function get_status() {
        return $this->is_active() ? 'active' : 'inactive';
    }

    public function get_status_message() {
        return sanitize_text_field( (string) get_option( self::OPTION_MESSAGE, '' ) );
    }

    public function get_last_checked() {
        return absint( get_option( self::OPTION_LAST_CHECKED, 0 ) );
    }

    public function get_masked_key() {
        if ( 'master' === $this->get_license_source() ) {
            return 'Master license · ••••1426';
        }

        $key = $this->get_stored_key();

        if ( '' === $key ) {
            return '';
        }

        $suffix = substr( $key, -4 );

        return 'BRB-••••-••••-' . $suffix;
    }

    public function get_domain() {
        $domain = wp_parse_url( home_url(), PHP_URL_HOST );

        if ( ! is_string( $domain ) || '' === $domain ) {
            $domain = preg_replace( '#^https?://#i', '', home_url() );
            $domain = strtok( $domain, '/' );
        }

        $domain = strtolower( trim( (string) $domain ) );
        $domain = preg_replace( '/^www\./i', '', $domain );

        return sanitize_text_field( $domain );
    }

    public function handle_admin_action() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to manage this license.', 'wpbmm' ) );
        }

        check_admin_referer( 'wpbmm_license_action', 'wpbmm_license_nonce' );

        $operation = isset( $_POST['license_operation'] ) ? sanitize_key( wp_unslash( $_POST['license_operation'] ) ) : '';

        if ( ! in_array( $operation, array( 'activate', 'check', 'deactivate' ), true ) ) {
            $this->set_admin_notice( false, 'Invalid license action.' );
            $this->redirect_to_license_tab();
        }

        if ( 'activate' === $operation ) {
            $license_key = isset( $_POST['wpbmm_license_key'] ) ? $this->sanitize_license_key( wp_unslash( $_POST['wpbmm_license_key'] ) ) : '';

            if ( '' === $license_key ) {
                $this->set_admin_notice( false, 'Enter a Borbila license key to continue.' );
                $this->redirect_to_license_tab();
            }

            if ( $this->is_master_license_key( $license_key ) ) {
                $this->activate_master_license();
                $this->set_admin_notice( true, 'Master license activated instantly.' );
                $this->redirect_to_license_tab();
            }
        } else {
            $license_key = $this->get_stored_key();

            if ( '' === $license_key ) {
                $this->set_admin_notice( false, 'No license key is stored on this website.' );
                $this->redirect_to_license_tab();
            }
        }

        if ( 'master' === $this->get_license_source() ) {
            $this->handle_master_license_action( $operation );
            $this->redirect_to_license_tab();
        }

        $result = $this->request( $operation, $license_key );

        if ( 'activate' === $operation && $result['success'] ) {
            $this->store_private_option( self::OPTION_KEY, $license_key );
            $this->store_private_option( self::OPTION_SOURCE, 'server' );
            $this->store_private_option( self::OPTION_STATUS, 'active' );
            $this->store_private_option( self::OPTION_LAST_SUCCESS, time() );
        }

        if ( 'check' === $operation && ! $result['connection_error'] ) {
            $this->store_private_option( self::OPTION_STATUS, $result['success'] ? 'active' : 'inactive' );

            if ( $result['success'] ) {
                $this->store_private_option( self::OPTION_LAST_SUCCESS, time() );
            }
        }

        if ( 'deactivate' === $operation && $result['success'] ) {
            delete_option( self::OPTION_KEY );
            delete_option( self::OPTION_SOURCE );
            $this->store_private_option( self::OPTION_STATUS, 'inactive' );
            delete_option( self::OPTION_LAST_SUCCESS );
        }

        $this->store_private_option( self::OPTION_MESSAGE, $result['message'] );
        $this->store_private_option( self::OPTION_LAST_CHECKED, time() );
        $this->set_admin_notice( $result['success'], $result['message'] );
        $this->redirect_to_license_tab();
    }

    public function validate_stored_license() {
        if ( 'master' === $this->get_license_source() ) {
            $this->store_private_option( self::OPTION_STATUS, 'active' );
            $this->store_private_option( self::OPTION_MESSAGE, 'Master license valid.' );
            $this->store_private_option( self::OPTION_LAST_CHECKED, time() );
            $this->store_private_option( self::OPTION_LAST_SUCCESS, time() );
            return;
        }

        $license_key = $this->get_stored_key();

        if ( '' === $license_key ) {
            return;
        }

        $result = $this->request( 'check', $license_key );

        $this->store_private_option( self::OPTION_LAST_CHECKED, time() );
        $this->store_private_option( self::OPTION_MESSAGE, $result['message'] );

        if ( $result['connection_error'] ) {
            return;
        }

        $this->store_private_option( self::OPTION_STATUS, $result['success'] ? 'active' : 'inactive' );

        if ( $result['success'] ) {
            $this->store_private_option( self::OPTION_LAST_SUCCESS, time() );
        }
    }

    public function pop_admin_notice() {
        $key    = 'wpbmm_license_notice_' . get_current_user_id();
        $notice = get_transient( $key );

        if ( false !== $notice ) {
            delete_transient( $key );
        }

        return is_array( $notice ) ? $notice : array();
    }

    private function request( $action, $license_key ) {
        $allowed_actions = array( 'activate', 'check', 'deactivate' );

        if ( ! in_array( $action, $allowed_actions, true ) ) {
            return array(
                'success'          => false,
                'connection_error' => false,
                'message'          => 'Invalid license action.',
            );
        }

        $response = wp_remote_post(
            trailingslashit( WPBMM_LICENSE_API_URL ) . $action,
            array(
                'timeout'   => 20,
                'sslverify' => true,
                'headers'   => array(
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                ),
                'body'      => wp_json_encode(
                    array(
                        'license_key' => $this->sanitize_license_key( $license_key ),
                        'template_id' => WPBMM_LICENSE_TEMPLATE_ID,
                        'domain'      => $this->get_domain(),
                    )
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return array(
                'success'          => false,
                'connection_error' => true,
                'message'          => 'Could not connect to the Borbila license server. Your last valid state was kept.',
            );
        }

        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( ! is_array( $data ) || ! array_key_exists( 'success', $data ) ) {
            return array(
                'success'          => false,
                'connection_error' => true,
                'message'          => 'The license server returned an invalid response. Your last valid state was kept.',
            );
        }

        return array(
            'success'          => (bool) $data['success'],
            'connection_error' => false,
            'message'          => isset( $data['message'] ) ? sanitize_text_field( $data['message'] ) : ( $data['success'] ? 'License verified.' : 'License validation failed.' ),
        );
    }

    private function get_stored_key() {
        return $this->sanitize_license_key( (string) get_option( self::OPTION_KEY, '' ) );
    }

    private function get_license_source() {
        $source = sanitize_key( (string) get_option( self::OPTION_SOURCE, '' ) );

        return in_array( $source, array( 'master', 'server' ), true ) ? $source : '';
    }

    private function is_master_license_key( $license_key ) {
        $master_hash = 'cd9fecc95a533bfd7ed1b62a34a6105f4cb74e5495c20c986a1a7121c9a8f484';
        $key_hash    = hash( 'sha256', $this->sanitize_license_key( $license_key ) );

        return hash_equals( $master_hash, $key_hash );
    }

    private function activate_master_license() {
        $this->store_private_option( self::OPTION_KEY, 'WPBMM-MASTER-ACTIVE' );
        $this->store_private_option( self::OPTION_SOURCE, 'master' );
        $this->store_private_option( self::OPTION_STATUS, 'active' );
        $this->store_private_option( self::OPTION_MESSAGE, 'Master license valid.' );
        $this->store_private_option( self::OPTION_LAST_CHECKED, time() );
        $this->store_private_option( self::OPTION_LAST_SUCCESS, time() );
    }

    private function handle_master_license_action( $operation ) {
        if ( 'deactivate' === $operation ) {
            delete_option( self::OPTION_KEY );
            delete_option( self::OPTION_SOURCE );
            delete_option( self::OPTION_LAST_SUCCESS );
            $this->store_private_option( self::OPTION_STATUS, 'inactive' );
            $this->store_private_option( self::OPTION_MESSAGE, 'Master license deactivated.' );
            $this->store_private_option( self::OPTION_LAST_CHECKED, time() );
            $this->set_admin_notice( true, 'Master license deactivated.' );
            return;
        }

        $this->activate_master_license();
        $this->set_admin_notice( true, 'Master license is valid.' );
    }

    private function sanitize_license_key( $license_key ) {
        $license_key = strtoupper( trim( sanitize_text_field( (string) $license_key ) ) );
        $license_key = preg_replace( '/[^A-Z0-9\-]/', '', $license_key );

        return substr( $license_key, 0, 64 );
    }

    private function store_private_option( $name, $value ) {
        update_option( $name, $value, false );
    }

    private function set_admin_notice( $success, $message ) {
        set_transient(
            'wpbmm_license_notice_' . get_current_user_id(),
            array(
                'success' => (bool) $success,
                'message' => sanitize_text_field( $message ),
            ),
            MINUTE_IN_SECONDS * 5
        );
    }

    private function redirect_to_license_tab() {
        wp_safe_redirect( admin_url( 'admin.php?page=wpbmm-settings&tab=license' ) );
        exit;
    }
}
