<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPBMM_Frontend {

    /** @var WPBMM_Options */
    private $options;

    /** @var WPBMM_License */
    private $license;

    public function __construct( WPBMM_Options $options, WPBMM_License $license ) {
        $this->options = $options;
        $this->license = $license;
    }

    public function register_hooks() {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'wp_footer', array( $this, 'render_menu' ) );
    }

    public function enqueue_assets() {
        if ( is_admin() || ! $this->options->is_enabled() || ! $this->license->is_active() ) {
            return;
        }

        wp_enqueue_style( 'wpbmm-icons', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css', array(), '6.6.0' );
        wp_enqueue_style( 'wpbmm-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Manrope:wght@400;500;600;700;800&family=Poppins:wght@400;500;600;700;800&display=swap', array(), null );

        wp_enqueue_style( 'wpbmm-frontend', WPBMM_URL . 'assets/css/wpbmm-frontend.css', array( 'wpbmm-icons', 'wpbmm-fonts' ), WPBMM_VERSION );
        wp_add_inline_style( 'wpbmm-frontend', $this->build_runtime_css() );
    }

    public function render_menu() {
        if ( is_admin() || ! $this->options->is_enabled() || ! $this->license->is_active() ) {
            return;
        }

        $items       = $this->options->get_menu_items();
        $style       = $this->options->get_style_values();
        $menu_classes = array( 'wpbmm-style-' . $style['preset'] );

        if ( ! $style['show_labels'] ) {
            $menu_classes[] = 'wpbmm-no-labels';
        }

        echo '<nav id="wpbmm-menu" class="' . esc_attr( implode( ' ', $menu_classes ) ) . '" aria-label="Mobile bottom menu">';

        foreach ( $items as $item ) {
            $item_class = 'wpbmm-item wpbmm-item-' . sanitize_html_class( $item['key'] );

            if ( $this->options->is_item_active( $item['key'] ) ) {
                $item_class .= ' wpbmm-item-active';
            }

            $aria_current = $this->options->is_item_active( $item['key'] ) ? ' aria-current="page"' : '';

            echo '<a class="' . esc_attr( $item_class ) . '" href="' . esc_url( $item['link'] ) . '"' . $aria_current . '>';
            echo '<i class="' . esc_attr( $item['icon'] ) . '" aria-hidden="true"></i>';
            echo '<span class="wpbmm-label">' . esc_html( $item['label'] ) . '</span>';
            echo '</a>';
        }

        echo '</nav>';
    }

    private function build_runtime_css() {
        $style = $this->options->get_style_values();
        $font_stack = str_replace( array( ';', '{', '}' ), '', (string) $style['font_stack'] );

        return sprintf(
            '#wpbmm-menu{' .
            '--wpbmm-menu-bg:%1$s;' .
            '--wpbmm-menu-bg-alt:%2$s;' .
            '--wpbmm-menu-border:%3$s;' .
            '--wpbmm-icon-bg:%4$s;' .
            '--wpbmm-icon-color:%5$s;' .
            '--wpbmm-icon-active-bg:%6$s;' .
            '--wpbmm-icon-active-color:%7$s;' .
            '--wpbmm-text-color:%8$s;' .
            '--wpbmm-text-active-color:%9$s;' .
            '--wpbmm-radius:%10$dpx;' .
            '--wpbmm-icon-size:%11$dpx;' .
            '--wpbmm-text-size:%12$dpx;' .
            '--wpbmm-icon-padding:%13$dpx;' .
            '--wpbmm-menu-padding-y:%14$dpx;' .
            '--wpbmm-item-gap:%15$dpx;' .
            '--wpbmm-font-weight:%16$d;' .
            '--wpbmm-menu-max-width:%17$dpx;' .
            '--wpbmm-font-stack:%18$s;' .
            '--wpbmm-icon-shadow:%19$s;' .
            '--wpbmm-active-shadow:%20$s;' .
            '--wpbmm-neon-border:%21$s;' .
            '--wpbmm-neon-icon-1:%22$s;' .
            '--wpbmm-neon-icon-2:%23$s;' .
            '--wpbmm-neon-active-1:%24$s;' .
            '--wpbmm-neon-active-2:%25$s;' .
            '}',
            $style['menu_bg'],
            $style['menu_bg_alt'],
            $style['menu_border'],
            $style['icon_bg'],
            $style['icon_color'],
            $style['icon_active_bg'],
            $style['icon_active_color'],
            $style['text_color'],
            $style['text_active_color'],
            (int) $style['radius'],
            (int) $style['icon_size'],
            (int) $style['text_size'],
            (int) $style['icon_padding'],
            (int) $style['menu_padding_y'],
            (int) $style['item_gap'],
            (int) $style['font_weight'],
            (int) $style['menu_max_width'],
            $font_stack,
            $style['icon_shadow'],
            $style['active_shadow'],
            $style['neon_border'],
            $style['neon_icon_1'],
            $style['neon_icon_2'],
            $style['neon_active_1'],
            $style['neon_active_2']
        );
    }
}
