<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPBMM_Admin {

    /** @var WPBMM_Options */
    private $options;

    /** @var WPBMM_License */
    private $license;

    public function __construct( WPBMM_Options $options, WPBMM_License $license ) {
        $this->options = $options;
        $this->license = $license;
    }

    public function register_hooks() {
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_init', array( $this, 'guard_design_editor_access' ), 20 );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'admin_head', array( $this, 'hide_sidebar_submenus' ) );
    }

    /**
     * Prevent the editor URL from bypassing the preset license lock.
     */
    public function guard_design_editor_access() {
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

        if ( 'wpbmm-design-editor' !== $page || $this->license->is_active() ) {
            return;
        }

        wp_safe_redirect( admin_url( 'admin.php?page=wpbmm-settings&tab=license&license_required=1' ) );
        exit;
    }

    public function add_settings_page() {
        add_menu_page(
            'Mobile Bottom Menu',
            'Mobile Menu',
            'manage_options',
            'wpbmm-settings',
            array( $this, 'render_settings_page' ),
            'dashicons-smartphone'
        );

        add_submenu_page(
            'wpbmm-settings',
            'Edit Mobile Menu Design',
            'Design Editor',
            'manage_options',
            'wpbmm-design-editor',
            array( $this, 'render_design_editor_page' )
        );

    }

    /**
     * Keep the registered editor route accessible from each card's Edit button,
     * while removing the duplicate child links from the WordPress sidebar.
     */
    public function hide_sidebar_submenus() {
        ?>
        <style id="wpbmm-hide-sidebar-submenus">
            #adminmenu #toplevel_page_wpbmm-settings .wp-submenu {
                display: none !important;
            }
        </style>
        <?php
    }

    public function enqueue_assets( $hook_suffix ) {
        $is_settings_page = 'toplevel_page_wpbmm-settings' === $hook_suffix;
        $is_editor_page   = isset( $_GET['page'] ) && 'wpbmm-design-editor' === sanitize_key( wp_unslash( $_GET['page'] ) );

        if ( ! $is_settings_page && ! $is_editor_page ) {
            return;
        }

        wp_enqueue_style( 'wpbmm-admin-icons', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css', array(), '6.6.0' );
        wp_enqueue_style( 'wpbmm-admin', WPBMM_URL . 'assets/css/wpbmm-admin.css', array(), WPBMM_VERSION );
        wp_enqueue_script( 'wpbmm-admin', WPBMM_URL . 'assets/js/wpbmm-admin.js', array(), WPBMM_VERSION, true );

        if ( $is_settings_page ) {
            $preset_meta = array();
            foreach ( $this->options->get_style_presets() as $key => $preset ) {
                $preset_meta[ $key ] = array(
                    'description' => $preset['description'],
                    'defaults'    => $preset['defaults'],
                );
            }

            wp_add_inline_script( 'wpbmm-admin', 'window.wpbmmPresetMeta = ' . wp_json_encode( $preset_meta ) . ';', 'before' );
        }
    }

    public function register_settings() {
        $presets = $this->options->get_style_presets();

        register_setting(
            'wpbmm_settings',
            'wpbmm_enabled',
            array(
                'sanitize_callback' => array( $this->options, 'sanitize_checkbox' ),
            )
        );

        register_setting(
            'wpbmm_settings',
            'wpbmm_style_preset',
            array(
                'sanitize_callback' => function ( $value ) use ( $presets ) {
                    if ( ! $this->license->is_active() ) {
                        return $this->options->get_active_preset_key();
                    }

                    return isset( $presets[ $value ] ) ? $value : 'classic';
                },
            )
        );

        $url_fields = array(
            'wpbmm_link_2',
            'wpbmm_link_3',
            'wpbmm_link_4',
            'wpbmm_link_5',
        );

        foreach ( $url_fields as $field ) {
            register_setting(
                'wpbmm_settings',
                $field,
                array(
                    'sanitize_callback' => array( $this->options, 'sanitize_url_option' ),
                )
            );
        }

        $color_fields = array(
            'wpbmm_menu_bg',
            'wpbmm_menu_bg_alt',
            'wpbmm_menu_border',
            'wpbmm_icon_bg',
            'wpbmm_icon_color',
            'wpbmm_icon_active_bg',
            'wpbmm_icon_active_color',
            'wpbmm_text_color',
            'wpbmm_text_active_color',
        );

        foreach ( $color_fields as $field ) {
            register_setting(
                'wpbmm_settings',
                $field,
                array(
                    'sanitize_callback' => array( $this->options, 'sanitize_color_option' ),
                )
            );
        }

        $numeric_fields = array(
            'wpbmm_radius'         => array( 'min' => 0, 'max' => 48, 'default' => 14 ),
            'wpbmm_icon_size'      => array( 'min' => 12, 'max' => 32, 'default' => 18 ),
            'wpbmm_text_size'      => array( 'min' => 9, 'max' => 22, 'default' => 13 ),
            'wpbmm_icon_padding'   => array( 'min' => 0, 'max' => 20, 'default' => 0 ),
            'wpbmm_menu_padding_y' => array( 'min' => 4, 'max' => 24, 'default' => 10 ),
            'wpbmm_item_gap'       => array( 'min' => 0, 'max' => 16, 'default' => 4 ),
            'wpbmm_font_weight'    => array( 'min' => 400, 'max' => 800, 'default' => 500 ),
            'wpbmm_menu_max_width' => array( 'min' => 320, 'max' => 1200, 'default' => 980 ),
        );

        foreach ( $numeric_fields as $field => $rule ) {
            register_setting(
                'wpbmm_settings',
                $field,
                array(
                    'sanitize_callback' => function ( $value ) use ( $rule ) {
                        return (string) $this->options->sanitize_int_option( $value, $rule['min'], $rule['max'], $rule['default'] );
                    },
                )
            );
        }

        register_setting(
            'wpbmm_settings',
            'wpbmm_font_family',
            array(
                'sanitize_callback' => array( $this->options, 'sanitize_font_family' ),
            )
        );

        register_setting(
            'wpbmm_settings',
            'wpbmm_show_labels',
            array(
                'sanitize_callback' => array( $this->options, 'sanitize_checkbox' ),
            )
        );

        $text_fields = array(
            'wpbmm_label_home',
            'wpbmm_label_chat',
            'wpbmm_label_cart',
            'wpbmm_label_account',
        );

        foreach ( $text_fields as $field ) {
            register_setting(
                'wpbmm_settings',
                $field,
                array(
                    'sanitize_callback' => array( $this->options, 'sanitize_text_option' ),
                )
            );
        }

        $icon_fields = array(
            'wpbmm_icon_home',
            'wpbmm_icon_chat',
            'wpbmm_icon_cart',
            'wpbmm_icon_account',
        );

        foreach ( $icon_fields as $field ) {
            register_setting(
                'wpbmm_settings',
                $field,
                array(
                    'sanitize_callback' => array( $this->options, 'sanitize_icon_class_option' ),
                )
            );
        }

        foreach ( array_keys( $presets ) as $preset_key ) {
            $group = 'wpbmm_editor_' . $preset_key;

            register_setting(
                $group,
                'wpbmm_style_preset',
                array(
                    'sanitize_callback' => function ( $value ) use ( $presets, $preset_key ) {
                        if ( ! $this->license->is_active() ) {
                            return $this->options->get_active_preset_key();
                        }

                        return isset( $presets[ $value ] ) ? $value : $preset_key;
                    },
                )
            );

            foreach ( $this->get_design_editor_items( $preset_key ) as $item ) {
                register_setting( $group, $item['label_option'], array( 'sanitize_callback' => array( $this->options, 'sanitize_text_option' ) ) );
                register_setting( $group, $item['icon_option'], array( 'sanitize_callback' => array( $this->options, 'sanitize_icon_class_option' ) ) );
                register_setting( $group, $item['link_option'], array( 'sanitize_callback' => array( $this->options, 'sanitize_url_option' ) ) );
            }

            foreach ( $this->get_design_editor_colors( $preset_key ) as $color ) {
                register_setting( $group, $color['option'], array( 'sanitize_callback' => array( $this->options, 'sanitize_color_option' ) ) );
            }

            register_setting(
                $group,
                'wpbmm_' . $preset_key . '_font_size',
                array(
                    'sanitize_callback' => function ( $value ) {
                        return (string) $this->options->sanitize_int_option( $value, 9, 22, 12 );
                    },
                )
            );

            register_setting(
                $group,
                'wpbmm_' . $preset_key . '_font_family',
                array(
                    'sanitize_callback' => array( $this->options, 'sanitize_font_family' ),
                )
            );
        }
    }

    private function get_design_editor_items( $preset_key ) {
        if ( 'spotlight' === $preset_key ) {
            $definitions = array(
                'category' => array( 'title' => 'Categories', 'label' => 'ক্যাটাগরি', 'icon' => 'fa-solid fa-border-all', 'legacy_label' => 'Categories', 'legacy_icon' => 'fa-solid fa-table-cells-large' ),
                'whatsapp' => array( 'title' => 'WhatsApp', 'label' => 'হোয়াটসঅ্যাপ', 'icon' => 'fa-brands fa-whatsapp', 'legacy_label' => 'WhatsApp', 'legacy_icon' => '' ),
                'home'     => array( 'title' => 'Home (center)', 'label' => 'হোম', 'icon' => 'fa-solid fa-house', 'legacy_label' => 'Home', 'legacy_icon' => '' ),
                'messenger'=> array( 'title' => 'Messenger', 'label' => 'মেসেঞ্জার', 'icon' => 'fa-brands fa-facebook-messenger', 'legacy_label' => 'Messenger', 'legacy_icon' => '' ),
                'track'    => array( 'title' => 'Track order', 'label' => 'অর্ডার ট্র্যাক', 'icon' => 'fa-solid fa-truck', 'legacy_label' => 'Track order', 'legacy_icon' => 'fa-solid fa-truck-fast' ),
            );
            $items = array();

            foreach ( $definitions as $key => $definition ) {
                $label_option = 'wpbmm_spotlight_label_' . $key;
                $icon_option  = 'wpbmm_spotlight_icon_' . $key;
                $link_option  = 'wpbmm_spotlight_link_' . $key;
                $label = $this->options->get_text_with_default( $label_option, $definition['label'] );
                $icon  = $this->options->get_icon_with_default( $icon_option, $definition['icon'] );

                if ( $definition['legacy_label'] === $label || ( 'track' === $key && 'Track' === $label ) ) {
                    $label = $definition['label'];
                }
                if ( $definition['legacy_icon'] && $definition['legacy_icon'] === $icon ) {
                    $icon = $definition['icon'];
                }

                $items[ $key ] = array(
                    'key'          => $key,
                    'title'        => $definition['title'],
                    'label_option' => $label_option,
                    'icon_option'  => $icon_option,
                    'link_option'  => $link_option,
                    'label'        => $label,
                    'icon'         => $icon,
                    'link'         => trim( (string) get_option( $link_option, '' ) ),
                );
            }

            return $items;
        }

        $preset_defaults = $this->options->get_standard_preset_item_defaults();
        $definitions     = isset( $preset_defaults[ $preset_key ] ) ? $preset_defaults[ $preset_key ] : $preset_defaults['classic'];
        $items           = array();

        foreach ( $definitions as $index => $definition ) {
            $slot         = $index + 1;
            $label_option = 'wpbmm_' . $preset_key . '_label_' . $slot;
            $icon_option  = 'wpbmm_' . $preset_key . '_icon_' . $slot;
            $link_option  = 'wpbmm_' . $preset_key . '_link_' . $slot;
            $items[] = array(
                'key'          => $index,
                'title'        => $definition['label'],
                'label_option' => $label_option,
                'icon_option'  => $icon_option,
                'link_option'  => $link_option,
                'label'        => $this->options->get_text_with_default( $label_option, $definition['label'] ),
                'icon'         => $this->options->get_icon_with_default( $icon_option, $definition['icon'] ),
                'link'         => trim( (string) get_option( $link_option, '' ) ),
            );
        }

        return $items;
    }

    private function get_design_editor_colors( $preset_key ) {
        $presets = $this->options->get_style_presets();

        if ( 'spotlight' === $preset_key ) {
            $normalize_spotlight_color = static function ( $value ) {
                return '#a50f2d' === strtolower( (string) $value ) ? '#ad0d2f' : $value;
            };

            return array(
                array( 'label' => 'Menu background', 'option' => 'wpbmm_spotlight_menu_bg', 'value' => $this->options->get_option_with_preset_default( 'wpbmm_spotlight_menu_bg', 'spotlight' ) ),
                array( 'label' => 'Icon color', 'option' => 'wpbmm_spotlight_icon_color', 'value' => $normalize_spotlight_color( $this->options->get_option_with_preset_default( 'wpbmm_spotlight_icon_color', 'spotlight' ) ) ),
                array( 'label' => 'Text color', 'option' => 'wpbmm_spotlight_text_color', 'value' => $normalize_spotlight_color( $this->options->get_option_with_preset_default( 'wpbmm_spotlight_text_color', 'spotlight' ) ) ),
                array( 'label' => 'Center circle', 'option' => 'wpbmm_spotlight_center_bg', 'value' => $normalize_spotlight_color( $this->options->get_option_with_preset_default( 'wpbmm_spotlight_center_bg', 'spotlight' ) ) ),
                array( 'label' => 'Center icon', 'option' => 'wpbmm_spotlight_center_color', 'value' => $this->options->get_option_with_preset_default( 'wpbmm_spotlight_center_color', 'spotlight' ) ),
            );
        }

        $labels = array(
            'menu_bg'      => 'Menu background',
            'icon_color'   => 'Icon color',
            'text_color'   => 'Text color',
            'active_bg'    => 'Active background',
            'active_color' => 'Active icon color',
        );
        $defaults = array(
            'menu_bg'      => 'wpbmm_menu_bg',
            'icon_color'   => 'wpbmm_icon_color',
            'text_color'   => 'wpbmm_text_color',
            'active_bg'    => 'wpbmm_icon_active_bg',
            'active_color' => 'wpbmm_icon_active_color',
        );
        $colors = array();

        foreach ( $labels as $key => $label ) {
            $option       = 'wpbmm_' . $preset_key . '_' . $key;
            $fallback_key = $defaults[ $key ];
            $fallback     = isset( $presets[ $preset_key ]['defaults'][ $fallback_key ] ) ? $presets[ $preset_key ]['defaults'][ $fallback_key ] : '#ffffff';
            $stored       = sanitize_hex_color( (string) get_option( $option, '' ) );
            $colors[]     = array(
                'label'  => $label,
                'option' => $option,
                'value'  => $stored ? $stored : $fallback,
            );
        }

        return $colors;
    }

    private function get_design_typography( $preset_key ) {
        $presets       = $this->options->get_style_presets();
        $font_option   = 'wpbmm_' . $preset_key . '_font_family';
        $size_option   = 'wpbmm_' . $preset_key . '_font_size';
        $font_fallback = isset( $presets[ $preset_key ]['defaults']['wpbmm_font_family'] ) ? $presets[ $preset_key ]['defaults']['wpbmm_font_family'] : 'inter';
        $size_fallback = isset( $presets[ $preset_key ]['defaults']['wpbmm_text_size'] ) ? $presets[ $preset_key ]['defaults']['wpbmm_text_size'] : '12';
        $stored_font   = sanitize_key( (string) get_option( $font_option, '' ) );
        $stored_size   = get_option( $size_option, '' );

        return array(
            'font_option' => $font_option,
            'font_value'  => $this->options->sanitize_font_family( $stored_font ? $stored_font : $font_fallback ),
            'size_option' => $size_option,
            'size_value'  => $this->options->sanitize_int_option( '' !== $stored_size ? $stored_size : $size_fallback, 9, 22, 12 ),
        );
    }

    private function get_icon_choices() {
        return array(
            'fa-solid fa-house'                  => 'Home',
            'fa-solid fa-magnifying-glass'       => 'Search',
            'fa-regular fa-compass'              => 'Compass',
            'fa-solid fa-store'                  => 'Shop',
            'fa-solid fa-table-cells-large'      => 'Categories',
            'fa-solid fa-border-all'             => 'Category grid',
            'fa-solid fa-tag'                    => 'Deals',
            'fa-solid fa-bag-shopping'           => 'Shopping bag',
            'fa-solid fa-cart-shopping'          => 'Cart',
            'fa-regular fa-circle-user'          => 'Account',
            'fa-solid fa-bars-staggered'         => 'Menu',
            'fa-regular fa-bell'                 => 'Alerts',
            'fa-solid fa-phone'                  => 'Phone',
            'fa-brands fa-whatsapp'              => 'WhatsApp',
            'fa-brands fa-facebook-messenger'    => 'Messenger',
            'fa-solid fa-truck'                  => 'Order truck',
            'fa-solid fa-truck-fast'             => 'Track order',
            'fa-solid fa-heart'                  => 'Favorites',
        );
    }

    public function render_settings_page() {
        $presets        = $this->options->get_style_presets();
        $font_choices   = $this->options->get_font_choices();
        $current_preset = $this->options->get_active_preset_key();
        $font_key       = $this->options->sanitize_font_family( $this->options->get_option_with_preset_default( 'wpbmm_font_family', $current_preset ) );
        $browse_label   = sanitize_text_field( (string) get_option( 'wpbmm_label_chat', 'Browse' ) );
        $home_icon      = sanitize_text_field( (string) get_option( 'wpbmm_icon_home', 'fa-solid fa-house' ) );
        $browse_icon    = sanitize_text_field( (string) get_option( 'wpbmm_icon_chat', 'fa-regular fa-compass' ) );
        $cart_icon      = sanitize_text_field( (string) get_option( 'wpbmm_icon_cart', 'fa-solid fa-bag-shopping' ) );
        $account_icon   = sanitize_text_field( (string) get_option( 'wpbmm_icon_account', 'fa-regular fa-circle-user' ) );
        $browse_link    = trim( (string) get_option( 'wpbmm_link_5', '' ) );
        $spotlight_items = $this->get_design_editor_items( 'spotlight' );
        $active_tab     = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'designs';
        $allowed_tabs   = array( 'designs', 'license' );
        $license_notice = $this->license->pop_admin_notice();
        $license_active = $this->license->is_active();
        $preset_items   = array(
            'classic'  => array(
                array( 'fa-solid fa-house', 'Home' ),
                array( 'fa-solid fa-magnifying-glass', 'Search' ),
                array( 'fa-solid fa-bag-shopping', 'Cart' ),
                array( 'fa-regular fa-circle-user', 'Account' ),
            ),
            'outline'  => array(
                array( 'fa-solid fa-house', 'Home' ),
                array( 'fa-regular fa-compass', 'Browse' ),
                array( 'fa-solid fa-phone', 'Call' ),
                array( 'fa-regular fa-circle-user', 'Account' ),
            ),
            'floating' => array(
                array( 'fa-solid fa-house', 'Home' ),
                array( 'fa-solid fa-store', 'Shop' ),
                array( 'fa-solid fa-bag-shopping', 'Cart' ),
                array( 'fa-regular fa-circle-user', 'Account' ),
            ),
            'capsule'  => array(
                array( 'fa-solid fa-house', 'Home' ),
                array( 'fa-solid fa-tag', 'Deals' ),
                array( 'fa-solid fa-bag-shopping', 'Cart' ),
                array( 'fa-regular fa-circle-user', 'Profile' ),
            ),
            'neon'     => array(
                array( 'fa-solid fa-house', 'Home' ),
                array( 'fa-solid fa-bars-staggered', 'Menu' ),
                array( 'fa-regular fa-bell', 'Alerts' ),
                array( 'fa-regular fa-circle-user', 'Account' ),
            ),
            'spotlight' => array(
                array( 'fa-solid fa-border-all', 'ক্যাটাগরি' ),
                array( 'fa-brands fa-whatsapp', 'হোয়াটসঅ্যাপ' ),
                array( 'fa-solid fa-house', 'হোম' ),
                array( 'fa-brands fa-facebook-messenger', 'মেসেঞ্জার' ),
                array( 'fa-solid fa-truck', 'অর্ডার ট্র্যাক' ),
            ),
        );

        if ( ! in_array( $active_tab, $allowed_tabs, true ) ) {
            $active_tab = 'designs';
        }

        if ( '' === $browse_label || 'WhatsApp' === $browse_label ) {
            $browse_label = 'Browse';
        }

        if ( '' === $browse_icon || in_array( $browse_icon, array( 'fa-brands fa-whatsapp', 'fa-solid fa-border-all' ), true ) ) {
            $browse_icon = 'fa-regular fa-compass';
        }

        if ( '' === $cart_icon || 'fa-solid fa-cart-shopping' === $cart_icon ) {
            $cart_icon = 'fa-solid fa-bag-shopping';
        }

        if ( '' === $account_icon || in_array( $account_icon, array( 'fa-solid fa-user', 'fa-regular fa-user' ), true ) ) {
            $account_icon = 'fa-regular fa-circle-user';
        }

        if ( false !== strpos( $browse_link, 'wa.me' ) ) {
            $browse_link = '';
        }
        ?>
        <div class="wrap wpbmm-admin-wrap">
            <form id="wpbmm-settings-form" method="post" action="options.php">
                <?php settings_fields( 'wpbmm_settings' ); ?>
                <div class="wpbmm-hidden-form" aria-hidden="true">
                    <?php foreach ( array_keys( $presets ) as $preview_preset_key ) : ?>
                        <?php foreach ( $this->get_design_editor_items( $preview_preset_key ) as $preview_editor_item ) : ?>
                            <input type="hidden" name="<?php echo esc_attr( $preview_editor_item['label_option'] ); ?>" value="<?php echo esc_attr( $preview_editor_item['label'] ); ?>">
                            <input type="hidden" name="<?php echo esc_attr( $preview_editor_item['icon_option'] ); ?>" value="<?php echo esc_attr( $preview_editor_item['icon'] ); ?>">
                        <?php endforeach; ?>
                        <?php foreach ( $this->get_design_editor_colors( $preview_preset_key ) as $preview_editor_color ) : ?>
                            <input type="hidden" name="<?php echo esc_attr( $preview_editor_color['option'] ); ?>" value="<?php echo esc_attr( $preview_editor_color['value'] ); ?>">
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                </div>

                <div class="wpbmm-admin-shell">
                    <div class="wpbmm-admin-hero">
                        <div class="wpbmm-admin-brand">
                            <span class="wpbmm-admin-logo" aria-hidden="true">
                                <i class="fa-solid fa-mobile-screen-button"></i>
                            </span>
                            <div class="wpbmm-admin-hero-titlebox">
                                <span class="wpbmm-eyebrow">Mobile navigation studio</span>
                                <h1>Mobile Bottom Menu</h1>
                                <p>Design a polished, app-like navigation bar for your mobile visitors.</p>
                            </div>
                        </div>
                        <div class="wpbmm-admin-hero-actions">
                            <label class="wpbmm-enable-control">
                                <span>Menu</span>
                                <input type="hidden" name="wpbmm_enabled" value="0">
                                <input type="checkbox" name="wpbmm_enabled" value="1" <?php checked( $this->options->is_enabled() ); ?>>
                                <span class="wpbmm-switch-ui" aria-hidden="true"></span>
                            </label>
                            <span class="wpbmm-status-pill <?php echo $license_active ? 'is-licensed' : 'is-unlicensed'; ?>">
                                <i class="fa-solid <?php echo $license_active ? 'fa-circle-check' : 'fa-key'; ?>" aria-hidden="true"></i>
                                <?php echo $license_active ? 'Licensed' : 'License required'; ?>
                            </span>
                            <div class="wpbmm-admin-hero-social">
                                <a class="wpbmm-hero-social is-facebook" href="https://www.facebook.com/borbilax" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                                    <i class="fa-brands fa-facebook-f" aria-hidden="true"></i>
                                </a>
                                <a class="wpbmm-hero-social is-youtube" href="https://www.youtube.com/@borbila" target="_blank" rel="noopener noreferrer" aria-label="YouTube">
                                    <i class="fa-brands fa-youtube" aria-hidden="true"></i>
                                </a>
                                <a class="wpbmm-hero-social is-telegram" href="https://borbila.com/contact-us/" target="_blank" rel="noopener noreferrer" aria-label="Borbila support">
                                    <i class="fa-solid fa-headset" aria-hidden="true"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="wpbmm-admin-workspace">
                        <div class="wpbmm-tab-nav" role="tablist" aria-label="WPBMM Settings Tabs">
                            <span class="wpbmm-tab-nav-label">Customize</span>
                            <button type="button" class="wpbmm-tab <?php echo 'designs' === $active_tab ? 'is-active' : ''; ?>" data-tab-target="designs" role="tab" aria-selected="<?php echo 'designs' === $active_tab ? 'true' : 'false'; ?>">
                                <i class="fa-solid fa-wand-magic-sparkles" aria-hidden="true"></i>
                                <span><strong>Designs</strong><small>Choose a preset</small></span>
                            </button>
                            <button type="button" class="wpbmm-tab <?php echo 'license' === $active_tab ? 'is-active' : ''; ?>" data-tab-target="license" role="tab" aria-selected="<?php echo 'license' === $active_tab ? 'true' : 'false'; ?>">
                                <i class="fa-solid fa-key" aria-hidden="true"></i>
                                <span><strong>License</strong><small>Activate with Borbila</small></span>
                            </button>
                            <div class="wpbmm-nav-tip">
                                <i class="fa-regular fa-lightbulb" aria-hidden="true"></i>
                                <p><strong>Quick tip</strong> Choose a preset, then use its Edit button to customize it.</p>
                            </div>
                        </div>

                        <div class="wpbmm-panel-stack">

                    <section class="wpbmm-tab-panel <?php echo 'designs' === $active_tab ? 'is-active' : ''; ?>" data-tab-panel="designs">
                        <div class="wpbmm-panel-heading">
                            <div>
                                <span class="wpbmm-section-kicker">Style presets</span>
                                <h2>Pick your starting point</h2>
                                <p>Select one of six crafted styles. You can personalize every detail afterward.</p>
                            </div>
                            <span class="wpbmm-step-badge">6 editable designs</span>
                        </div>

                        <div class="wpbmm-design-layout">
                            <div class="wpbmm-preset-grid">
                                <?php foreach ( $presets as $preset_key => $preset_data ) : ?>
                                    <?php $preset_selected = $license_active && $current_preset === $preset_key; ?>
                                    <div
                                        class="wpbmm-preset-card wpbmm-preset-<?php echo esc_attr( $preset_key ); ?> <?php echo $preset_selected ? 'is-active' : ''; ?> <?php echo ! $license_active ? 'is-license-locked' : ''; ?>"
                                        data-preset-card
                                        data-preset-key="<?php echo esc_attr( $preset_key ); ?>"
                                        role="radio"
                                        aria-checked="<?php echo $preset_selected ? 'true' : 'false'; ?>"
                                        <?php echo ! $license_active ? 'aria-disabled="true" data-license-locked="true"' : ''; ?>
                                        tabindex="0"
                                    >
                                        <input type="radio" name="wpbmm_style_preset" value="<?php echo esc_attr( $preset_key ); ?>" <?php checked( $current_preset, $preset_key ); ?> <?php disabled( ! $license_active ); ?>>
                                        <span class="wpbmm-preset-check" aria-hidden="true"><i class="fa-solid fa-check"></i></span>
                                        <span class="wpbmm-preset-demo" aria-hidden="true">
                                            <?php foreach ( $preset_items[ $preset_key ] as $item_index => $preview_item ) : ?>
                                                <span class="wpbmm-preset-demo-item <?php echo ( 'spotlight' === $preset_key ? 2 : 0 ) === $item_index ? 'is-active' : ''; ?>">
                                                    <i class="<?php echo esc_attr( $preview_item[0] ); ?>"></i>
                                                    <small><?php echo esc_html( $preview_item[1] ); ?></small>
                                                </span>
                                            <?php endforeach; ?>
                                        </span>
                                        <span class="wpbmm-preset-title"><?php echo esc_html( $preset_data['label'] ); ?></span>
                                        <span class="wpbmm-preset-description"><?php echo esc_html( $preset_data['description'] ); ?></span>
                                        <div class="wpbmm-preset-actions">
                                            <button type="button" class="wpbmm-use-template" data-apply-preset="<?php echo esc_attr( $preset_key ); ?>" aria-pressed="<?php echo $preset_selected ? 'true' : 'false'; ?>" <?php disabled( ! $license_active ); ?>>
                                                <i class="fa-solid <?php echo $preset_selected ? 'fa-circle-check' : 'fa-arrow-pointer'; ?>" aria-hidden="true"></i>
                                                <span><?php echo $preset_selected ? 'Design selected' : 'Select this design'; ?></span>
                                            </button>
                                            <?php if ( $license_active ) : ?>
                                                <a class="wpbmm-edit-template" href="<?php echo esc_url( admin_url( 'admin.php?page=wpbmm-design-editor&preset=' . $preset_key ) ); ?>">
                                                    <i class="fa-solid fa-pen" aria-hidden="true"></i>
                                                    <span>Edit</span>
                                                </a>
                                            <?php else : ?>
                                                <button type="button" class="wpbmm-edit-template" disabled aria-disabled="true">
                                                    <i class="fa-solid fa-pen" aria-hidden="true"></i>
                                                    <span>Edit</span>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                        <?php if ( ! $license_active ) : ?>
                                            <div class="wpbmm-license-lock-overlay" data-license-lock-overlay>
                                                <span class="wpbmm-license-lock-icon" aria-hidden="true"><i class="fa-solid fa-lock"></i></span>
                                                <strong>Please activate your license</strong>
                                                <a class="wpbmm-get-license-button" href="https://borbila.com/my-account/licenses/" target="_blank" rel="noopener noreferrer" data-get-license>
                                                    Get License
                                                    <i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <aside class="wpbmm-preview-card" aria-label="Live menu preview">
                                <div class="wpbmm-preview-card-head">
                                    <div>
                                        <span>Live preview</span>
                                        <small>Updates while you edit</small>
                                    </div>
                                    <i class="fa-solid fa-signal" aria-hidden="true"></i>
                                </div>
                                <div class="wpbmm-phone-preview">
                                    <div class="wpbmm-phone-speaker"></div>
                                    <div class="wpbmm-phone-content">
                                        <div class="wpbmm-preview-copy">
                                            <span></span><span></span><span></span>
                                        </div>
                                        <div id="wpbmm-admin-preview" class="wpbmm-preview-menu wpbmm-preview-<?php echo esc_attr( $current_preset ); ?>">
                                            <span class="is-active" data-standard-preview><i class="<?php echo esc_attr( $home_icon ); ?>"></i><small data-preview-label="wpbmm_label_home"><?php echo esc_html( get_option( 'wpbmm_label_home', 'Home' ) ); ?></small></span>
                                            <span data-standard-preview><i class="<?php echo esc_attr( $browse_icon ); ?>"></i><small data-preview-label="wpbmm_label_chat"><?php echo esc_html( $browse_label ); ?></small></span>
                                            <span data-standard-preview><i class="<?php echo esc_attr( $cart_icon ); ?>"></i><small data-preview-label="wpbmm_label_cart"><?php echo esc_html( get_option( 'wpbmm_label_cart', 'Cart' ) ); ?></small></span>
                                            <span data-standard-preview><i class="<?php echo esc_attr( $account_icon ); ?>"></i><small data-preview-label="wpbmm_label_account"><?php echo esc_html( get_option( 'wpbmm_label_account', 'Account' ) ); ?></small></span>
                                            <?php foreach ( $spotlight_items as $spotlight_key => $spotlight_item ) : ?>
                                                <span class="wpbmm-preview-spotlight-item wpbmm-preview-spotlight-<?php echo esc_attr( $spotlight_key ); ?> <?php echo 'home' === $spotlight_key ? 'is-active' : ''; ?>" data-spotlight-preview>
                                                    <i class="<?php echo esc_attr( $spotlight_item['icon'] ); ?>" data-preview-icon="<?php echo esc_attr( $spotlight_item['icon_option'] ); ?>"></i>
                                                    <small data-preview-label="<?php echo esc_attr( $spotlight_item['label_option'] ); ?>"><?php echo esc_html( $spotlight_item['label'] ); ?></small>
                                                </span>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <div class="wpbmm-phone-home"></div>
                                </div>
                            </aside>
                        </div>

                    </section>

                    <section class="wpbmm-tab-panel <?php echo 'text' === $active_tab ? 'is-active' : ''; ?>" data-tab-panel="text">
                        <div class="wpbmm-panel-heading">
                            <div>
                                <span class="wpbmm-section-kicker">Menu content</span>
                                <h2>Make every item yours</h2>
                                <p>Set destinations, labels, icons, typography and spacing.</p>
                            </div>
                            <span class="wpbmm-step-badge">Step 2 of 3</span>
                        </div>
                        <div class="wpbmm-grid-2">
                            <div class="wpbmm-card">
                                <h3>Menu Links</h3>
                                <div class="wpbmm-field">
                                    <label for="wpbmm_link_3">Home Link</label>
                                    <input type="text" id="wpbmm_link_3" name="wpbmm_link_3" value="<?php echo esc_attr( get_option( 'wpbmm_link_3', '' ) ); ?>" class="regular-text">
                                </div>
                                <div class="wpbmm-field">
                                    <label for="wpbmm_link_5">Browse Link</label>
                                    <input type="text" id="wpbmm_link_5" name="wpbmm_link_5" value="<?php echo esc_attr( $browse_link ); ?>" class="regular-text">
                                </div>
                                <div class="wpbmm-field">
                                    <label for="wpbmm_link_2">Cart Link</label>
                                    <input type="text" id="wpbmm_link_2" name="wpbmm_link_2" value="<?php echo esc_attr( get_option( 'wpbmm_link_2', '' ) ); ?>" class="regular-text">
                                </div>
                                <div class="wpbmm-field">
                                    <label for="wpbmm_link_4">Account Link</label>
                                    <input type="text" id="wpbmm_link_4" name="wpbmm_link_4" value="<?php echo esc_attr( get_option( 'wpbmm_link_4', '' ) ); ?>" class="regular-text">
                                </div>
                            </div>

                            <div class="wpbmm-card">
                                <h3>Labels &amp; Icons</h3>
                                <div class="wpbmm-field-inline">
                                    <label for="wpbmm_label_home">Home Label</label>
                                    <input type="text" id="wpbmm_label_home" name="wpbmm_label_home" value="<?php echo esc_attr( get_option( 'wpbmm_label_home', 'Home' ) ); ?>">
                                </div>
                                <div class="wpbmm-field-inline">
                                    <label for="wpbmm_icon_home">Home Icon</label>
                                    <input type="text" id="wpbmm_icon_home" name="wpbmm_icon_home" value="<?php echo esc_attr( $home_icon ); ?>">
                                </div>

                                <div class="wpbmm-field-inline">
                                    <label for="wpbmm_label_chat">Browse Label</label>
                                    <input type="text" id="wpbmm_label_chat" name="wpbmm_label_chat" value="<?php echo esc_attr( $browse_label ); ?>">
                                </div>
                                <div class="wpbmm-field-inline">
                                    <label for="wpbmm_icon_chat">Browse Icon</label>
                                    <input type="text" id="wpbmm_icon_chat" name="wpbmm_icon_chat" value="<?php echo esc_attr( $browse_icon ); ?>">
                                </div>

                                <div class="wpbmm-field-inline">
                                    <label for="wpbmm_label_cart">Cart Label</label>
                                    <input type="text" id="wpbmm_label_cart" name="wpbmm_label_cart" value="<?php echo esc_attr( get_option( 'wpbmm_label_cart', 'Cart' ) ); ?>">
                                </div>
                                <div class="wpbmm-field-inline">
                                    <label for="wpbmm_icon_cart">Cart Icon</label>
                                    <input type="text" id="wpbmm_icon_cart" name="wpbmm_icon_cart" value="<?php echo esc_attr( $cart_icon ); ?>">
                                </div>

                                <div class="wpbmm-field-inline">
                                    <label for="wpbmm_label_account">Account Label</label>
                                    <input type="text" id="wpbmm_label_account" name="wpbmm_label_account" value="<?php echo esc_attr( get_option( 'wpbmm_label_account', 'Account' ) ); ?>">
                                </div>
                                <div class="wpbmm-field-inline">
                                    <label for="wpbmm_icon_account">Account Icon</label>
                                    <input type="text" id="wpbmm_icon_account" name="wpbmm_icon_account" value="<?php echo esc_attr( $account_icon ); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="wpbmm-card">
                            <h3>Text &amp; Size Controls</h3>
                            <div class="wpbmm-grid-3">
                                <div class="wpbmm-field">
                                    <label for="wpbmm_icon_size">Icon Size (px)</label>
                                    <input type="number" min="12" max="32" id="wpbmm_icon_size" name="wpbmm_icon_size" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_icon_size', $current_preset ) ); ?>">
                                </div>
                                <div class="wpbmm-field">
                                    <label for="wpbmm_text_size">Text Size (px)</label>
                                    <input type="number" min="9" max="22" id="wpbmm_text_size" name="wpbmm_text_size" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_text_size', $current_preset ) ); ?>">
                                </div>
                                <div class="wpbmm-field">
                                    <label for="wpbmm_icon_padding">Icon Padding (px)</label>
                                    <input type="number" min="0" max="20" id="wpbmm_icon_padding" name="wpbmm_icon_padding" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_icon_padding', $current_preset ) ); ?>">
                                </div>
                                <div class="wpbmm-field">
                                    <label for="wpbmm_item_gap">Icon/Text Gap (px)</label>
                                    <input type="number" min="0" max="16" id="wpbmm_item_gap" name="wpbmm_item_gap" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_item_gap', $current_preset ) ); ?>">
                                </div>
                                <div class="wpbmm-field">
                                    <label for="wpbmm_menu_padding_y">Menu Vertical Padding (px)</label>
                                    <input type="number" min="4" max="24" id="wpbmm_menu_padding_y" name="wpbmm_menu_padding_y" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_menu_padding_y', $current_preset ) ); ?>">
                                </div>
                                <div class="wpbmm-field">
                                    <label for="wpbmm_radius">Menu Radius (px)</label>
                                    <input type="number" min="0" max="48" id="wpbmm_radius" name="wpbmm_radius" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_radius', $current_preset ) ); ?>">
                                </div>
                                <div class="wpbmm-field">
                                    <label for="wpbmm_font_family">Font Family</label>
                                    <select id="wpbmm_font_family" name="wpbmm_font_family">
                                        <?php foreach ( $font_choices as $key => $font_data ) : ?>
                                            <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $font_key, $key ); ?>>
                                                <?php echo esc_html( $font_data['label'] ); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="wpbmm-field">
                                    <label for="wpbmm_font_weight">Font Weight</label>
                                    <input type="number" min="400" max="800" step="100" id="wpbmm_font_weight" name="wpbmm_font_weight" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_font_weight', $current_preset ) ); ?>">
                                </div>
                                <div class="wpbmm-field">
                                    <label for="wpbmm_menu_max_width">Menu Max Width (px)</label>
                                    <input type="number" min="320" max="1200" id="wpbmm_menu_max_width" name="wpbmm_menu_max_width" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_menu_max_width', $current_preset ) ); ?>">
                                </div>
                            </div>

                            <div class="wpbmm-checkbox-row">
                                <input type="hidden" name="wpbmm_show_labels" value="0">
                                <label>
                                    <input type="checkbox" name="wpbmm_show_labels" value="1" <?php checked( $this->options->get_show_labels() ); ?>>
                                    Show text labels under icons
                                </label>
                            </div>
                        </div>
                    </section>

                    <section class="wpbmm-tab-panel <?php echo 'colors' === $active_tab ? 'is-active' : ''; ?>" data-tab-panel="colors">
                        <div class="wpbmm-panel-heading">
                            <div>
                                <span class="wpbmm-section-kicker">Brand palette</span>
                                <h2>Bring in your colors</h2>
                                <p>Fine-tune the menu, icons and active states to match your site.</p>
                            </div>
                            <span class="wpbmm-step-badge">Step 3 of 3</span>
                        </div>
                        <div class="wpbmm-card">
                            <h3>Color Customization</h3>
                            <div class="wpbmm-color-grid">
                                <div class="wpbmm-field"><label for="wpbmm_menu_bg">Menu Background</label><input type="color" id="wpbmm_menu_bg" name="wpbmm_menu_bg" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_menu_bg', $current_preset ) ); ?>"></div>
                                <div class="wpbmm-field"><label for="wpbmm_menu_bg_alt">Menu Secondary</label><input type="color" id="wpbmm_menu_bg_alt" name="wpbmm_menu_bg_alt" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_menu_bg_alt', $current_preset ) ); ?>"></div>
                                <div class="wpbmm-field"><label for="wpbmm_menu_border">Menu Border</label><input type="color" id="wpbmm_menu_border" name="wpbmm_menu_border" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_menu_border', $current_preset ) ); ?>"></div>
                                <div class="wpbmm-field"><label for="wpbmm_icon_bg">Icon Background</label><input type="color" id="wpbmm_icon_bg" name="wpbmm_icon_bg" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_icon_bg', $current_preset ) ); ?>"></div>
                                <div class="wpbmm-field"><label for="wpbmm_icon_color">Icon Color</label><input type="color" id="wpbmm_icon_color" name="wpbmm_icon_color" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_icon_color', $current_preset ) ); ?>"></div>
                                <div class="wpbmm-field"><label for="wpbmm_icon_active_bg">Active Icon BG</label><input type="color" id="wpbmm_icon_active_bg" name="wpbmm_icon_active_bg" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_icon_active_bg', $current_preset ) ); ?>"></div>
                                <div class="wpbmm-field"><label for="wpbmm_icon_active_color">Active Icon Color</label><input type="color" id="wpbmm_icon_active_color" name="wpbmm_icon_active_color" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_icon_active_color', $current_preset ) ); ?>"></div>
                                <div class="wpbmm-field"><label for="wpbmm_text_color">Text Color</label><input type="color" id="wpbmm_text_color" name="wpbmm_text_color" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_text_color', $current_preset ) ); ?>"></div>
                                <div class="wpbmm-field"><label for="wpbmm_text_active_color">Active Text Color</label><input type="color" id="wpbmm_text_active_color" name="wpbmm_text_active_color" value="<?php echo esc_attr( $this->options->get_option_with_preset_default( 'wpbmm_text_active_color', $current_preset ) ); ?>"></div>
                            </div>
                        </div>
                    </section>

                    <section class="wpbmm-tab-panel <?php echo 'license' === $active_tab ? 'is-active' : ''; ?>" data-tab-panel="license">
                        <div class="wpbmm-panel-heading">
                            <div>
                                <span class="wpbmm-section-kicker">Borbila licensing</span>
                                <h2>License your mobile menu</h2>
                                <p>Activate this website securely with your Borbila license key.</p>
                            </div>
                            <span class="wpbmm-step-badge <?php echo $license_active ? 'is-success' : ''; ?>">
                                <?php echo $license_active ? 'Active' : 'Not activated'; ?>
                            </span>
                        </div>

                        <?php if ( ! empty( $license_notice ) ) : ?>
                            <div class="wpbmm-license-notice <?php echo ! empty( $license_notice['success'] ) ? 'is-success' : 'is-error'; ?>" role="status">
                                <i class="fa-solid <?php echo ! empty( $license_notice['success'] ) ? 'fa-circle-check' : 'fa-circle-exclamation'; ?>" aria-hidden="true"></i>
                                <span><?php echo esc_html( $license_notice['message'] ); ?></span>
                            </div>
                        <?php endif; ?>

                        <div class="wpbmm-license-layout">
                            <div class="wpbmm-license-card">
                                <div class="wpbmm-license-card-icon <?php echo $license_active ? 'is-active' : ''; ?>">
                                    <i class="fa-solid <?php echo $license_active ? 'fa-shield-halved' : 'fa-key'; ?>" aria-hidden="true"></i>
                                </div>
                                <div class="wpbmm-license-card-copy">
                                    <span class="wpbmm-license-label">License status</span>
                                    <h3><?php echo $license_active ? 'Your license is active' : 'Activate Mobile Bottom Menu'; ?></h3>
                                    <p><?php echo $license_active ? 'This site is verified and the mobile menu is enabled for licensed use.' : 'Enter the license key from your Borbila order to unlock the menu on this domain.'; ?></p>
                                </div>
                            </div>

                            <div class="wpbmm-license-details">
                                <div>
                                    <span>Website</span>
                                    <strong><?php echo esc_html( $this->license->get_domain() ); ?></strong>
                                </div>
                                <div>
                                    <span>Template ID</span>
                                    <strong><?php echo esc_html( WPBMM_LICENSE_TEMPLATE_ID ); ?></strong>
                                </div>
                                <div>
                                    <span>License key</span>
                                    <strong><?php echo $license_active ? esc_html( $this->license->get_masked_key() ) : 'Not stored'; ?></strong>
                                </div>
                                <div>
                                    <span>License validity</span>
                                    <strong><?php echo $license_active ? 'Lifetime' : 'Not active'; ?></strong>
                                </div>
                            </div>

                            <?php if ( ! $license_active ) : ?>
                                <div class="wpbmm-license-activate">
                                    <label for="wpbmm_license_key">Borbila license key</label>
                                    <div class="wpbmm-license-input-row">
                                        <input type="text" id="wpbmm_license_key" name="wpbmm_license_key" form="wpbmm-license-form" placeholder="BRB-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false">
                                        <button type="submit" name="license_operation" value="activate" form="wpbmm-license-form" class="button button-primary wpbmm-license-primary">
                                            <i class="fa-solid fa-bolt" aria-hidden="true"></i> Activate license
                                        </button>
                                    </div>
                                    <p>Your key is sent only in an encrypted HTTPS request to borbila.com.</p>
                                </div>
                            <?php else : ?>
                                <div class="wpbmm-license-actions">
                                    <button type="submit" name="license_operation" value="check" form="wpbmm-license-form" class="button wpbmm-license-check">
                                        <i class="fa-solid fa-rotate" aria-hidden="true"></i> Check license
                                    </button>
                                    <button type="submit" name="license_operation" value="deactivate" form="wpbmm-license-form" class="button wpbmm-license-deactivate" data-confirm-deactivate>
                                        Deactivate license
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </section>
                    <div class="wpbmm-shell-footer <?php echo 'license' === $active_tab ? 'is-hidden' : ''; ?>" data-settings-footer>
                        <div class="wpbmm-submit-row">
                            <?php submit_button( 'Save changes', 'primary', 'submit', false ); ?>
                        </div>
                        <p class="wpbmm-devline"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i> Your current menu stays live until you save.</p>
                    </div>
                        </div>
                    </div>
                    <p class="wpbmm-credit">Crafted by <a href="https://www.borbila.com" target="_blank" rel="noopener noreferrer">Borbila</a></p>
                </div>
            </form>
            <form id="wpbmm-license-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wpbmm-hidden-form">
                <input type="hidden" name="action" value="wpbmm_license_action">
                <?php wp_nonce_field( 'wpbmm_license_action', 'wpbmm_license_nonce' ); ?>
            </form>
        </div>
        <?php
    }

    public function render_design_editor_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to edit this design.', 'wpbmm' ) );
        }

        $presets     = $this->options->get_style_presets();
        $preset_key  = isset( $_GET['preset'] ) ? sanitize_key( wp_unslash( $_GET['preset'] ) ) : 'classic';

        if ( ! isset( $presets[ $preset_key ] ) ) {
            $preset_key = 'classic';
        }

        $preset       = $presets[ $preset_key ];
        $items        = array_values( $this->get_design_editor_items( $preset_key ) );
        $colors       = $this->get_design_editor_colors( $preset_key );
        $typography   = $this->get_design_typography( $preset_key );
        $font_choices = $this->options->get_font_choices();
        $icon_choices = $this->get_icon_choices();
        $color_values = array();

        foreach ( $colors as $color ) {
            $color_values[ $color['option'] ] = $color['value'];
        }

        if ( 'spotlight' === $preset_key ) {
            $color_fields = array(
                'menu'        => 'wpbmm_spotlight_menu_bg',
                'icon'        => 'wpbmm_spotlight_icon_color',
                'text'        => 'wpbmm_spotlight_text_color',
                'active_bg'   => 'wpbmm_spotlight_center_bg',
                'active_icon' => 'wpbmm_spotlight_center_color',
            );
        } else {
            $color_fields = array(
                'menu'        => 'wpbmm_' . $preset_key . '_menu_bg',
                'icon'        => 'wpbmm_' . $preset_key . '_icon_color',
                'text'        => 'wpbmm_' . $preset_key . '_text_color',
                'active_bg'   => 'wpbmm_' . $preset_key . '_active_bg',
                'active_icon' => 'wpbmm_' . $preset_key . '_active_color',
            );
        }

        $font_stack    = isset( $font_choices[ $typography['font_value'] ] ) ? $font_choices[ $typography['font_value'] ]['stack'] : $font_choices['inter']['stack'];
        $menu_border   = isset( $preset['defaults']['wpbmm_menu_border'] ) ? $preset['defaults']['wpbmm_menu_border'] : '#e5e7eb';
        $icon_bg       = isset( $preset['defaults']['wpbmm_icon_bg'] ) ? $preset['defaults']['wpbmm_icon_bg'] : '#eef0f4';
        $back_url      = admin_url( 'admin.php?page=wpbmm-settings' );
        $editor_group  = 'wpbmm_editor_' . $preset_key;
        ?>
        <div
            class="wrap wpbmm-admin-wrap wpbmm-design-editor-page"
            data-design-editor-page
            data-editor-preset="<?php echo esc_attr( $preset_key ); ?>"
            data-menu-bg-field="<?php echo esc_attr( $color_fields['menu'] ); ?>"
            data-icon-color-field="<?php echo esc_attr( $color_fields['icon'] ); ?>"
            data-text-color-field="<?php echo esc_attr( $color_fields['text'] ); ?>"
            data-active-bg-field="<?php echo esc_attr( $color_fields['active_bg'] ); ?>"
            data-active-icon-field="<?php echo esc_attr( $color_fields['active_icon'] ); ?>"
            data-font-family-field="<?php echo esc_attr( $typography['font_option'] ); ?>"
            data-font-size-field="<?php echo esc_attr( $typography['size_option'] ); ?>"
        >
            <form id="wpbmm-design-editor-form" method="post" action="options.php">
                <?php settings_fields( $editor_group ); ?>
                <input type="hidden" name="wpbmm_style_preset" value="<?php echo esc_attr( $preset_key ); ?>">
                <input type="hidden" name="_wp_http_referer" value="<?php echo esc_url( $back_url ); ?>">

                <div class="wpbmm-editor-shell">
                    <header class="wpbmm-editor-toolbar">
                        <div class="wpbmm-editor-toolbar-copy">
                            <a class="wpbmm-editor-back" href="<?php echo esc_url( $back_url ); ?>">
                                <i class="fa-solid fa-arrow-left" aria-hidden="true"></i> Back to designs
                            </a>
                            <span class="wpbmm-section-kicker">Design editor</span>
                            <h1><?php echo esc_html( $preset['label'] ); ?></h1>
                            <p>Customize this design only. Saving will activate it and return to the design list.</p>
                        </div>
                        <button type="submit" class="button button-primary wpbmm-editor-save">
                            <i class="fa-solid fa-check" aria-hidden="true"></i> Save &amp; return
                        </button>
                    </header>

                    <div class="wpbmm-editor-page-layout">
                        <main class="wpbmm-editor-controls">
                            <section class="wpbmm-editor-section">
                                <div class="wpbmm-editor-section-head">
                                    <span class="wpbmm-editor-section-icon"><i class="fa-solid fa-icons" aria-hidden="true"></i></span>
                                    <div><h2>Menu items</h2><p>Choose an icon, write a short label and add its destination.</p></div>
                                </div>
                                <div class="wpbmm-friendly-item-grid">
                                    <?php foreach ( $items as $item_index => $item ) : ?>
                                        <article class="wpbmm-friendly-item-card <?php echo 'spotlight' === $preset_key && 'home' === $item['key'] ? 'is-center-item' : ''; ?>">
                                            <div class="wpbmm-friendly-item-title">
                                                <span class="wpbmm-friendly-icon-preview" data-icon-field-preview="<?php echo esc_attr( $item['icon_option'] ); ?>"><i class="<?php echo esc_attr( $item['icon'] ); ?>" aria-hidden="true"></i></span>
                                                <div><strong><?php echo esc_html( $item['title'] ); ?></strong><small>Item <?php echo esc_html( $item_index + 1 ); ?></small></div>
                                            </div>
                                            <div class="wpbmm-friendly-field">
                                                <label for="<?php echo esc_attr( $item['icon_option'] ); ?>">Icon</label>
                                                <select id="<?php echo esc_attr( $item['icon_option'] ); ?>" name="<?php echo esc_attr( $item['icon_option'] ); ?>">
                                                    <?php if ( ! isset( $icon_choices[ $item['icon'] ] ) ) : ?>
                                                        <option value="<?php echo esc_attr( $item['icon'] ); ?>" selected>Current custom icon</option>
                                                    <?php endif; ?>
                                                    <?php foreach ( $icon_choices as $icon_class => $icon_label ) : ?>
                                                        <option value="<?php echo esc_attr( $icon_class ); ?>" <?php selected( $item['icon'], $icon_class ); ?>><?php echo esc_html( $icon_label ); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div class="wpbmm-friendly-field">
                                                <label for="<?php echo esc_attr( $item['label_option'] ); ?>">Text</label>
                                                <input type="text" id="<?php echo esc_attr( $item['label_option'] ); ?>" name="<?php echo esc_attr( $item['label_option'] ); ?>" value="<?php echo esc_attr( $item['label'] ); ?>" maxlength="24">
                                            </div>
                                            <div class="wpbmm-friendly-field">
                                                <label for="<?php echo esc_attr( $item['link_option'] ); ?>">Link</label>
                                                <input type="text" id="<?php echo esc_attr( $item['link_option'] ); ?>" name="<?php echo esc_attr( $item['link_option'] ); ?>" value="<?php echo esc_attr( $item['link'] ); ?>" placeholder="https://example.com/page/">
                                            </div>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                            </section>

                            <section class="wpbmm-editor-section">
                                <div class="wpbmm-editor-section-head">
                                    <span class="wpbmm-editor-section-icon"><i class="fa-solid fa-palette" aria-hidden="true"></i></span>
                                    <div><h2>Colors</h2><p>Click a color to match the menu with your brand.</p></div>
                                </div>
                                <div class="wpbmm-friendly-color-grid">
                                    <?php foreach ( $colors as $color ) : ?>
                                        <label class="wpbmm-friendly-color" for="<?php echo esc_attr( $color['option'] ); ?>">
                                            <span><?php echo esc_html( $color['label'] ); ?></span>
                                            <input type="color" id="<?php echo esc_attr( $color['option'] ); ?>" name="<?php echo esc_attr( $color['option'] ); ?>" value="<?php echo esc_attr( $color['value'] ); ?>">
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </section>

                            <section class="wpbmm-editor-section">
                                <div class="wpbmm-editor-section-head">
                                    <span class="wpbmm-editor-section-icon"><i class="fa-solid fa-font" aria-hidden="true"></i></span>
                                    <div><h2>Typography</h2><p>Choose an easy-to-read font and label size.</p></div>
                                </div>
                                <div class="wpbmm-friendly-type-grid">
                                    <div class="wpbmm-friendly-field">
                                        <label for="<?php echo esc_attr( $typography['font_option'] ); ?>">Font family</label>
                                        <select id="<?php echo esc_attr( $typography['font_option'] ); ?>" name="<?php echo esc_attr( $typography['font_option'] ); ?>">
                                            <?php foreach ( $font_choices as $font_choice_key => $font_choice ) : ?>
                                                <option value="<?php echo esc_attr( $font_choice_key ); ?>" <?php selected( $typography['font_value'], $font_choice_key ); ?>><?php echo esc_html( $font_choice['label'] ); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="wpbmm-friendly-field wpbmm-font-size-control">
                                        <div class="wpbmm-range-label"><label for="<?php echo esc_attr( $typography['size_option'] ); ?>">Font size</label><output data-font-size-output><?php echo esc_html( $typography['size_value'] ); ?>px</output></div>
                                        <input type="range" min="9" max="22" step="1" id="<?php echo esc_attr( $typography['size_option'] ); ?>" name="<?php echo esc_attr( $typography['size_option'] ); ?>" value="<?php echo esc_attr( $typography['size_value'] ); ?>">
                                    </div>
                                </div>
                            </section>

                            <div class="wpbmm-editor-bottom-actions">
                                <a class="button" href="<?php echo esc_url( $back_url ); ?>">Cancel</a>
                                <button type="submit" class="button button-primary wpbmm-editor-save"><i class="fa-solid fa-check" aria-hidden="true"></i> Save &amp; return</button>
                            </div>
                        </main>

                        <aside class="wpbmm-editor-live-card">
                            <div class="wpbmm-preview-card-head"><div><span>Live preview</span><small>Updates as you edit</small></div><i class="fa-solid fa-signal" aria-hidden="true"></i></div>
                            <div class="wpbmm-phone-preview">
                                <div class="wpbmm-phone-speaker"></div>
                                <div class="wpbmm-phone-content">
                                    <div class="wpbmm-preview-copy"><span></span><span></span><span></span></div>
                                    <div
                                        class="wpbmm-preview-menu wpbmm-preview-<?php echo esc_attr( $preset_key ); ?>"
                                        data-editor-live-preview
                                        style="--preview-menu-bg: <?php echo esc_attr( $color_values[ $color_fields['menu'] ] ); ?>; --preview-menu-bg-alt: <?php echo esc_attr( $color_values[ $color_fields['menu'] ] ); ?>; --preview-menu-border: <?php echo esc_attr( $menu_border ); ?>; --preview-icon-bg: <?php echo esc_attr( $icon_bg ); ?>; --preview-icon-color: <?php echo esc_attr( $color_values[ $color_fields['icon'] ] ); ?>; --preview-active-bg: <?php echo esc_attr( $color_values[ $color_fields['active_bg'] ] ); ?>; --preview-active-color: <?php echo esc_attr( $color_values[ $color_fields['active_icon'] ] ); ?>; --preview-text-color: <?php echo esc_attr( $color_values[ $color_fields['text'] ] ); ?>; --preview-text-active: <?php echo esc_attr( $color_values[ $color_fields['text'] ] ); ?>; --preview-text-size: <?php echo esc_attr( max( 6, round( $typography['size_value'] * 0.58 ) ) ); ?>px; font-family: <?php echo esc_attr( $font_stack ); ?>;"
                                    >
                                        <?php foreach ( $items as $preview_index => $item ) : ?>
                                            <?php $is_center = 'spotlight' === $preset_key && 'home' === $item['key']; ?>
                                            <?php $is_preview_active = 'spotlight' === $preset_key ? $is_center : 0 === $preview_index; ?>
                                            <span class="<?php echo $is_preview_active ? 'is-active ' : ''; ?><?php echo $is_center ? 'wpbmm-preview-spotlight-item wpbmm-preview-spotlight-home' : ''; ?>" <?php echo 'spotlight' === $preset_key ? 'data-spotlight-preview' : 'data-standard-preview'; ?> data-editor-preview-item data-label-source="<?php echo esc_attr( $item['label_option'] ); ?>" data-icon-source="<?php echo esc_attr( $item['icon_option'] ); ?>">
                                                <i class="<?php echo esc_attr( $item['icon'] ); ?>" aria-hidden="true"></i><small><?php echo esc_html( $item['label'] ); ?></small>
                                            </span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="wpbmm-phone-home"></div>
                            </div>
                            <div class="wpbmm-editor-preview-note"><i class="fa-solid fa-circle-info" aria-hidden="true"></i><span>Save &amp; return will activate this design.</span></div>
                        </aside>
                    </div>
                </div>
            </form>
        </div>
        <?php
    }
}
