(function ($) {
    $(function () {
        var $modal = $('#wpbmm-search-modal');
        var $input = $('#wpbmm-search-input');

        if (!$modal.length) {
            return;
        }

        function closeModal() {
            $modal.fadeOut(150).attr('aria-hidden', 'true');
        }

        $('#wpbmm-search-btn').on('click', function (e) {
            e.preventDefault();
            $modal.css('display', 'flex').hide().fadeIn(150).attr('aria-hidden', 'false');
            setTimeout(function () {
                $input.trigger('focus');
            }, 120);
        });

        $('#wpbmm-close-search').on('click', function () {
            closeModal();
        });

        $modal.on('click', function (e) {
            if (e.target.id === 'wpbmm-search-modal') {
                closeModal();
            }
        });

        $(document).on('keydown', function (e) {
            if (e.key === 'Escape' && $modal.is(':visible')) {
                closeModal();
            }
        });
    });
})(jQuery);
