(function () {
    'use strict';

    function $(selector, root) {
        return Array.prototype.slice.call((root || document).querySelectorAll(selector));
    }

    function activePresetInput() {
        return document.querySelector('input[name="wpbmm_style_preset"]:checked');
    }

    function updatePresetCardState() {
        $('[data-preset-card]').forEach(function (card) {
            var input = card.querySelector('input[name="wpbmm_style_preset"]');
            var button = card.querySelector('[data-apply-preset]');
            var buttonIcon = button ? button.querySelector('i') : null;
            var buttonLabel = button ? button.querySelector('span') : null;
            var isActive = !!(input && input.checked);

            if ('true' === card.getAttribute('data-license-locked')) {
                card.classList.remove('is-active');
                card.setAttribute('aria-checked', 'false');

                if (button) {
                    button.setAttribute('aria-pressed', 'false');
                }

                return;
            }

            card.classList.toggle('is-active', isActive);
            card.setAttribute('aria-checked', isActive ? 'true' : 'false');

            if (button) {
                button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
            }

            if (buttonIcon) {
                buttonIcon.className = 'fa-solid ' + (isActive ? 'fa-circle-check' : 'fa-arrow-pointer');
            }

            if (buttonLabel) {
                buttonLabel.textContent = isActive ? 'Design selected' : 'Select this design';
            }
        });
    }

    function readField(name) {
        var field = document.querySelector('#wpbmm-settings-form [name="' + name + '"]');
        return field ? field.value : '';
    }

    function loadPresetDefaults(meta, presetKey) {
        var details = meta[presetKey] || {};

        if (!details.defaults) {
            return;
        }

        Object.keys(details.defaults).forEach(function (fieldName) {
            var field = document.querySelector('#wpbmm-settings-form [name="' + fieldName + '"]');

            if (field && !('spotlight' === presetKey && 0 === fieldName.indexOf('wpbmm_spotlight_') && field.value)) {
                field.value = details.defaults[fieldName];
            }
        });
    }

    function updatePreview() {
        var preview = document.getElementById('wpbmm-admin-preview');
        var active = activePresetInput();

        if (!preview || !active) {
            return;
        }

        preview.className = 'wpbmm-preview-menu wpbmm-preview-' + active.value;

        var isSpotlight = 'spotlight' === active.value;
        var presetPrefix = 'wpbmm_' + active.value + '_';
        var colorProperties = {
            wpbmm_menu_border: '--preview-menu-border',
            wpbmm_icon_bg: '--preview-icon-bg'
        };

        if (isSpotlight) {
            colorProperties.wpbmm_spotlight_menu_bg = '--preview-menu-bg';
            colorProperties.wpbmm_spotlight_icon_color = '--preview-icon-color';
            colorProperties.wpbmm_spotlight_center_bg = '--preview-active-bg';
            colorProperties.wpbmm_spotlight_center_color = '--preview-active-color';
            colorProperties.wpbmm_spotlight_text_color = '--preview-text-color';
        } else {
            colorProperties[presetPrefix + 'menu_bg'] = '--preview-menu-bg';
            colorProperties[presetPrefix + 'icon_color'] = '--preview-icon-color';
            colorProperties[presetPrefix + 'active_bg'] = '--preview-active-bg';
            colorProperties[presetPrefix + 'active_color'] = '--preview-active-color';
            colorProperties[presetPrefix + 'text_color'] = '--preview-text-color';
        }

        Object.keys(colorProperties).forEach(function (fieldName) {
            var value = readField(fieldName);
            if (value) {
                preview.style.setProperty(colorProperties[fieldName], value);
            }
        });

        var menuBackground = readField(isSpotlight ? 'wpbmm_spotlight_menu_bg' : presetPrefix + 'menu_bg');
        var activeTextColor = readField(isSpotlight ? 'wpbmm_spotlight_text_color' : presetPrefix + 'text_color');

        if (menuBackground) {
            preview.style.setProperty('--preview-menu-bg-alt', menuBackground);
        }

        if (activeTextColor) {
            preview.style.setProperty('--preview-text-active', activeTextColor);
        }

        if (!isSpotlight) {
            $('[data-standard-preview]', preview).forEach(function (item, index) {
                var icon = item.querySelector('i');
                var label = item.querySelector('small');
                var iconClass = readField(presetPrefix + 'icon_' + (index + 1)).trim();
                var labelText = readField(presetPrefix + 'label_' + (index + 1));

                if (icon && iconClass) {
                    icon.className = iconClass;
                }

                if (label && labelText) {
                    label.textContent = labelText;
                }
            });
        }

        $('[data-preview-icon]', preview).forEach(function (icon) {
            if (!isSpotlight) {
                return;
            }

            var iconClass = readField(icon.getAttribute('data-preview-icon')).trim();

            if (iconClass) {
                icon.className = iconClass;
            }
        });

        $('[data-spotlight-preview] [data-preview-label]', preview).forEach(function (label) {
            if (!isSpotlight) {
                return;
            }

            var value = readField(label.getAttribute('data-preview-label'));
            if (value) {
                label.textContent = value;
            }
        });

        var iconSize = parseInt(readField('wpbmm_icon_size'), 10);
        var textSize = parseInt(readField('wpbmm_text_size'), 10);
        var radius = parseInt(readField('wpbmm_radius'), 10);
        var showLabels = document.querySelector('input[name="wpbmm_show_labels"][type="checkbox"]');

        if (!isNaN(iconSize)) {
            preview.style.setProperty('--preview-icon-size', Math.max(9, Math.round(iconSize * 0.62)) + 'px');
        }

        if (!isNaN(textSize)) {
            preview.style.setProperty('--preview-text-size', Math.max(6, Math.round(textSize * 0.58)) + 'px');
        }

        if (!isNaN(radius)) {
            preview.style.setProperty('--preview-radius', Math.max(8, Math.round(radius * 0.62)) + 'px');
        }

        preview.classList.toggle('wpbmm-preview-no-labels', !!(showLabels && !showLabels.checked));
    }

    function activateTab(button, tabButtons, tabPanels) {
        var target = button.getAttribute('data-tab-target');
        var settingsFooter = document.querySelector('[data-settings-footer]');

        tabButtons.forEach(function (tabButton) {
            var isActive = tabButton === button;
            tabButton.classList.toggle('is-active', isActive);
            tabButton.setAttribute('aria-selected', isActive ? 'true' : 'false');
            tabButton.setAttribute('tabindex', isActive ? '0' : '-1');
        });

        tabPanels.forEach(function (panel) {
            var isActive = panel.getAttribute('data-tab-panel') === target;
            panel.classList.toggle('is-active', isActive);
            panel.setAttribute('aria-hidden', isActive ? 'false' : 'true');
        });

        if (settingsFooter) {
            settingsFooter.classList.toggle('is-hidden', 'license' === target);
        }
    }

    function initTabs() {
        var tabButtons = $('[data-tab-target]');
        var tabPanels = $('[data-tab-panel]');

        tabButtons.forEach(function (button, index) {
            button.setAttribute('tabindex', button.classList.contains('is-active') ? '0' : '-1');

            button.addEventListener('click', function () {
                activateTab(button, tabButtons, tabPanels);
            });

            button.addEventListener('keydown', function (event) {
                var nextIndex;

                if ('ArrowRight' === event.key || 'ArrowDown' === event.key) {
                    nextIndex = (index + 1) % tabButtons.length;
                } else if ('ArrowLeft' === event.key || 'ArrowUp' === event.key) {
                    nextIndex = (index - 1 + tabButtons.length) % tabButtons.length;
                } else {
                    return;
                }

                event.preventDefault();
                activateTab(tabButtons[nextIndex], tabButtons, tabPanels);
                tabButtons[nextIndex].focus();
            });
        });

        tabPanels.forEach(function (panel) {
            panel.setAttribute('role', 'tabpanel');
            panel.setAttribute('aria-hidden', panel.classList.contains('is-active') ? 'false' : 'true');
        });
    }

    function initDesignEditorPage() {
        var editor = document.querySelector('[data-design-editor-page]');

        if (!editor) {
            return;
        }

        var form = document.getElementById('wpbmm-design-editor-form');
        var preview = editor.querySelector('[data-editor-live-preview]');
        var sizeOutput = editor.querySelector('[data-font-size-output]');
        var fontStacks = {
            inter: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
            poppins: '"Poppins", "Segoe UI", sans-serif',
            manrope: '"Manrope", "Segoe UI", sans-serif',
            system: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
        };

        function editorField(name) {
            return form ? form.querySelector('[name="' + name + '"]') : null;
        }

        function editorValue(attributeName) {
            var fieldName = editor.getAttribute(attributeName);
            var field = fieldName ? editorField(fieldName) : null;
            return field ? field.value : '';
        }

        function updateEditorPreview() {
            if (!preview) {
                return;
            }

            var menuColor = editorValue('data-menu-bg-field');
            var iconColor = editorValue('data-icon-color-field');
            var textColor = editorValue('data-text-color-field');
            var activeBackground = editorValue('data-active-bg-field');
            var activeIcon = editorValue('data-active-icon-field');
            var fontFamily = editorValue('data-font-family-field');
            var fontSize = parseInt(editorValue('data-font-size-field'), 10);

            if (menuColor) {
                preview.style.setProperty('--preview-menu-bg', menuColor);
                preview.style.setProperty('--preview-menu-bg-alt', menuColor);
            }
            if (iconColor) {
                preview.style.setProperty('--preview-icon-color', iconColor);
            }
            if (textColor) {
                preview.style.setProperty('--preview-text-color', textColor);
                preview.style.setProperty('--preview-text-active', textColor);
            }
            if (activeBackground) {
                preview.style.setProperty('--preview-active-bg', activeBackground);
            }
            if (activeIcon) {
                preview.style.setProperty('--preview-active-color', activeIcon);
            }
            if (fontFamily && fontStacks[fontFamily]) {
                preview.style.fontFamily = fontStacks[fontFamily];
            }
            if (!isNaN(fontSize)) {
                preview.style.setProperty('--preview-text-size', Math.max(6, Math.round(fontSize * 0.58)) + 'px');
                if (sizeOutput) {
                    sizeOutput.textContent = fontSize + 'px';
                }
            }

            $('[data-editor-preview-item]', preview).forEach(function (item) {
                var iconField = editorField(item.getAttribute('data-icon-source'));
                var labelField = editorField(item.getAttribute('data-label-source'));
                var icon = item.querySelector('i');
                var label = item.querySelector('small');

                if (icon && iconField && iconField.value) {
                    icon.className = iconField.value;
                }
                if (label && labelField) {
                    label.textContent = labelField.value || 'Item';
                }
            });

            $('[data-icon-field-preview]', editor).forEach(function (badge) {
                var field = editorField(badge.getAttribute('data-icon-field-preview'));
                var icon = badge.querySelector('i');

                if (field && icon && field.value) {
                    icon.className = field.value;
                }
            });
        }

        if (form) {
            $('input, select', form).forEach(function (field) {
                field.addEventListener('input', updateEditorPreview);
                field.addEventListener('change', updateEditorPreview);
            });
        }

        updateEditorPreview();
    }

    document.addEventListener('DOMContentLoaded', function () {
        var presetMeta = window.wpbmmPresetMeta || {};
        var presetInputs = $('input[name="wpbmm_style_preset"]');
        var presetCards = $('[data-preset-card]');
        var applyButtons = $('[data-apply-preset]');
        var previewFields = $('#wpbmm-settings-form input, #wpbmm-settings-form select');
        var deactivateButton = document.querySelector('[data-confirm-deactivate]');

        function showLicensePrompt(card) {
            if (!card) {
                return;
            }

            presetCards.forEach(function (presetCard) {
                if (presetCard !== card) {
                    presetCard.classList.remove('is-license-prompt');
                }
            });

            card.classList.add('is-license-prompt');
        }

        function selectPreset(presetKey) {
            var input = document.querySelector('input[name="wpbmm_style_preset"][value="' + presetKey + '"]');
            var card = input ? input.closest('[data-preset-card]') : null;
            var wasActive;

            if (!input) {
                return;
            }

            if (card && 'true' === card.getAttribute('data-license-locked')) {
                showLicensePrompt(card);
                return;
            }

            wasActive = input.checked;

            input.checked = true;
            if (!wasActive) {
                loadPresetDefaults(presetMeta, presetKey);
            }
            updatePresetCardState();
            updatePreview();
        }

        initTabs();
        initDesignEditorPage();

        presetInputs.forEach(function (input) {
            input.addEventListener('change', function () {
                updatePresetCardState();
                updatePreview();
            });
        });

        applyButtons.forEach(function (button) {
            button.addEventListener('click', function (event) {
                event.stopPropagation();
                selectPreset(button.getAttribute('data-apply-preset'));
            });
        });

        presetCards.forEach(function (card) {
            card.addEventListener('click', function (event) {
                if ('true' === card.getAttribute('data-license-locked')) {
                    if (!event.target.closest('[data-get-license]')) {
                        event.preventDefault();
                        showLicensePrompt(card);
                    }
                    return;
                }

                if (event.target.closest('a, button, input, select, textarea')) {
                    return;
                }
                selectPreset(card.getAttribute('data-preset-key'));
            });

            card.addEventListener('keydown', function (event) {
                if ('true' === card.getAttribute('data-license-locked')) {
                    if ('Enter' === event.key || ' ' === event.key) {
                        event.preventDefault();
                        showLicensePrompt(card);
                    }
                    return;
                }

                if (event.target.closest('a, button, input, select, textarea')) {
                    return;
                }

                if ('Enter' !== event.key && ' ' !== event.key) {
                    return;
                }

                event.preventDefault();
                selectPreset(card.getAttribute('data-preset-key'));
            });
        });

        document.addEventListener('click', function (event) {
            presetCards.forEach(function (card) {
                if (!card.contains(event.target)) {
                    card.classList.remove('is-license-prompt');
                }
            });
        });

        previewFields.forEach(function (field) {
            field.addEventListener('input', updatePreview);
            field.addEventListener('change', updatePreview);
        });

        if (deactivateButton) {
            deactivateButton.addEventListener('click', function (event) {
                if (!window.confirm('Deactivate this license for the current website?')) {
                    event.preventDefault();
                }
            });
        }

        updatePresetCardState();
        updatePreview();
    });
})();
