<?php
/**
 * Plugin Name: Mobile Bottom Menu
 * Description: Premium mobile bottom navigation with ready-made templates, live customization, and secure Borbila licensing.
 * Version: 3.0.15
 * Author: Borbila
 * Author URI: https://borbila.com
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'WPBMM_VERSION', '3.0.15' );
define( 'WPBMM_FILE', __FILE__ );
define( 'WPBMM_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPBMM_URL', plugin_dir_url( __FILE__ ) );
define( 'WPBMM_LICENSE_API_URL', 'https://borbila.com/wp-json/borbila-license/v1' );
define( 'WPBMM_LICENSE_TEMPLATE_ID', 'wp-bottom-mobile-menu' );

require_once WPBMM_DIR . 'includes/class-wpbmm-options.php';
require_once WPBMM_DIR . 'includes/class-wpbmm-license.php';
require_once WPBMM_DIR . 'includes/class-wpbmm-frontend.php';
require_once WPBMM_DIR . 'includes/class-wpbmm-admin.php';
require_once WPBMM_DIR . 'includes/class-wpbmm-plugin.php';

function wpbmm_bootstrap() {
    static $instance = null;

    if ( null === $instance ) {
        $instance = new WPBMM_Plugin();
        $instance->register_hooks();
    }

    return $instance;
}

add_action( 'plugins_loaded', 'wpbmm_bootstrap' );

register_activation_hook(
    WPBMM_FILE,
    function () {
        if ( ! wp_next_scheduled( WPBMM_License::CRON_HOOK ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', WPBMM_License::CRON_HOOK );
        }
    }
);

register_deactivation_hook(
    WPBMM_FILE,
    function () {
        wp_clear_scheduled_hook( WPBMM_License::CRON_HOOK );
    }
);
