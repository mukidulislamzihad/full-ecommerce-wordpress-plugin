(function($){
var C=window.qvcp,m,d,sel,cur;
function e(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function close(){if(m){m.remove();m=null}$('body').removeClass('qvcp-lock')}
function match(){
 var all=d.attrs.every(function(a){return sel[a.key]});
 if(!all)return null;
 return d.vars.find(function(v){return d.attrs.every(function(a){var x=v.attrs[a.key];return x===''||x===undefined||x===sel[a.key]})})||false;
}
function compat(key,val){ // is option possible given other selections
 return d.vars.some(function(v){
  if(!v.ok)return false;
  return d.attrs.every(function(a){
   var want=a.key===key?val:sel[a.key], x=v.attrs[a.key];
   return !want||x===''||x===undefined||x===want;
  });
 });
}
function update(){
 var v=match(),$b=m.find('.qvcp-btn'),$q=m.find('.qvcp-qty input');
 m.find('.qvcp-sw button').each(function(){var $t=$(this);$t.toggleClass('on',sel[$t.data('k')]===$t.data('v')).toggleClass('off',!compat($t.data('k'),$t.data('v')))});
 m.find('.qvcp-msg').removeClass('ok').text('');
 m.find('.qvcp-meta').empty();cur=null;
 if(v===null){$b.prop('disabled',true);return}
 if(v===false||!v.ok){$b.prop('disabled',true);m.find('.qvcp-msg').text(C.i.na);if(v&&v.stock)m.find('.qvcp-meta').html(v.stock);return}
 cur=v;
 m.find('.qvcp-price').html(v.price);
 if(C.preview&&v.img){m.find('.qvcp-img img').attr('src',v.img);m.find('.qvcp-thumbs button').removeClass('on')}
 var meta='';if(C.stock&&v.stock)meta+='<div>'+v.stock+'</div>';if(C.sku&&v.sku)meta+='<p>'+e(C.i.sku)+': '+e(v.sku)+'</p>';
 m.find('.qvcp-meta').html(meta);
 $q.attr('min',v.min||1);if(v.max!=='')$q.attr('max',v.max);else $q.removeAttr('max');
 if(+$q.val()<(v.min||1))$q.val(v.min||1);
 if(v.max!==''&&+$q.val()>+v.max)$q.val(v.max);
 $b.prop('disabled',false);
}
function render(){
 var ic={cart:'<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="20" r="1.4"/><circle cx="18" cy="20" r="1.4"/><path d="M2 3h3l2.7 12.4a1 1 0 0 0 1 .8h8.8a1 1 0 0 0 1-.8L20 7H6"/></svg>',bolt:'<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M13 2 4 14h6l-1 8 9-12h-6z"/></svg>'};
 var g=d.gallery||[],th='';
 if(g.length>1)th='<div class="qvcp-thumbs">'+g.map(function(x,i){return'<button type="button" class="'+(i?'':'on')+'" data-f="'+e(x.f)+'"><img src="'+e(x.t)+'" alt=""></button>'}).join('')+'</div>';
 var h='<div class="qvcp-wrap"><div class="qvcp-left"><div class="qvcp-img"><img src="'+e(d.image)+'" alt=""></div>'+th+'</div><div class="qvcp-info"><h3>'+e(d.title)+'</h3>'
  +(d.cat?'<div class="qvcp-cat">'+e(C.i.category)+': '+(d.cat_url?'<a href="'+e(d.cat_url)+'">'+e(d.cat)+'</a>':e(d.cat))+'</div>':'')
  +'<div class="qvcp-price">'+d.price+'</div>'+(d.desc?'<p class="qvcp-desc">'+e(d.desc)+'</p>':'')+'<div class="qvcp-meta"></div>';
 d.attrs.forEach(function(a){
  h+='<div class="qvcp-attr"><label>'+e(a.label)+'</label>';
  if(C.style==='dropdown'){
   h+='<select data-k="'+e(a.key)+'"><option value="">'+e(C.i.select)+'</option>'+a.opts.map(function(o){return'<option value="'+e(o.v)+'"'+(sel[a.key]===o.v?' selected':'')+'>'+e(o.l)+'</option>'}).join('')+'</select>';
  }else{
   h+='<div class="qvcp-sw">'+a.opts.map(function(o){return'<button type="button" data-k="'+e(a.key)+'" data-v="'+e(o.v)+'">'+e(o.l)+'</button>'}).join('')+'</div>';
  }
  h+='</div>';
 });
 h+='<div class="qvcp-row"><div class="qvcp-qty"><button type="button" data-d="-1">&minus;</button><input type="number" value="1" min="1" inputmode="numeric"><button type="button" data-d="1">+</button></div>'
  +'<button type="button" class="qvcp-btn add" disabled>'+ic.cart+'<span>'+e(C.i.add)+'</span></button>'+(C.buy?'<button type="button" class="qvcp-btn buy" disabled>'+ic.bolt+'<span>'+e(C.i.buynow)+'</span></button>':'')+'</div><div class="qvcp-msg"></div></div></div>';
 m.find('.qvcp-body').html(h);update();
}
function submit(buy){
 if(!cur){m.find('.qvcp-msg').text(C.i.choose);return}
 var $b=m.find('.qvcp-btn').prop('disabled',true),$c=m.find(buy?'.qvcp-btn.buy':'.qvcp-btn.add'),t0=$c.html(),box=m;$c.addClass('busy').html('<span>...</span>');
 function reset(){$c.removeClass('busy').html(t0);$b.prop('disabled',false)}
 $.post(C.ajax,{action:'qvcp_add',nonce:C.nonce,product_id:d.id,variation_id:cur.id,quantity:m.find('.qvcp-qty input').val(),attrs:sel},function(r){
  if(!r||!r.success){reset();m.find('.qvcp-msg').html((r&&r.data&&r.data.msg)||C.i.err);return}
  if(buy){location.href=C.checkout;return}
  if(C.after==='cart'){location.href=C.cart;return}
  if(C.after==='stay'){reset();m.find('.qvcp-msg').addClass('ok').text(C.i.added)}else close();
  try{$(document.body).trigger('added_to_cart',[r.data.fragments,r.data.cart_hash,null])}catch(x){}
 }).fail(function(){reset();m.find('.qvcp-msg').text(C.i.err)});
}
var cache=window.qvcpData||{},pend={},q=[],run=0;
function load(id){
 if(cache[id])return $.Deferred().resolve(cache[id]).promise();
 if(pend[id])return pend[id];
 return pend[id]=$.post(C.ajax,{action:'qvcp_get',nonce:C.nonce,product_id:id}).then(function(r){delete pend[id];if(!r.success)return $.Deferred().reject();return cache[id]=r.data},function(){delete pend[id]});
}
function pump(){
 if(run>=2||!q.length)return;
 var id=q.shift();if(cache[id]||pend[id])return pump();
 run++;load(id).always(function(){run--;pump()});pump();
}
function img(id){var x=cache[id];if(!x||x.pl)return;x.pl=1;[x.image].concat((x.gallery||[]).map(function(g){return g.f})).slice(0,4).forEach(function(u){if(u)(new Image()).src=u})}
function pre(id){img(id);if(id&&!cache[id]&&!pend[id]&&q.indexOf(id)<0){q.unshift(id);pump()}}
function warm(){
 $('.qvcp-trigger').slice(0,12).each(function(){img($(this).data('product_id'))});
 var els=$('.qvcp-trigger');if(!els.length)return;
 if(!window.IntersectionObserver){els.slice(0,6).each(function(){pre($(this).data('product_id'))});return}
 var io=new IntersectionObserver(function(en){en.forEach(function(x){if(x.isIntersecting){io.unobserve(x.target);var id=$(x.target).data('product_id');if(id&&!cache[id]&&q.indexOf(id)<0){q.push(id);(window.requestIdleCallback||setTimeout)(pump)}}})},{rootMargin:'200px'});
 els.each(function(){io.observe(this)});
}
document.addEventListener('error',function(ev){var i=ev.target;if(!i||i.tagName!=='IMG'||!$(i).closest('.qvcp-ov').length)return;var n=+i.getAttribute('data-fb')||0,u=i.getAttribute('data-o')||i.src;if(!i.getAttribute('data-o'))i.setAttribute('data-o',u);var b=u.replace(/\.(jpe?g|png|gif|webp|avif)(\?.*)?$/i,''),c=[b+'.avif',u+'.avif',b+'.webp',u+'.webp'];if(n<c.length){i.setAttribute('data-fb',n+1);i.src=c[n]}},true);
$(warm);
$(document).on('pointerenter touchstart mouseover','.qvcp-trigger',function(){pre($(this).data('product_id'))});
function open(id){
 close();
 m=$('<div class="qvcp-ov"><div class="qvcp-box" role="dialog" aria-modal="true"><button type="button" class="qvcp-x" aria-label="Close">&times;</button><div class="qvcp-body"><div class="qvcp-load">'+e(C.i.loading)+'</div></div></div></div>').appendTo('body');
 $('body').addClass('qvcp-lock');
 var box=m;
 load(id).done(function(x){if(m!==box)return;d=x;sel={};$.each(d.defaults||{},function(k,v){sel[k]=v});render()}).fail(function(){if(m===box)close()});
}
$(document).on('click','.qvcp-trigger,.add_to_cart_button.product_type_variable',function(ev){
 var id=$(this).data('product_id');if(!id)return;
 ev.preventDefault();ev.stopImmediatePropagation();open(id);
});
$(document).on('click','.qvcp-ov',function(ev){if($(ev.target).is('.qvcp-ov,.qvcp-x'))close()});
$(document).on('keydown',function(ev){if(ev.key==='Escape')close()});
$(document).on('click','.qvcp-sw button',function(){var $t=$(this);sel[$t.data('k')]=sel[$t.data('k')]===$t.data('v')?'':$t.data('v');update()});
$(document).on('change','.qvcp-attr select',function(){sel[$(this).data('k')]=this.value;update()});
$(document).on('click','.qvcp-qty button',function(){
 var $i=$(this).siblings('input'),v=(+$i.val()||1)+(+$(this).data('d')),mn=+$i.attr('min')||1,mx=$i.attr('max')?+$i.attr('max'):Infinity;
 $i.val(Math.max(mn,Math.min(mx,v)));
});
$(document).on('change','.qvcp-qty input',function(){var mn=+$(this).attr('min')||1,mx=$(this).attr('max')?+$(this).attr('max'):Infinity;this.value=Math.max(mn,Math.min(mx,+this.value||mn))});
$(document).on('click','.qvcp-thumbs button',function(){var $t=$(this);m.find('.qvcp-img img').attr('src',$t.data('f'));$t.addClass('on').siblings().removeClass('on')});
$(document).on('click','.qvcp-btn.add',function(){submit(false)});
$(document).on('click','.qvcp-btn.buy',function(){submit(true)});
})(jQuery);
