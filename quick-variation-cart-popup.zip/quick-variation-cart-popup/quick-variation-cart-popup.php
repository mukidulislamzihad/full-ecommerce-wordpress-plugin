<?php
/**
 * Plugin Name: Quick Variation Cart Popup
 * Description: Variable product er jonno fast variation popup — shop/category/search page theke-i variation select, quantity, Add to Cart ar Buy Now.
 * Version: 1.5.1
 * Requires Plugins: woocommerce
 * Text Domain: quick-variation-cart-popup
 * Domain Path: /languages
 */
defined('ABSPATH') || exit;

final class QVCP {
	const VER = '1.5.1';

	static function fields() {
		return [
			'general' => ['title' => __('General', 'quick-variation-cart-popup'), 'f' => [
				'enable'       => ['check', __('Enable popup', 'quick-variation-cart-popup'), 1],
				'show_buy_now' => ['check', __('Show Buy Now button', 'quick-variation-cart-popup'), 1],
				'show_sku'     => ['check', __('Show SKU', 'quick-variation-cart-popup'), 1],
				'show_stock'   => ['check', __('Show stock status', 'quick-variation-cart-popup'), 1],
				'after_add'    => ['select', __('After Add to Cart', 'quick-variation-cart-popup'), 'close', ['close' => 'Close popup', 'cart' => 'Go to cart', 'stay' => 'Stay open']],
			]],
			'design' => ['title' => __('Design', 'quick-variation-cart-popup'), 'f' => [
				'overlay'      => ['color', __('Overlay color', 'quick-variation-cart-popup'), '#000000'],
				'overlay_op'   => ['number', __('Overlay opacity (0-90 %)', 'quick-variation-cart-popup'), 55, 90],
				'glass'        => ['color', __('Glass card color', 'quick-variation-cart-popup'), '#ffffff'],
				'glass_op'     => ['number', __('Glass opacity (10-100 %)', 'quick-variation-cart-popup'), 100, 100],
				'blur'         => ['number', __('Glass blur (px)', 'quick-variation-cart-popup'), 0, 60],
				'glass_border' => ['color', __('Glass border color', 'quick-variation-cart-popup'), '#ffffff'],
				'radius'       => ['number', __('Card radius (px)', 'quick-variation-cart-popup'), 18, 50],
				'btn_radius'   => ['number', __('Button / swatch radius (px)', 'quick-variation-cart-popup'), 12, 50],
				'title_color'  => ['color', __('Title color', 'quick-variation-cart-popup'), '#1a1a2e'],
				'cat_color'    => ['color', __('Category link color', 'quick-variation-cart-popup'), '#e11d48'],
				'desc_color'   => ['color', __('Description color', 'quick-variation-cart-popup'), '#555b66'],
				'price_color'  => ['color', __('Price color', 'quick-variation-cart-popup'), '#111111'],
				'label_color'  => ['color', __('Attribute label color', 'quick-variation-cart-popup'), '#222222'],
				'meta_color'   => ['color', __('SKU / stock text color', 'quick-variation-cart-popup'), '#555555'],
				'close_color'  => ['color', __('Close button background', 'quick-variation-cart-popup'), '#111111'],
				'close_text'   => ['color', __('Close button icon color', 'quick-variation-cart-popup'), '#ffffff'],
				'close_hover'  => ['color', __('Close button hover background', 'quick-variation-cart-popup'), '#333333'],
				'divider'      => ['color', __('Divider line color', 'quick-variation-cart-popup'), '#e3e5e8'],
				'err_color'    => ['color', __('Error message color', 'quick-variation-cart-popup'), '#d93025'],
				'ok_color'     => ['color', __('Success message color', 'quick-variation-cart-popup'), '#1e8e3e'],
				'swatch_bg'    => ['color', __('Swatch background', 'quick-variation-cart-popup'), '#fdf6dc'],
				'swatch_color' => ['color', __('Swatch text', 'quick-variation-cart-popup'), '#222222'],
				'swatch_border'=> ['color', __('Swatch border', 'quick-variation-cart-popup'), '#efe3b4'],
				'swatch_hover' => ['color', __('Swatch hover border', 'quick-variation-cart-popup'), '#2563eb'],
				'sel_bg'       => ['color', __('Selected swatch background', 'quick-variation-cart-popup'), '#2563eb'],
				'sel_color'    => ['color', __('Selected swatch text', 'quick-variation-cart-popup'), '#ffffff'],
				'qty_bg'       => ['color', __('Quantity background', 'quick-variation-cart-popup'), '#ffffff'],
				'qty_border'   => ['color', __('Quantity border', 'quick-variation-cart-popup'), '#d6d6d6'],
				'qty_color'    => ['color', __('Quantity text', 'quick-variation-cart-popup'), '#111111'],
				'btn_bg'       => ['color', __('Add to Cart background', 'quick-variation-cart-popup'), '#111111'],
				'btn_color'    => ['color', __('Add to Cart text', 'quick-variation-cart-popup'), '#ffffff'],
				'btn_hover'    => ['color', __('Add to Cart hover background', 'quick-variation-cart-popup'), '#333333'],
				'btn_hover_c'  => ['color', __('Add to Cart hover text', 'quick-variation-cart-popup'), '#ffffff'],
				'buy_bg'       => ['color', __('Buy Now background', 'quick-variation-cart-popup'), '#f97316'],
				'buy_color'    => ['color', __('Buy Now text', 'quick-variation-cart-popup'), '#ffffff'],
				'buy_hover'    => ['color', __('Buy Now hover background', 'quick-variation-cart-popup'), '#ea580c'],
				'buy_hover_c'  => ['color', __('Buy Now hover text', 'quick-variation-cart-popup'), '#ffffff'],
			]],
			'layout' => ['title' => __('Layout & Size', 'quick-variation-cart-popup'), 'f' => [
				'box_width'    => ['number', __('Popup max width (px)', 'quick-variation-cart-popup'), 900, 1400, 280],
				'box_height'   => ['number', __('Popup max height (% of screen)', 'quick-variation-cart-popup'), 92, 100, 40],
				'ov_pad'       => ['number', __('Space around popup on desktop (px)', 'quick-variation-cart-popup'), 16, 80],
				'left_width'   => ['number', __('Image panel width (%)', 'quick-variation-cart-popup'), 40, 60, 20],
				'left_bg'      => ['color', __('Image panel background', 'quick-variation-cart-popup'), '#f1f2f4'],
				'left_pad'     => ['number', __('Image panel padding (px)', 'quick-variation-cart-popup'), 16, 60],
				'img_bg'       => ['color', __('Image box background', 'quick-variation-cart-popup'), '#ffffff'],
				'img_border'   => ['color', __('Image box border', 'quick-variation-cart-popup'), '#e3e5e8'],
				'img_radius'   => ['number', __('Image box radius (px)', 'quick-variation-cart-popup'), 14, 50],
				'img_height'   => ['number', __('Image max height (px)', 'quick-variation-cart-popup'), 340, 800, 120],
				'thumb_active' => ['color', __('Active thumbnail border', 'quick-variation-cart-popup'), '#2563eb'],
				'info_pad'     => ['number', __('Info area padding (px)', 'quick-variation-cart-popup'), 28, 80],
				'title_size'   => ['number', __('Title font size (px)', 'quick-variation-cart-popup'), 26, 60, 12],
				'price_size'   => ['number', __('Price font size (px)', 'quick-variation-cart-popup'), 19, 60, 10],
				'desc_size'    => ['number', __('Description font size (px)', 'quick-variation-cart-popup'), 13, 30, 8],
				'label_size'   => ['number', __('Attribute label font size (px)', 'quick-variation-cart-popup'), 11, 30, 8],
				'swatch_size'  => ['number', __('Swatch font size (px)', 'quick-variation-cart-popup'), 12, 30, 8],
				'btn_size'     => ['number', __('Button font size (px)', 'quick-variation-cart-popup'), 13, 30, 8],
				'mob_title'    => ['number', __('Title font size on mobile (px)', 'quick-variation-cart-popup'), 19, 40, 12],
				'mob_sheet'    => ['check', __('Mobile: show as bottom sheet', 'quick-variation-cart-popup'), 1],
			]],
			'advanced' => ['title' => __('Custom CSS', 'quick-variation-cart-popup'), 'f' => [
				'custom_css'   => ['textarea', __('Custom CSS (loaded after plugin CSS)', 'quick-variation-cart-popup'), ''],
			]],
			'variations' => ['title' => __('Variations', 'quick-variation-cart-popup'), 'f' => [
				'style'        => ['select', __('Option style', 'quick-variation-cart-popup'), 'buttons', ['buttons' => 'Buttons', 'dropdown' => 'Dropdown']],
				'image_preview'=> ['check', __('Live variation image preview', 'quick-variation-cart-popup'), 1],
			]],
			'buttons' => ['title' => __('Buttons', 'quick-variation-cart-popup'), 'f' => [
				'loop_label'   => ['text', __('Loop button label', 'quick-variation-cart-popup'), __('Select options', 'quick-variation-cart-popup')],
				'add_label'    => ['text', __('Add to Cart label', 'quick-variation-cart-popup'), __('Add to Cart', 'quick-variation-cart-popup')],
				'buy_label'    => ['text', __('Buy Now label', 'quick-variation-cart-popup'), __('Buy Now', 'quick-variation-cart-popup')],
			]],
		];
	}

	static function o($tab, $key) {
		$saved = get_option("qvcp_$tab", []);
		if (isset($saved[$key])) return $saved[$key];
		return self::fields()[$tab]['f'][$key][2];
	}

	static function init() {
		add_action('admin_menu', [__CLASS__, 'menu']);
		add_action('plugins_loaded', function () {
			load_plugin_textdomain('quick-variation-cart-popup', false, dirname(plugin_basename(__FILE__)) . '/languages');
		});
		if (!class_exists('WooCommerce') && !in_array('woocommerce/woocommerce.php', (array) get_option('active_plugins', []), true)) return;
		add_filter('woocommerce_loop_add_to_cart_link', [__CLASS__, 'loop_btn'], 20, 2);
		add_action('wp_enqueue_scripts', [__CLASS__, 'assets']);
		add_action('wp_footer', [__CLASS__, 'inline_data'], 5);
		foreach (['woocommerce_update_product', 'woocommerce_new_product', 'woocommerce_delete_product', 'woocommerce_product_set_stock', 'woocommerce_update_product_variation'] as $h) add_action($h, [__CLASS__, 'bust']);
		add_action('woocommerce_variation_set_stock', [__CLASS__, 'bust']);
		add_action('woocommerce_product_set_stock_status', [__CLASS__, 'bust']);
		add_action('woocommerce_variation_set_stock_status', [__CLASS__, 'bust']);
		foreach (['get', 'add'] as $a) {
			add_action("wp_ajax_qvcp_$a", [__CLASS__, "ajax_$a"]);
			add_action("wp_ajax_nopriv_qvcp_$a", [__CLASS__, "ajax_$a"]);
		}
	}

	/* ---------- Admin ---------- */
	static function menu() {
		add_submenu_page('woocommerce', 'Variation Popup', 'Variation Popup', 'manage_woocommerce', 'qvcp', [__CLASS__, 'page']);
	}

	static function page() {
		if (!current_user_can('manage_woocommerce')) return;
		$all = self::fields();
		$tab = isset($_GET['tab'], $all[$_GET['tab']]) ? sanitize_key($_GET['tab']) : 'general';

		if (isset($_POST['qvcp_save']) && check_admin_referer('qvcp_' . $tab)) {
			$new = [];
			foreach ($all[$tab]['f'] as $k => $f) {
				$v = isset($_POST[$k]) ? wp_unslash($_POST[$k]) : '';
				switch ($f[0]) {
					case 'check':  $new[$k] = $v ? 1 : 0; break;
					case 'color':  $new[$k] = sanitize_hex_color($v) ?: $f[2]; break;
					case 'number': $new[$k] = max((int) ($f[4] ?? 0), min((int) ($f[3] ?? 100), (int) $v)); break;
					case 'textarea': $new[$k] = trim(wp_strip_all_tags($v)); break;
					case 'select': $new[$k] = isset($f[3][$v]) ? $v : $f[2]; break;
					default:       $new[$k] = sanitize_text_field($v);
				}
			}
			update_option("qvcp_$tab", $new); // only this tab's option
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Saved.', 'quick-variation-cart-popup') . '</p></div>';
		}

		echo '<div class="wrap"><h1>Quick Variation Cart Popup</h1><nav class="nav-tab-wrapper">';
		foreach ($all as $id => $t) {
			printf('<a class="nav-tab %s" href="%s">%s</a>', $id === $tab ? 'nav-tab-active' : '', esc_url(admin_url("admin.php?page=qvcp&tab=$id")), esc_html($t['title']));
		}
		echo '</nav><form method="post" style="margin-top:15px">';
		wp_nonce_field('qvcp_' . $tab);
		echo '<table class="form-table">';
		foreach ($all[$tab]['f'] as $k => $f) {
			$val = self::o($tab, $k);
			echo '<tr><th><label for="' . esc_attr($k) . '">' . esc_html($f[1]) . '</label></th><td>';
			switch ($f[0]) {
				case 'check':  printf('<input type="checkbox" id="%1$s" name="%1$s" value="1" %2$s>', esc_attr($k), checked($val, 1, false)); break;
				case 'select':
					echo '<select id="' . esc_attr($k) . '" name="' . esc_attr($k) . '">';
					foreach ($f[3] as $ov => $ol) printf('<option value="%s" %s>%s</option>', esc_attr($ov), selected($val, $ov, false), esc_html($ol));
					echo '</select>'; break;
				case 'textarea':
					printf('<textarea id="%1$s" name="%1$s" rows="14" class="large-text code" spellcheck="false" placeholder=".qvcp-box{ }">%2$s</textarea><p class="description">%3$s</p>', esc_attr($k), esc_textarea($val), esc_html__('Example: .qvcp-ov .qvcp-info h3{letter-spacing:0}', 'quick-variation-cart-popup'));
					break;
				case 'number':
					printf('<input type="number" id="%1$s" name="%1$s" value="%2$s" min="%3$d" max="%4$d" step="1">', esc_attr($k), esc_attr($val), (int) ($f[4] ?? 0), (int) ($f[3] ?? 100));
					break;
				default: printf('<input type="%s" id="%2$s" name="%2$s" value="%3$s" %4$s>', $f[0] === 'text' ? 'text' : $f[0], esc_attr($k), esc_attr($val), $f[0] === 'text' ? 'class="regular-text"' : '');
			}
			echo '</td></tr>';
		}
		echo '</table><p><button class="button button-primary" name="qvcp_save" value="1">' . esc_html__('Save Changes', 'quick-variation-cart-popup') . '</button></p></form></div>';
	}

	/* ---------- Frontend ---------- */
	static $ids = [];

	static function loop_btn($html, $product) {
		if (!self::o('general', 'enable') || !$product->is_type('variable')) return $html;
		self::$ids[$product->get_id()] = 1;
		return sprintf(
			'<a href="%s" class="button qvcp-trigger" data-product_id="%d" rel="nofollow">%s</a>',
			esc_url($product->get_permalink()), $product->get_id(), esc_html(self::o('buttons', 'loop_label'))
		);
	}

	static function inline_data() {
		if (!self::$ids) return;
		$out = [];
		foreach (array_slice(array_keys(self::$ids), 0, 60) as $id) {
			$p = wc_get_product($id);
			if ($p && $p->is_type('variable') && $p->is_visible() && ($d = self::data($p))) $out[$id] = $d;
		}
		if ($out) echo '<script id="qvcp-data">window.qvcpData=' . wp_json_encode($out, JSON_HEX_TAG | JSON_HEX_AMP) . ';</script>';
	}

	static function bust($id) {
		$o = is_object($id) ? $id : wc_get_product($id);
		if (!$o) return;
		delete_transient('qvcp2_' . ($o->get_parent_id() ?: $o->get_id()));
	}

	static function assets() {
		if (!self::o('general', 'enable')) return;
		wp_enqueue_style('qvcp-font', 'https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap', [], null);
		wp_enqueue_style('qvcp', plugins_url('assets/qvcp.css', __FILE__), ['qvcp-font'], self::VER . '.' . filemtime(__DIR__ . '/assets/qvcp.css'));
		$g = fn($k) => self::o('design', $k);
		$rgba = function ($hex, $op) {
			$hex = ltrim($hex, '#');
			if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
			return sprintf('rgba(%d,%d,%d,%.2f)', hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2)), $op / 100);
		};
		$v = [
			'ov' => $rgba($g('overlay'), $g('overlay_op')), 'glass' => $rgba($g('glass'), max(10, $g('glass_op'))),
			'gb' => $rgba($g('glass_border'), 60), 'blur' => (int) $g('blur') . 'px', 'r' => (int) $g('radius') . 'px', 'br' => (int) $g('btn_radius') . 'px',
			'title' => $g('title_color'), 'cat' => $g('cat_color'), 'desc' => $g('desc_color'), 'price' => $g('price_color'), 'label' => $g('label_color'), 'meta' => $g('meta_color'), 'x' => $g('close_color'),
			'sbg' => $g('swatch_bg'), 'sc' => $g('swatch_color'), 'sb' => $g('swatch_border'), 'sh' => $g('swatch_hover'), 'sel' => $g('sel_bg'), 'selc' => $g('sel_color'),
			'qbg' => $g('qty_bg'), 'qb' => $g('qty_border'), 'qc' => $g('qty_color'),
			'btn' => $g('btn_bg'), 'btnc' => $g('btn_color'), 'btnh' => $g('btn_hover'), 'btnhc' => $g('btn_hover_c'),
			'buy' => $g('buy_bg'), 'buyc' => $g('buy_color'), 'buyh' => $g('buy_hover'), 'buyhc' => $g('buy_hover_c'),
		];
		$l = fn($k) => self::o('layout', $k);
		$v += [
			'x' => $g('close_color'), 'xc' => $g('close_text'), 'xh' => $g('close_hover'), 'dv' => $g('divider'), 'err' => $g('err_color'), 'ok' => $g('ok_color'),
			'bw' => (int) $l('box_width') . 'px', 'bh' => (int) $l('box_height') . 'vh', 'bhd' => (int) $l('box_height') . 'dvh', 'op' => (int) $l('ov_pad') . 'px',
			'lw' => (int) $l('left_width') . '%', 'lbg' => $l('left_bg'), 'lp' => (int) $l('left_pad') . 'px',
			'ibg' => $l('img_bg'), 'ib' => $l('img_border'), 'ir' => (int) $l('img_radius') . 'px', 'ih' => (int) $l('img_height') . 'px', 'ta' => $l('thumb_active'),
			'ip' => (int) $l('info_pad') . 'px', 'ts' => (int) $l('title_size') . 'px', 'ps' => (int) $l('price_size') . 'px', 'ds' => (int) $l('desc_size') . 'px',
			'ls' => (int) $l('label_size') . 'px', 'ss' => (int) $l('swatch_size') . 'px', 'bs' => (int) $l('btn_size') . 'px', 'mts' => (int) $l('mob_title') . 'px',
		];
		$vars = '';
		foreach ($v as $k => $val) $vars .= "--qv-$k:" . esc_attr($val) . ';';
		$css = ".qvcp-ov{{$vars}}";
		if (!self::o('layout', 'mob_sheet')) $css .= '@media(max-width:700px){.qvcp-ov{align-items:center;padding:12px}.qvcp-ov .qvcp-box{border-radius:var(--qv-r)}}';
		$custom = trim((string) self::o('advanced', 'custom_css'));
		if ($custom !== '') $css .= "\n" . wp_strip_all_tags($custom);
		wp_add_inline_style('qvcp', $css);
		wp_enqueue_script('qvcp', plugins_url('assets/qvcp.js', __FILE__), ['jquery'], self::VER . '.' . filemtime(__DIR__ . '/assets/qvcp.js'), true);
		wp_localize_script('qvcp', 'qvcp', [
			'ajax' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('qvcp'),
			'checkout' => wc_get_checkout_url(), 'cart' => wc_get_cart_url(),
			'after' => self::o('general', 'after_add'), 'style' => self::o('variations', 'style'),
			'preview' => (int) self::o('variations', 'image_preview'),
			'buy' => (int) self::o('general', 'show_buy_now'), 'sku' => (int) self::o('general', 'show_sku'), 'stock' => (int) self::o('general', 'show_stock'),
			'i' => [
				'add' => self::o('buttons', 'add_label'), 'buynow' => self::o('buttons', 'buy_label'),
				'loading' => __('Loading...', 'quick-variation-cart-popup'),
				'choose' => __('Please select all options.', 'quick-variation-cart-popup'),
				'na' => __('Sorry, this combination is unavailable.', 'quick-variation-cart-popup'),
				'select' => __('Choose', 'quick-variation-cart-popup'), 'sku' => __('SKU', 'quick-variation-cart-popup'),
				'err' => __('Something went wrong.', 'quick-variation-cart-popup'), 'added' => __('Added to cart', 'quick-variation-cart-popup'), 'category' => __('Category', 'quick-variation-cart-popup'),
			],
		]);
	}

	static function ajax_get() {
		check_ajax_referer('qvcp', 'nonce');
		$p = wc_get_product(absint($_POST['product_id'] ?? 0));
		if (!$p || !$p->is_type('variable') || !$p->is_visible()) wp_send_json_error();
		wp_send_json_success(self::data($p));
	}

	static function img($u) {
		if (!$u || !is_string($u)) return $u;
		$d = wp_upload_dir();
		if (strpos($u, $d['baseurl']) !== 0) return $u;
		$ex = fn($url) => file_exists($d['basedir'] . substr(strtok($url, '?'), strlen($d['baseurl'])));
		if ($ex($u)) return $u;
		$b = preg_replace('/\.(jpe?g|png|gif|webp)$/i', '', $u);
		foreach ([$b . '.avif', $u . '.avif', $b . '.webp', $u . '.webp'] as $c) if ($ex($c)) return $c;
		return $u;
	}

	static function data($p) {
		$ck = 'qvcp2_' . $p->get_id();
		if (($hit = get_transient($ck)) !== false) return $hit;
		$attrs = [];
		foreach ($p->get_variation_attributes() as $name => $opts) {
			$opt = [];
			foreach ($opts as $v) {
				$label = $v;
				if (taxonomy_exists($name) && ($t = get_term_by('slug', $v, $name))) $label = $t->name;
				$opt[] = ['v' => $v, 'l' => $label];
			}
			$attrs[] = ['key' => 'attribute_' . sanitize_title($name), 'label' => wc_attribute_label($name, $p), 'opts' => $opt];
		}
		$vars = [];
		foreach ($p->get_available_variations() as $v) {
			$vars[] = [
				'id' => $v['variation_id'], 'attrs' => $v['attributes'], 'price' => $v['price_html'],
				'img' => self::img($v['image']['src'] ?? ''), 'sku' => $v['sku'], 'stock' => $v['availability_html'],
				'min' => $v['min_qty'], 'max' => $v['max_qty'] === '' ? '' : $v['max_qty'], 'ok' => $v['is_purchasable'] && $v['is_in_stock'],
			];
		}
		$cat = ''; $cat_url = '';
		$terms = get_the_terms($p->get_id(), 'product_cat');
		if ($terms && !is_wp_error($terms)) {
			foreach ($terms as $t) if ($t->slug !== 'uncategorized') { $cat = $t->name; $cat_url = get_term_link($t); break; }
		}
		$desc = wp_trim_words(html_entity_decode(wp_strip_all_tags($p->get_short_description() ?: $p->get_description()), ENT_QUOTES, 'UTF-8'), 60);
		$gallery = [];
		foreach (array_merge([$p->get_image_id()], $p->get_gallery_image_ids()) as $gid) {
			if (!$gid) continue;
			$f = wp_get_attachment_image_url($gid, 'woocommerce_single');
			if ($f) $gallery[] = ['t' => self::img(wp_get_attachment_image_url($gid, 'thumbnail') ?: $f), 'f' => self::img($f)];
		}
		$out = [
			'cat' => $cat, 'cat_url' => is_string($cat_url) ? $cat_url : '', 'desc' => $desc, 'gallery' => $gallery,
			'id' => $p->get_id(), 'title' => $p->get_name(), 'price' => $p->get_price_html(),
			'image' => self::img(wp_get_attachment_image_url($p->get_image_id(), 'woocommerce_single') ?: wc_placeholder_img_src()),
			'attrs' => $attrs, 'vars' => $vars, 'defaults' => $p->get_default_attributes() ? array_combine(
				array_map(fn($k) => 'attribute_' . sanitize_title($k), array_keys($p->get_default_attributes())), array_values($p->get_default_attributes())
			) : new stdClass(),
		];
		set_transient($ck, $out, 6 * HOUR_IN_SECONDS);
		return $out;
	}

	static function ajax_add() {
		check_ajax_referer('qvcp', 'nonce');
		$pid = absint($_POST['product_id'] ?? 0);
		$vid = absint($_POST['variation_id'] ?? 0);
		$qty = max(1, (int) ($_POST['quantity'] ?? 1));
		$attrs = isset($_POST['attrs']) && is_array($_POST['attrs']) ? array_map('wc_clean', wp_unslash($_POST['attrs'])) : [];
		$var = [];
		foreach ($attrs as $k => $v) if (strpos($k, 'attribute_') === 0) $var[sanitize_title($k)] = $v;
		if (!$pid || !$vid || !WC()->cart->add_to_cart($pid, $qty, $vid, $var)) {
			wp_send_json_error(['msg' => wc_print_notices(true) ?: __('Could not add to cart.', 'quick-variation-cart-popup')]);
		}
		wc_clear_notices();
		ob_start();
		woocommerce_mini_cart();
		$frag = apply_filters('woocommerce_add_to_cart_fragments', ['div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . ob_get_clean() . '</div>']);
		wp_send_json_success(['fragments' => $frag, 'cart_hash' => WC()->cart->get_cart_hash()]);
	}
}
QVCP::init();
