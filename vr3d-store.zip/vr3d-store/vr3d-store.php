<?php
/**
 * Plugin Name: 3D Virtual Store for WooCommerce
 * Description: Immersive 3D walk-through store. Put the shortcode [vr3d_store] anywhere. Full control from the "3D Store" admin menu.
 * Version: 1.0.0
 * Author: Your Name
 * Requires Plugins: woocommerce
 * Text Domain: vr3d-store
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'VR3D_VER', '1.0.5' );
define( 'VR3D_DIR', plugin_dir_path( __FILE__ ) );
define( 'VR3D_URL', plugin_dir_url( __FILE__ ) );

/* ---------- Options ---------- */
function vr3d_default_sections() {
	$def = array(
		array( 'Dehydrated Fruits', 'shelf', array( array( '100% Natural', 'No added sugar', '#2f5d3a' ), array( 'Sun Dried', 'Pure fruit', '#d9942b' ) ) ),
		array( 'Organic Pantry', 'shelf', array( array( 'Farm Fresh', 'Grown with care', '#7a9a3a' ), array( 'Organic', 'Certified clean', '#8a4b2a' ) ) ),
		array( 'Oils & Honey', 'table', array( array( 'Cold Pressed', 'Pure & raw', '#c58a1e' ), array( 'Raw Honey', 'Straight from the hive', '#5b3a1e' ) ) ),
		array( 'Healthy Snacks', 'table', array( array( 'Crunch Time', 'Guilt free', '#a8472b' ), array( 'Eat Clean', 'Live well', '#2f5d3a' ) ) ),
	);
	$out = array();
	foreach ( $def as $d ) {
		$posters = array();
		foreach ( $d[2] as $pp ) { $posters[] = array( 'text' => $pp[0], 'sub' => $pp[1], 'color' => $pp[2], 'image_id' => 0 ); }
		$out[] = array( 'title' => $d[0], 'layout' => $d[1], 'source' => 'latest', 'category' => 0, 'product_ids' => array(), 'limit' => 24, 'per_page' => 0, 'posters' => $posters );
	}
	return $out;
}

function vr3d_defaults() {
	return array(
		'brand_text'    => 'ORGANIC STORE',
		'subtitle'      => 'ORGANIC & DEHYDRATED FOODS',
		'logo_id'       => 0,
		'height'        => '85vh',
		'wall_color'    => '#eadfc8',
		'floor_color'   => '#ffffff',
		'ceiling_color' => '#f4ecdc',
		'accent_color'  => '#2f5d3a',
		'success_color' => '#5a8f2a',
		'remove_bg'     => 1,
		'fullscreen'    => 1,
		'autorotate'    => 1,
		'show_cart'     => 1,
		'cart_action'   => 'popup',
		'cart_selector' => '',
		'txt_add'       => 'Add to Cart',
		'txt_added'     => 'Added to cart ✓',
		'txt_view_cart' => 'View cart →',
		'txt_select'    => 'Select',
		'txt_oos'       => 'Out of stock',
		'txt_view'      => 'View product page',
		'three_url'     => '',
		'shoppers'      => 2,
		'shopper1_id'   => 0,
		'shopper2_id'   => 0,
		'highlights'    => "Fresh packed\nPure & natural\nFast delivery",
		'sections'      => vr3d_default_sections(),
	);
}

function vr3d_opts() {
	$saved = get_option( 'vr3d_options', array() );
	$o     = wp_parse_args( is_array( $saved ) ? $saved : array(), vr3d_defaults() );
	if ( empty( $o['sections'] ) || ! is_array( $o['sections'] ) ) { $o['sections'] = array(); }
	foreach ( $o['sections'] as $k => $sec ) {
		$ly = isset( $sec['layout'] ) ? $sec['layout'] : 'shelf';
		$o['sections'][ $k ]['layout'] = ( 'table' === $ly || 'rail' === $ly ) ? 'table' : 'shelf';
	}
	return $o;
}

function vr3d_sanitize( $in ) {
	if ( ! empty( $in['reset'] ) ) { return vr3d_defaults(); }
	$d   = vr3d_defaults();
	$out = array();
	$txt = array( 'brand_text', 'subtitle', 'txt_add', 'txt_added', 'txt_view_cart', 'txt_select', 'txt_oos', 'txt_view' );
	foreach ( $txt as $k ) { $out[ $k ] = isset( $in[ $k ] ) ? sanitize_text_field( $in[ $k ] ) : $d[ $k ]; }
	foreach ( array( 'wall_color', 'floor_color', 'ceiling_color', 'accent_color', 'success_color' ) as $k ) {
		$c = isset( $in[ $k ] ) ? sanitize_hex_color( $in[ $k ] ) : '';
		$out[ $k ] = $c ? $c : $d[ $k ];
	}
	foreach ( array( 'remove_bg', 'fullscreen', 'autorotate', 'show_cart' ) as $k ) { $out[ $k ] = ! empty( $in[ $k ] ) ? 1 : 0; }
	$out['logo_id'] = isset( $in['logo_id'] ) ? absint( $in['logo_id'] ) : 0;
	$h = isset( $in['height'] ) ? trim( $in['height'] ) : '';
	$out['height'] = preg_match( '/^\d+(\.\d+)?(px|vh|%|rem|em)$/', $h ) ? $h : '85vh';
	$ca = isset( $in['cart_action'] ) ? $in['cart_action'] : 'popup';
	$out['cart_action']   = in_array( $ca, array( 'popup', 'cart', 'checkout', 'stay' ), true ) ? $ca : 'popup';
	$out['cart_selector'] = isset( $in['cart_selector'] ) ? sanitize_text_field( $in['cart_selector'] ) : '';
	$out['three_url']     = isset( $in['three_url'] ) ? esc_url_raw( $in['three_url'] ) : '';
	$out['shoppers']        = isset( $in['shoppers'] ) ? min( 2, absint( $in['shoppers'] ) ) : 2;
	$out['shopper1_id']     = isset( $in['shopper1_id'] ) ? absint( $in['shopper1_id'] ) : 0;
	$out['shopper2_id']     = isset( $in['shopper2_id'] ) ? absint( $in['shopper2_id'] ) : 0;
	$out['highlights']      = isset( $in['highlights'] ) ? sanitize_textarea_field( $in['highlights'] ) : '';

	$out['sections'] = array();
	if ( ! empty( $in['sections'] ) && is_array( $in['sections'] ) ) {
		foreach ( $in['sections'] as $s ) {
			if ( ! is_array( $s ) ) { continue; }
			$posters = array();
			for ( $i = 0; $i < 4; $i++ ) {
				$p = isset( $s['posters'][ $i ] ) && is_array( $s['posters'][ $i ] ) ? $s['posters'][ $i ] : array();
				$c = isset( $p['color'] ) ? sanitize_hex_color( $p['color'] ) : '';
				$posters[] = array(
					'text'     => isset( $p['text'] ) ? sanitize_text_field( $p['text'] ) : '',
					'sub'      => isset( $p['sub'] ) ? sanitize_text_field( $p['sub'] ) : '',
					'color'    => $c ? $c : '#222222',
					'image_id' => isset( $p['image_id'] ) ? absint( $p['image_id'] ) : 0,
				);
			}
			$out['sections'][] = array(
				'title'       => isset( $s['title'] ) ? sanitize_text_field( $s['title'] ) : 'Section',
				'layout'      => ( isset( $s['layout'] ) && in_array( $s['layout'], array( 'table', 'rail' ), true ) ) ? 'table' : 'shelf',
				'source'      => ( isset( $s['source'] ) && in_array( $s['source'], array( 'latest', 'category', 'products' ), true ) ) ? $s['source'] : 'latest',
				'category'    => isset( $s['category'] ) ? absint( $s['category'] ) : 0,
				'product_ids' => isset( $s['product_ids'] ) && is_array( $s['product_ids'] ) ? array_values( array_filter( array_map( 'absint', $s['product_ids'] ) ) ) : array(),
				'limit'       => isset( $s['limit'] ) ? min( 60, max( 1, absint( $s['limit'] ) ) ) : 24,
				'per_page'    => isset( $s['per_page'] ) ? min( 20, absint( $s['per_page'] ) ) : 0,
				'posters'     => $posters,
			);
		}
	}
	return $out;
}

/* ---------- Helpers ---------- */
function vr3d_facts( $p ) {
	$f = array();
	foreach ( $p->get_attributes() as $a ) {
		if ( is_object( $a ) && $a->get_visible() && ! $a->get_variation() ) {
			$v = $p->get_attribute( $a->get_name() );
			if ( $v ) { $f[] = array( wc_attribute_label( $a->get_name() ), $v ); }
		}
		if ( count( $f ) >= 4 ) { break; }
	}
	if ( $p->get_weight() ) { $f[] = array( 'Weight', $p->get_weight() . ' ' . get_option( 'woocommerce_weight_unit' ) ); }
	return $f;
}

// remove leftovers of the old AI assistant (API key etc.)
add_action( 'admin_init', function () {
	$o = get_option( 'vr3d_options' );
	if ( is_array( $o ) && ( isset( $o['gemini_key'] ) || isset( $o['extra_knowledge'] ) ) ) {
		foreach ( array( 'gemini_key', 'gemini_model', 'extra_knowledge', 'chat_enable', 'assistant_show', 'assistant_name', 'greeting', 'welcome_msg' ) as $k ) { unset( $o[ $k ] ); }
		update_option( 'vr3d_options', $o );
		delete_transient( 'vr3d_kb' );
	}
} );

/* ---------- Product data ---------- */
function vr3d_product_data( $product, $cat_label = '' ) {
	$img_id = $product->get_image_id();
	$main   = $img_id ? wp_get_attachment_image_url( $img_id, 'large' ) : wc_placeholder_img_src( 'large' );
	$images = array( $main );
	foreach ( array_slice( $product->get_gallery_image_ids(), 0, 4 ) as $gid ) {
		$u = wp_get_attachment_image_url( $gid, 'large' );
		if ( $u ) { $images[] = $u; }
	}
	$d = array(
		'id'       => $product->get_id(),
		'name'     => $product->get_name(),
		'link'     => get_permalink( $product->get_id() ),
		'price'    => $product->get_price_html(),
		'price_t'  => trim( html_entity_decode( wp_strip_all_tags( $product->get_price_html() ) ) ),
		'img'      => $main,
		'images'   => $images,
		'type'     => $product->get_type(),
		'in_stock' => $product->is_in_stock(),
		'attrs'    => array(),
		'vars'     => array(),
		'cat'      => '',
		'png'      => '',
		'short'    => wp_html_excerpt( trim( wp_strip_all_tags( do_shortcode( $product->get_short_description() ? $product->get_short_description() : $product->get_description() ) ) ), 260, '…' ),
		'rating'   => (float) $product->get_average_rating(),
		'rcount'   => (int) $product->get_review_count(),
		'save'     => 0,
		'facts'    => function_exists( 'vr3d_facts' ) ? vr3d_facts( $product ) : array(),
	);
	$cn = wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'names' ) );
	if ( ! is_wp_error( $cn ) && $cn ) { $d['cat'] = $cn[0]; }
	$png = (int) get_post_meta( $product->get_id(), '_vr3d_png_id', true );
	if ( $png ) { $u = wp_get_attachment_image_url( $png, 'large' ); if ( $u ) { $d['png'] = $u; } }
	if ( $product->is_type( 'simple' ) && $product->is_on_sale() && (float) $product->get_regular_price() > 0 ) {
		$d['save'] = (int) round( ( (float) $product->get_regular_price() - (float) $product->get_sale_price() ) / (float) $product->get_regular_price() * 100 );
	}
	if ( $product->is_type( 'variable' ) ) {
		foreach ( $product->get_variation_attributes() as $name => $opts ) {
			$options = array();
			foreach ( $opts as $o ) {
				$label = $o;
				if ( taxonomy_exists( $name ) ) {
					$t = get_term_by( 'slug', $o, $name );
					if ( $t ) { $label = $t->name; }
				}
				$options[] = array( 'v' => $o, 'l' => $label );
			}
			$d['attrs'][] = array( 'key' => 'attribute_' . sanitize_title( $name ), 'label' => wc_attribute_label( $name, $product ), 'options' => $options );
		}
		foreach ( $product->get_children() as $vid ) {
			$v = wc_get_product( $vid );
			if ( ! $v || ! $v->exists() || ! $v->variation_is_visible() ) { continue; }
			$d['vars'][] = array( 'id' => $vid, 'a' => $v->get_variation_attributes(), 's' => ( $v->is_purchasable() && $v->is_in_stock() ), 'p' => $v->get_price_html() );
		}
	}
	return $d;
}

function vr3d_section_products( $s ) {
	$list = array();
	if ( 'products' === $s['source'] ) {
		foreach ( $s['product_ids'] as $id ) {
			$p = wc_get_product( $id );
			if ( $p && 'publish' === $p->get_status() ) { $list[] = $p; }
		}
	} else {
		$args = array( 'status' => 'publish', 'limit' => (int) $s['limit'], 'orderby' => 'date', 'order' => 'DESC', 'return' => 'objects' );
		if ( 'category' === $s['source'] && $s['category'] ) {
			$t = get_term( $s['category'], 'product_cat' );
			if ( $t && ! is_wp_error( $t ) ) { $args['category'] = array( $t->slug ); }
		}
		$list = wc_get_products( $args );
	}
	$out = array();
	foreach ( $list as $p ) {
		if ( ! $p->get_image_id() && ! get_post_meta( $p->get_id(), '_vr3d_png_id', true ) ) { continue; }
		$out[] = vr3d_product_data( $p, $s['title'] );
		if ( count( $out ) >= 60 ) { break; }
	}
	return $out;
}

/* ---------- Assets + shortcode ---------- */
add_action( 'wp_enqueue_scripts', function () {
	$o     = vr3d_opts();
	$three = $o['three_url'] ? $o['three_url'] : 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
	wp_register_script( 'vr3d-three', $three, array(), 'r128', true );
	wp_register_script( 'vr3d-store', VR3D_URL . 'assets/js/store.js', array( 'jquery', 'vr3d-three' ), VR3D_VER, true );
	wp_register_style( 'vr3d-store', VR3D_URL . 'assets/css/store.css', array(), VR3D_VER );
} );

add_shortcode( 'vr3d_store', function ( $atts ) {
	if ( ! class_exists( 'WooCommerce' ) ) {
		return current_user_can( 'manage_options' ) ? '<p>3D Store: WooCommerce is required.</p>' : '';
	}
	$o = vr3d_opts();
	$a = shortcode_atts( array( 'height' => $o['height'] ), $atts, 'vr3d_store' );
	$h = preg_match( '/^\d+(\.\d+)?(px|vh|%|rem|em)$/', $a['height'] ) ? $a['height'] : '85vh';

	$sections = array();
	foreach ( $o['sections'] as $s ) {
		$prods = vr3d_section_products( $s );
		if ( ! $prods ) { continue; }
		$posters = array();
		foreach ( $s['posters'] as $p ) {
			$posters[] = array( 'text' => $p['text'], 'sub' => $p['sub'], 'color' => $p['color'], 'image' => $p['image_id'] ? wp_get_attachment_image_url( $p['image_id'], 'large' ) : '' );
		}
		$sections[] = array( 'title' => $s['title'], 'layout' => $s['layout'], 'per_page' => (int) $s['per_page'], 'posters' => $posters, 'products' => $prods );
	}

	$data = array(
		'sections'  => $sections,
		'opts'      => array(
			'brand'      => $o['brand_text'],
			'subtitle'   => $o['subtitle'],
			'logo'       => $o['logo_id'] ? wp_get_attachment_image_url( $o['logo_id'], 'large' ) : '',
			'wall'       => $o['wall_color'],
			'floor'      => $o['floor_color'],
			'ceiling'    => $o['ceiling_color'],
			'accent'     => $o['accent_color'],
			'success'    => $o['success_color'],
			'remove_bg'  => (int) $o['remove_bg'],
			'fullscreen' => (int) $o['fullscreen'],
			'autorotate' => (int) $o['autorotate'],
			'show_cart'  => (int) $o['show_cart'],
			'cart_action'   => $o['cart_action'],
			'cart_selector' => $o['cart_selector'],
			'shoppers'   => (int) $o['shoppers'],
			'shopper_imgs' => array( $o['shopper1_id'] ? wp_get_attachment_image_url( $o['shopper1_id'], 'large' ) : '', $o['shopper2_id'] ? wp_get_attachment_image_url( $o['shopper2_id'], 'large' ) : '' ),
			'highlights' => array_values( array_filter( array_map( 'trim', explode( "\n", $o['highlights'] ) ) ) ),
		),
		't'         => array(
			'add' => $o['txt_add'], 'added' => $o['txt_added'], 'view_cart' => $o['txt_view_cart'], 'select' => $o['txt_select'],
			'oos' => $o['txt_oos'], 'view' => $o['txt_view'], 'store' => 'Store', 'close' => 'Close', 'adding' => '…',
			'help' => 'Drag to look around · Click a wall to enter a section · Click a product to see details',
			'error' => 'Could not add to cart', 'buy' => 'Buy now', 'instock' => 'In stock', 'outstock' => 'Out of stock',
		),
		'ajax_add'  => WC_AJAX::get_endpoint( 'vr3d_add_to_cart' ),
		'cart_url'  => wc_get_cart_url(),
		'checkout'  => wc_get_checkout_url(),
		'cart_count' => ( function_exists( 'WC' ) && WC()->cart ) ? WC()->cart->get_cart_contents_count() : 0,
	);

	wp_enqueue_style( 'vr3d-store' );
	wp_enqueue_script( 'wc-cart-fragments' );
	wp_enqueue_script( 'vr3d-store' );
	wp_localize_script( 'vr3d-store', 'VR3D', $data );

	if ( ! $sections ) {
		return current_user_can( 'manage_options' ) ? '<p>3D Store: no products found. Add products in the "3D Store" settings.</p>' : '';
	}
	return '<script>document.documentElement.classList.add("vr3d-page");(document.body||document.documentElement).classList.add("vr3d-page");</script><div id="vr3d-root" class="vr3d-wrap" style="height:' . esc_attr( $h ) . ';--vr3d-accent:' . esc_attr( $o['accent_color'] ) . ';--vr3d-ok:' . esc_attr( $o['success_color'] ) . '"></div>';
} );

/* ---------- Add to cart (wc-ajax) ---------- */
add_action( 'wc_ajax_vr3d_add_to_cart', function () {
	$pid     = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$qty     = isset( $_POST['quantity'] ) ? max( 1, absint( $_POST['quantity'] ) ) : 1; // phpcs:ignore
	$product = $pid ? wc_get_product( $pid ) : false;
	if ( ! $product ) { wp_send_json( array( 'error' => true, 'message' => 'Invalid product' ) ); }
	$vid = 0; $var = array();
	if ( $product->is_type( 'variable' ) ) {
		$var = ( isset( $_POST['variation'] ) && is_array( $_POST['variation'] ) ) ? array_map( 'wc_clean', wp_unslash( $_POST['variation'] ) ) : array(); // phpcs:ignore
		$vid = WC_Data_Store::load( 'product' )->find_matching_product_variation( $product, $var );
		if ( ! $vid ) { wp_send_json( array( 'error' => true, 'message' => 'Please choose product options' ) ); }
	}
	$ok = WC()->cart->add_to_cart( $pid, $qty, $vid, $var );
	if ( ! $ok ) {
		$m = '';
		foreach ( wc_get_notices( 'error' ) as $n ) { $m .= wp_strip_all_tags( is_array( $n ) ? $n['notice'] : $n ) . ' '; }
		wc_clear_notices();
		wp_send_json( array( 'error' => true, 'message' => trim( $m ) ) );
	}
	do_action( 'woocommerce_ajax_added_to_cart', $pid );
	wc_clear_notices();
	ob_start();
	woocommerce_mini_cart();
	$mini = ob_get_clean();
	$fragments = apply_filters( 'woocommerce_add_to_cart_fragments', array( 'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini . '</div>' ) );
	wp_send_json( array( 'error' => false, 'fragments' => $fragments, 'cart_hash' => WC()->cart->get_cart_hash(), 'count' => WC()->cart->get_cart_contents_count() ) );
} );

if ( is_admin() ) { require_once VR3D_DIR . 'includes/admin.php'; }
