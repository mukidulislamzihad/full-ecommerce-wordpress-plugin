<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'admin_menu', function () {
	add_menu_page( '3D Store', '3D Store', 'manage_options', 'vr3d-store', 'vr3d_admin_page', 'dashicons-store', 56 );
} );

add_action( 'admin_init', function () {
	register_setting( 'vr3d_group', 'vr3d_options', array( 'sanitize_callback' => 'vr3d_sanitize' ) );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'toplevel_page_vr3d-store' !== $hook ) { return; }
	wp_enqueue_media();
	wp_enqueue_script( 'jquery-ui-sortable' );
	wp_enqueue_style( 'vr3d-admin', VR3D_URL . 'assets/css/admin.css', array(), VR3D_VER );
	wp_enqueue_script( 'vr3d-admin', VR3D_URL . 'assets/js/admin.js', array( 'jquery', 'jquery-ui-sortable' ), VR3D_VER, true );
	wp_localize_script( 'vr3d-admin', 'VR3DA', array( 'ajax' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'vr3d_admin' ) ) );
} );

add_action( 'wp_ajax_vr3d_search_products', function () {
	check_ajax_referer( 'vr3d_admin', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) || ! class_exists( 'WooCommerce' ) ) { wp_send_json( array() ); }
	$q  = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
	$ps = wc_get_products( array( 'status' => 'publish', 's' => $q, 'limit' => 20, 'return' => 'objects' ) );
	$r  = array();
	foreach ( $ps as $p ) {
		$r[] = array( 'id' => $p->get_id(), 'title' => $p->get_name(), 'thumb' => $p->get_image_id() ? wp_get_attachment_image_url( $p->get_image_id(), 'thumbnail' ) : wc_placeholder_img_src( 'thumbnail' ) );
	}
	wp_send_json( $r );
} );

function vr3d_media_field( $name, $id, $label ) {
	$url = $id ? wp_get_attachment_image_url( $id, 'thumbnail' ) : '';
	echo '<div class="vr3d-media"><span class="vr3d-media-prev">' . ( $url ? '<img src="' . esc_url( $url ) . '">' : '' ) . '</span>';
	echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $id ) . '">';
	echo '<button type="button" class="button vr3d-pick">' . esc_html( $label ) . '</button> <a href="#" class="vr3d-unpick">Remove</a></div>';
}

function vr3d_section_row( $i, $s ) {
	$n    = 'vr3d_options[sections][' . $i . ']';
	$cats = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
	?>
	<div class="vr3d-sec">
		<div class="vr3d-sec-head">
			<span class="dashicons dashicons-menu vr3d-handle" title="Drag to reorder"></span>
			<strong class="vr3d-sec-title"><?php echo esc_html( $s['title'] ); ?></strong>
			<span class="vr3d-sec-actions"><a href="#" class="vr3d-toggle">Edit</a> | <a href="#" class="vr3d-remove">Delete</a></span>
		</div>
		<div class="vr3d-sec-body" style="display:none">
			<table class="form-table">
				<tr><th>Section name</th><td><input type="text" class="vr3d-title-in" name="<?php echo esc_attr( $n ); ?>[title]" value="<?php echo esc_attr( $s['title'] ); ?>"></td></tr>
				<tr><th>Display style</th><td>
					<select name="<?php echo esc_attr( $n ); ?>[layout]">
						<option value="shelf" <?php selected( $s['layout'], 'shelf' ); ?>>Wooden shelf unit (jars, pouches, boxes)</option>
						<option value="table" <?php selected( $s['layout'], 'table' ); ?>>Rustic display table (oils, honey, snacks)</option>
					</select></td></tr>
				<tr><th>Products from</th><td>
					<select class="vr3d-source" name="<?php echo esc_attr( $n ); ?>[source]">
						<option value="latest" <?php selected( $s['source'], 'latest' ); ?>>Latest products</option>
						<option value="category" <?php selected( $s['source'], 'category' ); ?>>A product category</option>
						<option value="products" <?php selected( $s['source'], 'products' ); ?>>Hand-picked products</option>
					</select>
					<span class="vr3d-src vr3d-src-category">
						<select name="<?php echo esc_attr( $n ); ?>[category]">
							<option value="0">— choose category —</option>
							<?php
							if ( ! is_wp_error( $cats ) ) {
								foreach ( $cats as $c ) {
									echo '<option value="' . (int) $c->term_id . '"' . selected( (int) $s['category'], (int) $c->term_id, false ) . '>' . esc_html( $c->name ) . '</option>';
								}
							}
							?>
						</select>
					</span>
					<span class="vr3d-src vr3d-src-latest vr3d-src-category">Max products: <input type="number" min="1" max="60" style="width:70px" name="<?php echo esc_attr( $n ); ?>[limit]" value="<?php echo (int) $s['limit']; ?>"></span>
				</td></tr>
				<tr class="vr3d-src vr3d-src-products"><th>Hand-picked</th><td>
					<input type="text" class="vr3d-psearch regular-text" placeholder="Type product name to search…" autocomplete="off">
					<ul class="vr3d-results"></ul>
					<ul class="vr3d-chips">
						<?php
						foreach ( $s['product_ids'] as $pid ) {
							$p = wc_get_product( $pid );
							if ( ! $p ) { continue; }
							$th = $p->get_image_id() ? wp_get_attachment_image_url( $p->get_image_id(), 'thumbnail' ) : wc_placeholder_img_src( 'thumbnail' );
							echo '<li data-id="' . (int) $pid . '"><img src="' . esc_url( $th ) . '"><span>' . esc_html( $p->get_name() ) . '</span><input type="hidden" name="' . esc_attr( $n ) . '[product_ids][]" value="' . (int) $pid . '"><a href="#" class="vr3d-x">×</a></li>';
						}
						?>
					</ul>
					<p class="description">Drag to change the order.</p>
				</td></tr>
				<tr><th>Items per page</th><td><input type="number" min="0" max="20" style="width:70px" name="<?php echo esc_attr( $n ); ?>[per_page]" value="<?php echo (int) $s['per_page']; ?>"> <span class="description">0 = automatic (about 15 on a shelf, 10 on a table)</span></td></tr>
				<?php for ( $k = 0; $k < 4; $k++ ) {
					$p = isset( $s['posters'][ $k ] ) ? $s['posters'][ $k ] : array( 'text' => '', 'sub' => '', 'color' => '#222222', 'image_id' => 0 );
					?>
				<tr><th>Poster <?php echo array( 'left', 'right', 'left (top)', 'right (top)' )[ $k ]; ?></th><td>
					<input type="text" placeholder="Big text" name="<?php echo esc_attr( $n ); ?>[posters][<?php echo (int) $k; ?>][text]" value="<?php echo esc_attr( $p['text'] ); ?>">
					<input type="text" placeholder="Small text" name="<?php echo esc_attr( $n ); ?>[posters][<?php echo (int) $k; ?>][sub]" value="<?php echo esc_attr( $p['sub'] ); ?>">
					<input type="color" name="<?php echo esc_attr( $n ); ?>[posters][<?php echo (int) $k; ?>][color]" value="<?php echo esc_attr( $p['color'] ); ?>">
					<?php vr3d_media_field( $n . '[posters][' . $k . '][image_id]', (int) $p['image_id'], 'Poster image' ); ?>
				</td></tr>
				<?php } ?>
			</table>
		</div>
	</div>
	<?php
}

function vr3d_admin_page() {
	$o     = vr3d_opts();
	$f     = 'vr3d_options';
	$field = function ( $key, $type = 'text', $attrs = '' ) use ( $o, $f ) {
		echo '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $f ) . '[' . esc_attr( $key ) . ']" value="' . esc_attr( $o[ $key ] ) . '" ' . $attrs . '>'; // phpcs:ignore
	};
	$check = function ( $key, $label ) use ( $o, $f ) {
		echo '<label><input type="checkbox" name="' . esc_attr( $f ) . '[' . esc_attr( $key ) . ']" value="1" ' . checked( ! empty( $o[ $key ] ), true, false ) . '> ' . esc_html( $label ) . '</label><br>'; // phpcs:ignore
	};
	?>
	<div class="wrap vr3d-admin">
		<h1>3D Virtual Store</h1>
		<?php
		if ( ! class_exists( 'WooCommerce' ) ) {
			echo '<div class="notice notice-error"><p>WooCommerce must be active.</p></div>';
		}
		?>
		<p>Shortcode: <code>[vr3d_store]</code> &nbsp; (optional height: <code>[vr3d_store height="90vh"]</code>)</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'vr3d_group' ); ?>
			<h2 class="nav-tab-wrapper vr3d-tabs">
				<a href="#vr3d-t-sections" class="nav-tab nav-tab-active">Sections &amp; Products</a>
				<a href="#vr3d-t-brand" class="nav-tab">Brand &amp; Colors</a>
				<a href="#vr3d-t-cart" class="nav-tab">Cart &amp; Texts</a>
				<a href="#vr3d-t-ai" class="nav-tab">Shoppers &amp; Popup</a>
				<a href="#vr3d-t-adv" class="nav-tab">Advanced</a>
			</h2>

			<div class="vr3d-tab" id="vr3d-t-sections">
				<p class="description">Each section becomes one wall of the 3D store. Add, delete or drag to reorder.</p>
				<div id="vr3d-secs">
					<?php
					foreach ( $o['sections'] as $i => $s ) { vr3d_section_row( 'i' . $i, $s ); }
					?>
				</div>
				<p><button type="button" class="button button-secondary" id="vr3d-add-sec">+ Add section</button></p>
				<script type="text/template" id="vr3d-sec-tpl">
					<?php
					vr3d_section_row( '__i__', array(
						'title' => 'New section', 'layout' => 'shelf', 'source' => 'latest', 'category' => 0, 'product_ids' => array(), 'limit' => 24, 'per_page' => 0,
						'posters' => array( array( 'text' => '', 'sub' => '', 'color' => '#222222', 'image_id' => 0 ), array( 'text' => '', 'sub' => '', 'color' => '#c8f03c', 'image_id' => 0 ) ),
					) );
					?>
				</script>
			</div>

			<div class="vr3d-tab" id="vr3d-t-brand" style="display:none">
				<table class="form-table">
					<tr><th>Brand text</th><td><?php $field( 'brand_text' ); ?></td></tr>
					<tr><th>Sub title</th><td><?php $field( 'subtitle' ); ?></td></tr>
					<tr><th>Brand logo (optional)</th><td><?php vr3d_media_field( $f . '[logo_id]', (int) $o['logo_id'], 'Choose logo' ); ?><p class="description">Transparent PNG works best. Replaces the brand text.</p></td></tr>
					<tr><th>Wall color</th><td><?php $field( 'wall_color', 'color' ); ?></td></tr>
					<tr><th>Floor tint</th><td><?php $field( 'floor_color', 'color' ); ?></td></tr>
					<tr><th>Ceiling color</th><td><?php $field( 'ceiling_color', 'color' ); ?></td></tr>
					<tr><th>Button color</th><td><?php $field( 'accent_color', 'color' ); ?></td></tr>
					<tr><th>"Added" color</th><td><?php $field( 'success_color', 'color' ); ?></td></tr>
					<tr><th>Store height</th><td><?php $field( 'height', 'text', 'style="width:90px"' ); ?> <span class="description">e.g. 85vh, 700px</span></td></tr>
					<tr><th>Options</th><td>
						<?php $check( 'remove_bg', 'Remove white background from product images (best for white-background photos)' ); ?>
						<?php $check( 'autorotate', 'Slowly rotate the store when idle' ); ?>
						<?php $check( 'fullscreen', 'Show fullscreen button' ); ?>
						<?php $check( 'show_cart', 'Show cart icon' ); ?>
					</td></tr>
				</table>
			</div>

			<div class="vr3d-tab" id="vr3d-t-cart" style="display:none">
				<table class="form-table">
					<tr><th>After "Add to Cart"</th><td>
						<select name="vr3d_options[cart_action]">
							<option value="popup" <?php selected( $o['cart_action'], 'popup' ); ?>>Open cart popup (your cart plugin)</option>
							<option value="cart" <?php selected( $o['cart_action'], 'cart' ); ?>>Go to Cart page</option>
							<option value="checkout" <?php selected( $o['cart_action'], 'checkout' ); ?>>Go to Checkout page</option>
							<option value="stay" <?php selected( $o['cart_action'], 'stay' ); ?>>Stay in store (button shows "Added")</option>
						</select></td></tr>
					<tr><th>Cart popup trigger (CSS selector)</th><td><?php $field( 'cart_selector', 'text', 'class="regular-text" placeholder=".xoo-wsc-basket"' ); ?>
						<p class="description">Selector of your cart plugin's cart icon/button. It is clicked to open the popup, and also used by the cart icon inside the store.<br>Leave empty if your cart plugin already opens by itself when a product is added.</p></td></tr>
					<tr><th>"Add to Cart" text</th><td><?php $field( 'txt_add' ); ?></td></tr>
					<tr><th>"Added" text</th><td><?php $field( 'txt_added' ); ?></td></tr>
					<tr><th>"View cart" text</th><td><?php $field( 'txt_view_cart' ); ?></td></tr>
					<tr><th>Option prefix</th><td><?php $field( 'txt_select' ); ?> <span class="description">shows as "Select Size"</span></td></tr>
					<tr><th>"Out of stock" text</th><td><?php $field( 'txt_oos' ); ?></td></tr>
					<tr><th>"View product" text</th><td><?php $field( 'txt_view' ); ?></td></tr>
				</table>
			</div>

			<div class="vr3d-tab" id="vr3d-t-ai" style="display:none">
				<table class="form-table">
					<tr><th>Walking shoppers</th><td><input type="number" min="0" max="2" style="width:70px" name="vr3d_options[shoppers]" value="<?php echo (int) $o['shoppers']; ?>"> <span class="description">0, 1 or 2 people walking inside the store. They never stand in front of the section you are viewing.</span></td></tr>
					<tr><th>Shopper 1 photo</th><td><?php vr3d_media_field( $f . '[shopper1_id]', (int) $o['shopper1_id'], 'Choose photo' ); ?><p class="description">Optional. A standing full-body person with transparent background (PNG) looks like a real person. Empty = 3D character.</p></td></tr>
					<tr><th>Shopper 2 photo</th><td><?php vr3d_media_field( $f . '[shopper2_id]', (int) $o['shopper2_id'], 'Choose photo' ); ?></td></tr>
					<tr><th>Product highlights</th><td><textarea name="vr3d_options[highlights]" rows="3" class="regular-text"><?php echo esc_textarea( $o['highlights'] ); ?></textarea> <span class="description">One per line, shown as small badges in the product popup.</span></td></tr>
				</table>
			</div>

			<div class="vr3d-tab" id="vr3d-t-adv" style="display:none">
				<table class="form-table">
					<tr><th>three.js URL</th><td><?php $field( 'three_url', 'url', 'class="regular-text" placeholder="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"' ); ?>
						<p class="description">Leave empty to use the default CDN. To self-host, upload three.min.js (r128) to your site and paste its URL here.</p></td></tr>
					<tr><th>Reset</th><td><label><input type="checkbox" name="vr3d_options[reset]" value="1"> Reset ALL settings (sections, colors, texts) to the organic-store defaults on next save</label></td></tr>
				</table>
			</div>
			<?php submit_button( 'Save settings' ); ?>
		</form>
	</div>
	<?php
}


/* ---------- Product edit screen: "3D Store Transparency Image" ---------- */
add_action( 'add_meta_boxes', function () {
	add_meta_box( 'vr3d_png', '3D Store – Transparency Image', function ( $post ) {
		wp_nonce_field( 'vr3d_png', 'vr3d_png_nonce' );
		$id = (int) get_post_meta( $post->ID, '_vr3d_png_id', true );
		vr3d_media_field( 'vr3d_png_id', $id, 'Choose transparent PNG' );
		echo '<p class="description">Shown only in the 3D store. Use a PNG with a transparent background. Leave empty to use the product image.</p>';
	}, 'product', 'side', 'default' );
} );
add_action( 'save_post_product', function ( $post_id ) {
	if ( ! isset( $_POST['vr3d_png_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vr3d_png_nonce'] ) ), 'vr3d_png' ) ) { return; }
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
	if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }
	$v = isset( $_POST['vr3d_png_id'] ) ? absint( $_POST['vr3d_png_id'] ) : 0;
	if ( $v ) { update_post_meta( $post_id, '_vr3d_png_id', $v ); } else { delete_post_meta( $post_id, '_vr3d_png_id' ); }
} );
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) || 'product' !== get_post_type() ) { return; }
	wp_enqueue_media();
	wp_enqueue_style( 'vr3d-admin', VR3D_URL . 'assets/css/admin.css', array(), VR3D_VER );
	wp_enqueue_script( 'vr3d-admin', VR3D_URL . 'assets/js/admin.js', array( 'jquery', 'jquery-ui-sortable' ), VR3D_VER, true );
	wp_localize_script( 'vr3d-admin', 'VR3DA', array( 'ajax' => admin_url( 'admin-ajax.php' ), 'nonce' => '' ) );
} );
