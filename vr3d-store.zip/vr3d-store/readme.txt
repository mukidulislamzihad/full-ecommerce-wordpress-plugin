=== 3D Virtual Store for WooCommerce ===
Shortcode: [vr3d_store]  (optional: [vr3d_store height="90vh"])
Admin: WP Admin > 3D Store
Requires: WooCommerce.
