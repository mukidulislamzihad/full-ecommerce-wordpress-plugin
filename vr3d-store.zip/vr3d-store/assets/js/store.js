(function ($) {
  'use strict';
  var D = window.VR3D, root = document.getElementById('vr3d-root');
  if (!D || !root) return;
  if (!window.THREE) { root.innerHTML = '<p class="vr3d-err">3D library could not be loaded.</p>'; return; }
  var THREE = window.THREE, O = D.opts, T = D.t, SEC = D.sections, N = SEC.length;

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function wrap(a) { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; }

  /* ---------- DOM ---------- */
  var brandHtml = O.logo ? '<img src="' + esc(O.logo) + '" alt="' + esc(O.brand) + '">' : '<b>' + esc(O.brand) + '</b><small>' + esc(O.subtitle) + '</small>';
  var cartSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 7h12l-1 13H7L6 7z"/><path d="M9 7a3 3 0 016 0"/></svg>';
  var fsSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>';
  root.innerHTML =
    '<div class="vr3d-stage">' +
    '<canvas class="vr3d-canvas"></canvas>' +
    '<div class="vr3d-top"><button type="button" class="vr3d-btn vr3d-back" hidden>' + esc(T.close) + '</button>' +
    '<div class="vr3d-brand">' + brandHtml + '</div><div class="vr3d-tools">' +
    (O.fullscreen ? '<button type="button" class="vr3d-btn vr3d-fs" aria-label="Fullscreen">' + fsSvg + '</button>' : '') +
    (O.show_cart ? '<button type="button" class="vr3d-btn vr3d-cartbtn" aria-label="Cart">' + cartSvg + '<i class="vr3d-count" data-n="0"></i></button>' : '') +
    '</div></div>' +
    '<div class="vr3d-tip" hidden></div>' +
    '<button type="button" class="vr3d-pg vr3d-pg-l" hidden aria-label="Previous">‹</button>' +
    '<button type="button" class="vr3d-pg vr3d-pg-r" hidden aria-label="Next">›</button>' +
    '<div class="vr3d-nav"></div><div class="vr3d-help" hidden>' + esc(T.help) + '</div>' +
    '<div class="vr3d-pv" hidden>' +
    '<button type="button" class="vr3d-btn pv-close">' + esc(T.close) + '</button>' +
    '<div class="pv-thumbs"></div>' +
    '<div class="pv-stage"><button type="button" class="pv-nav pv-prev" aria-label="Previous">‹</button>' +
    '<a class="pv-imgwrap" href="#"><img class="pv-img" alt=""></a>' +
    '<button type="button" class="pv-nav pv-next" aria-label="Next">›</button></div>' +
    '<div class="pv-count"></div>' +
    '<aside class="pv-card"><span class="pv-cat"></span><h3 class="pv-name"><a href="#"></a></h3>' +
    '<div class="pv-meta"><span class="pv-stars"></span><span class="pv-stock"></span></div>' +
    '<div class="pv-pricebox"><span class="pv-price"></span><span class="pv-save" hidden></span></div>' +
    '<p class="pv-short"></p><div class="pv-facts"></div><div class="pv-optwrap"></div>' +
    '<div class="pv-buyrow"><div class="pv-qty"><button type="button" class="pv-qb" data-d="-1" aria-label="Less">−</button><span class="pv-qn">1</span><button type="button" class="pv-qb" data-d="1" aria-label="More">+</button></div><button type="button" class="pv-add"></button></div>' +
    '<button type="button" class="pv-buy"></button><ul class="pv-badges"></ul>' +
    '<div class="pv-links"><a class="pv-lk" href="#">' + esc(T.view) + '</a><a class="pv-vc" href="#" hidden>' + esc(T.view_cart) + '</a></div></aside>' +
    '</div><div class="vr3d-load"><span></span></div></div>';

  function q(s) { return root.querySelector(s); }
  var stage = q('.vr3d-stage'), canvas = q('.vr3d-canvas'), tip = q('.vr3d-tip'), nav = q('.vr3d-nav'),
    pgL = q('.vr3d-pg-l'), pgR = q('.vr3d-pg-r'), backBtn = q('.vr3d-back'), helpEl = q('.vr3d-help'),
    pvEl = q('.vr3d-pv'), loader = q('.vr3d-load'), countEl = q('.vr3d-count');

  /* ---------- Three setup ---------- */
  var LOW = (window.matchMedia && matchMedia('(pointer:coarse)').matches) || Math.min(screen.width, screen.height) < 820 || (navigator.hardwareConcurrency || 8) <= 4;
  var MAXTEX = 1024, ANISO = 4, LAYERS = 6, MIN_DT = 0;
  var renderer;
  try { renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, powerPreference: 'high-performance', alpha: false, stencil: false }); }
  catch (e) { root.innerHTML = '<p class="vr3d-err">Your browser does not support WebGL.</p>'; return; }
  var PR = Math.min(window.devicePixelRatio || 1, 2); renderer.setPixelRatio(PR);
  var scene = new THREE.Scene();
  scene.background = new THREE.Color(0x2b2118);
  var camera = new THREE.PerspectiveCamera(68, 1, 0.1, 60);
  scene.add(new THREE.AmbientLight(0xfff1dc, 0.88));
  var dl = new THREE.DirectionalLight(0xffffff, 0.32); dl.position.set(0.3, 1, 0.5); scene.add(dl);

  /* ---------- Room geometry ---------- */
  var H = 4.4, M = Math.max(N, 4);
  var A = Math.min(12, Math.max(5.2, 3.9 / Math.tan(Math.PI / M)));
  var WW = 2 * A * Math.tan(Math.PI / M), CR = A / Math.cos(Math.PI / M);
  var L = Math.min(6.2, WW - 3.4);
  function posIdx(i) { return N <= 2 ? i * 2 : i; }
  function theta(i) { return posIdx(i) * 2 * Math.PI / M; }
  function canvasOf(w, h) { var c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
  function rnd(a, b) { return a + Math.random() * (b - a); }
  function rep(t, x, y) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(x, y); t.anisotropy = ANISO; return t; }

  /* textures: plaster, wood, planks, burlap, soft blobs */
  function plasterTex() {
    var c = canvasOf(256, 256), x = c.getContext('2d'), i; x.fillStyle = '#fff'; x.fillRect(0, 0, 256, 256);
    for (i = 0; i < 2600; i++) { x.fillStyle = 'rgba(' + (i % 3 ? '90,70,40' : '255,255,255') + ',' + rnd(0.02, 0.07) + ')'; x.beginPath(); x.arc(rnd(0, 256), rnd(0, 256), rnd(1, 7), 0, 6.3); x.fill(); }
    return rep(new THREE.CanvasTexture(c), WW / 3, H / 3);
  }
  function woodTex(base, rx, ry, dark) {
    var c = canvasOf(256, 256), x = c.getContext('2d'), i; x.fillStyle = base; x.fillRect(0, 0, 256, 256);
    for (i = 0; i < 90; i++) { x.fillStyle = 'rgba(' + (i % 2 ? '70,40,15' : '255,230,190') + ',' + rnd(0.03, dark ? 0.12 : 0.08) + ')'; x.fillRect(0, rnd(0, 256), 256, rnd(1, 4)); }
    return rep(new THREE.CanvasTexture(c), rx, ry);
  }
  function floorTex() {
    var c = canvasOf(512, 512), x = c.getContext('2d'), i, rows = 8, ph = 512 / rows, tones = ['#c79a63', '#b98a54', '#d1a672', '#bd915b', '#c4975f'];
    for (i = 0; i < rows; i++) {
      var off = rnd(0, 256);
      for (var j = -1; j < 3; j++) {
        x.fillStyle = tones[(i * 3 + j + 5) % tones.length]; x.fillRect(off + j * 256, i * ph, 256, ph);
        x.fillStyle = 'rgba(60,30,10,.35)'; x.fillRect(off + j * 256, i * ph, 2, ph);
      }
      x.fillStyle = 'rgba(60,30,10,.4)'; x.fillRect(0, i * ph, 512, 2);
      for (var k = 0; k < 14; k++) { x.fillStyle = 'rgba(80,45,15,' + rnd(0.04, 0.1) + ')'; x.fillRect(rnd(0, 512), i * ph + rnd(4, ph - 4), rnd(30, 120), 1); }
    }
    return rep(new THREE.CanvasTexture(c), 1 / 2.4, 1 / 2.4);
  }
  function burlapTex() {
    var c = canvasOf(128, 128), x = c.getContext('2d'), i; x.fillStyle = '#cdb07a'; x.fillRect(0, 0, 128, 128);
    for (i = 0; i < 128; i += 3) { x.fillStyle = 'rgba(110,80,40,' + rnd(0.08, 0.22) + ')'; x.fillRect(i, 0, 1, 128); x.fillRect(0, i, 128, 1); }
    return rep(new THREE.CanvasTexture(c), 2, 2);
  }
  function blobTex(r, g, b) {
    var c = canvasOf(128, 128), x = c.getContext('2d'), gr = x.createRadialGradient(64, 64, 0, 64, 64, 64);
    gr.addColorStop(0, 'rgba(' + r + ',' + g + ',' + b + ',1)'); gr.addColorStop(1, 'rgba(' + r + ',' + g + ',' + b + ',0)');
    x.fillStyle = gr; x.fillRect(0, 0, 128, 128); return new THREE.CanvasTexture(c);
  }

  var matWood = new THREE.MeshLambertMaterial({ map: woodTex('#b98a5a', 3, 1, false) });
  var matWoodDark = new THREE.MeshLambertMaterial({ map: woodTex('#8a6238', 3, 1, true) });
  var matBeam = new THREE.MeshLambertMaterial({ color: 0x6a4727 });
  var matWall = new THREE.MeshLambertMaterial({ color: new THREE.Color(O.wall), map: plasterTex() });
  var matWain = new THREE.MeshLambertMaterial({ map: woodTex('#9a7348', WW / 1.6, 1, true) });
  var matFloor = new THREE.MeshLambertMaterial({ color: new THREE.Color(O.floor), map: floorTex(), side: THREE.DoubleSide });
  var matBurlap = new THREE.MeshLambertMaterial({ map: burlapTex() });
  var matTerra = new THREE.MeshLambertMaterial({ color: 0xb5653a });
  var greens = [0x3f7a35, 0x4f8f3f, 0x2f6a30, 0x5f9a45].map(function (c) { return new THREE.MeshLambertMaterial({ color: c, side: THREE.DoubleSide }); });
  var glowT = blobTex(255, 214, 140), shadowT = blobTex(30, 18, 8);
  var wallPlanes = [], k;
  var cornerPts = [];
  for (k = 0; k < M; k++) { var psi = k * 2 * Math.PI / M + Math.PI / M; cornerPts.push([CR * Math.sin(psi), -CR * Math.cos(psi)]); }
  function poly(sign) {
    var sh = new THREE.Shape();
    cornerPts.forEach(function (p, i) { var y = sign * p[1]; if (i) sh.lineTo(p[0], y); else sh.moveTo(p[0], y); });
    return new THREE.ShapeGeometry(sh);
  }
  var floor = new THREE.Mesh(poly(-1), matFloor); floor.rotation.x = -Math.PI / 2; scene.add(floor);
  var ceil = new THREE.Mesh(poly(1), new THREE.MeshLambertMaterial({ color: new THREE.Color(O.ceiling), side: THREE.DoubleSide }));
  ceil.rotation.x = Math.PI / 2; ceil.position.y = H; scene.add(ceil);

  function box(w, h, d, mat, x, y, z, parent) { var m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(x, y, z); (parent || scene).add(m); return m; }

  function addPlant(g, x, z, s) {
    var pl = new THREE.Group(); pl.position.set(x, 0, z); pl.scale.setScalar(s); g.add(pl);
    var pot = new THREE.Mesh(new THREE.CylinderGeometry(0.19, 0.13, 0.3, 14), matTerra); pot.position.y = 0.15; pl.add(pot);
    var soil = new THREE.Mesh(new THREE.CircleGeometry(0.17, 14), new THREE.MeshBasicMaterial({ color: 0x3b2a1a })); soil.rotation.x = -Math.PI / 2; soil.position.y = 0.295; pl.add(soil);
    var lg = new THREE.SphereGeometry(1, 8, 6); lg.scale(0.085, 0.42, 0.018); lg.translate(0, 0.42, 0);
    for (var i = 0; i < 11; i++) {
      var lf = new THREE.Mesh(lg, greens[i % greens.length]); lf.position.y = 0.29;
      lf.rotation.set(0, i * 0.57 + rnd(0, 0.3), 0); var tilt = new THREE.Group(); tilt.rotation.set(0, i * 0.57, 0); tilt.add(lf); lf.rotation.set(0, 0, 0); lf.rotation.z = rnd(0.25, 0.85) * (i % 2 ? 1 : 1); pl.add(tilt);
      lf.scale.setScalar(rnd(0.8, 1.25));
    }
  }
  function addSack(g, x, z, s) {
    var sk = new THREE.Group(); sk.position.set(x, 0, z); sk.scale.set(s, s, s); sk.rotation.y = rnd(-0.5, 0.5); g.add(sk);
    var body = new THREE.Mesh(new THREE.CylinderGeometry(0.27, 0.32, 0.52, 18), matBurlap); body.position.y = 0.26; sk.add(body);
    var lip = new THREE.Mesh(new THREE.TorusGeometry(0.27, 0.05, 8, 20), matBurlap); lip.rotation.x = Math.PI / 2; lip.position.y = 0.52; sk.add(lip);
    var fill = new THREE.Mesh(new THREE.CircleGeometry(0.26, 18), new THREE.MeshLambertMaterial({ color: 0xb98b45 })); fill.rotation.x = -Math.PI / 2; fill.position.y = 0.5; sk.add(fill);
  }
  function addLamp(g, x) {
    var wire = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, H - 3.72, 4), mBlackLine); wire.position.set(x, (H + 3.72) / 2, 0.5); g.add(wire);
    var shade = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.26, 24, 1, true), new THREE.MeshLambertMaterial({ color: 0x2f4a30, side: THREE.DoubleSide })); shade.position.set(x, 3.62, 0.5); g.add(shade);
    var bulb = new THREE.Mesh(new THREE.SphereGeometry(0.06, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffe4a8 })); bulb.position.set(x, 3.52, 0.5); g.add(bulb);
    var sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowT, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.8 })); sp.scale.set(1.3, 1.3, 1); sp.position.set(x, 3.5, 0.55); g.add(sp);
  }
  var mBlackLine = new THREE.MeshBasicMaterial({ color: 0x1b1b1b });

  var walls = [], wallGroups = [];
  for (k = 0; k < M; k++) {
    var th = k * 2 * Math.PI / M;
    var g = new THREE.Group(); g.position.set(A * Math.sin(th), 0, -A * Math.cos(th)); g.rotation.y = -th; scene.add(g);
    var wm = new THREE.Mesh(new THREE.PlaneGeometry(WW + 0.02, H), matWall); wm.position.y = H / 2; g.add(wm);
    var secIdx = -1, si;
    for (si = 0; si < N; si++) if (posIdx(si) === k) secIdx = si;
    wm.userData = { sec: secIdx }; wallPlanes.push(wm);
    var wain = new THREE.Mesh(new THREE.PlaneGeometry(WW + 0.02, 1.0), matWain); wain.position.set(0, 0.5, 0.012); g.add(wain);
    box(WW + 0.02, 0.05, 0.05, matWood, 0, 1.02, 0.025, g);
    box(0.22, 0.2, A, matBeam, 0, H - 0.1, A / 2, g);
    addPlant(g, -(WW / 2 - 0.55), 0.35, 1.15); addPlant(g, WW / 2 - 0.55, 0.35, 0.95);
    wallGroups.push(g);
  }

  /* ---------- Textures for products & signs ---------- */
  var texCache = {};
  function loadImg(url) {
    return new Promise(function (res) { var im = new Image(); im.crossOrigin = 'anonymous'; im.onload = function () { res(im); }; im.onerror = function () { res(null); }; im.src = url; });
  }
  function cropCanvas(c, x0, y0, x1, y1, pad) {
    x0 = Math.max(0, x0 - pad); y0 = Math.max(0, y0 - pad); x1 = Math.min(c.width - 1, x1 + pad); y1 = Math.min(c.height - 1, y1 + pad);
    var cw = x1 - x0 + 1, ch = y1 - y0 + 1, c2 = canvasOf(cw, ch);
    c2.getContext('2d').drawImage(c, x0, y0, cw, ch, 0, 0, cw, ch);
    return c2;
  }
  function cutout(img) {
    var s = Math.min(1, 600 / Math.max(img.naturalWidth, img.naturalHeight));
    var w = Math.max(1, Math.round(img.naturalWidth * s)), h = Math.max(1, Math.round(img.naturalHeight * s));
    var c = canvasOf(w, h), x = c.getContext('2d'); x.drawImage(img, 0, 0, w, h);
    var id = x.getImageData(0, 0, w, h), d = id.data, n = w * h, i, px, py, st = [];
    // already transparent PNG? just crop it
    if ([0, w - 1, (h - 1) * w, n - 1].every(function (p) { return d[p * 4 + 3] < 10; })) {
      var tx0 = w, ty0 = h, tx1 = 0, ty1 = 0;
      for (py = 0; py < h; py++) for (px = 0; px < w; px++) if (d[(py * w + px) * 4 + 3] > 20) { if (px < tx0) tx0 = px; if (px > tx1) tx1 = px; if (py < ty0) ty0 = py; if (py > ty1) ty1 = py; }
      return (tx1 > tx0 && ty1 > ty0) ? cropCanvas(c, tx0, ty0, tx1, ty1, 2) : null;
    }
    var lm = new Uint8Array(n);
    for (i = 0; i < n; i++) { var o = i * 4, mx = Math.max(d[o], d[o + 1], d[o + 2]), mn = Math.min(d[o], d[o + 1], d[o + 2]); lm[i] = (d[o + 3] < 10 || (mn > 182 && (mx - mn) < 24)) ? 1 : 0; }
    // eroded light mask: thin leaks (glass highlights, label edges) cannot carry the flood inside the product
    var le = new Uint8Array(n);
    for (py = 0; py < h; py++) for (px = 0; px < w; px++) {
      i = py * w + px;
      le[i] = (lm[i] && (px === 0 || lm[i - 1]) && (px === w - 1 || lm[i + 1]) && (py === 0 || lm[i - w]) && (py === h - 1 || lm[i + w])) ? 1 : 0;
    }
    var bg = new Uint8Array(n);
    for (px = 0; px < w; px++) { st.push(px); st.push((h - 1) * w + px); }
    for (py = 0; py < h; py++) { st.push(py * w); st.push(py * w + w - 1); }
    while (st.length) {
      i = st.pop(); if (bg[i] || !le[i]) continue; bg[i] = 1; px = i % w; py = (i - px) / w;
      if (px > 0) st.push(i - 1); if (px < w - 1) st.push(i + 1); if (py > 0) st.push(i - w); if (py < h - 1) st.push(i + w);
    }
    // grow background back by 2px over light pixels (undo the erosion)
    var it, add;
    for (it = 0; it < 2; it++) {
      add = [];
      for (i = 0; i < n; i++) {
        if (bg[i] || !lm[i]) continue; px = i % w; py = (i - px) / w;
        if ((px > 0 && bg[i - 1]) || (px < w - 1 && bg[i + 1]) || (py > 0 && bg[i - w]) || (py < h - 1 && bg[i + w])) add.push(i);
      }
      for (i = 0; i < add.length; i++) bg[add[i]] = 1;
    }
    var lab = new Int32Array(n), sizes = [0], cnt = 0, big = 0, p, sz;
    for (i = 0; i < n; i++) {
      if (bg[i] || lab[i]) continue; cnt++; sz = 0; st = [i]; lab[i] = cnt;
      while (st.length) {
        p = st.pop(); sz++; px = p % w; py = (p - px) / w;
        if (px > 0 && !bg[p - 1] && !lab[p - 1]) { lab[p - 1] = cnt; st.push(p - 1); }
        if (px < w - 1 && !bg[p + 1] && !lab[p + 1]) { lab[p + 1] = cnt; st.push(p + 1); }
        if (py > 0 && !bg[p - w] && !lab[p - w]) { lab[p - w] = cnt; st.push(p - w); }
        if (py < h - 1 && !bg[p + w] && !lab[p + w]) { lab[p + w] = cnt; st.push(p + w); }
      }
      sizes[cnt] = sz; if (sz > big) big = sz;
    }
    if (big < n * 0.02) return null;
    for (i = 0; i < n; i++) if (!bg[i] && sizes[lab[i]] < big * 0.1) bg[i] = 1;
    var a = new Float32Array(n), t = new Float32Array(n);
    for (i = 0; i < n; i++) a[i] = bg[i] ? 0 : 1;
    for (py = 0; py < h; py++) for (px = 0; px < w; px++) { i = py * w + px; t[i] = (a[px > 0 ? i - 1 : i] + a[i] + a[px < w - 1 ? i + 1 : i]) / 3; }
    for (py = 0; py < h; py++) for (px = 0; px < w; px++) { i = py * w + px; a[i] = (t[py > 0 ? i - w : i] + t[i] + t[py < h - 1 ? i + w : i]) / 3; }
    var x0 = w, y0 = h, x1 = 0, y1 = 0, v, fg = 0;
    for (py = 0; py < h; py++) for (px = 0; px < w; px++) {
      i = py * w + px; v = Math.max(0, Math.min(1, (a[i] - 0.3) / 0.5)); v = v * v * (3 - 2 * v);
      d[i * 4 + 3] = Math.min(d[i * 4 + 3], Math.round(255 * v));
      if (v > 0.5) { fg++; if (px < x0) x0 = px; if (px > x1) x1 = px; if (py < y0) y0 = py; if (py > y1) y1 = py; }
    }
    if (x1 <= x0 || y1 <= y0) return null;
    // cutout looks broken (too little left of the bounding box) -> use the plain photo instead
    if (fg / ((x1 - x0 + 1) * (y1 - y0 + 1)) < 0.34) return null;
    x.putImageData(id, 0, 0);
    return cropCanvas(c, x0, y0, x1, y1, 3);
  }
  function loadTex(url) {
    if (texCache[url]) return texCache[url];
    texCache[url] = loadImg(url).then(function (img) {
      if (!img) return null;
      var tex, w = img.naturalWidth, h = img.naturalHeight;
      try {
        if (O.remove_bg) { var c = cutout(img); if (c) { tex = new THREE.CanvasTexture(c); w = c.width; h = c.height; } }
        if (!tex) { var sc = Math.min(1, MAXTEX / Math.max(w, h)), cc = canvasOf(Math.max(1, Math.round(w * sc)), Math.max(1, Math.round(h * sc))); cc.getContext('2d').drawImage(img, 0, 0, cc.width, cc.height); tex = new THREE.CanvasTexture(cc); }
      } catch (e) { tex = new THREE.Texture(img); tex.needsUpdate = true; }
      tex.anisotropy = ANISO;
      return { tex: tex, w: w, h: h };
    });
    return texCache[url];
  }
  function fitText(ctx, txt, font, maxW, size) { do { ctx.font = font.replace('{s}', size); size -= 4; } while (ctx.measureText(txt).width > maxW && size > 12); }
  var SERIF = 'Georgia,"Times New Roman",serif';

  function logoTex() {
    if (O.logo) return loadImg(O.logo).then(function (im) { if (!im) return null; var t = new THREE.Texture(im); t.needsUpdate = true; return { tex: t, w: im.naturalWidth, h: im.naturalHeight }; });
    var c = canvasOf(1024, 256), x = c.getContext('2d');
    x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillStyle = '#3d5a2a';
    fitText(x, O.brand, '700 {s}px ' + SERIF, 940, 170);
    x.fillText(O.brand, 512, 120);
    if (O.subtitle) { x.font = '600 28px Helvetica,Arial,sans-serif'; if ('letterSpacing' in x) x.letterSpacing = '8px'; x.fillStyle = '#7a6a48'; x.fillText(O.subtitle, 512, 226); }
    var t = new THREE.CanvasTexture(c); t.anisotropy = ANISO; return Promise.resolve({ tex: t, w: 1024, h: 256 });
  }
  function signTex(txt) {
    var c = canvasOf(512, 128), x = c.getContext('2d'), i;
    x.fillStyle = '#c29a66'; x.fillRect(0, 0, 512, 128);
    for (i = 0; i < 40; i++) { x.fillStyle = 'rgba(' + (i % 2 ? '80,45,15' : '255,235,200') + ',' + rnd(0.05, 0.14) + ')'; x.fillRect(0, rnd(0, 128), 512, rnd(1, 3)); }
    x.strokeStyle = 'rgba(70,40,15,.55)'; x.lineWidth = 5; x.strokeRect(3, 3, 506, 122);
    x.textAlign = 'center'; x.textBaseline = 'middle';
    if ('letterSpacing' in x) x.letterSpacing = '3px';
    fitText(x, txt, '700 {s}px ' + SERIF, 440, 58);
    x.fillStyle = 'rgba(255,240,215,.5)'; x.fillText(txt, 257, 68);
    x.fillStyle = '#3a2412'; x.fillText(txt, 256, 66);
    var t = new THREE.CanvasTexture(c); t.anisotropy = ANISO; return t;
  }
  function posterTex(p) {
    var w = 340, h = 460, c = canvasOf(w, h), x = c.getContext('2d');
    x.fillStyle = p.color; x.fillRect(0, 0, w, h);
    function finish() {
      var hex = p.color.replace('#', ''), r = parseInt(hex.substr(0, 2), 16), g = parseInt(hex.substr(2, 2), 16), b = parseInt(hex.substr(4, 2), 16);
      var fg = (0.299 * r + 0.587 * g + 0.114 * b) > 150 ? '#1d1308' : '#fff8e8';
      x.strokeStyle = fg; x.globalAlpha = 0.55; x.lineWidth = 3; x.strokeRect(16, 16, w - 32, h - 32); x.globalAlpha = 1;
      x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle';
      if (p.text) {
        var words = p.text.split(' '), lines = [], cur = '';
        words.forEach(function (wd) { if (cur && (cur + ' ' + wd).length > 9) { lines.push(cur); cur = wd; } else cur = cur ? cur + ' ' + wd : wd; });
        if (cur) lines.push(cur);
        var sz = lines.length > 2 ? 54 : 68, y0 = h * 0.42 - (lines.length - 1) * sz * 0.5;
        lines.forEach(function (ln, i) { fitText(x, ln, '700 {s}px ' + SERIF, w - 80, sz); x.fillText(ln, w / 2, y0 + i * sz * 1.05); });
        if (p.sub) { fitText(x, p.sub, 'italic 400 {s}px ' + SERIF, w - 70, 26); x.fillText(p.sub, w / 2, h - 62); }
      } else if (p.sub) { x.font = 'italic 400 28px ' + SERIF; x.fillText(p.sub, w / 2, h / 2); }
      var t = new THREE.CanvasTexture(c); t.anisotropy = ANISO; return t;
    }
    if (p.image) return loadImg(p.image).then(function (im) {
      if (im) { var s = Math.max(w / im.naturalWidth, h / im.naturalHeight); x.drawImage(im, (w - im.naturalWidth * s) / 2, (h - im.naturalHeight * s) / 2, im.naturalWidth * s, im.naturalHeight * s); }
      return finish();
    });
    return Promise.resolve(finish());
  }

  /* ---------- Sections ---------- */
  var secs = [];
  var mFrame = new THREE.MeshLambertMaterial({ color: 0x6b4a2b }), mRope = new THREE.MeshBasicMaterial({ color: 0xa88a5a });
  function fit(r, mw, mh) { var s = Math.min(mw / r.w, mh / r.h); return { w: r.w * s, h: r.h * s }; }

  SEC.forEach(function (sec, i) {
    var g = wallGroups[posIdx(i)], table = sec.layout === 'table', cols, pp;
    if (table) {
      cols = sec.per_page > 0 ? Math.min(5, Math.max(2, Math.ceil(sec.per_page / 2))) : Math.min(5, Math.max(3, Math.floor(L / 1.0)));
      pp = sec.per_page > 0 ? sec.per_page : cols * 2;
    } else {
      cols = sec.per_page > 0 ? Math.min(5, Math.max(2, Math.ceil(sec.per_page / 3))) : Math.min(5, Math.max(2, Math.floor(L / 1.0)));
      pp = sec.per_page > 0 ? sec.per_page : cols * 3;
    }
    var items = new THREE.Group(); g.add(items);
    var S = { g: g, items: items, meshes: [], pp: pp, cols: cols, Wu: Math.min(L, cols * 1.05 + 0.3), table: table, page: 0, token: 0, pages: Math.max(1, Math.ceil(sec.products.length / pp)) };
    secs[i] = S;

    var sign = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 0.375), new THREE.MeshBasicMaterial({ map: signTex(sec.title) }));
    sign.position.set(0, 4.0, 0.5); g.add(sign);
    [-0.6, 0.6].forEach(function (dx) { var wr = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, H - 4.0 - 0.18, 5), mRope); wr.position.set(dx, (H + 4.0 + 0.18) / 2, 0.5); g.add(wr); });
    addLamp(g, -1.75); addLamp(g, 1.75);
    var pool = new THREE.Mesh(new THREE.PlaneGeometry(5.2, 3.6), new THREE.MeshBasicMaterial({ map: glowT, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.35 }));
    pool.position.set(0, 2.2, 0.015); g.add(pool);
    addSack(g, -(L / 2 + 0.55), 0.45, 1); addSack(g, L / 2 + 0.6, 0.5, 0.9); addSack(g, -(L / 2 + 0.6), 0.95, 0.8);
    if (table) logoTex().then(function (r) { if (!r) return; var sz = fit(r, 2.1, 0.7); var m = new THREE.Mesh(new THREE.PlaneGeometry(sz.w, sz.h), new THREE.MeshBasicMaterial({ map: r.tex, transparent: true })); m.position.set(0, 2.75, 0.03); g.add(m); dirty = true; });
    sec.posters.forEach(function (p, k) {
      if (!p.text && !p.sub && !p.image) return;
      var big = k < 2, sc = big ? 1 : 0.62, px = (k % 2 ? 1 : -1) * (L / 2 + 1.05), py = big ? 2.1 : 3.3;
      box(0.92 * sc, 1.2 * sc, 0.05, mFrame, px, py, 0.035, g);
      posterTex(p).then(function (t) { var m = new THREE.Mesh(new THREE.PlaneGeometry(0.8 * sc, 1.08 * sc), new THREE.MeshBasicMaterial({ map: t })); m.position.set(px, py, 0.065); g.add(m); dirty = true; });
    });
  });

  /* a "real" 3D pack: front photo + stacked darker layers = thickness */
  function makePack(r, size, si, gi) {
    var grp = new THREE.Group(); grp.userData.pack = true;
    var depth = Math.min(0.1, Math.max(0.045, size.w * 0.2)), layers = LAYERS, geo = new THREE.PlaneGeometry(size.w, size.h), l;
    var back = new THREE.MeshBasicMaterial({ map: r.tex, transparent: true, alphaTest: 0.5, color: new THREE.Color(0.52, 0.5, 0.46) });
    for (l = 1; l < layers; l++) { var bm = new THREE.Mesh(geo, back); bm.position.z = depth / 2 - depth * l / (layers - 1); grp.add(bm); }
    var front = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: r.tex, transparent: true, alphaTest: 0.4 }));
    front.position.z = depth / 2 + 0.002; front.userData = { sec: si, gi: gi }; grp.add(front);
    return { grp: grp, front: front };
  }
  function contactShadow(parent, w, x, y, z) {
    var sh = new THREE.Mesh(new THREE.PlaneGeometry(w * 1.25, 0.26), new THREE.MeshBasicMaterial({ map: shadowT, transparent: true, opacity: 0.55, depthWrite: false }));
    sh.rotation.x = -Math.PI / 2; sh.position.set(x, y + 0.004, z); parent.add(sh);
  }

  function renderPage(si, p) {
    var S = secs[si], sec = SEC[si]; S.page = p; var tk = ++S.token;
    var start = p * S.pp, prods = sec.products.slice(start, start + S.pp);
    return Promise.all(prods.map(function (pr) { return loadTex(pr.png || pr.img); })).then(function (res) {
      if (tk !== S.token) return;
      while (S.items.children.length) S.items.remove(S.items.children[0]);
      S.meshes.length = 0; hoverGrp = null;
      var n = prods.length, i, r, size, pk, cols = S.cols, Wu = S.Wu, sp = (Wu - 0.3) / cols, rows = Math.max(1, Math.ceil(n / cols));
      function place(i, x, y, z, mw, mh) {
        r = res[i]; if (!r) return;
        size = fit(r, mw, mh); pk = makePack(r, size, si, start + i);
        pk.grp.position.set(x, y + size.h / 2, z); pk.grp.rotation.y = (((i * 37) % 11) / 11 - 0.5) * 0.12;
        S.items.add(pk.grp); S.meshes.push(pk.front); contactShadow(S.items, size.w, x, y, z);
      }
      if (!S.table) {
        var th = 0.98, base = 0.32, hh = rows * th;
        box(Wu, hh + 0.08, 0.03, matWoodDark, 0, base - 0.03 + (hh + 0.08) / 2, 0.03, S.items);
        [-1, 1].forEach(function (s) { box(0.07, hh + 0.1, 0.4, matWood, s * (Wu / 2 - 0.035), base + hh / 2, 0.2, S.items); box(0.08, base, 0.36, matWoodDark, s * (Wu / 2 - 0.12), base / 2, 0.2, S.items); });
        for (i = 0; i <= rows; i++) box(Wu, 0.04, 0.4, matWood, 0, base + i * th, 0.2, S.items);
        box(Wu + 0.1, 0.05, 0.44, matWood, 0, base + rows * th + 0.045, 0.2, S.items);
        for (i = 0; i < n; i++) {
          var row = Math.floor(i / cols), cnt = Math.min(cols, n - row * cols), c = i % cols;
          place(i, (c - (cnt - 1) / 2) * sp, base + (rows - 1 - row) * th + 0.02, 0.22, sp * 0.88, 0.8);
        }
      } else {
        var topY = 0.86, rowD = 0.42, z0 = 0.14, Dt = rows * rowD + 0.2;
        box(Wu, 0.07, Dt, matWood, 0, topY - 0.035, z0 + Dt / 2, S.items);
        [-1, 1].forEach(function (sx) { [0, 1].forEach(function (sz) { box(0.07, topY - 0.07, 0.07, matWoodDark, sx * (Wu / 2 - 0.08), (topY - 0.07) / 2, z0 + 0.08 + sz * (Dt - 0.16), S.items); }); });
        box(Wu - 0.1, 0.05, 0.04, matWoodDark, 0, 0.3, z0 + Dt - 0.1, S.items);
        for (var rr = 0; rr < rows; rr++) {
          var stepH = (rows - 1 - rr) * 0.13, zz = z0 + 0.1 + rowD * (rr + 0.5);
          if (stepH > 0) box(Wu - 0.3, stepH, rowD - 0.02, matWoodDark, 0, topY + stepH / 2, zz, S.items);
          var cnt2 = Math.min(cols, n - rr * cols);
          for (var cc = 0; cc < cnt2; cc++) place(rr * cols + cc, (cc - (cnt2 - 1) / 2) * sp, topY + stepH + 0.005, zz, sp * 0.88, rr === rows - 1 ? 0.72 : 0.8);
        }
      }
      dirty = true;
    });
  }

  /* ---------- State, camera, tween ---------- */
  var S0 = { view: 'store', sec: -1, yaw: 0, pitch: 0, fov: 68, x: 0, y: 1.65, z: 0, baseYaw: 0, idle: performance.now() };
  var dirty = true, tw = null, visible = true;
  var drag = { down: false, x: 0, y: 0, moved: 0 };

  function applyCam() {
    camera.position.set(S0.x, S0.y, S0.z); camera.rotation.set(S0.pitch, S0.yaw, 0, 'YXZ');
    if (camera.fov !== S0.fov) { camera.fov = S0.fov; camera.updateProjectionMatrix(); }
  }
  function go(t, ms) {
    var f = { yaw: S0.yaw, pitch: S0.pitch, fov: S0.fov, x: S0.x, y: S0.y, z: S0.z };
    t.yaw = f.yaw + wrap(t.yaw - f.yaw);
    tw = { t0: performance.now(), ms: ms, f: f, to: t }; dirty = true;
  }
  function secPose(i) {
    var th = theta(i), asp = camera.aspect || 1.7, need = L + 2.4, d = Math.min(A - 0.7, 4.0);
    var t = Math.max(need / (2 * d * asp), 3.9 / (2 * d));
    var fov = Math.max(46, Math.min(72, 2 * Math.atan(t) * 180 / Math.PI));
    return { x: A * Math.sin(th) - Math.sin(th) * 0 + (-Math.sin(th)) * d, y: 1.9, z: -A * Math.cos(th) + Math.cos(th) * d, yaw: -th, pitch: 0.02, fov: fov };
  }
  function setNav() {
    $(nav).find('button[data-s]').each(function () { $(this).toggleClass('on', +$(this).attr('data-s') === (S0.view === 'section' ? S0.sec : -1)); });
    backBtn.hidden = S0.view === 'store';
    var multi = S0.view === 'section' && secs[S0.sec].pages > 1 && !PV.open;
    pgL.hidden = pgR.hidden = !multi;
  }
  function enterSection(i) {
    S0.view = 'section'; S0.sec = i; var p = secPose(i); S0.baseYaw = p.yaw; go(p, 950); setNav(); hideTip();
  }
  function enterStore() {
    S0.view = 'store'; go({ x: 0, y: 1.65, z: 0, yaw: S0.yaw, pitch: 0, fov: 68 }, 800); setNav(); hideTip(); S0.idle = performance.now();
  }
  function setPage(i, p) {
    var S = secs[i]; p = (p + S.pages) % S.pages; if (p === S.page) return; renderPage(i, p);
  }

  /* ---------- Nav bar ---------- */
  var nb = '<button type="button" data-s="-1" class="on">' + esc(T.store) + '</button>';
  SEC.forEach(function (s, i) { nb += '<button type="button" data-s="' + i + '">' + esc(s.title) + '</button>'; });
  nb += '<button type="button" class="i" aria-label="Help">i</button>';
  nav.innerHTML = nb;
  $(nav).on('click', 'button', function () {
    if ($(this).hasClass('i')) { helpEl.hidden = !helpEl.hidden; return; }
    helpEl.hidden = true;
    var s = +$(this).attr('data-s'); if (s < 0) enterStore(); else enterSection(s);
  });
  $(backBtn).on('click', enterStore);
  $(pgL).on('click', function () { setPage(S0.sec, secs[S0.sec].page - 1); });
  $(pgR).on('click', function () { setPage(S0.sec, secs[S0.sec].page + 1); });

  /* ---------- Pointer interaction ---------- */
  var ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  function pick(ev) {
    var r = canvas.getBoundingClientRect();
    ndc.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
    ray.setFromCamera(ndc, camera);
    var objs = [];
    if (S0.view === 'section') objs = secs[S0.sec].meshes.slice();
    else { secs.forEach(function (s) { objs = objs.concat(s.meshes); }); objs = objs.concat(wallPlanes); }
    var h = ray.intersectObjects(objs, false)[0];
    return h ? h.object : null;
  }
  var hoverGrp = null;
  function setHover(o) { var gp = (o && o.parent && o.parent.userData.pack) ? o.parent : null; if (gp === hoverGrp) return; if (hoverGrp) hoverGrp.scale.setScalar(1); hoverGrp = gp; if (gp) gp.scale.setScalar(1.08); dirty = true; }
  function hideTip() { tip.hidden = true; canvas.classList.remove('hot'); setHover(null); }
  function hover(e) {
    if (tw || PV.open) return;
    var o = pick(e), ud = o && o.userData;
    if (!ud || (S0.view === 'section' && ud.gi == null) || (ud.sec < 0)) { hideTip(); return; }
    canvas.classList.add('hot'); setHover(S0.view === 'section' ? o : null);
    var r = stage.getBoundingClientRect();
    tip.style.left = (e.clientX - r.left) + 'px'; tip.style.top = (e.clientY - r.top) + 'px';
    if (S0.view === 'section' && ud.gi != null) { var p = SEC[ud.sec].products[ud.gi]; tip.textContent = p.name + (p.price_t ? ' · ' + p.price_t : ''); }
    else tip.textContent = SEC[ud.sec].title;
    tip.hidden = false;
  }
  canvas.addEventListener('pointerdown', function (e) {
    drag.down = true; drag.x = e.clientX; drag.y = e.clientY; drag.moved = 0; S0.idle = performance.now();
    try { canvas.setPointerCapture(e.pointerId); } catch (x) { }
    canvas.classList.add('dragging');
  });
  canvas.addEventListener('pointermove', function (e) {
    if (!drag.down) { hover(e); return; }
    var dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.x = e.clientX; drag.y = e.clientY; drag.moved += Math.abs(dx) + Math.abs(dy);
    if (tw) return;
    hideTip();
    var k = S0.fov / 68 * 0.0042;
    S0.yaw += dx * k; S0.pitch += dy * k * 0.8;
    if (S0.view === 'section') {
      var lim = 0.35 + (camera.aspect < 1 ? 0.5 : 0);
      S0.yaw = S0.baseYaw + Math.max(-lim, Math.min(lim, wrap(S0.yaw - S0.baseYaw)));
      S0.pitch = Math.max(-0.18, Math.min(0.18, S0.pitch));
    } else { S0.yaw = wrap(S0.yaw); S0.pitch = Math.max(-0.35, Math.min(0.45, S0.pitch)); }
    dirty = true; S0.idle = performance.now();
  });
  function up(e) {
    if (!drag.down) return; drag.down = false; canvas.classList.remove('dragging'); S0.idle = performance.now();
    if (drag.moved < 6 && e.type === 'pointerup' && !tw) {
      var o = pick(e), ud = o && o.userData; if (!ud || ud.sec < 0) return;
      if (S0.view === 'section') { if (ud.gi != null) openPV(ud.sec, ud.gi); }
      else enterSection(ud.sec);
    }
  }
  canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
  canvas.addEventListener('pointerleave', function () { if (!drag.down) hideTip(); });

  /* ---------- Cart ---------- */
  function setCount(n) { if (!countEl) return; countEl.textContent = n > 0 ? n : ''; countEl.setAttribute('data-n', n); }
  setCount(+D.cart_count || 0);
  function exitFS() { try { if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen(); } catch (e) { } }
  function openCartPopup() {
    var sel = O.cart_selector, el = null;
    if (sel) { try { var l = document.querySelectorAll(sel); for (var i = 0; i < l.length; i++) { if (!root.contains(l[i])) { el = l[i]; break; } } } catch (e) { } }
    if (el) { exitFS(); el.click(); return true; }
    return false;
  }
  function openCart() { if (!openCartPopup()) { location.href = D.cart_url; } }
  $(root).on('click', '.vr3d-cartbtn', openCart);
  $(root).on('click', '.pv-vc', function (e) { e.preventDefault(); openCart(); });

  /* ---------- Product view ---------- */
  var PV = { open: false, si: 0, gi: 0, img: 0, sel: {}, busy: false, added: false, qty: 1 };
  var $add = $(q('.pv-add'));
  function cur() { return SEC[PV.si].products[PV.gi]; }
  function stars(r) { var f = Math.round(r), s = ''; for (var i = 0; i < 5; i++) s += i < f ? '★' : '☆'; return s; }
  function matchVar(p) {
    for (var i = 0; i < p.vars.length; i++) {
      var v = p.vars[i], ok = true;
      p.attrs.forEach(function (at) { var x = v.a[at.key]; if (x && x !== PV.sel[at.key]) ok = false; });
      if (ok) return v;
    }
    return null;
  }
  function avail(p, key, val) {
    return p.vars.some(function (v) {
      if (!v.s) return false; var a = v.a;
      if (a[key] && a[key] !== val) return false;
      for (var k in PV.sel) { if (k === key) continue; if (a[k] && PV.sel[k] && a[k] !== PV.sel[k]) return false; }
      return true;
    });
  }
  function renderPV() {
    var sec = SEC[PV.si], p = cur();
    $(q('.pv-thumbs')).html(p.images.length > 1 ? p.images.map(function (u, k) { return '<button type="button" class="pv-th' + (k === PV.img ? ' on' : '') + '" data-k="' + k + '"><img src="' + esc(u) + '" alt=""></button>'; }).join('') : '');
    var im = q('.pv-img'); im.src = p.images[PV.img] || p.img; im.alt = p.name;
    q('.pv-imgwrap').href = p.link;
    q('.pv-cat').textContent = p.cat || sec.title;
    var a = q('.pv-name a'); a.textContent = p.name; a.href = p.link;
    q('.pv-lk').href = p.link;
    var v = p.type === 'variable' ? matchVar(p) : null;
    q('.pv-price').innerHTML = (v && v.p) ? v.p : p.price;
    var sv = q('.pv-save'); sv.hidden = !(p.save > 0); sv.textContent = '-' + p.save + '%';
    q('.pv-stars').innerHTML = p.rcount > 0 ? '<span class="st">' + stars(p.rating) + '</span> ' + p.rating.toFixed(1) + ' (' + p.rcount + ')' : '';
    var stk = q('.pv-stock'); var simpleP = p.type === 'simple';
    stk.textContent = simpleP ? '● ' + (p.in_stock ? T.instock : T.outstock) : ''; stk.className = 'pv-stock ' + (p.in_stock ? 'in' : 'out');
    var sh = q('.pv-short'); sh.textContent = p.short || ''; sh.hidden = !p.short;
    $(q('.pv-facts')).html((p.facts || []).map(function (f) { return '<span><b>' + esc(f[0]) + '</b>' + esc(f[1]) + '</span>'; }).join(''));
    var oh = '';
    if (p.type === 'variable') {
      p.attrs.forEach(function (at) {
        oh += '<div class="pv-optblock"><span class="pv-optlabel">' + esc(T.select + ' ' + at.label) + '</span><div class="pv-opts">';
        at.options.forEach(function (o) {
          var on = PV.sel[at.key] === o.v, off = !avail(p, at.key, o.v);
          oh += '<button type="button" class="pv-opt' + (on ? ' on' : '') + (off ? ' off' : '') + '" data-k="' + esc(at.key) + '" data-v="' + esc(o.v) + '">' + esc(o.l) + '</button>';
        });
        oh += '</div></div>';
      });
    }
    q('.pv-optwrap').innerHTML = oh;
    var simple = p.type === 'simple' || p.type === 'variable';
    var oos = simple && p.type === 'simple' && !p.in_stock;
    $add.removeClass('ok shake').prop('disabled', oos).text(!simple ? T.view : (oos ? T.oos : (PV.added ? T.added : T.add)));
    if (PV.added) $add.addClass('ok');
    q('.pv-qn').textContent = PV.qty;
    q('.pv-qty').style.display = simple ? '' : 'none';
    var buy = q('.pv-buy'); buy.textContent = T.buy; buy.style.display = (simple && !oos) ? '' : 'none';
    q('.pv-vc').hidden = !PV.added;
    $(q('.pv-badges')).html((O.highlights || []).map(function (b) { return '<li>' + esc(b) + '</li>'; }).join(''));
    q('.pv-count').textContent = (PV.gi + 1) + ' / ' + sec.products.length;
    var many = sec.products.length > 1; q('.pv-prev').style.display = q('.pv-next').style.display = many ? '' : 'none';
  }
  function openPV(si, gi) {
    PV.open = true; PV.si = si; PV.gi = gi; PV.img = 0; PV.sel = {}; PV.added = false; PV.busy = false; PV.qty = 1;
    pvEl.hidden = false; stage.classList.add('pv-open'); hideTip(); renderPV(); setNav();
  }
  function closePV() {
    if (!PV.open) return; PV.open = false; pvEl.hidden = true; stage.classList.remove('pv-open');
    var S = secs[PV.si], pg = Math.floor(PV.gi / S.pp); if (pg !== S.page) renderPage(PV.si, pg);
    setNav(); S0.idle = performance.now();
  }
  function stepPV(d) { var n = SEC[PV.si].products.length; PV.gi = (PV.gi + d + n) % n; PV.img = 0; PV.sel = {}; PV.added = false; PV.qty = 1; renderPV(); }
  $(q('.pv-close')).on('click', closePV);
  $(q('.pv-prev')).on('click', function () { stepPV(-1); });
  $(q('.pv-next')).on('click', function () { stepPV(1); });
  $(pvEl).on('click', '.pv-th', function () { PV.img = +$(this).attr('data-k'); renderPV(); });
  $(pvEl).on('click', '.pv-qb', function () { PV.qty = Math.max(1, Math.min(99, PV.qty + (+$(this).attr('data-d')))); PV.added = false; renderPV(); });
  $(pvEl).on('click', '.pv-opt', function () {
    if ($(this).hasClass('off')) return;
    var k = $(this).attr('data-k'), v = $(this).attr('data-v');
    PV.sel[k] = (PV.sel[k] === v) ? '' : v; if (!PV.sel[k]) delete PV.sel[k];
    PV.added = false; renderPV();
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && PV.open) closePV(); });

  function afterAdd(res, $btn, forceCheckout) {
    setCount(res.count);
    $(document.body).trigger('added_to_cart', [res.fragments, res.cart_hash, $btn]);
    $(document.body).trigger('wc_fragment_refresh');
    var a = O.cart_action;
    if (forceCheckout || a === 'checkout') location.href = D.checkout;
    else if (a === 'cart') location.href = D.cart_url;
    else if (a === 'popup' && O.cart_selector) setTimeout(openCartPopup, 350);
    else if (a === 'popup') exitFS();
  }
  function flash(msg) {
    $add.addClass('shake').text(msg);
    setTimeout(function () { if (!PV.busy && !PV.added) { $add.removeClass('shake').text(T.add); } }, 1400);
  }
  function doAdd(buyNow) {
    var p = cur();
    if (p.type !== 'simple' && p.type !== 'variable') { location.href = p.link; return; }
    if (PV.busy) return;
    if (p.type === 'variable') {
      for (var i = 0; i < p.attrs.length; i++) if (!PV.sel[p.attrs[i].key]) { flash(T.select + ' ' + p.attrs[i].label); return; }
      var mv = matchVar(p); if (!mv || !mv.s) { flash(T.oos); return; }
    }
    PV.busy = true; $add.prop('disabled', true).text(T.adding);
    var data = { product_id: p.id, quantity: PV.qty };
    if (p.type === 'variable') data.variation = $.extend({}, PV.sel);
    $.post(D.ajax_add, data).done(function (res) {
      PV.busy = false; $add.prop('disabled', false);
      if (!res || res.error) { flash((res && res.message) || T.error); return; }
      PV.added = true; renderPV(); afterAdd(res, $add, buyNow);
    }).fail(function () { PV.busy = false; $add.prop('disabled', false); flash(T.error); });
  }
  $add.on('click', function () { doAdd(false); });
  $(q('.pv-buy')).on('click', function () { doAdd(true); });

  var pvStage = q('.pv-stage'), pvImg = q('.pv-img');
  pvStage.addEventListener('pointermove', function (e) {
    var r = pvStage.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
    pvImg.style.transform = 'perspective(900px) rotateY(' + (x * 20) + 'deg) rotateX(' + (-y * 12) + 'deg) scale(1.02)';
  });
  pvStage.addEventListener('pointerleave', function () { pvImg.style.transform = ''; });

  /* ---------- Fullscreen ---------- */
  $(root).on('click', '.vr3d-fs', function () {
    if (document.fullscreenElement) { exitFS(); return; }
    var f = root.requestFullscreen || root.webkitRequestFullscreen; if (f) f.call(root);
  });

  /* ---------- Shoppers (2 people walking; they never block the section you are viewing) ---------- */
  var people = [];
  function lam(c) { return new THREE.MeshLambertMaterial({ color: c }); }
  function makePerson(o) {
    var g = new THREE.Group(), skin = lam(o.skin), shirt = lam(o.shirt), pants = lam(o.pants), hair = lam(o.hair), shoe = lam(o.shoe || 0x2a2420), legs = [], arms = [];
    function add(geo, mat, x, y, z, par, sc) { var m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); if (sc) m.scale.set(sc[0], sc[1], sc[2]); (par || g).add(m); return m; }
    [-1, 1].forEach(function (s) {
      var lg = new THREE.Group(); lg.position.set(s * 0.085, 0.93, 0); g.add(lg);
      add(new THREE.CylinderGeometry(0.082, 0.06, 0.84, 12), pants, 0, -0.42, 0, lg);
      add(new THREE.BoxGeometry(0.105, 0.07, 0.24), shoe, 0, -0.9, 0.05, lg); legs.push(lg);
      var ar = new THREE.Group(); ar.position.set(s * 0.245, 1.5, 0); g.add(ar);
      add(new THREE.CylinderGeometry(0.052, 0.045, 0.3, 10), shirt, 0, -0.15, 0, ar);
      add(new THREE.CylinderGeometry(0.043, 0.036, 0.28, 10), o.longSleeve ? shirt : skin, 0, -0.43, 0, ar);
      add(new THREE.SphereGeometry(0.045, 10, 8), skin, 0, -0.6, 0, ar); arms.push(ar);
    });
    add(new THREE.SphereGeometry(1, 16, 12), shirt, 0, 1.2, 0, null, [0.2, 0.34, 0.125]);
    add(new THREE.SphereGeometry(1, 16, 10), shirt, 0, 1.46, 0, null, [0.255, 0.1, 0.12]);
    add(new THREE.CylinderGeometry(0.175, 0.17, 0.22, 14), o.dress ? shirt : pants, 0, 0.98, 0);
    if (o.dress) add(new THREE.CylinderGeometry(0.17, 0.3, 0.55, 16), shirt, 0, 0.78, 0);
    add(new THREE.CylinderGeometry(0.045, 0.05, 0.12, 10), skin, 0, 1.56, 0);
    add(new THREE.SphereGeometry(1, 16, 14), skin, 0, 1.69, 0, null, [0.115, 0.14, 0.125]);
    add(new THREE.SphereGeometry(0.135, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.58), hair, 0, 1.71, -0.015);
    if (o.long) { add(new THREE.SphereGeometry(1, 12, 10), hair, 0, 1.55, -0.1, null, [0.13, 0.22, 0.07]); }
    if (o.scarf) add(new THREE.SphereGeometry(0.15, 14, 12, 0, Math.PI * 2, 0, Math.PI * 0.75), lam(o.scarf), 0, 1.67, -0.01);
    [-1, 1].forEach(function (s) { add(new THREE.SphereGeometry(0.013, 6, 5), lam(0x1a1a1a), s * 0.045, 1.7, 0.118); });
    scene.add(g);
    return { g: g, legs: legs, arms: arms, phase: Math.random() * 6, wait: 0, tgt: null, vis: 1, bill: null };
  }
  function makeBillboard(url) {
    var P = { g: new THREE.Group(), legs: [], arms: [], phase: Math.random() * 6, wait: 0, tgt: null, vis: 1, bill: null };
    scene.add(P.g);
    loadTex(url).then(function (r) {
      if (!r) return;
      var hgt = 1.75, wd = hgt * r.w / r.h, pivot = new THREE.Group(); P.g.add(pivot);
      var m = new THREE.Mesh(new THREE.PlaneGeometry(wd, hgt), new THREE.MeshBasicMaterial({ map: r.tex, transparent: true, alphaTest: 0.35, side: THREE.DoubleSide }));
      m.position.y = hgt / 2; pivot.add(m); P.bill = pivot;
      var sh = new THREE.Mesh(new THREE.PlaneGeometry(wd * 1.1, 0.4), new THREE.MeshBasicMaterial({ map: shadowT, transparent: true, opacity: 0.5, depthWrite: false }));
      sh.rotation.x = -Math.PI / 2; sh.position.y = 0.01; P.g.add(sh); dirty = true;
    });
    return P;
  }
  function animPerson(P, moving, dt, t) {
    if (moving) P.phase += dt * 7.5;
    if (P.bill) { P.bill.position.y = moving ? Math.abs(Math.sin(P.phase)) * 0.035 : 0; P.bill.rotation.z = moving ? Math.sin(P.phase) * 0.035 : 0; return; }
    if (!P.legs.length) return;
    var sw = moving ? Math.sin(P.phase) * 0.6 : 0;
    P.legs[0].rotation.x = sw; P.legs[1].rotation.x = -sw;
    P.arms[0].rotation.x = -sw * 0.7; P.arms[1].rotation.x = sw * 0.7;
    P.arms[0].rotation.z = -0.06; P.arms[1].rotation.z = 0.06;
  }
  function stepTo(P, tx, tz, speed, dt) {
    var g = P.g, dx = tx - g.position.x, dz = tz - g.position.z, d = Math.hypot(dx, dz);
    if (d < 0.05) return false;
    var st = Math.min(d, speed * dt); g.position.x += dx / d * st; g.position.z += dz / d * st;
    g.rotation.y += wrap(Math.atan2(dx, dz) - g.rotation.y) * Math.min(1, dt * 8); return true;
  }
  function faceTo(P, tx, tz, dt) { P.g.rotation.y += wrap(Math.atan2(tx - P.g.position.x, tz - P.g.position.z) - P.g.rotation.y) * Math.min(1, dt * 5); }
  function viewedSec() { return S0.view === 'section' ? S0.sec : -1; }
  function inZone(x, z) {
    var v = viewedSec(); if (v < 0) return false;
    var th = theta(v), s = Math.sin(th), c = Math.cos(th), dx = x - A * s, dz = z + A * c;
    return (dx * (-s) + dz * c) < 4.8 && Math.abs(dx * c + dz * s) < 6.5;
  }
  function pickTarget(P) {
    var v = viewedSec(), cand = [], i; for (i = 0; i < N; i++) if (i !== v) cand.push(i); if (!cand.length) cand = [0];
    var si = cand[Math.floor(Math.random() * cand.length)], th = theta(si), s = Math.sin(th), c = Math.cos(th), lat = (Math.random() - 0.5) * L * 0.9, dist = 1.7 + Math.random() * 0.8;
    P.tgt = { si: si, x: A * s - s * dist + c * lat, z: -A * c + c * dist + s * lat, wx: A * s, wz: -A * c };
  }
  var shopStyles = [
    { skin: 0xc68b62, shirt: 0x3d6b8f, pants: 0x2e3340, hair: 0x15100d, longSleeve: true },
    { skin: 0xe8b894, shirt: 0xb5483a, pants: 0x2e3340, hair: 0x2a1a12, dress: true, long: true, scarf: 0xe9d9b0 }
  ];
  for (var pi = 0; pi < Math.min(2, O.shoppers || 0); pi++) {
    var img = (O.shopper_imgs || [])[pi], P = img ? makeBillboard(img) : makePerson(shopStyles[pi % shopStyles.length]);
    pickTarget(P); P.g.position.set(P.tgt.x * 0.8 + (pi ? 1.2 : -1.2), 0, P.tgt.z * 0.8); P.wait = Math.random() * 2; people.push(P);
  }
  function updatePeople(now, dt) {
    var v = viewedSec();
    people.forEach(function (P) {
      var moving = false, g = P.g, zone = inZone(g.position.x, g.position.z);
      if (v >= 0 && P.tgt && P.tgt.si === v) { pickTarget(P); P.wait = 0; }
      if (zone && P.wait > 0) { P.wait = 0; pickTarget(P); }
      if (P.wait > 0) { P.wait -= dt; faceTo(P, P.tgt.wx, P.tgt.wz, dt); if (P.wait <= 0) pickTarget(P); }
      else { moving = stepTo(P, P.tgt.x, P.tgt.z, zone ? 1.4 : 0.7, dt); if (!moving) P.wait = 4 + Math.random() * 5; }
      if (P.bill) g.rotation.y = Math.atan2(S0.x - g.position.x, S0.z - g.position.z);
      animPerson(P, moving, dt, now);
      var tv = zone ? 0 : 1; P.vis += (tv - P.vis) * Math.min(1, dt * 4);
      g.scale.setScalar(Math.max(0.001, P.vis)); g.visible = P.vis > 0.03;
    });
  }

  /* ---------- Loop ---------- */
  function resize() {
    var w = stage.clientWidth, h = stage.clientHeight; if (!w || !h) return;
    renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
    if (S0.view === 'section' && !tw) { var p = secPose(S0.sec); S0.x = p.x; S0.y = p.y; S0.z = p.z; S0.fov = p.fov; S0.yaw = p.yaw; S0.baseYaw = p.yaw; }
    dirty = true;
  }
  if (window.ResizeObserver) new ResizeObserver(resize).observe(stage); else window.addEventListener('resize', resize);
  if (window.IntersectionObserver) new IntersectionObserver(function (en) { visible = en[0].isIntersecting; if (visible) dirty = true; }).observe(root);

  var lastT = performance.now(), fT = 0, fSum = 0, fN = 0;
  function tick(now) {
    requestAnimationFrame(tick);
    if (!visible || document.hidden) { lastT = now; return; }
    if (MIN_DT && !drag.down && !tw && !(S0.view === 'store' && O.autorotate) && now - S0.idle > 1500 && now - lastT < MIN_DT) return;
    var dt = Math.min(0.05, Math.max(0, (now - lastT) / 1000)); lastT = now;
    if (people.length) { updatePeople(now, dt); dirty = true; }
    if (tw) {
      var k = Math.min(1, (now - tw.t0) / tw.ms), e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
      ['yaw', 'pitch', 'fov', 'x', 'y', 'z'].forEach(function (n) { S0[n] = tw.f[n] + (tw.to[n] - tw.f[n]) * e; });
      if (k >= 1) { var t = tw.to; tw = null; S0.yaw = wrap(S0.yaw); if (S0.view === 'section') S0.baseYaw = t.yaw; }
      dirty = true;
    } else if (S0.view === 'store' && O.autorotate && !drag.down && !PV.open && now - S0.idle > 3500) { S0.yaw = wrap(S0.yaw + 0.0009); dirty = true; }
    if (dirty) {
      applyCam(); renderer.render(scene, camera); dirty = false;
      // adaptive sharpness: only drops resolution if the device really struggles while moving
      if (drag.down || tw) {
        if (now - fT < 100) { fSum += now - fT; fN++; }
        if (fN >= 40) {
          var avg = fSum / fN; fSum = 0; fN = 0;
          if (avg > 26 && PR > 1) { PR = Math.max(1, PR - 0.25); renderer.setPixelRatio(PR); resize(); }
        }
      }
      fT = now;
    }
  }

  resize(); applyCam();
  Promise.all(SEC.map(function (s, i) { return renderPage(i, 0); })).then(function () { dirty = true; });
  var hide = function () { loader.classList.add('done'); dirty = true; };
  Promise.race([Promise.all(SEC.map(function (s, i) { return texCache[s.products[0].png || s.products[0].img] || Promise.resolve(); })), new Promise(function (r) { setTimeout(r, 9000); })]).then(function () { setTimeout(hide, 250); });
  requestAnimationFrame(tick);
})(jQuery);
