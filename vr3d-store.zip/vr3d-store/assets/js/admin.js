jQuery(function ($) {
  var $secs = $('#vr3d-secs');

  $('.vr3d-tabs a').on('click', function (e) {
    e.preventDefault();
    $('.vr3d-tabs a').removeClass('nav-tab-active'); $(this).addClass('nav-tab-active');
    $('.vr3d-tab').hide(); $($(this).attr('href')).show();
  });

  function sync($s) { $s.attr('data-src', $s.find('.vr3d-source').val()); }
  function chips($c) { $c.sortable({}); }
  $secs.find('.vr3d-sec').each(function () { sync($(this)); });
  $secs.sortable({ handle: '.vr3d-handle', items: '.vr3d-sec' });
  $secs.find('.vr3d-chips').each(function () { chips($(this)); });

  $secs.on('change', '.vr3d-source', function () { sync($(this).closest('.vr3d-sec')); });
  $secs.on('input', '.vr3d-title-in', function () { $(this).closest('.vr3d-sec').find('.vr3d-sec-title').text($(this).val() || 'Section'); });
  $secs.on('click', '.vr3d-toggle', function (e) { e.preventDefault(); $(this).closest('.vr3d-sec').find('.vr3d-sec-body').slideToggle(120); });
  $secs.on('click', '.vr3d-remove', function (e) { e.preventDefault(); if (confirm('Delete this section?')) $(this).closest('.vr3d-sec').remove(); });
  $secs.on('click', '.vr3d-x', function (e) { e.preventDefault(); $(this).closest('li').remove(); });

  $('#vr3d-add-sec').on('click', function () {
    var html = $('#vr3d-sec-tpl').html().replace(/__i__/g, 'n' + Date.now());
    var $n = $(html).appendTo($secs); sync($n); chips($n.find('.vr3d-chips'));
    $n.find('.vr3d-sec-body').show();
  });

  var timer;
  $secs.on('input', '.vr3d-psearch', function () {
    var $in = $(this), $res = $in.siblings('.vr3d-results'), q = $in.val();
    clearTimeout(timer);
    if (q.length < 2) { $res.hide().empty(); return; }
    timer = setTimeout(function () {
      $.get(VR3DA.ajax, { action: 'vr3d_search_products', nonce: VR3DA.nonce, q: q }, function (r) {
        $res.empty();
        $.each(r, function (_, p) {
          $('<li>').data('p', p).append($('<img>').attr('src', p.thumb)).append($('<span>').text(p.title)).appendTo($res);
        });
        $res.toggle(r.length > 0);
      });
    }, 250);
  });
  $secs.on('click', '.vr3d-results li', function () {
    var p = $(this).data('p'), $sec = $(this).closest('.vr3d-sec');
    var name = $sec.find('.vr3d-source').attr('name').replace('[source]', '[product_ids][]');
    var $li = $('<li>').attr('data-id', p.id)
      .append($('<img>').attr('src', p.thumb)).append($('<span>').text(p.title))
      .append($('<input type="hidden">').attr('name', name).val(p.id))
      .append('<a href="#" class="vr3d-x">×</a>');
    $sec.find('.vr3d-chips').append($li).sortable('refresh');
    $(this).closest('.vr3d-results').hide().empty();
    $sec.find('.vr3d-psearch').val('');
  });

  $(document).on('click', '.vr3d-pick', function (e) {
    e.preventDefault();
    var $w = $(this).closest('.vr3d-media');
    var frame = wp.media({ multiple: false, library: { type: 'image' } });
    frame.on('select', function () {
      var a = frame.state().get('selection').first().toJSON();
      $w.find('input').val(a.id);
      var u = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
      $w.find('.vr3d-media-prev').html('<img src="' + u + '">');
    });
    frame.open();
  });
  $(document).on('click', '.vr3d-unpick', function (e) {
    e.preventDefault();
    var $w = $(this).closest('.vr3d-media'); $w.find('input').val(0); $w.find('.vr3d-media-prev').empty();
  });
});
