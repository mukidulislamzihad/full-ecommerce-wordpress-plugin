jQuery(function($){
 $('.hbp-color').wpColorPicker();
 $('.hbp-tabs button').on('click',function(){var t=$(this).data('tab');$('.hbp-tabs button').removeClass('on');$(this).addClass('on');$('.hbp-p').removeClass('on').filter('[data-p="'+t+'"]').addClass('on');try{localStorage.hbpTab=t}catch(e){}});
 var st;try{st=localStorage.hbpTab}catch(e){}
 var b=$('.hbp-tabs button[data-tab="'+st+'"]');(b.length?b:$('.hbp-tabs button').first()).trigger('click');
 $('.hbp-rep').sortable({handle:'.hbp-drag',axis:'y'});
 $(document).on('click','.hbp-add',function(){var k=$(this).data('k');$('.hbp-rep[data-k="'+k+'"]').append($('#hbp-t-'+k).html().replace(/__i__/g,Date.now()))});
 $(document).on('click','.hbp-del',function(){$(this).closest('.hbp-row').remove()});
 $(document).on('click','.hbp-pick',function(e){e.preventDefault();var w=$(this).closest('.hbp-media');var f=wp.media({multiple:false}).on('select',function(){var u=f.state().get('selection').first().toJSON().url;w.find('input').val(u);w.find('img').remove();w.append('<img src="'+u+'" alt="">')}).open()});
 $('.hbp-tc input').on('change',function(){$('.hbp-tc').removeClass('on');$(this).closest('.hbp-tc').addClass('on')});
 $('.hbp-copy').on('click',function(){var b=$(this);navigator.clipboard&&navigator.clipboard.writeText('[hbp_header]');b.text('Copied!')});
});
