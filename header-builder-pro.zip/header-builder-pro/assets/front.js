document.addEventListener('click',function(e){
 var h=e.target.closest('.hbp'),b=e.target.closest('.hbp-burger'),t=e.target.closest('[data-hbp-toggle]');
 if(b&&h){h.classList.add('is-open');b.setAttribute('aria-expanded','true');return}
 if(h&&e.target.closest('.hbp-x,.hbp-ov')){h.classList.remove('is-open');return}
 document.querySelectorAll('.hbp .open').forEach(function(x){if(!t||!x.contains(t))x.classList.remove('open')});
 if(t)t.parentNode.classList.toggle('open');
});
document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.hbp.is-open,.hbp .open').forEach(function(x){x.classList.remove('is-open','open')})});

(function(){
 if(!window.HBP_AJ||!HBP_AJ.on)return;
 var tm,xhr;
 function box(f){var b=f.querySelector('.hbp-sg');if(!b){b=document.createElement('div');b.className='hbp-sg';f.appendChild(b)}return b}
 function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x)e.textContent=x;return e}
 function show(f,d){
  var b=box(f);b.innerHTML='';
  if(!d.r.length){b.appendChild(el('div','hbp-no','No products found'));b.classList.add('on');return}
  d.r.forEach(function(x){var a=el('a');a.href=x.u;
   if(x.i){var im=el('img');im.src=x.i;im.alt='';im.loading='lazy';a.appendChild(im)}else a.appendChild(el('i'));
   a.appendChild(el('span','',x.t));if(x.p)a.appendChild(el('b','',x.p));b.appendChild(a)});
  var all=el('a','hbp-all','View all results');all.href=d.all;b.appendChild(all);b.classList.add('on');
 }
 document.addEventListener('input',function(e){
  var i=e.target;if(!i.matches||!i.matches('.hbp-search input[type=search]'))return;
  var f=i.closest('.hbp-search'),q=i.value.trim();clearTimeout(tm);
  if(q.length<2){box(f).classList.remove('on');return}
  tm=setTimeout(function(){
   if(xhr)xhr.abort();xhr=new XMLHttpRequest();
   xhr.open('GET',HBP_AJ.u+'?action=hbp_search&q='+encodeURIComponent(q));
   xhr.onload=function(){try{show(f,JSON.parse(xhr.responseText))}catch(_){}};xhr.send();
  },250);
 });
 document.addEventListener('click',function(e){if(!e.target.closest('.hbp-search'))document.querySelectorAll('.hbp-sg.on').forEach(function(x){x.classList.remove('on')})});
 document.addEventListener('keydown',function(e){if(e.key==='Escape')document.querySelectorAll('.hbp-sg.on').forEach(function(x){x.classList.remove('on')})});
})();
