<?php
if(!defined('ABSPATH'))exit;
class HBP_Widget extends \Elementor\Widget_Base{
 function get_name(){return 'hbp_header';}
 function get_title(){return 'Header Builder Pro';}
 function get_icon(){return 'eicon-header';}
 function get_categories(){return ['general'];}
 protected function render(){echo HBP::render();}
}
