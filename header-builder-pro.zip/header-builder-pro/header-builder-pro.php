<?php
/*
Plugin Name: Header Builder Pro
Description: 3 ready header templates (SunFry, Amar Bazar, MegaShop). Shortcode [hbp_header] ba Elementor widget diye use korun. Full admin customizable.
Version: 1.2.0
Text Domain: hbp
*/
if(!defined('ABSPATH'))exit;
define('HBP_URL',plugin_dir_url(__FILE__));define('HBP_VER','1.2.0');

final class HBP{
const OPT='hbp_settings';
static function init(){
 add_action('admin_menu',[__CLASS__,'menu']);
 add_action('admin_init',function(){register_setting('hbp_group',self::OPT,['sanitize_callback'=>[__CLASS__,'san']]);});
 add_action('admin_enqueue_scripts',[__CLASS__,'admin_assets']);
 add_action('wp_enqueue_scripts',[__CLASS__,'front_assets']);
 add_shortcode('hbp_header',[__CLASS__,'render']);
 add_filter('woocommerce_add_to_cart_fragments',[__CLASS__,'frag']);
 add_action('wp_ajax_hbp_search',[__CLASS__,'ajax']);add_action('wp_ajax_nopriv_hbp_search',[__CLASS__,'ajax']);
 add_action('admin_post_hbp_demo',[__CLASS__,'demo_do']);
 add_action('elementor/widgets/register',function($m){if(class_exists('\Elementor\Widget_Base')){require_once __DIR__.'/elementor-widget.php';$m->register(new HBP_Widget());}});
}
/* ---------- data ---------- */
static function d($t='sunfry'){
 $p=function($s){$r=[];foreach(explode(';',$s) as $x){$a=array_map('trim',explode('|',$x))+['','#',''];if($a[0])$r[]=['label'=>$a[0],'url'=>$a[1],'badge'=>$a[2]];}return $r;};
 $b=['template'=>$t,'logo_img'=>'','logo_text'=>'MY SHOP','logo_link'=>'','search_ph'=>'Search for Products…','track_url'=>'','account_url'=>'','cart_url'=>'','wish_url'=>'','sticky'=>0,'full'=>1,'bp'=>991,'live'=>1,'logo_h'=>52,'logo_hm'=>40,'bar_grad'=>0,'ann'=>'','ann_url'=>'','ann_bg'=>'','ann_tx'=>'','shadow'=>0,'custom_css'=>'','accent'=>'','bar_bg'=>'','bar_text'=>'','text'=>'','bg'=>'','menu'=>[],'cats'=>[],'more'=>[],'quick'=>[]];
 if($t==='sunfry'){$b['logo_text']='SunFry';$b['search_ph']='Search Honey';
  $b['menu']=$p('Home|/;Combos|/combos/;Offers|/offers/|NEW;Track Order|/track-order/');
  $b['cats']=$p('Dates|/product-category/dates/;Dry Food|/product-category/dry-food/;Falaq Food Special|/product-category/falaq/;Honey|/product-category/honey/;Mix food|/product-category/mix-food/;Nuts & Seeds|/product-category/nuts-seeds/;Tea|/product-category/tea/');$b['more']=$p('About us|/about-us/');$b['quick']=$p('Combos|/combos/;Corporate Deals|/corporate-deals/;Contact Us|/contact-us/');}
 if($t==='amar'){$b['logo_text']='AMAR BAZAR';
  $b['menu']=$p('Home|/;Shop|/shop/;Combos|/combos/;Organic|/product-category/organic/;Honey|/product-category/honey/;Oil & Ghee|/product-category/oil-ghee/;Dates|/product-category/dates/;Spices|/product-category/spices/;Nuts & Seeds|/product-category/nuts-seeds/;Beverage|/product-category/beverage/;Rice|/product-category/rice/;Flours & Lentils|/product-category/flours-lentils/');
  $b['more']=$p('About Us|/about-us/;Contact Us|/contact-us/;FAQs|/faqs/;Call Us|tel:+8801000000000;WhatsApp|https://wa.me/8801000000000');}
 if($t==='mega'){$b['logo_text']='MEGASHOP';
  $b['menu']=$p('Home|/;Shop|/shop/;New Arrivals|/new-arrivals/;Deals & Offers|/offers/');
  $b['cats']=$p('Accessories;Men Fashions;Women Fashions;Home & Living;Kitchen Items;Toys Products;Baby & Kids;Health Care;Beauty;Electronics;Fitness;Grocery;Watches;Shoes');
  $b['more']=$p('Track Order|/track-order/;Store Location|/store-location/');}
 return $b;
}
static function get(){$o=get_option(self::OPT);if(!is_array($o))$o=[];return wp_parse_args($o,self::d($o['template']??'sunfry'));}
static function san($in){
 $o=[];$o['template']=in_array($in['template']??'',['sunfry','amar','mega'],true)?$in['template']:'sunfry';
 foreach(['logo_text','search_ph','ann'] as $k)$o[$k]=sanitize_text_field($in[$k]??'');
 foreach(['logo_img','ann_url','logo_link','track_url','account_url','cart_url','wish_url'] as $k)$o[$k]=esc_url_raw($in[$k]??'');
 foreach(['accent','bar_bg','bar_text','text','bg','ann_bg','ann_tx'] as $k)$o[$k]=sanitize_hex_color($in[$k]??'')?:'';
 $o['sticky']=empty($in['sticky'])?0:1;$o['live']=empty($in['live'])?0:1;$o['bar_grad']=empty($in['bar_grad'])?0:1;$o['shadow']=empty($in['shadow'])?0:1;$o['logo_h']=max(16,min(200,intval($in['logo_h']??52)));$o['logo_hm']=max(16,min(120,intval($in['logo_hm']??40)));$o['full']=empty($in['full'])?0:1;$o['bp']=max(480,min(1400,intval($in['bp']??991)));
 $o['custom_css']=wp_strip_all_tags($in['custom_css']??'');
 foreach(['menu','cats','more','quick'] as $k){$o[$k]=[];foreach((array)($in[$k]??[]) as $r){if(empty($r['label']))continue;$o[$k][]=['label'=>sanitize_text_field($r['label']),'url'=>esc_url_raw($r['url']??''),'badge'=>sanitize_text_field($r['badge']??'')];}}
 return $o;
}
static function demo_do(){
 if(!current_user_can('manage_options')||!wp_verify_nonce($_POST['_wpnonce']??'','hbp_demo'))wp_die('No');
 $t=sanitize_key($_POST['template']??'sunfry');update_option(self::OPT,self::d($t));
 wp_safe_redirect(admin_url('admin.php?page=hbp&demo=1'));exit;
}
/* ---------- assets ---------- */
static function front_assets(){
 $s=self::get();$css=file_get_contents(__DIR__.'/assets/front.css');$css=str_replace('991px',$s['bp'].'px',$css);
 wp_register_style('hbp',false);wp_enqueue_style('hbp');wp_add_inline_style('hbp',$css.$s['custom_css']);
 wp_enqueue_script('hbp',HBP_URL.'assets/front.js',[],HBP_VER,true);wp_localize_script('hbp','HBP_AJ',['u'=>admin_url('admin-ajax.php'),'on'=>(int)$s['live']]);
}
static function admin_assets($h){
 if($h!=='toplevel_page_hbp')return;
 wp_enqueue_media();wp_enqueue_style('wp-color-picker');
 wp_enqueue_style('hbp-a',HBP_URL.'assets/admin.css',[],HBP_VER);
 wp_enqueue_script('hbp-a',HBP_URL.'assets/admin.js',['jquery','wp-color-picker','jquery-ui-sortable'],HBP_VER,true);
}
static function ajax(){
 $q=sanitize_text_field(wp_unslash($_GET['q']??''));$out=[];
 if(mb_strlen($q)>=2){
  $woo=class_exists('WooCommerce');
  $r=new WP_Query(['s'=>$q,'post_type'=>$woo?'product':'post','post_status'=>'publish','posts_per_page'=>6,'no_found_rows'=>true,'ignore_sticky_posts'=>true]);
  foreach($r->posts as $po){
   $pr='';if($woo){$pd=wc_get_product($po->ID);if($pd){if($pd->get_catalog_visibility()==='hidden')continue;$pr=wp_strip_all_tags(html_entity_decode(wc_price((float)$pd->get_price())));}}
   $out[]=['t'=>get_the_title($po),'u'=>get_permalink($po),'i'=>get_the_post_thumbnail_url($po,'thumbnail')?:'','p'=>$pr];
  }
 }
 wp_send_json(['r'=>$out,'all'=>add_query_arg(['s'=>$q]+(class_exists('WooCommerce')?['post_type'=>'product']:[]),home_url('/'))]);
}
/* ---------- helpers ---------- */
static function ic($n){
 $p=['search'=>'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>','cart'=>'<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.7 12.4a1 1 0 0 0 1 .8h8.8a1 1 0 0 0 1-.8L20 7H6"/>','user'=>'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>','heart'=>'<path d="M12 21s-8-5-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 6-8 11-8 11z"/>','pin'=>'<path d="M12 22s7-6.5 7-12a7 7 0 0 0-14 0c0 5.5 7 12 7 12z"/><circle cx="12" cy="10" r="2.5"/>','dots'=>'<path d="M4 7h16M4 12h16M4 17h16"/>','grid'=>'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>','box'=>'<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>','chev'=>'<path d="m9 6 6 6-6 6"/>','down'=>'<path d="m6 9 6 6 6-6"/>'];
 return '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.$p[$n].'</svg>';
}
static function u($u){if(!$u)return '#';return $u[0]==='/'?home_url($u):$u;}
static function links($a){
 static $cur=null;if($cur===null)$cur=untrailingslashit((is_ssl()?'https://':'http://').($_SERVER['HTTP_HOST']??'').strtok($_SERVER['REQUEST_URI']??'','?'));
 $h='';foreach((array)$a as $r){$u=self::u($r['url']);$h.='<a href="'.esc_url($u).'"'.(untrailingslashit($u)===$cur?' class="is-active"':'').'>'.esc_html($r['label']).($r['badge']?'<em class="hbp-badge">'.esc_html($r['badge']).'</em>':'').'</a>';}
 return $h;
}
static function cnt(){return function_exists('WC')&&WC()->cart?WC()->cart->get_cart_contents_count():0;}
static function tot(){return function_exists('WC')&&WC()->cart?wp_strip_all_tags(WC()->cart->get_cart_total()):'0৳';}
static function frag($f){$f['span.hbp-cnt']='<span class="hbp-cnt">'.self::cnt().'</span>';$f['span.hbp-tot']='<span class="hbp-tot">'.esc_html(self::tot()).'</span>';return $f;}
/* ---------- render ---------- */
static function render($atts=[]){
 $s=self::get();$a=shortcode_atts(['template'=>''],$atts);
 $t=in_array($a['template'],['sunfry','amar','mega'],true)?$a['template']:$s['template'];
 $v='';foreach(['accent'=>'--a','bar_bg'=>'--bb','bar_text'=>'--bt','text'=>'--tx','bg'=>'--bg'] as $k=>$c)if(!empty($s[$k]))$v.=$c.':'.$s[$k].';';
 $v.='--lh:'.intval($s['logo_h']).'px;--lhm:'.intval($s['logo_hm']).'px;';if($s['ann_bg'])$v.='--ab:'.$s['ann_bg'].';';if($s['ann_tx'])$v.='--at:'.$s['ann_tx'].';';
 $woo=class_exists('WooCommerce');
 $cu=$s['cart_url']?:($woo?wc_get_cart_url():home_url('/cart/'));
 $au=$s['account_url']?:($woo?wc_get_page_permalink('myaccount'):wp_login_url());
 $tu=$s['track_url']?:home_url('/track-order/');$wu=$s['wish_url']?:home_url('/wishlist/');
 $logo=$s['logo_img']?'<img src="'.esc_url($s['logo_img']).'" alt="'.esc_attr($s['logo_text']).'">':esc_html($s['logo_text']);
 $lab=function($x)use($t){return $t==='mega'?'':'<small>'.$x.'</small>';};
 $cart='<a class="hbp-ic hbp-cart" href="'.esc_url($cu).'" aria-label="Cart"><span class="hbp-i">'.self::ic('cart').'<span class="hbp-cnt">'.self::cnt().'</span></span>'.($t==='mega'?'<span class="hbp-tot">'.esc_html(self::tot()).'</span>':'<small>Cart</small>').'</a>';
 $acc='<a class="hbp-ic" href="'.esc_url($au).'" aria-label="Account"><span class="hbp-i">'.self::ic('user').'</span>'.$lab(is_user_logged_in()?'Account':'Sign In').'</a>';
 $trk='<a class="hbp-ic" href="'.esc_url($tu).'"><span class="hbp-i">'.self::ic('pin').'</span><small>Track Order</small></a>';
 $wish='<a class="hbp-ic" href="'.esc_url($wu).'" aria-label="Wishlist"><span class="hbp-i">'.self::ic('heart').'</span></a>';
 $more='<div class="hbp-ic hbp-more"><button type="button" data-hbp-toggle aria-label="More"><span class="hbp-i">'.self::ic('dots').'</span><small>More</small></button><div class="hbp-dd">'.self::links($s['more']).'</div></div>';
 $icons=['sunfry'=>$acc.$cart,'amar'=>$trk.$acc.$cart.$more,'mega'=>$wish.$acc.$cart][$t];
 $bar='';
 if($t==='sunfry'&&$s['cats'])$bar='<div class="hbp-bar"><nav class="hbp-wrap hbp-bn">'.self::links($s['cats']).'</nav></div>';
 if($t==='amar'&&$s['menu'])$bar='<div class="hbp-bar"><nav class="hbp-wrap hbp-bn">'.self::links($s['menu']).'</nav></div>';
 if($t==='mega')$bar='<div class="hbp-bar"><div class="hbp-wrap hbp-bn"><div class="hbp-browse"><button type="button" class="hbp-bc" data-hbp-toggle>'.self::ic('grid').'<b>BROWSE CATEGORIES</b>'.self::ic('down').'</button><div class="hbp-bl">'.self::links($s['cats']).'</div></div><nav class="hbp-bm">'.self::links($s['menu']).'</nav><nav class="hbp-br">'.self::links($s['more']).'</nav></div></div>';
 $gt=is_user_logged_in()?'My Account':'Sign In';
 $dr='<div class="hbp-ov"></div><aside class="hbp-drawer" aria-label="Menu"><div class="hbp-gc"><a href="'.esc_url($au).'" class="hbp-gu"><span class="hbp-av">'.self::ic('user').'</span><span><b>Hello, what are you looking for?</b><em>'.$gt.'</em></span></a><button type="button" class="hbp-x" aria-label="Close">×</button></div>';
 $pri=$s['cats']?:$s['menu'];$qa=$s['quick']?:($s['cats']?$s['menu']:[]);
 $dr.='<nav class="hbp-dl">'.self::links($pri).'</nav><div class="hbp-ds"></div><nav class="hbp-dl">'.($t==='mega'?'':'<a class="hbp-tk" href="'.esc_url($tu).'">Track Order</a>').self::links($s['more']).'</nav>';
 if($qa){$dr.='<h4 class="hbp-qh">Quick Action</h4><div class="hbp-qa">';foreach($qa as $q)$dr.='<a href="'.esc_url(self::u($q['url'])).'">'.self::ic('box').'<span>'.esc_html($q['label']).'</span>'.self::ic('chev').'</a>';$dr.='</div>';}
 $dr.='</aside>';
 $menu=$t==='sunfry'?'<nav class="hbp-menu">'.self::links($s['menu']).'</nav>':'';
 $ann=$s['ann']?'<div class="hbp-ann">'.($s['ann_url']?'<a href="'.esc_url($s['ann_url']).'">'.esc_html($s['ann']).'</a>':esc_html($s['ann'])).'</div>':'';
 return '<header class="hbp hbp-'.$t.($s['sticky']?' hbp-sticky':'').($s['bar_grad']?' hbp-grad':'').($s['shadow']?' hbp-shadow':'').($s['full']?' hbp-full':'').'" style="'.esc_attr($v).'">'.$ann.'<div class="hbp-top hbp-wrap"><button type="button" class="hbp-burger" aria-label="Menu" aria-expanded="false"><span></span><span></span><span></span></button><a class="hbp-logo" href="'.esc_url($s['logo_link']?:home_url('/')).'">'.$logo.'</a>'.$menu.'<form class="hbp-search" role="search" method="get" action="'.esc_url(home_url('/')).'"><input type="search" name="s" placeholder="'.esc_attr($s['search_ph']).'" aria-label="Search" value="'.esc_attr(get_search_query()).'">'.($woo?'<input type="hidden" name="post_type" value="product">':'').'<button type="submit" aria-label="Search">'.self::ic('search').'</button></form><div class="hbp-icons">'.$icons.'</div></div>'.$bar.$dr.'</header>';
}
/* ---------- admin ---------- */
static function menu(){add_menu_page('Header Builder','Header Builder','manage_options','hbp',[__CLASS__,'page'],'dashicons-welcome-widgets-menus',58);}
static function fld($k,$label,$type='text',$help=''){
 $s=self::get();$v=$s[$k]??'';$n=self::OPT."[$k]";echo '<div class="hbp-f"><label>'.esc_html($label).'</label>';
 if($type==='media')echo '<div class="hbp-media"><input type="text" name="'.$n.'" value="'.esc_attr($v).'"><button type="button" class="button hbp-pick">Choose</button>'.($v?'<img src="'.esc_url($v).'" alt="">':'').'</div>';
 elseif($type==='color')echo '<input type="text" class="hbp-color" name="'.$n.'" value="'.esc_attr($v).'">';
 elseif($type==='check')echo '<label class="hbp-sw"><input type="checkbox" name="'.$n.'" value="1" '.checked($v,1,false).'><i></i></label>';
 elseif($type==='num')echo '<input type="number" name="'.$n.'" value="'.esc_attr($v).'" min="16" max="200">';
 elseif($type==='number')echo '<input type="number" name="'.$n.'" value="'.esc_attr($v).'" min="480" max="1400">';
 else echo '<input type="text" name="'.$n.'" value="'.esc_attr($v).'">';
 if($help)echo '<p>'.esc_html($help).'</p>';echo '</div>';
}
static function row($k,$i,$r){$n=self::OPT."[$k][$i]";$r=$r+['label'=>'','url'=>'','badge'=>''];
 echo '<div class="hbp-row"><span class="hbp-drag">⋮⋮</span><input name="'.$n.'[label]" placeholder="Label" value="'.esc_attr($r['label']).'"><input name="'.$n.'[url]" placeholder="URL (/shop/ or https://…)" value="'.esc_attr($r['url']).'"><input class="sm" name="'.$n.'[badge]" placeholder="Badge" value="'.esc_attr($r['badge']).'"><button type="button" class="hbp-del" title="Remove">×</button></div>';}
static function rep($k,$title,$help){$s=self::get();
 echo '<div class="hbp-card"><h3>'.esc_html($title).'</h3><p class="hd">'.esc_html($help).'</p><div class="hbp-rep" data-k="'.$k.'">';
 foreach((array)$s[$k] as $i=>$r)self::row($k,$i,$r);
 echo '</div><button type="button" class="button hbp-add" data-k="'.$k.'">+ Add link</button><template id="hbp-t-'.$k.'">';self::row($k,'__i__',[]);echo '</template></div>';}
static function page(){
 $s=self::get();?>
<div class="wrap hbp-admin">
 <div class="hbp-ah"><div><h1>Header Builder Pro</h1><span>Shortcode: <code>[hbp_header]</code></span></div>
  <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>" onsubmit="return confirm('Current content replace hobe. Continue?')">
   <input type="hidden" name="action" value="hbp_demo"><?php wp_nonce_field('hbp_demo');?>
   <select name="template"><option value="sunfry">SunFry</option><option value="amar">Amar Bazar</option><option value="mega">MegaShop</option></select>
   <button class="button">Load demo content</button></form></div>
 <?php if(!empty($_GET['demo']))echo '<div class="notice notice-success is-dismissible"><p>Demo content loaded.</p></div>';?>
 <form method="post" action="options.php"><?php settings_fields('hbp_group');?>
 <div class="hbp-layout">
  <nav class="hbp-tabs"><button type="button" data-tab="tpl">🎨 Template</button><button type="button" data-tab="brand">🏷️ Branding & URLs</button><button type="button" data-tab="links">🔗 Menus & Links</button><button type="button" data-tab="style">🖌️ Colors & Layout</button><button type="button" data-tab="css">{ } Custom CSS</button></nav>
  <div class="hbp-panels">
   <div class="hbp-p" data-p="tpl"><div class="hbp-card"><h3>Choose Template</h3><div class="hbp-tcs">
    <?php foreach(['sunfry'=>['SunFry','Orange gradient bar, pill search','#f97f0f'],'amar'=>['Amar Bazar','Black menu bar, More dropdown','#000'],'mega'=>['MegaShop','Blue bar, Browse Categories','#0a4bdc']] as $k=>$x){?>
     <label class="hbp-tc<?php echo $s['template']===$k?' on':'';?>"><input type="radio" name="hbp_settings[template]" value="<?php echo $k;?>" <?php checked($s['template'],$k);?>><span class="sw" style="background:<?php echo $x[2];?>"></span><b><?php echo $x[0];?></b><small><?php echo $x[1];?></small></label>
    <?php }?></div></div>
    <div class="hbp-card"><h3>How to use</h3><p>Elementor → <b>Shortcode</b> widget (ba <b>Header Builder Pro</b> widget) → paste: <code>[hbp_header]</code><button type="button" class="button hbp-copy">Copy</button></p><p class="hd">Template change korle save korun, header auto update hobe. Sticky header-er jonno Elementor Theme Builder header e use korun.</p></div></div>
   <div class="hbp-p" data-p="brand"><div class="hbp-card"><h3>Branding</h3><?php self::fld('logo_img','Logo image','media','Khali rakhle text logo dekhabe.');self::fld('logo_text','Logo text');self::fld('logo_h','Logo height - Desktop (px)','num','Default 52. Logo boro/choto korte ei number change korun.');self::fld('logo_hm','Logo height - Mobile (px)','num','Default 40.');self::fld('logo_link','Logo link URL');self::fld('search_ph','Search placeholder');?></div>
    <div class="hbp-card"><h3>Page URLs</h3><?php self::fld('account_url','Account / Sign In URL','text','Khali = WooCommerce My Account');self::fld('cart_url','Cart URL','text','Khali = WooCommerce Cart');self::fld('track_url','Track Order URL');self::fld('wish_url','Wishlist URL');self::fld('live','Live product search suggestion','check','Typing korle product image, name, price dropdown e dekhabe.');self::fld('sticky','Sticky header','check');self::fld('full','Full width header','check','On korle header screen-er pura width e jabe, content boxed thakbe.');?></div></div>
   <div class="hbp-p" data-p="links"><?php
    self::rep('menu','Main Menu','SunFry: top row · Amar Bazar & MegaShop: navigation bar · Mobile: slide menu');
    self::rep('cats','Categories','SunFry: orange bar · MegaShop: Browse Categories dropdown');
    self::rep('quick','Quick Action (Mobile)','Mobile slide menu-r "Quick Action" section. Khali rakhle Menu links dekhabe.');
    self::rep('more','Extra Links','Amar Bazar: "More" dropdown · MegaShop: right side of bar (Track Order, Store Location)');?></div>
   <div class="hbp-p" data-p="style"><div class="hbp-card"><h3>Colors</h3><p class="hd">Khali rakhle template-er default color use hobe.</p><?php self::fld('accent','Accent (search border/button, badge)','color');self::fld('bar_bg','Menu bar background','color');self::fld('bar_text','Menu bar text','color');self::fld('text','Text color','color');self::fld('bg','Header background','color');self::fld('bar_grad','Menu bar gradient (off = solid color)','check');self::fld('shadow','Header bottom shadow','check');?></div>
    <div class="hbp-card"><h3>Announcement Bar (top)</h3><p class="hd">Khali rakhle dekhabe na. Eg: Free delivery over 1000৳</p><?php self::fld('ann','Text');self::fld('ann_url','Link URL');self::fld('ann_bg','Background','color');self::fld('ann_tx','Text color','color');?></div>
    <div class="hbp-card"><h3>Responsive</h3><?php self::fld('bp','Mobile breakpoint (px)','number','Ei width er niche hamburger menu dekhabe. Default 991. Minimum supported width 320px.');?></div></div>
   <div class="hbp-p" data-p="css"><div class="hbp-card"><h3>Custom CSS</h3><p class="hd">Selectors: <code>.hbp</code> <code>.hbp-top</code> <code>.hbp-search</code> <code>.hbp-bar</code> <code>.hbp-drawer</code></p><textarea name="hbp_settings[custom_css]" rows="16" spellcheck="false"><?php echo esc_textarea($s['custom_css']);?></textarea></div></div>
  </div></div>
  <div class="hbp-save"><button class="button button-primary button-hero">Save Changes</button></div>
 </form></div><?php }
}
HBP::init();
