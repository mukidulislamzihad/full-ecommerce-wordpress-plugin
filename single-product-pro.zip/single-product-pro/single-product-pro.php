<?php
/**
 * Plugin Name: Single Product Pro
 * Description: WooCommerce single product page. Shortcodes: [single_product_pro] (all), [spp_main], [spp_description], [spp_recent]. Full admin control + custom CSS.
 * Version: 1.0
 */
if (!defined('ABSPATH')) exit;

function spp_f(){return [
['_','General'],
['show_back','Show back link',1,'k'],['back_text','Back text','Back','t'],['show_bc','Show breadcrumb',1,'k'],['show_share','Show share icons',1,'k'],['share_label','Share label','Share on:','t'],
['max_w','Max width (px, 0=full)',1400,'n'],['gap','Gap between gallery & info (px)',40,'n'],['gal_w','Gallery width (%)',48,'n'],['bp','Mobile breakpoint (px)',768,'n'],['font','Font family (blank = theme)','','t'],
['primary','Primary color','#138a4b','c'],['text','Text color','#222222','c'],['muted','Muted text color','#6b7280','c'],['line','Border color','#e5e7eb','c'],
['_','Gallery'],
['img_ratio','Main image ratio','1/1','t'],['img_radius','Image radius (px)',14,'n'],['img_bg','Image background','#ffffff','c'],['show_zoom','Zoom button',1,'k'],['show_arrows','Gallery arrows',1,'k'],['show_thumbs','Thumbnails',1,'k'],['thumb_w','Thumbnail size (px)',100,'n'],['thumb_radius','Thumbnail radius (px)',8,'n'],['thumb_active','Active thumbnail color','#138a4b','c'],
['_','Title & Price'],
['title_size','Title size (px)',34,'n'],['title_weight','Title weight',700,'n'],['title_color','Title color','#111111','c'],['head_font','Heading font family (blank = theme)','','t'],
['short_show','Show short description',1,'k'],['short_size','Short desc size (px)',16,'n'],['short_color','Short desc color','#138a4b','c'],
['price_size','Price size (px)',38,'n'],['price_color','Price color','#138a4b','c'],['reg_color','Regular price color','#8a8a8a','c'],['show_off','Show discount badge',1,'k'],['off_text','Discount text ({p} = %)','-{p}% OFF','t'],['off_bg','Discount badge bg','#e11d1d','c'],['off_color','Discount badge text','#ffffff','c'],
['_','Variations'],
['var_label','Variation label ({attr} = name)','Select {attr}','t'],['var_price','Show price in option',1,'k'],['var_bg','Option background','#ffffff','c'],['var_border','Option border','#e5e7eb','c'],['var_active_bg','Selected background','#e6f6ee','c'],['var_active_border','Selected border','#138a4b','c'],['var_radius','Option radius (px)',8,'n'],['sel_msg','Select-option message','Please select an option','t'],
['_','Quantity & Buttons'],
['show_sub','Show subtotal',1,'k'],['sub_label','Subtotal label','Subtotal Price','t'],['qty_label','Quantity label','Quantity','t'],['save_text','Save text ({a} = amount)','Save {a}','t'],['save_color','Save badge color','#2563eb','c'],
['cart_text','Add to Cart text','Add to Cart','t'],['cart_bg','Add to Cart bg','#fdbb0e','c'],['cart_color','Add to Cart text color','#111111','c'],['added_text','Added text','Added ✓','t'],
['buy_show','Show Buy Now',1,'k'],['buy_text','Buy Now text','Buy Now','t'],['buy_bg','Buy Now bg','#138a4b','c'],['buy_color','Buy Now text color','#ffffff','c'],['buy_clear','Buy Now clears old cart items',1,'k'],
['btn_h','Button height (px)',52,'n'],['btn_radius','Button radius (px)',40,'n'],['btn_size','Button font size (px)',17,'n'],
['_','Call & WhatsApp'],
['call_show','Show call button',1,'k'],['call_number','Phone number','+8809613821489','t'],['call_sub','Call sub text','Call for Order','t'],
['wa_show','Show WhatsApp button',1,'k'],['wa_number','WhatsApp number (country code, no +)','8801700000000','t'],['wa_title','WhatsApp title','Order Via WhatsApp','t'],['wa_sub','WhatsApp sub text','Chat with us','t'],
['wa_msg','WhatsApp message ({product} {variation} {qty} {price} {url})','Hello, I want to order: {product} {variation} x{qty} - {url}','a'],['call_radius','Contact button radius (px)',40,'n'],
['_','Trust features'],
['trust_show','Show trust features',1,'k'],['trust_items',"Items — one per line: icon|title|subtitle (icons: truck, cash, shield, star, clock, gift)","truck|Fast Delivery|24-48 hours fast delivery\ncash|Cash on Delivery|Pay when you receive\nshield|Quality Guarantee|Pure & quality assured",'a'],['trust_bg','Icon background','#e6f6ee','c'],['trust_color','Icon color','#138a4b','c'],
['_','Description box'],
['desc_show','Show description in [single_product_pro]',1,'k'],['tab_desc','Description tab label','Description','t'],['tab_info_show','Additional info tab',1,'k'],['tab_info','Additional info label','Additional Information','t'],['tab_rev_show','Reviews tab',1,'k'],['tab_rev','Reviews label','Reviews','t'],
['collapse','Collapsed height (px, 0 = no Show more)',360,'n'],['more_text','Show more text','Show more','t'],['less_text','Show less text','Show less','t'],['tab_active','Active tab color','#138a4b','c'],['box_radius','Box radius (px)',12,'n'],
['_','Recently viewed'],
['rv_show','Show in [single_product_pro]',1,'k'],['rv_title','Heading','Recently viewed','t'],['rv_title_size','Heading size (px)',36,'n'],['rv_limit','Max products',8,'n'],['rv_fill','Fill with related/latest products if fewer viewed',1,'k'],['rv_d','Items – desktop',4,'n'],['rv_t','Items – tablet',3,'n'],['rv_m','Items – mobile',2,'n'],['rv_gap','Gap (px)',16,'n'],['rv_btn','Button text','Add to Cart','t'],['rv_btn_bg','Button bg','#138a4b','c'],['rv_btn_color','Button text color','#ffffff','c'],['rv_badge_bg','Badge bg','#e11d1d','c'],
];}
function spp_def(){$d=['css'=>''];foreach(spp_f() as $f)if($f[0]!=='_')$d[$f[0]]=$f[2];return $d;}
function spp_opt(){return wp_parse_args(get_option('spp_opts',[]),spp_def());}

add_action('admin_menu',function(){add_menu_page('Single Product Pro','Single Product Pro','manage_options','spp','spp_page','dashicons-cart',61);});
add_action('admin_enqueue_scripts',function($h){if($h==='toplevel_page_spp'){wp_enqueue_style('wp-color-picker');wp_enqueue_script('wp-color-picker');}});

function spp_page(){
 if(!empty($_POST['spp_go'])&&check_admin_referer('spp_s')&&current_user_can('manage_options')){
  $p=wp_unslash($_POST);$n=['css'=>wp_strip_all_tags($p['css']??'')];
  foreach(spp_f() as $f){if($f[0]==='_')continue;list($k,,$d,$t)=$f;$x=$p[$k]??'';
   if($t==='k')$n[$k]=empty($x)?0:1;elseif($t==='n')$n[$k]=(float)$x;elseif($t==='c')$n[$k]=sanitize_hex_color($x)?:$d;elseif($t==='a')$n[$k]=sanitize_textarea_field($x);else $n[$k]=sanitize_text_field($x);}
  update_option('spp_opts',$n);echo '<div class="updated"><p>Saved.</p></div>';}
 $o=spp_opt();
 echo '<div class="wrap"><h1>Single Product Pro</h1><p>Shortcodes: <code>[single_product_pro]</code> (সব একসাথে) · <code>[spp_main]</code> · <code>[spp_description]</code> · <code>[spp_recent]</code><br>Elementor single product template-এ বসাও।</p><form method="post">';
 wp_nonce_field('spp_s');echo '<table class="form-table" style="max-width:820px">';
 foreach(spp_f() as $f){
  if($f[0]==='_'){echo '<tr><th colspan="2"><h2 style="margin:14px 0 0">'.esc_html($f[1]).'</h2></th></tr>';continue;}
  list($k,$l,,$t)=$f;echo '<tr><th>'.esc_html($l).'</th><td>';
  if($t==='k')echo '<input type="checkbox" name="'.$k.'" value="1" '.checked($o[$k],1,false).'>';
  elseif($t==='a')echo '<textarea name="'.$k.'" rows="4" style="width:100%;max-width:520px">'.esc_textarea($o[$k]).'</textarea>';
  else echo '<input type="'.($t==='n'?'number':'text').'" step="any" name="'.$k.'" value="'.esc_attr($o[$k]).'" class="'.($t==='c'?'spp-c':'').'" style="'.($t==='t'?'width:100%;max-width:520px':'').'">';
  echo '</td></tr>';}
 echo '</table><h2>Custom CSS</h2><textarea name="css" rows="10" style="width:100%;max-width:820px;font-family:monospace" placeholder=".spp-title{} .spp-cart{} .spp-buy{} .spp-pill{} .spp-card{} .spp-tab{}">'.esc_textarea($o['css']).'</textarea>';
 echo '<p><button class="button button-primary button-large" name="spp_go" value="1">Save</button></p></form></div><script>jQuery(function($){$(".spp-c").wpColorPicker();});</script>';
}

/* recently viewed tracking */
add_action('template_redirect',function(){
 if(!is_singular('product'))return;$id=get_queried_object_id();
 $l=!empty($_COOKIE['spp_rv'])?array_filter(array_map('absint',explode(',',sanitize_text_field(wp_unslash($_COOKIE['spp_rv']))))):[];
 $l=array_slice(array_merge([$id],array_diff($l,[$id])),0,20);
 if(!headers_sent())setcookie('spp_rv',implode(',',$l),time()+30*DAY_IN_SECONDS,COOKIEPATH?:'/');
});

/* ajax add to cart */
add_action('wp_ajax_spp_add','spp_add');add_action('wp_ajax_nopriv_spp_add','spp_add');
function spp_add(){
 if(!function_exists('WC'))wp_send_json_error(['msg'=>'Error']);
 if(null===WC()->cart&&function_exists('wc_load_cart'))wc_load_cart();
 $pid=absint($_POST['pid']??0);$q=max(1,absint($_POST['qty']??1));$vid=absint($_POST['vid']??0);$at=[];
 foreach((array)($_POST['attr']??[]) as $k=>$v)$at[sanitize_text_field(wp_unslash($k))]=sanitize_text_field(wp_unslash($v));
 if(!$pid)wp_send_json_error(['msg'=>'Error']);
 $o=spp_opt();if(!empty($_POST['buy'])&&$o['buy_clear'])WC()->cart->empty_cart();
 if(WC()->cart->add_to_cart($pid,$q,$vid,$at))wp_send_json_success(['checkout'=>wc_get_checkout_url()]);
 $n=wc_get_notices('error');$m='Could not add to cart';
 if($n){$x=reset($n);$m=wp_strip_all_tags(is_array($x)?($x['notice']??$m):$x);}
 wc_clear_notices();wp_send_json_error(['msg'=>$m]);
}

function spp_ic($n){
 $p=['cart'=>'<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.5 12h11l2-8H6"/><path d="M13 7v5M10.5 9.5h5"/>',
 'buy'=>'<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M4 7.5l8 4.5 8-4.5M12 12v9"/>',
 'phone'=>'<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
 'wa'=>'<path d="M3 21l1.6-4.6A8.5 8.5 0 1 1 8 19.6z"/><path d="M9 9c0 3 3 6 6 6l1-1.5-2-1-1 .7c-1-.5-1.8-1.3-2.3-2.3l.7-1-1-2z"/>',
 'truck'=>'<path d="M2 6h11v9H2zM13 9h4l3 3v3h-7"/><circle cx="6" cy="17" r="1.8"/><circle cx="16" cy="17" r="1.8"/>',
 'cash'=>'<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="3"/>',
 'shield'=>'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
 'star'=>'<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
 'clock'=>'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 'gift'=>'<rect x="3" y="8" width="18" height="4"/><path d="M5 12v9h14v-9M12 8v13M12 8c-3 0-5-1-4-3s4 0 4 3zM12 8c3 0 5-1 4-3s-4 0-4 3z"/>',
 'zoom'=>'<circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5M11 8v6M8 11h6"/>',
 'back'=>'<path d="M19 12H5M12 5l-7 7 7 7"/>'];
 return '<svg class="spp-i" viewBox="0 0 24 24" aria-hidden="true">'.($p[$n]??$p['star']).'</svg>';}

function spp_prod($a){$id=!empty($a['id'])?(int)$a['id']:get_the_ID();$p=$id?wc_get_product($id):null;return $p?:null;}

function spp_assets(){
 static $done=false;if($done||!function_exists('WC'))return '';$done=true;$o=spp_opt();extract($o,EXTR_SKIP);
 $hf=$head_font?"font-family:{$head_font};":'';$mx=$max_w?$max_w.'px':'none';$gw=(float)$gal_w;$iw=100-$gw;
 $css=".spp{--p:$primary;--tx:$text;--mu:$muted;--ln:$line;max-width:$mx;margin:0 auto 30px;width:100%;color:var(--tx);".($font?"font-family:$font;":'')."box-sizing:border-box}
.spp *{box-sizing:border-box}.spp .spp-i{width:1.25em;height:1.25em;flex:none;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.spp a{text-decoration:none}.spp button{font-family:inherit}
.spp-back{display:inline-flex;align-items:center;gap:6px;color:var(--tx);cursor:pointer;font-size:15px;margin:0 0 14px;background:none;border:0;padding:0}
.spp-top{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px 16px;font-size:14px;margin-bottom:16px}
.spp-bc{display:flex;flex-wrap:wrap;align-items:center;gap:4px 10px;color:var(--mu)}.spp-bc a{color:var(--mu)}.spp-bc span.cur{color:var(--tx);font-weight:500}.spp-bc i{font-style:normal;opacity:.6}
.spp-share{display:flex;align-items:center;gap:8px;color:var(--mu)}.spp-share a,.spp-share button{width:30px;height:30px;border-radius:50%;border:1px solid var(--ln);display:inline-flex;align-items:center;justify-content:center;color:var(--mu);font-size:12px;background:#fff;cursor:pointer;padding:0;font-weight:600}
.spp-grid{display:grid;grid-template-columns:minmax(0,{$gw}fr) minmax(0,{$iw}fr);gap:{$gap}px;align-items:start}
.spp-stage{position:relative;border:1px solid var(--ln);border-radius:{$img_radius}px;overflow:hidden;background:$img_bg;aspect-ratio:$img_ratio}
.spp-stage img.spp-img{width:100%;height:100%;object-fit:contain;display:block;margin:0}
.spp-zoom,.spp-garr{position:absolute;z-index:2;border:1px solid var(--ln);background:#fff;color:var(--tx);cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;box-shadow:0 1px 4px rgba(0,0,0,.08)}
.spp-zoom{top:14px;right:14px;width:36px;height:36px;border-radius:8px}
.spp-garr{top:50%;transform:translateY(-50%);width:40px;height:40px;border-radius:50%;font-size:22px;line-height:1}.spp-gp{left:14px}.spp-gn{right:14px}
.spp-thumbs{display:flex;gap:10px;margin-top:14px;overflow-x:auto;scrollbar-width:thin;padding-bottom:4px}
.spp-th{flex:0 0 {$thumb_w}px;width:{$thumb_w}px;aspect-ratio:1/1;border:2px solid var(--ln);border-radius:{$thumb_radius}px;overflow:hidden;cursor:pointer;padding:0;background:#fff;position:relative}
.spp-th img{width:100%;height:100%;object-fit:cover;display:block}.spp-th.on{border-color:$thumb_active}
.spp-th.on:after{content:'✓';position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:22px;height:22px;border-radius:50%;background:$thumb_active;color:#fff;font-size:13px;display:flex;align-items:center;justify-content:center}
.spp-title{margin:0 0 10px;font-size:{$title_size}px;font-weight:{$title_weight};color:$title_color;line-height:1.25;{$hf}}
.spp-short{font-size:{$short_size}px;color:$short_color;line-height:1.55;margin-bottom:14px}.spp-short p{margin:0 0 6px}
.spp-prow{display:flex;align-items:center;flex-wrap:wrap;gap:6px 12px;margin:10px 0 18px}
.spp-price{font-size:{$price_size}px;font-weight:700;color:$price_color;line-height:1.1}.spp-price *{color:inherit;text-decoration:none;background:none}
.spp-reg{font-size:18px;color:$reg_color;text-decoration:line-through}
.spp-off{background:$off_bg;color:$off_color;font-size:13px;font-weight:600;padding:3px 8px;border-radius:5px;line-height:1.3}
.spp-vlabel{font-size:17px;font-weight:600;margin:0 0 10px}.spp-vgroup{margin-bottom:16px}.spp-pills{display:flex;flex-wrap:wrap;gap:10px}
.spp-pill{position:relative;min-width:84px;padding:10px 14px;background:$var_bg;border:1px solid $var_border;border-radius:{$var_radius}px;cursor:pointer;text-align:center;color:var(--tx);line-height:1.35;font-size:14px}
.spp-pill b{display:block;font-weight:600}.spp-pill small{display:block;color:var(--mu);font-size:13px}
.spp-pill.on{background:$var_active_bg;border-color:$var_active_border}.spp-pill.on:after{content:'✓';position:absolute;top:-8px;right:-8px;width:20px;height:20px;border-radius:50%;background:$var_active_border;color:#fff;font-size:12px;display:flex;align-items:center;justify-content:center}
.spp-buyrow{display:flex;justify-content:space-between;align-items:flex-end;gap:14px;margin:6px 0 18px}
.spp-lbl{font-size:15px;font-weight:600;margin-bottom:8px}.spp-subp{font-size:26px;font-weight:700;color:$price_color;margin-right:8px}
.spp-save{display:inline-block;font-size:13px;font-weight:600;color:$save_color;border:1px solid $save_color;border-radius:5px;padding:2px 8px;vertical-align:middle}
.spp-qty{display:inline-flex;border:1px solid var(--ln);border-radius:8px;overflow:hidden;background:#fff}.spp-qty button{width:42px;height:46px;border:0;background:#fff;font-size:20px;cursor:pointer;color:var(--mu);padding:0}
.spp-qty input{width:56px;height:46px;border:0;text-align:center;font-size:17px;font-weight:600;background:#fff;padding:0;-moz-appearance:textfield;color:var(--tx)}.spp-qty input::-webkit-outer-spin-button,.spp-qty input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}
.spp-btns,.spp-ctc{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-bottom:14px}
.spp-btns.one{grid-template-columns:1fr}
.spp-cart,.spp-buy{display:flex;align-items:center;justify-content:center;gap:8px;height:{$btn_h}px;border:0;border-radius:{$btn_radius}px;font-size:{$btn_size}px;font-weight:600;cursor:pointer;padding:0 10px;white-space:nowrap;transition:opacity .2s;line-height:1}
.spp-cart{background:$cart_bg;color:$cart_color}.spp-buy{background:$buy_bg;color:$buy_color}.spp-cart.ld{opacity:.6}.spp .dis{opacity:.45;pointer-events:none}
.spp-cb{display:flex;align-items:center;justify-content:center;gap:12px;min-height:{$btn_h}px;padding:6px 12px;border:1px solid var(--ln);border-radius:{$call_radius}px;color:var(--tx);background:#fff;text-align:left;min-width:0}
.spp-cb .spp-i{width:26px;height:26px}.spp-cb b{display:block;font-size:16px;font-weight:600;line-height:1.3;overflow:hidden;text-overflow:ellipsis}.spp-cb small{display:block;color:var(--mu);font-size:13px}.spp-cb .t{min-width:0}
.spp-trust{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:18px;text-align:center}
.spp-tr .ic{width:42px;height:42px;border-radius:10px;background:$trust_bg;color:$trust_color;display:flex;align-items:center;justify-content:center;margin:0 auto 6px}.spp-tr b{display:block;font-size:13px}.spp-tr small{display:block;color:var(--mu);font-size:12px;line-height:1.4;margin-top:2px}
.spp-dbox{border:1px solid var(--ln);border-radius:{$box_radius}px;overflow:hidden;margin:36px 0;background:#fff}
.spp-tabs{display:flex;overflow-x:auto;background:#f9fafb;border-bottom:1px solid var(--ln)}
.spp-tab{padding:14px 22px;border:0;background:none;font-size:15px;font-weight:500;cursor:pointer;color:var(--tx);border-bottom:2px solid transparent;white-space:nowrap;margin-bottom:-1px}.spp-tab.on{color:$tab_active;border-bottom-color:$tab_active;font-weight:600}
.spp-pane{display:none;padding:16px 22px 22px}.spp-pane.on{display:block}
.spp-inner{position:relative;overflow:hidden;line-height:1.7}.spp-inner img{max-width:100%;height:auto}.spp-inner table{display:block;overflow-x:auto;max-width:100%}
.spp-pane.col .spp-inner{max-height:{$collapse}px}.spp-pane.col .spp-inner:after{content:'';position:absolute;left:0;right:0;bottom:0;height:70px;background:linear-gradient(transparent,#fff)}
.spp-more{margin-top:14px;padding:9px 16px;border:1px solid var(--ln);border-radius:8px;background:#fff;color:var(--p);font-weight:600;cursor:pointer;font-size:14px}
.spp-rvh{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;gap:10px}.spp-rvt{margin:0;font-size:{$rv_title_size}px;font-weight:700;line-height:1.2;{$hf}}
.spp-rva{display:flex;gap:10px}.spp-rva button{width:40px;height:40px;border-radius:50%;border:1px solid var(--ln);background:#fff;color:var(--tx);font-size:22px;cursor:pointer;padding:0;line-height:1}
.spp-rv{--pv:$rv_d;--g:{$rv_gap}px}.spp-track{display:flex;gap:var(--g);overflow-x:auto;scroll-snap-type:x mandatory;scroll-behavior:smooth;scrollbar-width:none}.spp-track::-webkit-scrollbar{display:none}
.spp-card{position:relative;flex:0 0 calc((100% - var(--g)*(var(--pv) - 1))/var(--pv));min-width:0;scroll-snap-align:start;border:1px solid var(--ln);border-radius:14px;padding:12px;display:flex;flex-direction:column;background:#fff}
.spp-card .im{display:block;aspect-ratio:1/1;overflow:hidden;border-radius:10px}.spp-card .im img{width:100%;height:100%;object-fit:contain;display:block;margin:0}
.spp-card .bd{position:absolute;top:12px;right:12px;z-index:2;background:$rv_badge_bg;color:#fff;font-size:12px;font-weight:600;padding:2px 7px;border-radius:5px}
.spp-card .nm{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;margin:12px 0 6px;font-size:15px;font-weight:500;color:var(--tx);line-height:1.4;min-height:2.8em}
.spp-card .pr{margin:0 0 12px;font-size:19px;font-weight:700;color:var(--p);margin-top:auto}.spp-card .pr *{color:inherit;text-decoration:none;background:none}.spp-card .pr del{font-size:.7em;opacity:.6;font-weight:400;text-decoration:line-through;margin-left:4px}
.spp-card .bt{display:flex;align-items:center;justify-content:center;gap:8px;height:46px;border-radius:40px;background:$rv_btn_bg;color:$rv_btn_color!important;font-size:16px;font-weight:600;padding:0 8px;white-space:nowrap;overflow:hidden}.spp-card .added_to_cart{display:none}
.spp-lb{position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;cursor:zoom-out}.spp-lb img{max-width:100%;max-height:100%;object-fit:contain}
@media(max-width:{$bp}px){.spp-grid{grid-template-columns:minmax(0,1fr);gap:22px}.spp-title{font-size:".max(22,$title_size-10)."px}.spp-price{font-size:".max(26,$price_size-8)."px}.spp-th{flex-basis:70px;width:70px}.spp-pane{padding:14px}.spp-tab{padding:12px 16px}.spp-rvt{font-size:".max(22,$rv_title_size-12)."px}.spp-dbox{margin:26px 0}}
@media(max-width:1024px){.spp-rv{--pv:$rv_t}}
@media(max-width:640px){.spp-rv{--pv:$rv_m;--g:10px}.spp-card{padding:9px}.spp-card .nm{font-size:13px}.spp-card .pr{font-size:15px}.spp-card .bt{font-size:13px;height:38px;gap:5px}.spp-rva button{width:34px;height:34px}.spp-ctc{grid-template-columns:1fr}.spp-cart,.spp-buy{font-size:".max(13,$btn_size-3)."px;gap:5px}.spp-trust{gap:6px}.spp-tr b{font-size:12px}.spp-tr small{font-size:11px}.spp-subp{font-size:22px}.spp-buyrow{gap:8px}.spp-qty button{width:34px}.spp-qty input{width:42px}}
".$css;
 $js=<<<'JS'
(function(){var C=window.SPP||{};
function F(n){var s=n.toFixed(C.dec).split('.');s[0]=s[0].replace(/\B(?=(\d{3})+(?!\d))/g,C.ts);return C.fmt.replace('%1$s',C.cur).replace('%2$s',s.join(C.dec>0?C.ds:''));}
function Q(s,r){return(r||document).querySelector(s)}function A(s,r){return[].slice.call((r||document).querySelectorAll(s))}
A('.spp-main').forEach(function(w){
var D=JSON.parse(w.dataset.p),sel={},lab={},cur=null,qty=1,idx=0,E={price:Q('.spp-price',w),reg:Q('.spp-reg',w),off:Q('.spp-off',w),sub:Q('.spp-subp',w),save:Q('.spp-save',w),q:Q('.spp-q',w),cart:Q('.spp-cart',w),buy:Q('.spp-buy',w),wa:Q('.spp-wa',w),img:Q('.spp-img',w)},th=A('.spp-th',w);
A('.spp-pill.on',w).forEach(function(b){sel[b.dataset.k]=b.dataset.v;lab[b.dataset.k]=b.dataset.l});
function find(){if(D.type!=='variable')return null;if(Object.keys(sel).length<D.keys.length)return null;for(var i=0;i<D.vars.length;i++){var v=D.vars[i],ok=true;for(var k in v.attributes){if(v.attributes[k]!==''&&v.attributes[k]!==sel[k]){ok=false;break}}if(ok)return v}return null}
function show(i,keep){if(!th.length)return;idx=(i+th.length)%th.length;th.forEach(function(t,k){t.classList.toggle('on',k===idx)});if(keep)return;E.img.removeAttribute('srcset');E.img.src=th[idx].dataset.src;E.img.dataset.full=th[idx].dataset.full}
function up(img){var v=find(),p=null,r=0,st=true,mx=9999;cur=v;
if(D.type==='variable'){if(v){p=+v.display_price;r=+v.display_regular_price;st=v.is_in_stock;mx=(v.max_qty===''||v.max_qty===null||v.max_qty<=0)?9999:+v.max_qty}}else{p=D.price;r=D.reg;st=D.stock;mx=D.max>0?D.max:9999}
if(p!==null){E.price.textContent=F(p);if(r>p){E.reg.textContent=F(r);E.reg.style.display='';E.off.textContent=D.offt.replace('{p}',Math.round((r-p)/r*100));E.off.style.display=D.showoff?'':'none'}else{E.reg.style.display='none';E.off.style.display='none'}}
if(qty>mx)qty=mx;if(qty<1)qty=1;E.q.value=qty;
if(E.sub&&p!==null){E.sub.textContent=F(p*qty);if(r>p){E.save.textContent=D.savet.replace('{a}',F((r-p)*qty));E.save.style.display=''}else E.save.style.display='none'}
var ok=p!==null&&st;[E.cart,E.buy].forEach(function(b){if(b)b.classList.toggle('dis',!ok)});
if(img&&v&&v.image&&v.image.src){E.img.removeAttribute('srcset');E.img.src=v.image.src;E.img.dataset.full=v.image.full_src||v.image.src;var m=-1;th.forEach(function(t,k){if(t.dataset.id==v.image_id)m=k});if(m>-1)show(m,1)}
if(E.wa){var vt=Object.keys(lab).map(function(k){return lab[k]}).join(' / ');var msg=D.wamsg.replace('{product}',D.title).replace('{variation}',vt?'('+vt+')':'').replace('{qty}',qty).replace('{price}',p!==null?F(p*qty):'').replace('{url}',D.url);E.wa.href='https://wa.me/'+D.wanum+'?text='+encodeURIComponent(msg)}}
th.forEach(function(t,k){t.onclick=function(){show(k)}});
var gp=Q('.spp-gp',w),gn=Q('.spp-gn',w);if(gp){gp.onclick=function(){show(idx-1)};gn.onclick=function(){show(idx+1)}}
var z=Q('.spp-zoom',w);if(z)z.onclick=function(){var d=document.createElement('div');d.className='spp-lb';d.innerHTML='<img src="'+(E.img.dataset.full||E.img.src)+'">';d.onclick=function(){d.remove()};document.body.appendChild(d)};
A('.spp-pill',w).forEach(function(b){b.onclick=function(){var k=b.dataset.k;A('.spp-pill',b.parentNode).forEach(function(x){x.classList.remove('on')});b.classList.add('on');sel[k]=b.dataset.v;lab[k]=b.dataset.l;up(1)}});
Q('.spp-minus',w).onclick=function(){qty=Math.max(1,qty-1);up()};Q('.spp-plus',w).onclick=function(){qty++;up()};E.q.onchange=function(){qty=parseInt(E.q.value)||1;up()};
function add(buy,cb){if(D.type==='variable'&&!cur){alert(D.selmsg);return}var f=new FormData();f.append('action','spp_add');f.append('pid',D.id);f.append('qty',qty);f.append('vid',cur?cur.variation_id:0);f.append('buy',buy?1:0);for(var k in sel)f.append('attr['+k+']',sel[k]);
fetch(C.ajax,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(j){if(j.success)cb(j.data);else alert((j.data&&j.data.msg)||'Error')}).catch(function(){alert('Error')})}
if(E.cart)E.cart.onclick=function(){if(E.cart.classList.contains('dis')||E.cart.classList.contains('ld'))return;var s=Q('span',E.cart),o=s.textContent;E.cart.classList.add('ld');add(0,function(){s.textContent=D.added;E.cart.classList.remove('ld');if(window.jQuery)jQuery(document.body).trigger('wc_fragment_refresh');setTimeout(function(){s.textContent=o},1800)});setTimeout(function(){E.cart.classList.remove('ld')},6000)};
if(E.buy)E.buy.onclick=function(){if(E.buy.classList.contains('dis'))return;add(1,function(d){location.href=d.checkout})};
var bk=Q('.spp-back',w);if(bk)bk.onclick=function(){if(history.length>1)history.back();else location.href=D.shop};
var cp=Q('.spp-copy',w);if(cp)cp.onclick=function(){if(navigator.clipboard)navigator.clipboard.writeText(D.url);cp.textContent='✓'};
show(0,1);up();});
A('.spp-dbox').forEach(function(b){var tabs=A('.spp-tab',b),panes=A('.spp-pane',b);tabs.forEach(function(t,i){t.onclick=function(){tabs.forEach(function(x,k){x.classList.toggle('on',k===i);panes[k].classList.toggle('on',k===i)});chk(panes[i])}});
var col=+b.dataset.col,more=b.dataset.more,less=b.dataset.less;function chk(p){if(!col||p.dataset.init)return;p.dataset.init=1;var inn=Q('.spp-inner',p),btn=Q('.spp-more',p);if(!inn||!btn)return;if(inn.scrollHeight>col+40){p.classList.add('col');btn.style.display='';btn.textContent=more;btn.onclick=function(){var c=p.classList.toggle('col');btn.textContent=c?more:less}}}
chk(panes[0]);});
A('.spp-rv').forEach(function(r){var t=Q('.spp-track',r),c=Q('.spp-card',r);function s(d){c=Q('.spp-card',r);t.scrollBy({left:d*Math.max(c.offsetWidth+16,t.clientWidth-c.offsetWidth)})}var p=Q('.spp-rp',r),n=Q('.spp-rn',r);if(p){p.onclick=function(){s(-1)};n.onclick=function(){s(1)}}});
})();
JS;
 $cfg=['cur'=>html_entity_decode(get_woocommerce_currency_symbol(),ENT_QUOTES,'UTF-8'),'dec'=>wc_get_price_decimals(),'ts'=>wc_get_price_thousand_separator(),'ds'=>wc_get_price_decimal_separator(),'fmt'=>get_woocommerce_price_format(),'ajax'=>admin_url('admin-ajax.php')];
 return '<style>'.$css.'</style><script>window.SPP='.wp_json_encode($cfg).';</script><script>document.addEventListener("DOMContentLoaded",function(){'.$js.'});</script>';
}

function spp_main($a=[]){
 if(!function_exists('wc_get_product'))return '';$p=spp_prod($a);if(!$p)return '';$o=spp_opt();$id=$p->get_id();$url=get_permalink($id);
 $out=spp_assets();
 /* images */
 $ids=array_filter(array_merge([$p->get_image_id()],$p->get_gallery_image_ids()));$imgs=[];
 foreach($ids as $i){$s=wp_get_attachment_image_src($i,'large');$f=wp_get_attachment_image_src($i,'full');$t=wp_get_attachment_image_src($i,'thumbnail');if($s)$imgs[]=['id'=>$i,'src'=>$s[0],'full'=>$f?$f[0]:$s[0],'th'=>$t?$t[0]:$s[0]];}
 if(!$imgs){$ph=wc_placeholder_img_src();$imgs[]=['id'=>0,'src'=>$ph,'full'=>$ph,'th'=>$ph];}
 /* data */
 $D=['id'=>$id,'type'=>$p->is_type('variable')?'variable':'simple','title'=>$p->get_name(),'url'=>$url,'shop'=>wc_get_page_permalink('shop'),
  'offt'=>$o['off_text'],'showoff'=>(int)$o['show_off'],'savet'=>$o['save_text'],'added'=>$o['added_text'],'selmsg'=>$o['sel_msg'],'wamsg'=>$o['wa_msg'],'wanum'=>preg_replace('/\D/','',$o['wa_number']),
  'price'=>(float)wc_get_price_to_display($p),'reg'=>(float)wc_get_price_to_display($p,['price'=>$p->get_regular_price()]),'stock'=>$p->is_in_stock(),'max'=>(int)$p->get_max_purchase_quantity(),'vars'=>[],'keys'=>[]];
 $pills='';
 if($D['type']==='variable'){
  $vs=$p->get_available_variations();$D['vars']=$vs;$va=$p->get_variation_attributes();$def=[];
  foreach($p->get_default_attributes() as $k=>$v)$def['attribute_'.sanitize_title($k)]=$v;
  if(!$def&&$vs){foreach($vs as $v){if(!empty($v['is_in_stock'])){foreach($v['attributes'] as $k=>$x){$def[$k]=$x;}break;}}}
  $single=count($va)===1;
  foreach($va as $name=>$opts){
   $key='attribute_'.sanitize_title($name);$D['keys'][]=$key;
   if(!isset($def[$key])||$def[$key]==='')$def[$key]=is_array($opts)?reset($opts):'';
   $pills.='<div class="spp-vgroup"><div class="spp-vlabel">'.esc_html(str_replace('{attr}',wc_attribute_label($name,$p),$o['var_label'])).'</div><div class="spp-pills">';
   foreach((array)$opts as $op){
    $lb=taxonomy_exists($name)?(($tm=get_term_by('slug',$op,$name))?$tm->name:$op):$op;$pr='';
    if($single&&$o['var_price']){foreach($vs as $v){if(($v['attributes'][$key]??'')===$op||($v['attributes'][$key]??'x')===''){$pr='<small>'.wp_strip_all_tags(wc_price($v['display_price'])).'</small>';break;}}}
    $pills.='<button type="button" class="spp-pill'.(($def[$key]??'')===$op?' on':'').'" data-k="'.esc_attr($key).'" data-v="'.esc_attr($op).'" data-l="'.esc_attr($lb).'"><b>'.esc_html($lb).'</b>'.$pr.'</button>';}
   $pills.='</div></div>';}
 }
 /* breadcrumb */
 $bc='';if($o['show_bc']){$items=[[__('Home','woocommerce'),home_url('/')]];$tr=get_the_terms($id,'product_cat');
  if($tr&&!is_wp_error($tr)){$t0=reset($tr);$an=array_reverse(get_ancestors($t0->term_id,'product_cat'));foreach($an as $aid){$at=get_term($aid,'product_cat');if($at&&!is_wp_error($at))$items[]=[$at->name,get_term_link($at)];}$items[]=[$t0->name,get_term_link($t0)];}
  $items[]=[$p->get_name(),''];$n=count($items);$parts=[];
  foreach($items as $i=>$it)$parts[]=($i<$n-1&&!empty($it[1]))?'<a href="'.esc_url($it[1]).'">'.esc_html($it[0]).'</a>':'<span class="cur">'.esc_html($it[0]).'</span>';
  $bc='<div class="spp-bc">'.implode('<i>•</i>',$parts).'</div>';}
 $sh='';if($o['show_share']){$u=rawurlencode($url);$t=rawurlencode($p->get_name());$im=rawurlencode($imgs[0]['full']);
  $sh='<div class="spp-share">'.esc_html($o['share_label']).'<a target="_blank" rel="noopener" href="https://www.facebook.com/sharer/sharer.php?u='.$u.'">f</a><a target="_blank" rel="noopener" href="https://twitter.com/intent/tweet?url='.$u.'&text='.$t.'">X</a><a target="_blank" rel="noopener" href="https://pinterest.com/pin/create/button/?url='.$u.'&media='.$im.'&description='.$t.'">P</a><a target="_blank" rel="noopener" href="https://www.linkedin.com/sharing/share-offsite/?url='.$u.'">in</a><a target="_blank" rel="noopener" href="https://t.me/share/url?url='.$u.'&text='.$t.'">➤</a><button type="button" class="spp-copy" title="Copy link">⧉</button></div>';}
 ob_start();?>
<div class="spp spp-main" data-p="<?php echo esc_attr(wp_json_encode($D));?>">
<?php if($o['show_back'])echo '<button type="button" class="spp-back">'.spp_ic('back').esc_html($o['back_text']).'</button>';
 if($bc||$sh)echo '<div class="spp-top">'.$bc.$sh.'</div>';?>
<div class="spp-grid"><div class="spp-gal"><div class="spp-stage">
<img class="spp-img" src="<?php echo esc_url($imgs[0]['src']);?>" data-full="<?php echo esc_url($imgs[0]['full']);?>" alt="<?php echo esc_attr($p->get_name());?>">
<?php if($o['show_zoom'])echo '<button type="button" class="spp-zoom" aria-label="Zoom">'.spp_ic('zoom').'</button>';
 if($o['show_arrows']&&count($imgs)>1)echo '<button type="button" class="spp-garr spp-gp" aria-label="Prev">‹</button><button type="button" class="spp-garr spp-gn" aria-label="Next">›</button>';?>
</div>
<?php if($o['show_thumbs']&&count($imgs)>1){echo '<div class="spp-thumbs">';foreach($imgs as $m)echo '<button type="button" class="spp-th" data-id="'.(int)$m['id'].'" data-src="'.esc_url($m['src']).'" data-full="'.esc_url($m['full']).'"><img src="'.esc_url($m['th']).'" alt="" loading="lazy"></button>';echo '</div>';}?>
</div>
<div class="spp-info">
<h1 class="spp-title"><?php echo esc_html($p->get_name());?></h1>
<?php if($o['short_show']&&$p->get_short_description())echo '<div class="spp-short">'.do_shortcode(wpautop($p->get_short_description())).'</div>';?>
<div class="spp-prow"><span class="spp-price"><?php echo wp_kses_post($p->get_price_html());?></span><del class="spp-reg" style="display:none"></del><span class="spp-off" style="display:none"></span></div>
<?php echo $pills;?>
<div class="spp-buyrow">
<?php if($o['show_sub'])echo '<div><div class="spp-lbl">'.esc_html($o['sub_label']).'</div><span class="spp-subp"></span><span class="spp-save" style="display:none"></span></div>';else echo '<div></div>';?>
<div><div class="spp-lbl"><?php echo esc_html($o['qty_label']);?></div><div class="spp-qty"><button type="button" class="spp-minus">−</button><input class="spp-q" type="number" min="1" value="1" inputmode="numeric"><button type="button" class="spp-plus">+</button></div></div></div>
<div class="spp-btns<?php echo $o['buy_show']?'':' one';?>">
<button type="button" class="spp-cart"><?php echo spp_ic('cart');?><span><?php echo esc_html($o['cart_text']);?></span></button>
<?php if($o['buy_show'])echo '<button type="button" class="spp-buy">'.spp_ic('buy').'<span>'.esc_html($o['buy_text']).'</span></button>';?></div>
<?php if($o['call_show']||$o['wa_show']){echo '<div class="spp-ctc">';
 if($o['call_show'])echo '<a class="spp-cb" href="tel:'.esc_attr(preg_replace('/[^\d+]/','',$o['call_number'])).'">'.spp_ic('phone').'<span class="t"><b>'.esc_html($o['call_number']).'</b><small>'.esc_html($o['call_sub']).'</small></span></a>';
 if($o['wa_show'])echo '<a class="spp-cb spp-wa" target="_blank" rel="noopener" href="#">'.spp_ic('wa').'<span class="t"><b>'.esc_html($o['wa_title']).'</b><small>'.esc_html($o['wa_sub']).'</small></span></a>';
 echo '</div>';}
 if($o['trust_show']){echo '<div class="spp-trust">';foreach(preg_split('/\R/',trim($o['trust_items'])) as $ln){$x=array_map('trim',explode('|',$ln));if(count($x)<2)continue;echo '<div class="spp-tr"><div class="ic">'.spp_ic($x[0]).'</div><b>'.esc_html($x[1]).'</b>'.(!empty($x[2])?'<small>'.esc_html($x[2]).'</small>':'').'</div>';}echo '</div>';}?>
</div></div></div>
<?php return $out.ob_get_clean();}

function spp_desc($a=[]){
 if(!function_exists('wc_get_product'))return '';$p=spp_prod($a);if(!$p)return '';$o=spp_opt();$out=spp_assets();$id=$p->get_id();$tabs=[];
 $tabs[]=[$o['tab_desc'],do_shortcode(wpautop($p->get_description())),1];
 if($o['tab_info_show']&&($p->has_attributes()||$p->has_weight()||$p->has_dimensions())){ob_start();wc_display_product_attributes($p);$h=ob_get_clean();if($h)$tabs[]=[$o['tab_info'],$h,1];}
 if($o['tab_rev_show']&&comments_open($id)){global $product,$post;$product=$p;$post=get_post($id);ob_start();wc_get_template('single-product-reviews.php');$h=ob_get_clean();if($h)$tabs[]=[$o['tab_rev'],$h,0];}
 ob_start();?>
<div class="spp spp-dbox" data-col="<?php echo (int)$o['collapse'];?>" data-more="<?php echo esc_attr($o['more_text']);?>" data-less="<?php echo esc_attr($o['less_text']);?>">
<div class="spp-tabs"><?php foreach($tabs as $i=>$t)echo '<button type="button" class="spp-tab'.($i?'':' on').'">'.esc_html($t[0]).'</button>';?></div>
<?php foreach($tabs as $i=>$t){echo '<div class="spp-pane'.($i?'':' on').'"><div class="spp-inner">'.$t[1].'</div>'.($t[2]&&$o['collapse']?'<button type="button" class="spp-more" style="display:none"></button>':'').'</div>';}?>
</div>
<?php return $out.ob_get_clean();}

function spp_recent($a=[]){
 if(!function_exists('wc_get_products'))return '';$o=spp_opt();$cur=get_the_ID();
 $ids=!empty($_COOKIE['spp_rv'])?array_filter(array_map('absint',explode(',',sanitize_text_field(wp_unslash($_COOKIE['spp_rv']))))):[];
 $ids=array_values(array_diff($ids,[$cur]));$lim=max(1,(int)$o['rv_limit']);
 if($o['rv_fill']&&count($ids)<$lim){$ex=array_merge($ids,[$cur]);
  if($cur)$ids=array_merge($ids,array_diff(wc_get_related_products($cur,$lim),$ex));
  if(count($ids)<$lim)$ids=array_merge($ids,wc_get_products(['limit'=>$lim,'status'=>'publish','return'=>'ids','exclude'=>array_merge($ids,[$cur])]));
  $ids=array_slice(array_unique($ids),0,$lim);}
 if(!$ids)return '';
 $ps=wc_get_products(['include'=>$ids,'orderby'=>'post__in','limit'=>max(1,(int)$o['rv_limit']),'status'=>'publish']);if(!$ps)return '';
 $out=spp_assets();ob_start();?>
<div class="spp spp-rv"><div class="spp-rvh"><h2 class="spp-rvt"><?php echo esc_html($o['rv_title']);?></h2><div class="spp-rva"><button type="button" class="spp-rp" aria-label="Prev">‹</button><button type="button" class="spp-rn" aria-label="Next">›</button></div></div>
<div class="spp-track">
<?php foreach($ps as $pr){$u=get_permalink($pr->get_id());$bd='';
 if($pr->is_on_sale()){if($pr->is_type('variable')){$r=(float)$pr->get_variation_regular_price('min');$s=(float)$pr->get_variation_sale_price('min');}else{$r=(float)$pr->get_regular_price();$s=(float)$pr->get_sale_price();}
  if($r>0&&$s>0&&$s<$r)$bd='<span class="bd">-'.round(($r-$s)/$r*100).'%</span>';}
 $aj=$pr->supports('ajax_add_to_cart')&&$pr->is_purchasable()&&$pr->is_in_stock();
 echo '<div class="spp-card">'.$bd.'<a class="im" href="'.esc_url($u).'">'.$pr->get_image('woocommerce_thumbnail',['loading'=>'lazy']).'</a><a class="nm" href="'.esc_url($u).'">'.esc_html($pr->get_name()).'</a><div class="pr">'.wp_kses_post($pr->get_price_html()).'</div><a class="bt button'.($aj?' add_to_cart_button ajax_add_to_cart':'').'" href="'.esc_url($pr->add_to_cart_url()).'" data-product_id="'.$pr->get_id().'" data-quantity="1" rel="nofollow">'.spp_ic('cart').'<span>'.esc_html($pr->is_type('simple')&&$aj?$o['rv_btn']:$pr->add_to_cart_text()).'</span></a></div>';}?>
</div></div>
<?php return $out.ob_get_clean();}

function spp_safe($fn,$a){$l=ob_get_level();
 try{if($fn==='all'){$o=spp_opt();return spp_main($a).($o['desc_show']?spp_desc($a):'').($o['rv_show']?spp_recent($a):'');}return $fn($a);}
 catch(Throwable $e){while(ob_get_level()>$l)ob_end_clean();error_log('SPP: '.$e->getMessage().' @'.$e->getFile().':'.$e->getLine());
  return current_user_can('manage_options')?'<pre style="white-space:pre-wrap;background:#fee;padding:10px;color:#900">SPP error: '.esc_html($e->getMessage().' @ line '.$e->getLine()).'</pre>':'';}}
add_shortcode('spp_main',function($a){return spp_safe('spp_main',$a);});
add_shortcode('spp_description',function($a){return spp_safe('spp_desc',$a);});
add_shortcode('spp_recent',function($a){return spp_safe('spp_recent',$a);});
add_shortcode('single_product_pro',function($a){return spp_safe('all',$a);});
