<?php
/**
 * Plugin Name: Connect Box (Social Links + Mission & Vision)
 * Description: Shortcode [connect_box] — Google Review, Instagram, WhatsApp, Messenger, Facebook links + Mission & Vision. Fully editable from admin, with Custom CSS.
 * Version: 1.2.0
 * Author: You
 */
if ( ! defined( 'ABSPATH' ) ) exit;

const CBX_OPT = 'cbx_settings';

function cbx_defaults() {
	return array(
		'show_links' => 1, 'show_mv' => 1, 'browse_show' => 1, 'browse_text' => '🛍️ আমাদের প্রোডাক্ট ব্রাউজ করুন', 'browse_url' => '', 'links_title' => 'Connect With Us', 'brand_colors' => 1,
		'google_url' => '', 'google_label' => 'Review us on Google',
		'instagram_url' => '', 'instagram_label' => 'Follow on Instagram',
		'whatsapp_url' => '', 'whatsapp_label' => 'Chat on WhatsApp',
		'messenger_url' => '', 'messenger_label' => 'Message on Messenger',
		'facebook_url' => '', 'facebook_label' => 'Like our Facebook Page',
		'mission_title' => 'Our Mission', 'mission_text' => '',
		'vision_title' => 'Our Vision', 'vision_text' => '',
		'bg' => '#ffffff', 'card_bg' => '#f7f8fa', 'heading' => '#1d2327', 'text' => '#4b5563',
		'btn_bg' => '#2563eb', 'btn_text' => '#ffffff', 'accent' => '#2563eb',
		'show_fb' => 1, 'fb_title' => 'Share Your Experience', 'fb_sub' => 'আপনার অভিজ্ঞতা আমাদের জানান', 'fb_btn' => 'Submit', 'fb_success' => 'ধন্যবাদ! আপনার মতামত সফলভাবে জমা হয়েছে।', 'fb_notify' => 1,
		'fb_l_name' => 'নাম (Name)', 'fb_l_phone' => 'ফোন (Phone)', 'fb_l_email' => 'ইমেইল (Email)', 'fb_l_msg' => 'আপনার অভিজ্ঞতা *', 'fb_l_rating' => 'আপনার রেটিং', 'fb_show_rating' => 1, 'fb_max' => 500, 'fb_confetti' => 1, 'fb_redirect' => 1, 'fb_redirect_msg' => 'ধন্যবাদ! Google এ রিভিউ দিতে নিয়ে যাচ্ছি...', 'form_bg' => '#ffffff', 'input_bg' => '#f7f8fa', 'input_border' => '#d5d9e0', 'title_size' => 26,
		'radius' => 14, 'columns' => 3, 'custom_css' => '',
	);
}
function cbx_get() { return wp_parse_args( get_option( CBX_OPT, array() ), cbx_defaults() ); }

function cbx_networks() {
	return array(
		'google'    => array( '#f4b400', '<path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8-6.2-3.3-6.2 3.3L8 14.2 3 9.3l6.9-1z"/>' ),
		'instagram' => array( '#e1306c', '<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.5" cy="6.5" r="1.2"/>' ),
		'whatsapp'  => array( '#25d366', '<path d="M12 2a10 10 0 0 0-8.6 15L2 22l5.1-1.3A10 10 0 1 0 12 2zm5.2 13.9c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-4-4.7-4.2-.1-.2-1.1-1.5-1.1-2.8s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.4.1.6-.1l.8-1c.2-.3.4-.2.6-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.3z"/>' ),
		'messenger' => array( '#0084ff', '<path d="M12 2C6.5 2 2 6.2 2 11.5c0 2.9 1.3 5.5 3.5 7.2V22l3.2-1.8c1 .3 2 .4 3.3.4 5.5 0 10-4.2 10-9.5S17.5 2 12 2zm1 12.8l-2.5-2.7-4.9 2.7 5.4-5.7 2.6 2.7 4.8-2.7-5.4 5.7z"/>' ),
		'facebook'  => array( '#1877f2', '<path d="M22 12a10 10 0 1 0-11.6 9.9v-7H7.9V12h2.5V9.8c0-2.5 1.5-3.9 3.8-3.9 1.1 0 2.2.2 2.2.2v2.5h-1.3c-1.2 0-1.6.8-1.6 1.6V12h2.8l-.4 2.9h-2.3v7A10 10 0 0 0 22 12z"/>' ),
	);
}

/* ---------- Admin ---------- */
add_action( 'admin_menu', function () {
	add_menu_page( 'Connect Box', 'Connect Box', 'manage_options', 'cbx', 'cbx_page', 'dashicons-share', 58 );
	add_submenu_page( 'cbx', 'Connect Box Settings', 'Settings', 'manage_options', 'cbx', 'cbx_page' );
} );
add_action( 'admin_init', function () {
	register_setting( 'cbx_group', CBX_OPT, 'cbx_sanitize' );
} );
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'toplevel_page_cbx' !== $hook ) return;
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
	wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){$(".cbx-color").wpColorPicker();});' );
} );

function cbx_sanitize( $in ) {
	$d = cbx_defaults(); $out = array();
	foreach ( $d as $k => $v ) {
		$val = isset( $in[ $k ] ) ? $in[ $k ] : '';
		if ( in_array( $k, array( 'show_links', 'show_mv', 'brand_colors', 'browse_show', 'fb_notify', 'show_fb', 'fb_show_rating', 'fb_confetti', 'fb_redirect' ), true ) ) $out[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
		elseif ( substr( $k, -4 ) === '_url' ) $out[ $k ] = sanitize_text_field( $val ); // allows number for WhatsApp
		elseif ( in_array( $k, array( 'bg', 'card_bg', 'heading', 'text', 'btn_bg', 'btn_text', 'accent', 'form_bg', 'input_bg', 'input_border' ), true ) ) $out[ $k ] = sanitize_hex_color( $val ) ?: $v;
		elseif ( 'fb_max' === $k ) $out[ $k ] = max( 50, min( 5000, (int) $val ) );
		elseif ( in_array( $k, array( 'radius', 'columns', 'title_size' ), true ) ) $out[ $k ] = max( 0, min( 60, (int) $val ) );
		elseif ( 'custom_css' === $k ) $out[ $k ] = wp_strip_all_tags( $val );
		elseif ( in_array( $k, array( 'mission_text', 'vision_text' ), true ) ) $out[ $k ] = wp_kses_post( $val );
		else $out[ $k ] = sanitize_text_field( $val );
	}
	return $out;
}

function cbx_page() {
	$o = cbx_get(); $n = CBX_OPT;
	$f = function ( $k, $label, $type = 'text', $ph = '' ) use ( $o, $n ) {
		echo '<tr><th><label>' . esc_html( $label ) . '</label></th><td>';
		if ( 'color' === $type ) echo '<input class="cbx-color" name="' . $n . '[' . $k . ']" value="' . esc_attr( $o[ $k ] ) . '">';
		elseif ( 'check' === $type ) echo '<label><input type="checkbox" name="' . $n . '[' . $k . ']" value="1" ' . checked( $o[ $k ], 1, false ) . '> Enable</label>';
		elseif ( 'area' === $type ) echo '<textarea class="large-text" rows="4" name="' . $n . '[' . $k . ']">' . esc_textarea( $o[ $k ] ) . '</textarea>';
		elseif ( 'code' === $type ) echo '<textarea class="large-text code" rows="10" name="' . $n . '[' . $k . ']" placeholder=".cbx-card{...}">' . esc_textarea( $o[ $k ] ) . '</textarea>';
		elseif ( 'number' === $type ) echo '<input type="number" class="small-text" name="' . $n . '[' . $k . ']" value="' . esc_attr( $o[ $k ] ) . '">';
		else echo '<input type="text" class="regular-text" name="' . $n . '[' . $k . ']" value="' . esc_attr( $o[ $k ] ) . '" placeholder="' . esc_attr( $ph ) . '">';
		echo '</td></tr>';
	};
	?>
	<div class="wrap"><h1>Connect Box Settings</h1>
	<div class="notice notice-info"><p>নিচে Links ও Mission/Vision fill korun. <b>খালি রাখলে</b> website a oi section dekhabe na. Feedback dekhte: <b>Connect Box → Feedback</b>.</p></div>
	<p>Shortcode: <code>[connect_box]</code> &nbsp; | &nbsp; শুধু links: <code>[connect_box show="links"]</code> &nbsp; | &nbsp; শুধু mission/vision: <code>[connect_box show="mv"]</code> &nbsp; | &nbsp; শুধু form: <code>[connect_box show="form"]</code></p>
	<form method="post" action="options.php"><?php settings_fields( 'cbx_group' ); ?>
	<h2>Sections</h2><table class="form-table">
		<?php $f( 'show_links', 'Social Links Section', 'check' ); $f( 'browse_show', 'Browse Products Button (Connect With Us এর উপরে)', 'check' ); $f( 'browse_text', 'Browse Button Text' ); $f( 'browse_url', 'Browse Button URL (খালি রাখলে Shop page)' ); $f( 'links_title', 'Links Section Title' ); $f( 'show_mv', 'Mission & Vision Section', 'check' ); ?>
	</table>
	<h2>Links (খালি রাখলে ওই button দেখাবে না)</h2><table class="form-table">
		<?php
		$f( 'google_url', 'Google Review URL', 'text', 'https://g.page/r/.../review' ); $f( 'google_label', 'Google Button Text' );
		$f( 'instagram_url', 'Instagram URL', 'text', 'https://instagram.com/yourpage' ); $f( 'instagram_label', 'Instagram Button Text' );
		$f( 'whatsapp_url', 'WhatsApp Number / Link', 'text', '8801XXXXXXXXX অথবা https://wa.me/...' ); $f( 'whatsapp_label', 'WhatsApp Button Text' );
		$f( 'messenger_url', 'Messenger URL', 'text', 'https://m.me/yourpage' ); $f( 'messenger_label', 'Messenger Button Text' );
		$f( 'facebook_url', 'Facebook Page URL', 'text', 'https://facebook.com/yourpage' ); $f( 'facebook_label', 'Facebook Button Text' );
		?>
	</table>
	<h2>Mission & Vision</h2><table class="form-table">
		<?php $f( 'mission_title', 'Mission Title' ); $f( 'mission_text', 'Mission Text', 'area' ); $f( 'vision_title', 'Vision Title' ); $f( 'vision_text', 'Vision Text', 'area' ); ?>
	</table>
	<h2>Feedback Form</h2><table class="form-table">
		<?php $f( 'show_fb', 'Show form inside [connect_box]', 'check' ); $f( 'fb_title', 'Form Title' ); $f( 'fb_sub', 'Sub Text' ); $f( 'fb_btn', 'Button Text' ); $f( 'fb_l_name', 'Name Label' ); $f( 'fb_l_phone', 'Phone Label' ); $f( 'fb_l_email', 'Email Label' ); $f( 'fb_l_msg', 'Experience Label' ); $f( 'fb_show_rating', 'Show star rating (1-5)', 'check' ); $f( 'fb_l_rating', 'Rating Label' ); $f( 'fb_max', 'Max characters (50-5000)', 'number' ); $f( 'fb_confetti', 'Confetti after submit', 'check' ); $f( 'fb_redirect', 'Rating 4-5 হলে Google Review এ পাঠান (Google Review URL লাগবে)', 'check' ); $f( 'fb_redirect_msg', 'Redirect message' ); $f( 'fb_success', 'Success Message' ); $f( 'fb_notify', 'Email me on new feedback', 'check' ); ?>
	</table>
	<p>সব feedback দেখুন: <b>Connect Box → Feedback</b></p>
	<h2>Design</h2><table class="form-table">
		<?php
		$f( 'brand_colors', 'Use Brand Icon Colors', 'check' );
		$f( 'bg', 'Section Background', 'color' ); $f( 'card_bg', 'Card Background', 'color' );
		$f( 'heading', 'Heading Color', 'color' ); $f( 'text', 'Text Color', 'color' );
		$f( 'btn_bg', 'Button Background (brand colors off হলে)', 'color' ); $f( 'btn_text', 'Button Text Color', 'color' );
		$f( 'accent', 'Accent Color (Mission/Vision border)', 'color' ); $f( 'form_bg', 'Feedback Form Background', 'color' ); $f( 'input_bg', 'Form Input Background', 'color' ); $f( 'input_border', 'Form Input Border', 'color' ); $f( 'title_size', 'Title Font Size (px)', 'number' );
		$f( 'radius', 'Corner Radius (px)', 'number' ); $f( 'columns', 'Link Columns (desktop, 1-5)', 'number' );
		?>
	</table>
	<h2>Custom CSS</h2><table class="form-table"><?php $f( 'custom_css', 'Your CSS', 'code' ); ?></table>
	<p class="description">Classes: .cbx-wrap .cbx-title .cbx-links .cbx-card .cbx-icon .cbx-mv .cbx-mv-box</p>
	<?php submit_button(); ?></form></div>
	<?php
}

/* ---------- Frontend ---------- */
add_shortcode( 'connect_box', function ( $atts ) {
	$o = cbx_get();
	$a = shortcode_atts( array( 'show' => 'all' ), $atts );
	$id = 'cbx-' . wp_rand( 100, 9999 );
	$cols = max( 1, min( 5, (int) $o['columns'] ) );
	$css = "#$id{--bg:{$o['bg']};--card:{$o['card_bg']};--h:{$o['heading']};--t:{$o['text']};--btn:{$o['btn_bg']};--btnt:{$o['btn_text']};--ac:{$o['accent']};--r:{$o['radius']}px;--cols:$cols}"
	. "#$id{background:var(--bg);padding:32px 20px;border-radius:var(--r);font-family:inherit;color:var(--t);box-sizing:border-box}"
	. "#$id *{box-sizing:border-box}#$id:empty{display:none}"
	. "#$id .cbx-title{color:var(--h);text-align:center;font-size:{$o['title_size']}px;margin:0 0 22px;font-weight:700}"
	. "#$id .cbx-browse{text-align:center;margin:0 auto 30px;max-width:560px}#$id a.cbx-browse-btn{position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;gap:12px;width:100%;padding:20px 24px;border-radius:60px;background:linear-gradient(135deg,#ff9a1f,#ff5e00);color:#fff!important;text-decoration:none!important;font-size:clamp(17px,4.8vw,22px);font-weight:800;line-height:1.3;box-shadow:0 16px 34px rgba(255,94,0,.42);border:3px solid #fff;outline:3px solid rgba(255,122,0,.35);animation:cbxGlow 2.2s infinite;transition:transform .2s}#$id a.cbx-browse-btn:hover{transform:translateY(-4px) scale(1.02)}#$id a.cbx-browse-btn:active{transform:scale(.97)}"
	. "#$id a.cbx-browse-btn:before{content:'';position:absolute;top:0;left:-80%;width:50%;height:100%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.55),transparent);transform:skewX(-20deg);animation:cbxShineB 3s infinite}#$id a.cbx-browse-btn b{display:inline-block;font-size:26px;animation:cbxNudge 1.2s infinite}"
	. "@keyframes cbxGlow{0%,100%{box-shadow:0 16px 34px rgba(255,94,0,.42),0 0 0 0 rgba(255,122,0,.5)}50%{box-shadow:0 16px 34px rgba(255,94,0,.42),0 0 0 14px rgba(255,122,0,0)}}@keyframes cbxShineB{0%{left:-80%}60%,100%{left:130%}}@keyframes cbxNudge{0%,100%{transform:translateX(0)}50%{transform:translateX(7px)}}"
	. "#$id .cbx-links{display:grid;grid-template-columns:repeat(var(--cols),1fr);gap:14px;max-width:1000px;margin:0 auto 34px}"
	. "#$id .cbx-card{display:flex;align-items:center;gap:12px;padding:14px 16px;background:var(--card);color:var(--h);text-decoration:none;border-radius:var(--r);box-shadow:0 2px 8px rgba(0,0,0,.06);transition:transform .2s,box-shadow .2s;font-weight:600;font-size:15px;line-height:1.3}"
	. "#$id .cbx-card:hover{transform:translateY(-3px);box-shadow:0 8px 20px rgba(0,0,0,.12)}"
	. "#$id .cbx-icon{flex:0 0 42px;width:42px;height:42px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:var(--btn);color:var(--btnt)}"
	. "#$id .cbx-icon svg{width:22px;height:22px;fill:currentColor}"
	. "#$id .cbx-mv{display:grid;grid-template-columns:repeat(2,1fr);gap:18px;max-width:1000px;margin:0 auto 34px}"
	. "#$id .cbx-mv-box{background:var(--card);padding:24px;border-radius:var(--r);border-top:4px solid var(--ac);box-shadow:0 2px 8px rgba(0,0,0,.06)}"
	. "#$id .cbx-mv-box h3{margin:0 0 10px;color:var(--h);font-size:20px}"
	. "#$id .cbx-mv-box p{margin:0;line-height:1.7}"
	. "@media(max-width:900px){#$id .cbx-links{grid-template-columns:repeat(2,1fr)}}"
	. "@media(max-width:600px){#$id .cbx-links,#$id .cbx-mv{grid-template-columns:1fr}}";
	$custom = $o['custom_css'];

	ob_start();
	echo '<style>' . $css . $custom . '</style><div id="' . esc_attr( $id ) . '" class="cbx-wrap">';

	if ( in_array( $a['show'], array( 'all', 'mv' ), true ) && $o['show_mv'] && ( $o['mission_text'] || $o['vision_text'] ) ) {
		echo '<div class="cbx-mv">';
		if ( $o['mission_text'] ) echo '<div class="cbx-mv-box"><h3>' . esc_html( $o['mission_title'] ) . '</h3><p>' . wp_kses_post( nl2br( $o['mission_text'] ) ) . '</p></div>';
		if ( $o['vision_text'] ) echo '<div class="cbx-mv-box"><h3>' . esc_html( $o['vision_title'] ) . '</h3><p>' . wp_kses_post( nl2br( $o['vision_text'] ) ) . '</p></div>';
		echo '</div>';
	}
	if ( in_array( $a['show'], array( 'all', 'links' ), true ) && $o['show_links'] ) {
		if ( $o['browse_show'] ) {
			$bu = trim( $o['browse_url'] );
			if ( '' === $bu ) $bu = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
			echo '<div class="cbx-browse"><a class="cbx-browse-btn" href="' . esc_url( $bu ) . '"><span>' . esc_html( $o['browse_text'] ) . '</span><b aria-hidden="true">&rarr;</b></a></div>';
		}
		$items = '';
		foreach ( cbx_networks() as $k => $net ) {
			$url = trim( $o[ $k . '_url' ] );
			if ( '' === $url ) continue;
			if ( 'whatsapp' === $k && preg_match( '/^\+?[0-9\s-]+$/', $url ) ) $url = 'https://wa.me/' . preg_replace( '/\D/', '', $url );
			$style = $o['brand_colors'] ? ' style="background:' . $net[0] . ';color:#fff"' : '';
			$items .= '<a class="cbx-card cbx-' . $k . '" href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer"><span class="cbx-icon"' . $style . '><svg viewBox="0 0 24 24" aria-hidden="true">' . $net[1] . '</svg></span><span>' . esc_html( $o[ $k . '_label' ] ) . '</span></a>';
		}
		if ( $items ) {
			if ( $o['links_title'] ) echo '<h2 class="cbx-title">' . esc_html( $o['links_title'] ) . '</h2>';
			echo '<div class="cbx-links">' . $items . '</div>';
		}
	}
	echo '</div>';
	if ( in_array( $a['show'], array( 'all', 'form' ), true ) && $o['show_fb'] ) echo cbx_feedback_html();
	return ob_get_clean();
} );

/* ---------- Feedback form ---------- */
add_action( 'init', function () {
	register_post_type( 'cbx_feedback', array(
		'labels' => array( 'name' => 'Feedback', 'singular_name' => 'Feedback', 'all_items' => 'Feedback' ),
		'public' => false, 'show_ui' => true, 'show_in_menu' => 'cbx', 'supports' => array( 'title' ),
		'capability_type' => 'post', 'map_meta_cap' => true, 'capabilities' => array( 'create_posts' => 'do_not_allow' ),
	) );
} );
function cbx_fb_fields() {
	return array( 'name' => 'Name', 'phone' => 'Phone', 'email' => 'Email', 'message' => 'Experience', 'rating' => 'Rating', 'page' => 'Page', 'ip' => 'IP', 'user' => 'Logged-in User' );
}
add_filter( 'manage_cbx_feedback_posts_columns', function () {
	return array( 'cb' => '<input type="checkbox">', 'title' => 'Name', 'cbx_rating' => 'Rating', 'cbx_phone' => 'Phone', 'cbx_email' => 'Email', 'cbx_message' => 'Experience', 'date' => 'Date' );
} );
add_action( 'manage_cbx_feedback_posts_custom_column', function ( $col, $id ) {
	$k = str_replace( 'cbx_', '', $col );
	if ( 'rating' === $k ) { $r = (int) get_post_meta( $id, 'rating', true ); echo $r ? esc_html( str_repeat( '★', $r ) . str_repeat( '☆', 5 - $r ) ) : '—'; return; }
	echo esc_html( 'message' === $k ? wp_trim_words( get_post_meta( $id, 'message', true ), 18 ) : get_post_meta( $id, $k, true ) );
}, 10, 2 );
add_action( 'add_meta_boxes', function () {
	add_meta_box( 'cbx_details', 'Feedback Details', function ( $post ) {
		echo '<table class="widefat striped">';
		foreach ( cbx_fb_fields() as $k => $l ) echo '<tr><th style="width:150px">' . esc_html( $l ) . '</th><td>' . nl2br( esc_html( get_post_meta( $post->ID, $k, true ) ) ) . '</td></tr>';
		echo '</table>';
	}, 'cbx_feedback', 'normal', 'high' );
} );

add_action( 'wp_ajax_cbx_submit', 'cbx_submit' );
add_action( 'wp_ajax_nopriv_cbx_submit', 'cbx_submit' );
function cbx_submit() {
	check_ajax_referer( 'cbx_fb', 'nonce' );
	if ( ! empty( $_POST['website'] ) ) wp_send_json_success(); // honeypot
	$g = function ( $k ) { return isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : ''; };
	$name = $g( 'name' ); $phone = $g( 'phone' ); $email = $g( 'email' );
	$msg = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
	$o0 = cbx_get(); $msg = mb_substr( $msg, 0, (int) $o0['fb_max'] );
	$rating = isset( $_POST['rating'] ) ? max( 0, min( 5, (int) $_POST['rating'] ) ) : 0;
	if ( '' === $msg ) wp_send_json_error( 'দয়া করে আপনার অভিজ্ঞতা লিখুন।' );
	$u = wp_get_current_user();
	if ( $u->exists() ) { // logged-in customer: fill blanks from account
		if ( ! $email ) $email = $u->user_email;
		if ( ! $phone ) $phone = get_user_meta( $u->ID, 'billing_phone', true );
		if ( ! $name ) $name = $u->display_name;
	}
	if ( $email && ! is_email( $email ) ) wp_send_json_error( 'Email সঠিক নয়।' );
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : '';
	$tk = 'cbx_rl_' . md5( $ip );
	if ( get_transient( $tk ) ) wp_send_json_error( 'একটু পরে আবার চেষ্টা করুন।' );
	set_transient( $tk, 1, 30 );
	$id = wp_insert_post( array( 'post_type' => 'cbx_feedback', 'post_status' => 'publish', 'post_title' => $name ?: 'Anonymous' ) );
	if ( ! $id ) wp_send_json_error( 'Error, আবার চেষ্টা করুন।' );
	$meta = array( 'name' => $name, 'phone' => $phone, 'email' => $email, 'message' => $msg, 'rating' => $rating ? $rating : '', 'page' => esc_url_raw( $g( 'page' ) ), 'ip' => $ip, 'user' => $u->exists() ? $u->user_login . ' (#' . $u->ID . ')' : 'Guest' );
	foreach ( $meta as $k => $v ) update_post_meta( $id, $k, $v );
	$o = cbx_get();
	if ( $o['fb_notify'] ) {
		$body = '';
		foreach ( cbx_fb_fields() as $k => $l ) $body .= $l . ': ' . $meta[ $k ] . "\n";
		wp_mail( get_option( 'admin_email' ), 'New Feedback - ' . get_bloginfo( 'name' ), $body );
	}
	$resp = array( 'msg' => $o['fb_success'] );
	$gu = trim( $o['google_url'] );
	if ( $o['fb_redirect'] && $rating >= 4 && preg_match( '#^https?://#i', $gu ) ) { $resp['google'] = esc_url_raw( $gu ); $resp['msg'] = $o['fb_redirect_msg']; }
	wp_send_json_success( $resp );
}

function cbx_feedback_html() {
	$o = cbx_get(); $id = 'cbxf-' . wp_rand( 100, 9999 );
	$u = wp_get_current_user(); $n = $e = $p = '';
	if ( $u->exists() ) { $n = $u->display_name; $e = $u->user_email; $p = get_user_meta( $u->ID, 'billing_phone', true ); }
	$css = "#$id{--bg:{$o['form_bg']};--card:{$o['input_bg']};--bd:{$o['input_border']};--h:{$o['heading']};--t:{$o['text']};--btn:{$o['btn_bg']};--btnt:{$o['btn_text']};--r:{$o['radius']}px}"
	. "#$id{max-width:640px;margin:24px auto;background:var(--bg);padding:28px 22px;border-radius:var(--r);color:var(--t);box-sizing:border-box;box-shadow:0 4px 18px rgba(0,0,0,.07)}"
	. "#$id *{box-sizing:border-box}#$id h2{color:var(--h);text-align:center;margin:0 0 6px;font-size:{$o['title_size']}px}#$id .cbx-sub{text-align:center;margin:0 0 20px}"
	. "#$id label{display:block;font-weight:600;color:var(--h);margin:0 0 6px;font-size:14px}"
	. "#$id input,#$id textarea{width:100%;padding:12px 14px;border:1px solid var(--bd);border-radius:calc(var(--r)*.6);background:var(--card);color:var(--h);font:inherit}"
	. "#$id input:focus,#$id textarea:focus{outline:2px solid var(--btn);border-color:transparent}"
	. "#$id .cbx-row{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px}#$id .cbx-full{margin-bottom:14px}"
	. "#$id button{width:100%;padding:14px;border:0;border-radius:calc(var(--r)*.6);background:var(--btn);color:var(--btnt);font:inherit;font-weight:700;cursor:pointer;transition:opacity .2s}#$id button:hover{opacity:.88}#$id button:disabled{opacity:.6}"
	. "#$id .cbx-msg{margin-top:14px;padding:12px 14px;border-radius:calc(var(--r)*.6);display:none;text-align:center;font-weight:600}"
	. "#$id .cbx-ok{display:block;background:#e7f8ee;color:#157347}#$id .cbx-err{display:block;background:#fdecec;color:#b42318}#$id .cbx-hp{position:absolute;left:-9999px}"
	. "#$id .cbx-stars{display:flex;justify-content:center;gap:6px;margin:0 0 4px}#$id .cbx-star{font-size:40px;line-height:1;cursor:pointer;color:#d9dce1;transition:transform .15s,color .15s;user-select:none;-webkit-tap-highlight-color:transparent}#$id .cbx-star.on{color:#ffb400;text-shadow:0 3px 10px rgba(255,180,0,.45)}#$id .cbx-star:hover{transform:scale(1.2)}"
	. "#$id .cbx-rtxt{text-align:center;font-size:14px;font-weight:600;min-height:22px;margin:0 0 14px}#$id .cbx-count{text-align:right;font-size:12px;margin-top:4px;color:#888}#$id .cbx-count.warn{color:#e11d48}#$id .cbx-msg a{color:inherit;text-decoration:underline}"
	. ".cbx-confetti{position:fixed;top:-14px;width:10px;height:14px;z-index:99999;pointer-events:none;animation:cbxFall linear forwards}@keyframes cbxFall{to{transform:translateY(105vh) rotate(720deg)}}"
	. "@media(max-width:600px){#$id .cbx-row{grid-template-columns:1fr}#$id .cbx-star{font-size:36px}}";
	ob_start(); ?>
	<style><?php echo $css . $o['custom_css']; // phpcs:ignore ?></style>
	<div id="<?php echo esc_attr( $id ); ?>" class="cbx-wrap cbx-feedback">
		<h2 class="cbx-title"><?php echo esc_html( $o['fb_title'] ); ?></h2>
		<p class="cbx-sub"><?php echo esc_html( $o['fb_sub'] ); ?></p>
		<form novalidate>
			<div class="cbx-row">
				<div><label><?php echo esc_html( $o['fb_l_name'] ); ?></label><input type="text" name="name" value="<?php echo esc_attr( $n ); ?>"></div>
				<div><label><?php echo esc_html( $o['fb_l_phone'] ); ?></label><input type="tel" name="phone" value="<?php echo esc_attr( $p ); ?>"></div>
			</div>
			<div class="cbx-full"><label><?php echo esc_html( $o['fb_l_email'] ); ?></label><input type="email" name="email" value="<?php echo esc_attr( $e ); ?>"></div>
			<?php if ( $o['fb_show_rating'] ) : ?>
			<div class="cbx-full"><label style="text-align:center"><?php echo esc_html( $o['fb_l_rating'] ); ?></label><div class="cbx-stars" role="radiogroup"><?php for ( $i = 1; $i <= 5; $i++ ) echo '<span class="cbx-star" role="radio" tabindex="0" aria-label="' . $i . '" data-v="' . $i . '">★</span>'; ?></div><div class="cbx-rtxt"></div><input type="hidden" name="rating" value="0"></div>
			<?php endif; ?>
			<div class="cbx-full"><label><?php echo esc_html( $o['fb_l_msg'] ); ?></label><textarea name="message" rows="5" required maxlength="<?php echo (int) $o['fb_max']; ?>"></textarea><div class="cbx-count"><span>0</span>/<?php echo (int) $o['fb_max']; ?></div></div>
			<input class="cbx-hp" type="text" name="website" tabindex="-1" autocomplete="off">
			<button type="submit"><?php echo esc_html( $o['fb_btn'] ); ?></button>
			<div class="cbx-msg"></div>
		</form>
	</div>
	<script>
	(function(){
	var w=document.getElementById('<?php echo esc_js( $id ); ?>'),f=w.querySelector('form'),m=w.querySelector('.cbx-msg'),b=f.querySelector('button'),
	st=w.querySelectorAll('.cbx-star'),rv=f.querySelector('input[name=rating]'),rt=w.querySelector('.cbx-rtxt'),
	ta=f.querySelector('textarea'),ct=w.querySelector('.cbx-count span'),MAX=<?php echo (int) $o['fb_max']; ?>,CONF=<?php echo (int) $o['fb_confetti']; ?>,
	T=['','😞 খুব খারাপ','😕 খারাপ','😐 মোটামুটি','😊 ভালো','🤩 চমৎকার'];
	function setR(v){if(!rv)return;rv.value=v;st.forEach(function(s){s.classList.toggle('on',+s.getAttribute('data-v')<=v)});rt.textContent=T[v]||'';}
	st.forEach(function(s){var v=+s.getAttribute('data-v');s.addEventListener('click',function(){setR(v)});s.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();setR(v)}});});
	function cnt(){ct.textContent=ta.value.length;ct.parentNode.classList.toggle('warn',ta.value.length>MAX*.9);}
	ta.addEventListener('input',cnt);
	function confetti(){var c=['#ff8a00','#ff5e00','#25d366','#0084ff','#e1306c','#f4b400'];for(var i=0;i<80;i++){var e=document.createElement('i');e.className='cbx-confetti';e.style.left=Math.random()*100+'vw';e.style.background=c[i%c.length];e.style.animationDuration=(2+Math.random()*2)+'s';e.style.animationDelay=(Math.random()*.6)+'s';e.style.borderRadius=Math.random()>.5?'50%':'2px';document.body.appendChild(e);(function(x){setTimeout(function(){x.remove()},5000)})(e);}}
	f.addEventListener('submit',function(ev){ev.preventDefault();m.className='cbx-msg';
	var d=new FormData(f);d.append('action','cbx_submit');d.append('nonce','<?php echo esc_js( wp_create_nonce( 'cbx_fb' ) ); ?>');d.append('page',location.href);b.disabled=true;
	fetch('<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>',{method:'POST',body:d,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){
	b.disabled=false;
	if(r.success){var x=r.data||{};var msg=(typeof x==='object')?(x.msg||''):x;f.reset();setR(0);cnt();m.textContent=msg;m.className='cbx-msg cbx-ok';if(CONF)confetti();
	if(x.google){m.appendChild(document.createElement('br'));var a=document.createElement('a');a.href=x.google;a.target='_blank';a.rel='noopener';a.textContent='👉 Google Review';m.appendChild(a);setTimeout(function(){location.href=x.google},2800);}}
	else{m.textContent=r.data||'Error';m.className='cbx-msg cbx-err';}
	}).catch(function(){b.disabled=false;m.textContent='Network error';m.className='cbx-msg cbx-err';});});})();
	</script>
	<?php
	return ob_get_clean();
}
add_shortcode( 'connect_feedback', 'cbx_feedback_html' );
