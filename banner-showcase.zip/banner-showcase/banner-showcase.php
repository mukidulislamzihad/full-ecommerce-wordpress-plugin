<?php
/**
 * Plugin Name: Banner Showcase
 * Description: Slider + side banners layout. Shortcode: [banner_showcase]. Full admin control + custom CSS.
 * Version: 1.0
 */
if (!defined('ABSPATH')) exit;

function bsw_defaults(){
  return ['main'=>[],'side'=>[],'css'=>'','cfg'=>[
    'autoplay'=>1,'delay'=>4000,'speed'=>600,'effect'=>'slide','gap'=>15,'radius'=>14,
    'rw'=>2,'rh'=>1,'side_w'=>36,'dots'=>1,'dot_color'=>'#ffffff','dot_active'=>'#1db954','dot_bg'=>'#e9edf0',
    'dot_size'=>9,'arrows'=>0,'newtab'=>0,'zoom'=>1,'shadow'=>0,'bp'=>768,'m_rw'=>16,'m_rh'=>9,'m_cols'=>2,'m_gap'=>10,'max_w'=>1400
  ]];
}
function bsw_opt(){
  $d=bsw_defaults(); $o=get_option('bsw_opts',[]);
  $o=wp_parse_args($o,$d); $o['cfg']=wp_parse_args($o['cfg'],$d['cfg']); return $o;
}

add_action('admin_menu',function(){
  add_menu_page('Banner Showcase','Banner Showcase','manage_options','bsw','bsw_page','dashicons-images-alt2',58);
});
add_action('admin_enqueue_scripts',function($h){
  if($h!=='toplevel_page_bsw')return; wp_enqueue_media(); wp_enqueue_style('wp-color-picker'); wp_enqueue_script('wp-color-picker');
});

function bsw_save(){
  if(!current_user_can('manage_options')||!check_admin_referer('bsw_save'))return;
  $p=wp_unslash($_POST); $d=bsw_defaults(); $o=['main'=>[],'side'=>[]];
  foreach(['main','side'] as $k){
    foreach(($p[$k]??[]) as $r){ $i=esc_url_raw($r['img']??''); if(!$i)continue;
      $o[$k][]=['img'=>$i,'link'=>esc_url_raw($r['link']??''),'alt'=>sanitize_text_field($r['alt']??'')]; }
  }
  $c=[]; $in=$p['cfg']??[];
  foreach($d['cfg'] as $k=>$v){
    if(in_array($k,['dot_color','dot_active','dot_bg'])) $c[$k]=sanitize_hex_color($in[$k]??'')?:$v;
    elseif($k==='effect') $c[$k]=(($in[$k]??'')==='fade')?'fade':'slide';
    elseif(in_array($k,['autoplay','dots','arrows','newtab','zoom','shadow'])) $c[$k]=empty($in[$k])?0:1;
    else $c[$k]=max(0,(float)($in[$k]??$v));
  }
  $o['cfg']=$c; $o['css']=wp_strip_all_tags($p['css']??'');
  update_option('bsw_opts',$o);
  echo '<div class="updated"><p>Saved.</p></div>';
}

function bsw_row($k,$i,$r){
  ?><div class="bsw-row" style="display:flex;gap:8px;align-items:center;margin:6px 0;padding:8px;background:#fff;border:1px solid #ddd">
  <img src="<?php echo esc_url($r['img']);?>" style="width:90px;height:50px;object-fit:cover;background:#eee">
  <input type="hidden" class="bsw-img" name="<?php echo $k;?>[<?php echo $i;?>][img]" value="<?php echo esc_attr($r['img']);?>">
  <button type="button" class="button bsw-pick">Image</button>
  <input type="text" placeholder="Link URL" name="<?php echo $k;?>[<?php echo $i;?>][link]" value="<?php echo esc_attr($r['link']);?>" style="flex:1">
  <input type="text" placeholder="Alt text" name="<?php echo $k;?>[<?php echo $i;?>][alt]" value="<?php echo esc_attr($r['alt']);?>" style="width:140px">
  <button type="button" class="button bsw-up">↑</button><button type="button" class="button bsw-dn">↓</button>
  <button type="button" class="button bsw-del">✕</button></div><?php
}

function bsw_page(){
  if(!empty($_POST['bsw_submit']))bsw_save();
  $o=bsw_opt(); $c=$o['cfg'];
  $f=function($k,$label,$type='number',$step='1')use($c){
    echo '<tr><th>'.esc_html($label).'</th><td><input type="'.$type.'" step="'.$step.'" name="cfg['.$k.']" value="'.esc_attr($c[$k]).'" class="'.($type==='text'?'bsw-color':'').'"></td></tr>';};
  $chk=function($k,$label)use($c){
    echo '<tr><th>'.esc_html($label).'</th><td><input type="checkbox" name="cfg['.$k.']" value="1" '.checked($c[$k],1,false).'></td></tr>';};
  ?><div class="wrap"><h1>Banner Showcase</h1>
  <p>Shortcode: <code>[banner_showcase]</code> — Elementor-এ Shortcode widget-এ বসাও।</p>
  <form method="post"><?php wp_nonce_field('bsw_save');?>
  <h2>Main Slider</h2><div id="bsw-main"><?php foreach($o['main'] as $i=>$r)bsw_row('main',$i,$r);?></div>
  <button type="button" class="button button-primary bsw-add" data-t="main">+ Add Slide</button>
  <h2>Side Banners (উপরে থেকে নিচে)</h2><div id="bsw-side"><?php foreach($o['side'] as $i=>$r)bsw_row('side',$i,$r);?></div>
  <button type="button" class="button button-primary bsw-add" data-t="side">+ Add Side Banner</button>
  <h2>Settings</h2><table class="form-table" style="max-width:700px">
  <?php
  $chk('autoplay','Autoplay');$f('delay','Autoplay delay (ms)');$f('speed','Transition speed (ms)');
  echo '<tr><th>Effect</th><td><select name="cfg[effect]"><option value="slide" '.selected($c['effect'],'slide',false).'>Slide</option><option value="fade" '.selected($c['effect'],'fade',false).'>Fade</option></select></td></tr>';
  $f('max_w','Max width (px, 0 = full)');$f('gap','Gap (px)');$f('radius','Border radius (px)');
  $f('rw','Main ratio — width');$f('rh','Main ratio — height');$f('side_w','Side column width (%)');
  $chk('dots','Show dots');$f('dot_size','Dot size (px)');$f('dot_color','Dot color','text');$f('dot_active','Active dot color','text');$f('dot_bg','Dots background','text');
  $chk('arrows','Show arrows');$chk('newtab','Open links in new tab');$chk('zoom','Hover zoom');$chk('shadow','Box shadow');
  $f('bp','Mobile breakpoint (px)');$f('m_rw','Mobile main ratio — width');$f('m_rh','Mobile main ratio — height');
  $f('m_cols','Mobile side banners per row');$f('m_gap','Mobile gap (px)');
  ?></table>
  <h2>Custom CSS</h2><textarea name="css" rows="10" style="width:100%;max-width:700px;font-family:monospace" placeholder=".bsw-main{} .bsw-side-item{} .bsw-dots{}"><?php echo esc_textarea($o['css']);?></textarea>
  <p><button class="button button-primary button-large" name="bsw_submit" value="1">Save</button></p></form></div>
  <script>
  jQuery(function($){
    $('.bsw-color').wpColorPicker();
    function re(){['main','side'].forEach(function(k){$('#bsw-'+k+' .bsw-row').each(function(i){
      $(this).find('[name]').each(function(){this.name=this.name.replace(/^(main|side)\[\d+\]/,k+'['+i+']');});});});}
    $(document).on('click','.bsw-del',function(){$(this).closest('.bsw-row').remove();re();});
    $(document).on('click','.bsw-up',function(){var r=$(this).closest('.bsw-row');r.prev().before(r);re();});
    $(document).on('click','.bsw-dn',function(){var r=$(this).closest('.bsw-row');r.next().after(r);re();});
    function pick(cb){var m=wp.media({multiple:false,library:{type:'image'}});m.on('select',function(){cb(m.state().get('selection').first().toJSON().url);});m.open();}
    $(document).on('click','.bsw-pick',function(){var r=$(this).closest('.bsw-row');pick(function(u){r.find('.bsw-img').val(u);r.find('img').attr('src',u);});});
    $('.bsw-add').on('click',function(){var k=$(this).data('t');pick(function(u){var i=$('#bsw-'+k+' .bsw-row').length;
      $('#bsw-'+k).append('<div class="bsw-row" style="display:flex;gap:8px;align-items:center;margin:6px 0;padding:8px;background:#fff;border:1px solid #ddd"><img src="'+u+'" style="width:90px;height:50px;object-fit:cover"><input type="hidden" class="bsw-img" name="'+k+'['+i+'][img]" value="'+u+'"><button type="button" class="button bsw-pick">Image</button><input type="text" placeholder="Link URL" name="'+k+'['+i+'][link]" style="flex:1"><input type="text" placeholder="Alt text" name="'+k+'['+i+'][alt]" style="width:140px"><button type="button" class="button bsw-up">↑</button><button type="button" class="button bsw-dn">↓</button><button type="button" class="button bsw-del">✕</button></div>');});});
  });
  </script><?php
}

add_shortcode('banner_showcase',function(){
  static $n=0; $n++; $o=bsw_opt(); $c=$o['cfg'];
  if(!$o['main']&&!$o['side'])return '';
  $id='bsw-'.$n; $t=$c['newtab']?' target="_blank" rel="noopener"':'';
  $item=function($r,$cls)use($t){
    $img='<img src="'.esc_url($r['img']).'" alt="'.esc_attr($r['alt']).'" loading="lazy" draggable="false">';
    return $r['link']?'<a class="'.$cls.'" href="'.esc_url($r['link']).'"'.$t.'>'.$img.'</a>':'<div class="'.$cls.'">'.$img.'</div>';};
  $sw=(float)$c['side_w']; $sh=$c['shadow']?'box-shadow:0 4px 14px rgba(0,0,0,.15);':'';
  $css="#$id{width:100%;max-width:".($c['max_w']?$c['max_w'].'px':'none').";margin:0 auto;display:grid;grid-template-columns:minmax(0,".(100-$sw)."fr) minmax(0,{$sw}fr);gap:{$c['gap']}px;box-sizing:border-box}
#$id *{box-sizing:border-box}
#$id .bsw-main{position:relative;overflow:hidden;border-radius:{$c['radius']}px;aspect-ratio:{$c['rw']}/{$c['rh']};{$sh}touch-action:pan-y}
#$id .bsw-track{display:flex;height:100%;transition:transform {$c['speed']}ms ease}
#$id .bsw-slide{flex:0 0 100%;height:100%;display:block;position:relative;overflow:hidden}
#$id img{width:100%;height:100%;object-fit:cover;display:block;user-select:none;-webkit-user-drag:none".($c['zoom']?";transition:transform .5s":"")."}
".($c['zoom']?"#$id a:hover img{transform:scale(1.05)}":"")."
#$id.fade .bsw-track{display:block;position:relative}
#$id.fade .bsw-slide{position:absolute;inset:0;opacity:0;transition:opacity {$c['speed']}ms;pointer-events:none}
#$id.fade .bsw-slide.on{opacity:1;pointer-events:auto}
#$id .bsw-side{position:relative}
#$id .bsw-side-in{position:absolute;inset:0;display:flex;flex-direction:column;gap:{$c['gap']}px}
#$id .bsw-side-item{flex:1;min-height:0;display:block;overflow:hidden;border-radius:{$c['radius']}px;{$sh}}
#$id .bsw-dots{position:absolute;left:50%;bottom:12px;transform:translateX(-50%);display:flex;gap:8px;padding:6px 10px;border-radius:30px;background:{$c['dot_bg']};z-index:3}
#$id .bsw-dot{width:{$c['dot_size']}px;height:{$c['dot_size']}px;border-radius:30px;background:{$c['dot_color']};border:1px solid rgba(0,0,0,.2);padding:0;cursor:pointer;transition:width .3s,background .3s}
#$id .bsw-dot.on{width:".($c['dot_size']*2.8)."px;background:{$c['dot_active']}}
#$id .bsw-arr{position:absolute;top:50%;transform:translateY(-50%);width:34px;height:34px;border-radius:50%;border:0;background:rgba(0,0,0,.45);color:#fff;font-size:18px;cursor:pointer;z-index:3;padding:0;line-height:1}
#$id .bsw-prev{left:8px}#$id .bsw-next{right:8px}
@media(max-width:{$c['bp']}px){
#$id{grid-template-columns:minmax(0,1fr);gap:{$c['m_gap']}px}
#$id .bsw-main{aspect-ratio:{$c['m_rw']}/{$c['m_rh']}}
#$id .bsw-side-in{position:static;display:grid;grid-template-columns:repeat({$c['m_cols']},minmax(0,1fr));gap:{$c['m_gap']}px}
#$id .bsw-side-item{aspect-ratio:16/10;flex:none}
#$id .bsw-dots{bottom:6px;gap:5px;padding:4px 7px}}
".$o['css'];
  ob_start(); ?>
<style><?php echo $css;?></style>
<div id="<?php echo $id;?>" class="bsw <?php echo $c['effect']==='fade'?'fade':'';?>" data-auto="<?php echo (int)$c['autoplay'];?>" data-delay="<?php echo (int)$c['delay'];?>">
<?php if($o['main']):?><div class="bsw-main"><div class="bsw-track">
<?php foreach($o['main'] as $r)echo str_replace('class="bsw-s','class="bsw-s',$item($r,'bsw-slide'));?></div>
<?php if($c['arrows']):?><button class="bsw-arr bsw-prev" aria-label="Prev">‹</button><button class="bsw-arr bsw-next" aria-label="Next">›</button><?php endif;?>
<?php if($c['dots']&&count($o['main'])>1):?><div class="bsw-dots"><?php foreach($o['main'] as $i=>$r)echo '<button class="bsw-dot" aria-label="Slide '.($i+1).'"></button>';?></div><?php endif;?>
</div><?php endif;?>
<?php if($o['side']):?><div class="bsw-side"><div class="bsw-side-in"><?php foreach($o['side'] as $r)echo $item($r,'bsw-side-item');?></div></div><?php endif;?>
</div>
<?php if($n===1):?><script>
document.addEventListener('DOMContentLoaded',function(){
document.querySelectorAll('.bsw').forEach(function(w){
var tr=w.querySelector('.bsw-track');if(!tr)return;
var s=[].slice.call(tr.children),d=[].slice.call(w.querySelectorAll('.bsw-dot')),i=0,t,fade=w.classList.contains('fade');
function go(n){i=(n+s.length)%s.length;if(fade)s.forEach(function(e,k){e.classList.toggle('on',k===i)});else tr.style.transform='translateX(-'+i*100+'%)';
d.forEach(function(e,k){e.classList.toggle('on',k===i)});}
function play(){clearInterval(t);if(+w.dataset.auto&&s.length>1)t=setInterval(function(){go(i+1)},+w.dataset.delay||4000);}
d.forEach(function(e,k){e.onclick=function(){go(k);play()}});
var p=w.querySelector('.bsw-prev'),x=w.querySelector('.bsw-next');
if(p)p.onclick=function(){go(i-1);play()};if(x)x.onclick=function(){go(i+1);play()};
var sx=null,m=w.querySelector('.bsw-main');
m.addEventListener('touchstart',function(e){sx=e.touches[0].clientX},{passive:true});
m.addEventListener('touchend',function(e){if(sx===null)return;var dx=e.changedTouches[0].clientX-sx;if(Math.abs(dx)>40){go(i+(dx<0?1:-1));play()}sx=null});
go(0);play();});});
</script><?php endif;
  return ob_get_clean();
});
