<?php
/**
 * Plugin Name: Visitor Analytics Lite
 * Description: Daily visitors, GeoIP, real IP, pages, devices, sources, WooCommerce funnel, live visitors, charts & map.
 * Version: 1.1
 */
if (!defined('ABSPATH')) exit;

function vat_t() { global $wpdb; return $wpdb->prefix . 'vat_hits'; }

register_activation_hook(__FILE__, function () {
    global $wpdb; $t = vat_t();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta("CREATE TABLE $t (
      id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
      vid varchar(32) NOT NULL DEFAULT '',
      type varchar(10) NOT NULL DEFAULT 'view',
      ip varchar(45) NOT NULL DEFAULT '',
      country varchar(60) NOT NULL DEFAULT '',
      city varchar(80) NOT NULL DEFAULT '',
      lat float NULL,
      lon float NULL,
      page varchar(255) NOT NULL DEFAULT '',
      pid bigint(20) unsigned NOT NULL DEFAULT 0,
      src varchar(60) NOT NULL DEFAULT '',
      device varchar(10) NOT NULL DEFAULT '',
      browser varchar(20) NOT NULL DEFAULT '',
      os varchar(20) NOT NULL DEFAULT '',
      amount decimal(12,2) NOT NULL DEFAULT 0,
      t datetime NOT NULL,
      last datetime NOT NULL,
      PRIMARY KEY  (id),
      KEY t (t),
      KEY vid (vid),
      KEY type_t (type,t)
    ) " . $wpdb->get_charset_collate() . ";");
    if (!wp_next_scheduled('vat_clean')) wp_schedule_event(time(), 'daily', 'vat_clean');
});
register_deactivation_hook(__FILE__, function () { wp_clear_scheduled_hook('vat_clean'); });
add_action('vat_clean', function () {
    global $wpdb; $T = vat_t();
    $wpdb->query($wpdb->prepare("DELETE FROM $T WHERE t < %s", gmdate('Y-m-d H:i:s', current_time('timestamp') - 180 * DAY_IN_SECONDS)));
});

/* ---------- helpers ---------- */
function vat_ip() {
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_TRUE_CLIENT_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
        if (empty($_SERVER[$k])) continue;
        foreach (explode(',', $_SERVER[$k]) as $ip) {
            $ip = trim($ip);
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return $ip;
        }
    }
    return $_SERVER['REMOTE_ADDR'] ?? '';
}

function vat_geo($ip) {
    $x = apply_filters('vat_geo_pre', null, $ip); // plug MaxMind/ipinfo here: return [country, city, lat, lon]
    if ($x) return $x;
    // Cloudflare "Add visitor location headers" managed transform
    if (!empty($_SERVER['HTTP_CF_IPCITY']) && !empty($_SERVER['HTTP_CF_IPCOUNTRY'])) {
        $cc = strtoupper($_SERVER['HTTP_CF_IPCOUNTRY']);
        $cn = function_exists('WC') && WC()->countries ? (WC()->countries->countries[$cc] ?? $cc) : $cc;
        return [$cn, sanitize_text_field($_SERVER['HTTP_CF_IPCITY']), (float)($_SERVER['HTTP_CF_IPLATITUDE'] ?? 0), (float)($_SERVER['HTTP_CF_IPLONGITUDE'] ?? 0)];
    }
    $d = ['', '', null, null];
    if (!$ip || !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return $d;
    $k = 'vat_g_' . md5($ip);
    $c = get_transient($k);
    if ($c !== false) return $c;
    $r = wp_remote_get("http://ip-api.com/json/$ip?fields=status,country,city,lat,lon", ['timeout' => 3]);
    $ok = false;
    if (!is_wp_error($r)) {
        $j = json_decode(wp_remote_retrieve_body($r), true);
        if (($j['status'] ?? '') === 'success') { $d = [$j['country'], $j['city'], $j['lat'], $j['lon']]; $ok = true; }
    }
    set_transient($k, $d, $ok ? WEEK_IN_SECONDS : 300);
    return $d;
}

function vat_ua($u) {
    $dev = preg_match('/ipad|tablet/i', $u) ? 'Tablet' : (preg_match('/mobi|android|iphone/i', $u) ? 'Mobile' : 'Desktop');
    $b = 'Other';
    foreach (['Edg' => 'Edge', 'OPR' => 'Opera', 'Firefox' => 'Firefox', 'Chrome' => 'Chrome', 'Safari' => 'Safari', 'MSIE' => 'IE', 'Trident' => 'IE'] as $k => $v) if (stripos($u, $k) !== false) { $b = $v; break; }
    $o = 'Other';
    foreach (['Windows' => 'Windows', 'iPhone' => 'iOS', 'iPad' => 'iOS', 'Android' => 'Android', 'Mac OS' => 'macOS', 'Linux' => 'Linux'] as $k => $v) if (stripos($u, $k) !== false) { $o = $v; break; }
    return [$dev, $b, $o];
}

function vat_src($ref, $url) {
    parse_str((string)parse_url($url, PHP_URL_QUERY), $q);
    if (!empty($q['utm_source'])) return ucfirst(sanitize_text_field(substr($q['utm_source'], 0, 40)));
    $h = strtolower((string)parse_url($ref, PHP_URL_HOST));
    if (!$h || $h === strtolower((string)wp_parse_url(home_url(), PHP_URL_HOST))) return 'Direct';
    if ($h === 't.co') return 'Twitter/X';
    foreach (['google' => 'Google', 'facebook' => 'Facebook', 'fb.com' => 'Facebook', 'instagram' => 'Instagram', 'youtube' => 'YouTube', 'bing' => 'Bing', 'twitter' => 'Twitter/X', 'whatsapp' => 'WhatsApp', 'linkedin' => 'LinkedIn'] as $k => $v) if (strpos($h, $k) !== false) return $v;
    return substr(preg_replace('/^www\./', '', $h), 0, 60);
}

function vat_bot() { return (bool)preg_match('/bot|crawl|spider|slurp|facebookexternalhit|preview|monitor|curl|wget|headless/i', $_SERVER['HTTP_USER_AGENT'] ?? ''); }

function vat_base($type) {
    $ip = vat_ip();
    [$c, $ci, $la, $lo] = vat_geo($ip);
    [$d, $b, $o] = vat_ua($_SERVER['HTTP_USER_AGENT'] ?? '');
    $n = current_time('mysql');
    return [
        'vid' => substr(preg_replace('/\W/', '', $_COOKIE['vat_vid'] ?? ''), 0, 32), 'type' => $type, 'ip' => $ip,
        'country' => $c, 'city' => $ci, 'lat' => $la, 'lon' => $lo,
        'src' => sanitize_text_field($_COOKIE['vat_src'] ?? 'Direct'),
        'device' => $d, 'browser' => $b, 'os' => $o, 't' => $n, 'last' => $n,
    ];
}

/* ---------- frontend tracker ---------- */
add_action('wp_footer', function () {
    if (current_user_can('manage_options')) return;
    $cfg = ['u' => esc_url_raw(rest_url('vat/v1/hit')), 'pid' => (function_exists('is_product') && is_product()) ? get_the_ID() : 0];
    ?>
<script>(function(){var C=<?php echo wp_json_encode($cfg); ?>;
function ck(n){var m=document.cookie.match('(^|; )'+n+'=([^;]*)');return m?decodeURIComponent(m[2]):''}
function sc(n,v,d){document.cookie=n+'='+encodeURIComponent(v)+';path=/;max-age='+d*86400+';SameSite=Lax'}
var v=ck('vat_vid');if(!v){v=((window.crypto&&crypto.randomUUID)?crypto.randomUUID():Math.random().toString(36).slice(2)+Date.now().toString(36)).replace(/-/g,'');sc('vat_vid',v,365)}
var s=sessionStorage.getItem('vat_src')||'',id=0;
function send(o,b){o.vid=v;var j=JSON.stringify(o);
 if(b&&navigator.sendBeacon){navigator.sendBeacon(C.u,new Blob([j],{type:'application/json'}));return}
 return fetch(C.u,{method:'POST',headers:{'Content-Type':'application/json'},body:j,keepalive:true}).then(function(r){return r.json()})}
var p=send({a:'v',url:location.href,ref:document.referrer,src:s,pid:C.pid});
if(p)p.then(function(j){id=j.id;if(!s&&j.src){sessionStorage.setItem('vat_src',j.src);sc('vat_src',j.src,1)}}).catch(function(){});
setInterval(function(){if(id&&!document.hidden)send({a:'p',id:id},1)},15000);
document.addEventListener('visibilitychange',function(){if(id)send({a:'p',id:id},1)});
})();</script>
    <?php
});

/* ---------- REST ---------- */
add_action('rest_api_init', function () {
    register_rest_route('vat/v1', '/hit', ['methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'vat_hit']);
    register_rest_route('vat/v1', '/stats', ['methods' => 'GET', 'permission_callback' => function () { return current_user_can('manage_options'); }, 'callback' => 'vat_stats']);
});

function vat_hit($r) {
    global $wpdb; $T = vat_t();
    if (vat_bot()) return ['id' => 0];
    $vid = substr(preg_replace('/\W/', '', (string)$r['vid']), 0, 32);
    if (!$vid) return ['id' => 0];
    if ($r['a'] === 'p') {
        $wpdb->query($wpdb->prepare("UPDATE $T SET last=%s WHERE id=%d AND vid=%s", current_time('mysql'), (int)$r['id'], $vid));
        return ['ok' => 1];
    }
    $url = (string)$r['url'];
    $src = sanitize_text_field((string)$r['src']) ?: vat_src((string)$r['ref'], $url);
    $_COOKIE['vat_vid'] = $vid; $_COOKIE['vat_src'] = $src;
    $row = vat_base('view');
    $row['page'] = substr((string)wp_parse_url($url, PHP_URL_PATH), 0, 255) ?: '/';
    $row['pid'] = (int)$r['pid'];
    $wpdb->insert($T, $row);
    return ['id' => $wpdb->insert_id, 'src' => $src];
}

/* ---------- WooCommerce ---------- */
add_action('woocommerce_add_to_cart', function ($key, $pid) {
    if (vat_bot()) return;
    global $wpdb; $r = vat_base('cart'); $r['pid'] = (int)$pid;
    $wpdb->insert(vat_t(), $r);
}, 10, 2);

function vat_order($x) {
    $o = $x instanceof WC_Order ? $x : wc_get_order($x);
    if (!$o || $o->get_meta('_vat_done')) return;
    global $wpdb; $r = vat_base('order');
    $cc = $o->get_billing_country();
    $r['country'] = WC()->countries->countries[$cc] ?? $cc;
    if ($o->get_billing_city()) $r['city'] = $o->get_billing_city();
    $r['pid'] = $o->get_id(); $r['amount'] = $o->get_total();
    $wpdb->insert(vat_t(), $r);
    $o->update_meta_data('_vat_done', 1); $o->save();
}
add_action('woocommerce_checkout_order_processed', 'vat_order');
add_action('woocommerce_store_api_checkout_order_processed', 'vat_order');

/* ---------- stats ---------- */
function vat_stats($r) {
    global $wpdb; $T = vat_t();
    $days = (int)$r['days']; $days = $days > 0 ? min($days, 90) : 7;
    $from = gmdate('Y-m-d 00:00:00', current_time('timestamp') - ($days - 1) * DAY_IN_SECONDS);
    $live = gmdate('Y-m-d H:i:s', current_time('timestamp') - 60);
    $q = function ($sql, ...$a) use ($wpdb) { return $wpdb->get_results($wpdb->prepare($sql, ...$a), ARRAY_A); };
    $v = function ($sql, ...$a) use ($wpdb) { return $wpdb->get_var($wpdb->prepare($sql, ...$a)); };
    $g = function ($c, $type = 'view') use ($q, $T, $from) {
        $n = $type === 'order' ? 'COUNT(*)' : 'COUNT(DISTINCT vid)';
        return $q("SELECT $c k, $n n FROM $T WHERE type=%s AND t>=%s AND $c<>'' GROUP BY $c ORDER BY n DESC LIMIT 10", $type, $from);
    };
    $uv = (int)$v("SELECT COUNT(DISTINCT vid) FROM $T WHERE type='view' AND t>=%s", $from);
    $ord = $q("SELECT COUNT(*) c, COALESCE(SUM(amount),0) s FROM $T WHERE type='order' AND t>=%s", $from)[0];
    $pv = $q("SELECT pid, COUNT(*) n FROM $T WHERE type='view' AND pid>0 AND t>=%s GROUP BY pid ORDER BY n DESC LIMIT 8", $from);
    $ct = $q("SELECT pid, COUNT(*) n FROM $T WHERE type='cart' AND t>=%s GROUP BY pid", $from);
    $cm = []; foreach ($ct as $c) $cm[$c['pid']] = $c['n'];
    $prod = array_map(function ($p) use ($cm) { return ['k' => get_the_title($p['pid']) ?: '#' . $p['pid'], 'v' => $p['n'], 'c' => $cm[$p['pid']] ?? 0]; }, $pv);
    return [
        'uv' => $uv,
        'pviewers' => (int)$v("SELECT COUNT(DISTINCT vid) FROM $T WHERE type='view' AND pid>0 AND t>=%s", $from),
        'carters' => (int)$v("SELECT COUNT(DISTINCT vid) FROM $T WHERE type='cart' AND t>=%s", $from),
        'orders' => (int)$ord['c'], 'rev' => (float)$ord['s'],
        'conv' => $uv ? round($ord['c'] / $uv * 100, 2) : 0,
        'daily' => $q("SELECT DATE(t) d, COUNT(DISTINCT vid) u, COUNT(*) pv FROM $T WHERE type='view' AND t>=%s GROUP BY d ORDER BY d", $from),
        'hourly' => $q("SELECT HOUR(t) h, COUNT(DISTINCT vid) n FROM $T WHERE type='view' AND t>=%s GROUP BY h", $from),
        'countries' => $g('country'), 'device' => $g('device'), 'browser' => $g('browser'), 'os' => $g('os'), 'src' => $g('src'),
        'o_country' => $g('country', 'order'), 'o_src' => $g('src', 'order'),
        'cities' => $q("SELECT city, country, MAX(lat) lat, MAX(lon) lon, COUNT(DISTINCT vid) n FROM $T WHERE type='view' AND t>=%s AND lat IS NOT NULL GROUP BY city, country ORDER BY n DESC LIMIT 200", $from),
        'pages' => $q("SELECT page k, COUNT(*) v, ROUND(AVG(TIMESTAMPDIFF(SECOND,t,last))) d FROM $T WHERE type='view' AND t>=%s GROUP BY page ORDER BY v DESC LIMIT 15", $from),
        'products' => $prod,
        'visitors' => $q("SELECT vid, MAX(ip) ip, MAX(country) country, MAX(city) city, MAX(device) device, MAX(browser) browser, MAX(src) src, SUM(type='view') pv, SUM(type='cart') c, SUM(type='order') o, MAX(last) last FROM $T WHERE t>=%s AND vid<>'' GROUP BY vid ORDER BY MAX(last) DESC LIMIT 50", $from),
        'live' => $q("SELECT vid, MAX(page) page, MAX(city) city, MAX(country) country, MAX(device) device FROM $T WHERE type='view' AND last>=%s GROUP BY vid LIMIT 50", $live),
    ];
}

/* ---------- admin dashboard ---------- */
add_action('admin_menu', function () {
    add_menu_page('Visitor Analytics', 'Visitors', 'read', 'vat', 'vat_page', 'dashicons-chart-area', '25.7');
    add_management_page('Visitor Analytics', 'Visitor Analytics', 'read', 'vat', 'vat_page');
}, 99);
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($l) {
    array_unshift($l, '<a href="' . esc_url(admin_url('admin.php?page=vat')) . '">Dashboard</a>');
    return $l;
});

function vat_page() {
    if (!current_user_can('manage_options') && !current_user_can('manage_woocommerce')) wp_die('No access');
    $cfg = ['u' => esc_url_raw(rest_url('vat/v1/stats')), 'n' => wp_create_nonce('wp_rest')];
    ?>
<div class="wrap"><h1>Visitor Analytics <select id="d"><option value="1">Today</option><option value="7" selected>7 days</option><option value="30">30 days</option><option value="90">90 days</option></select>
<span id="live" style="background:#00a32a;color:#fff;padding:3px 10px;border-radius:12px;font-size:13px;margin-left:10px"></span></h1>
<style>.k{display:flex;gap:12px;flex-wrap:wrap;margin:12px 0}.k div{background:#fff;padding:12px 18px;border-radius:6px;min-width:120px;box-shadow:0 1px 2px #0002}.k b{display:block;font-size:22px}
.g{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:14px}.c{background:#fff;padding:12px;border-radius:6px;box-shadow:0 1px 2px #0002;overflow:auto}.c table{width:100%;border-collapse:collapse;font-size:12px}.c td,.c th{padding:4px 6px;border-bottom:1px solid #eee;text-align:left}#map{height:340px}</style>
<div class="k" id="kpi"></div>
<div class="g">
<div class="c"><h3>Unique visitors / day</h3><canvas id="cd"></canvas></div>
<div class="c"><h3>Visitors by hour</h3><canvas id="ch"></canvas></div>
<div class="c"><h3>Map</h3><div id="map"></div></div>
<div class="c"><h3>Live now</h3><table id="tl"></table></div>
<div class="c"><h3>Countries</h3><table id="tc"></table></div>
<div class="c"><h3>Sources</h3><canvas id="cs"></canvas></div>
<div class="c"><h3>Devices</h3><canvas id="cv"></canvas></div>
<div class="c"><h3>Browser / OS</h3><table id="tb"></table></div>
<div class="c"><h3>Pages (views, avg seconds)</h3><table id="tp"></table></div>
<div class="c"><h3>Products (views / cart)</h3><table id="tpr"></table></div>
<div class="c"><h3>Orders by country</h3><table id="toc"></table></div>
<div class="c"><h3>Orders by source</h3><table id="tos"></table></div>
</div>
<div class="c" style="margin-top:14px"><h3>Recent visitors</h3><table id="tv"></table></div></div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script>(function(){var C=<?php echo wp_json_encode($cfg); ?>,$=function(i){return document.getElementById(i)},ch={},pal=['#2271b1','#00a32a','#dba617','#d63638','#8c5cc4','#3db6b6','#999'];
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function tbl(id,h,rows){$(id).innerHTML='<tr>'+h.map(function(x){return'<th>'+x+'</th>'}).join('')+'</tr>'+rows.map(function(r){return'<tr>'+r.map(function(x){return'<td>'+esc(x)+'</td>'}).join('')+'</tr>'}).join('')}
function chart(id,type,l,d,lab){if(ch[id])ch[id].destroy();ch[id]=new Chart($(id),{type:type,data:{labels:l,datasets:[{label:lab||'',data:d,backgroundColor:type=='doughnut'?pal:'#2271b1',borderColor:'#2271b1'}]},options:{plugins:{legend:{display:type=='doughnut'}}}})}
var map=L.map('map').setView([20,0],2),lay=L.layerGroup().addTo(map);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; OpenStreetMap'}).addTo(map);
function kv(a){return a.map(function(x){return[x.k,x.n]})}
function load(){fetch(C.u+'?days='+$('d').value,{headers:{'X-WP-Nonce':C.n}}).then(function(r){return r.json()}).then(function(s){
 $('live').textContent='● '+s.live.length+' live';
 $('kpi').innerHTML=[['Unique visitors',s.uv],['Viewed product',s.pviewers],['Added to cart',s.carters],['Orders',s.orders],['Revenue',s.rev],['Conversion',s.conv+'%']].map(function(x){return'<div>'+x[0]+'<b>'+x[1]+'</b></div>'}).join('');
 chart('cd','line',s.daily.map(function(x){return x.d}),s.daily.map(function(x){return +x.u}),'Visitors');
 var h=Array(24).fill(0);s.hourly.forEach(function(x){h[x.h]=+x.n});chart('ch','bar',h.map(function(_,i){return i+':00'}),h,'Visitors');
 chart('cs','doughnut',s.src.map(function(x){return x.k}),s.src.map(function(x){return +x.n}));
 chart('cv','doughnut',s.device.map(function(x){return x.k}),s.device.map(function(x){return +x.n}));
 lay.clearLayers();s.cities.forEach(function(c){if(c.lat)L.circleMarker([c.lat,c.lon],{radius:4+Math.sqrt(c.n)*3,color:'#d63638'}).bindPopup(esc(c.city+', '+c.country+': '+c.n)).addTo(lay)});
 tbl('tl',['Page','Where','Device'],s.live.map(function(x){return[x.page,x.city+', '+x.country,x.device]}));
 tbl('tc',['Country','Visitors'],kv(s.countries));
 tbl('tb',['Browser','#'],kv(s.browser).concat([['—','—']],kv(s.os)));
 tbl('tp',['Page','Views','Avg s'],s.pages.map(function(x){return[x.k,x.v,x.d]}));
 tbl('tpr',['Product','Views','Cart'],s.products.map(function(x){return[x.k,x.v,x.c]}));
 tbl('toc',['Country','Orders'],kv(s.o_country));tbl('tos',['Source','Orders'],kv(s.o_src));
 tbl('tv',['IP','Location','Device','Source','Pages','Cart','Ordered','Last seen'],s.visitors.map(function(x){return[x.ip,x.city+', '+x.country,x.device+' / '+x.browser,x.src,x.pv,x.c>0?'Yes':'No',x.o>0?'Yes':'No',x.last]}));
})}
$('d').onchange=load;load();setInterval(load,30000);})();</script>
    <?php
}
