<?php
/**
 * Plugin Name: Customer Reviews Showcase
 * Description: Admin panel theke customer review/testimonial add-edit-delete-reorder kore shortcode (Elementor Shortcode widget soho) diye slider dekhan. Full customizable + responsive (min-width 320px).
 * Version: 1.1.0
 * Author: Custom
 * Text Domain: crs
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CRS_OPT_REVIEWS', 'crs_reviews' );
define( 'CRS_OPT_SETTINGS', 'crs_settings' );
define( 'CRS_VERSION', '1.1.0' );

/* ----------------------------------------------------------
 * Defaults
 * ---------------------------------------------------------- */
function crs_default_settings() {
	return array(
		'label_text'       => 'CUSTOMER REVIEWS',
		'label_color'      => '#1a1a1a',
		'heading_text'     => 'আমাদের গ্রাহকদের অভিজ্ঞতা',
		'heading_color'    => '#1e7145',
		'star_color'       => '#f5a623',
		'quote_color'      => '#cfd8d4',
		'card_bg'          => '#ffffff',
		'card_border'      => '#e6e6e6',
		'card_radius'      => 10,
		'arrow_bg'         => '#1e7145',
		'arrow_color'      => '#ffffff',
		'columns_desktop'  => 3,
		'columns_tablet'   => 2,
		'autoplay_seconds' => 0,
		'verified_text'    => 'ভেরিফায়েড ক্রেতা',
		'custom_css'       => '',
		'layout'           => 'centered',
		'use_hind'         => 1,
		'text_color'       => '#555555',
	);
}
function crs_get_settings() {
	return wp_parse_args( get_option( CRS_OPT_SETTINGS, array() ), crs_default_settings() );
}
function crs_get_reviews() {
	$r = get_option( CRS_OPT_REVIEWS, array() );
	return is_array( $r ) ? $r : array();
}

/* ----------------------------------------------------------
 * Admin menu
 * ---------------------------------------------------------- */
add_action( 'admin_menu', function () {
	add_menu_page( 'Customer Reviews', 'Customer Reviews', 'manage_options', 'crs-reviews', 'crs_render_admin_page', 'dashicons-star-filled', 27 );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( strpos( $hook, 'crs-reviews' ) === false ) return;
	wp_enqueue_media();
	wp_enqueue_script( 'jquery-ui-sortable' );
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
} );

/* ----------------------------------------------------------
 * Save handler
 * ---------------------------------------------------------- */
add_action( 'admin_init', function () {
	if ( ! isset( $_POST['crs_save_nonce'] ) || ! wp_verify_nonce( $_POST['crs_save_nonce'], 'crs_save_action' ) ) return;
	if ( ! current_user_can( 'manage_options' ) ) return;

	// Reviews (array order = DOM/submit order, preserved by sortable)
	$reviews = array();
	if ( ! empty( $_POST['reviews'] ) && is_array( $_POST['reviews'] ) ) {
		foreach ( $_POST['reviews'] as $r ) {
			$name = sanitize_text_field( $r['name'] ?? '' );
			if ( $name === '' && empty( $r['text'] ) ) continue; // skip totally empty rows
			$reviews[] = array(
				'name'        => $name,
				'designation' => sanitize_text_field( $r['designation'] ?? '' ),
				'rating'      => max( 1, min( 5, intval( $r['rating'] ?? 5 ) ) ),
				'text'        => sanitize_textarea_field( $r['text'] ?? '' ),
				'avatar_id'   => intval( $r['avatar_id'] ?? 0 ),
			);
		}
	}
	update_option( CRS_OPT_REVIEWS, $reviews );

	$settings = crs_default_settings();
	$settings['label_text']       = sanitize_text_field( $_POST['label_text'] ?? '' );
	$settings['label_color']      = sanitize_hex_color( $_POST['label_color'] ?? '' ) ?: '#1a1a1a';
	$settings['heading_text']     = sanitize_text_field( $_POST['heading_text'] ?? '' );
	$settings['heading_color']    = sanitize_hex_color( $_POST['heading_color'] ?? '' ) ?: '#1e7145';
	$settings['star_color']       = sanitize_hex_color( $_POST['star_color'] ?? '' ) ?: '#f5a623';
	$settings['quote_color']      = sanitize_hex_color( $_POST['quote_color'] ?? '' ) ?: '#cfd8d4';
	$settings['card_bg']          = sanitize_hex_color( $_POST['card_bg'] ?? '' ) ?: '#ffffff';
	$settings['card_border']      = sanitize_hex_color( $_POST['card_border'] ?? '' ) ?: '#e6e6e6';
	$settings['card_radius']      = max( 0, intval( $_POST['card_radius'] ?? 10 ) );
	$settings['arrow_bg']         = sanitize_hex_color( $_POST['arrow_bg'] ?? '' ) ?: '#1e7145';
	$settings['arrow_color']      = sanitize_hex_color( $_POST['arrow_color'] ?? '' ) ?: '#ffffff';
	$settings['columns_desktop']  = max( 1, min( 4, intval( $_POST['columns_desktop'] ?? 3 ) ) );
	$settings['columns_tablet']   = max( 1, min( 3, intval( $_POST['columns_tablet'] ?? 2 ) ) );
	$settings['autoplay_seconds'] = max( 0, intval( $_POST['autoplay_seconds'] ?? 0 ) );
	$settings['verified_text']    = sanitize_text_field( $_POST['verified_text'] ?? '' );
	$settings['layout']           = ( ( $_POST['layout'] ?? '' ) === 'card' ) ? 'card' : 'centered';
	$settings['use_hind']         = empty( $_POST['use_hind'] ) ? 0 : 1;
	$settings['text_color']       = sanitize_hex_color( $_POST['text_color'] ?? '' ) ?: '#555555';
	$settings['custom_css']       = wp_strip_all_tags( wp_unslash( $_POST['custom_css'] ?? '' ) );

	update_option( CRS_OPT_SETTINGS, $settings );

	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-success is-dismissible"><p>সেভ হয়েছে।</p></div>';
	} );
} );

/* ----------------------------------------------------------
 * Admin page
 * ---------------------------------------------------------- */
function crs_render_review_row( $r = array() ) {
	$r = wp_parse_args( $r, array( 'name' => '', 'designation' => '', 'rating' => 5, 'text' => '', 'avatar_id' => 0 ) );
	$img = $r['avatar_id'] ? wp_get_attachment_image_url( $r['avatar_id'], array( 60, 60 ) ) : '';
	?>
	<li class="crs-review-row" style="background:#f6f7f7;border:1px solid #ddd;padding:14px;margin-bottom:10px;display:flex;gap:14px;align-items:flex-start;">
		<span class="crs-drag" style="cursor:move;padding-top:8px;">☰</span>
		<div style="flex-shrink:0;text-align:center;">
			<img class="crs-avatar-preview" src="<?php echo esc_url( $img ); ?>" style="width:60px;height:60px;border-radius:50%;object-fit:cover;background:#ddd;display:<?php echo $img ? 'block' : 'none'; ?>;">
			<input type="hidden" class="crs-avatar-id" data-field="avatar_id" value="<?php echo esc_attr( $r['avatar_id'] ); ?>">
			<button type="button" class="button crs-choose-img" style="margin-top:6px;">ছবি</button>
		</div>
		<div style="flex:1; display:grid; grid-template-columns:1fr 1fr; gap:8px;">
			<input type="text" data-field="name" placeholder="নাম" value="<?php echo esc_attr( $r['name'] ); ?>">
			<input type="text" data-field="designation" placeholder="ডেজিগনেশন (খালি রাখলে ডিফল্ট)" value="<?php echo esc_attr( $r['designation'] ); ?>">
			<select data-field="rating">
				<?php for ( $i = 5; $i >= 1; $i-- ) : ?>
					<option value="<?php echo $i; ?>" <?php selected( $r['rating'], $i ); ?>><?php echo str_repeat( '★', $i ); ?> (<?php echo $i; ?>)</option>
				<?php endfor; ?>
			</select>
			<span></span>
			<textarea data-field="text" placeholder="রিভিউ টেক্সট" rows="2" style="grid-column:1/3;"><?php echo esc_textarea( $r['text'] ); ?></textarea>
		</div>
		<a href="#" class="crs-remove-row" style="color:#b32d2e;padding-top:8px;">✕</a>
	</li>
	<?php
}

function crs_render_admin_page() {
	$settings = crs_get_settings();
	$reviews  = crs_get_reviews();
	?>
	<div class="wrap">
		<h1>Customer Reviews</h1>
		<p>রিভিউ যোগ/এডিট/রিঅর্ডার করুন, তারপর Elementor Shortcode widget-এ বসান: <code>[crs_reviews]</code></p>

		<form method="post">
			<?php wp_nonce_field( 'crs_save_action', 'crs_save_nonce' ); ?>

			<h2 class="nav-tab-wrapper">
				<a href="#crs-tab-reviews" class="nav-tab nav-tab-active" data-tab="reviews">রিভিউ ম্যানেজ</a>
				<a href="#crs-tab-design" class="nav-tab" data-tab="design">ডিজাইন / টেক্সট</a>
			</h2>

			<div id="crs-tab-reviews" class="crs-tab-panel" style="display:block;margin-top:16px;">
				<ul id="crs-review-list" style="list-style:none;margin:0;padding:0;max-width:900px;">
					<?php foreach ( $reviews as $r ) crs_render_review_row( $r ); ?>
				</ul>
				<button type="button" class="button button-secondary" id="crs-add-row">+ নতুন রিভিউ যোগ করুন</button>
			</div>

			<div id="crs-tab-design" class="crs-tab-panel" style="display:none;margin-top:16px;">
				<table class="form-table">
					<tr><th>লেআউট ডিজাইন</th><td><select name="layout"><option value="centered" <?php selected( $settings['layout'], 'centered' ); ?>>ডিজাইন ২ — সেন্টার (গোল ছবি উপরে, নাম নিচে)</option><option value="card" <?php selected( $settings['layout'], 'card' ); ?>>ডিজাইন ১ — কার্ড (আগেরটা)</option></select></td></tr>
					<tr><th>Hind Siliguri ফন্ট</th><td><label><input type="checkbox" name="use_hind" value="1" <?php checked( $settings['use_hind'], 1 ); ?>> ব্যবহার করুন</label></td></tr>
					<tr><th>রিভিউ টেক্সট রং</th><td><input type="text" class="crs-color" name="text_color" value="<?php echo esc_attr( $settings['text_color'] ); ?>"></td></tr>
					<tr><th>উপরের ছোট লেবেল টেক্সট</th><td><input type="text" name="label_text" value="<?php echo esc_attr( $settings['label_text'] ); ?>" class="regular-text"></td></tr>
					<tr><th>লেবেল রং</th><td><input type="text" class="crs-color" name="label_color" value="<?php echo esc_attr( $settings['label_color'] ); ?>"></td></tr>
					<tr><th>হেডিং টেক্সট</th><td><input type="text" name="heading_text" value="<?php echo esc_attr( $settings['heading_text'] ); ?>" class="regular-text"></td></tr>
					<tr><th>হেডিং রং</th><td><input type="text" class="crs-color" name="heading_color" value="<?php echo esc_attr( $settings['heading_color'] ); ?>"></td></tr>
					<tr><th>স্টার রং</th><td><input type="text" class="crs-color" name="star_color" value="<?php echo esc_attr( $settings['star_color'] ); ?>"></td></tr>
					<tr><th>কোট আইকন রং</th><td><input type="text" class="crs-color" name="quote_color" value="<?php echo esc_attr( $settings['quote_color'] ); ?>"></td></tr>
					<tr><th>কার্ড ব্যাকগ্রাউন্ড</th><td><input type="text" class="crs-color" name="card_bg" value="<?php echo esc_attr( $settings['card_bg'] ); ?>"></td></tr>
					<tr><th>কার্ড বর্ডার রং</th><td><input type="text" class="crs-color" name="card_border" value="<?php echo esc_attr( $settings['card_border'] ); ?>"></td></tr>
					<tr><th>কার্ড Corner Radius (px)</th><td><input type="number" name="card_radius" min="0" value="<?php echo esc_attr( $settings['card_radius'] ); ?>"></td></tr>
					<tr><th>অ্যারো বাটন ব্যাকগ্রাউন্ড</th><td><input type="text" class="crs-color" name="arrow_bg" value="<?php echo esc_attr( $settings['arrow_bg'] ); ?>"></td></tr>
					<tr><th>অ্যারো আইকন রং</th><td><input type="text" class="crs-color" name="arrow_color" value="<?php echo esc_attr( $settings['arrow_color'] ); ?>"></td></tr>
					<tr><th>ডেস্কটপে কয়টা কার্ড দেখাবে</th><td><input type="number" name="columns_desktop" min="1" max="4" value="<?php echo esc_attr( $settings['columns_desktop'] ); ?>"></td></tr>
					<tr><th>ট্যাবলেটে কয়টা কার্ড দেখাবে</th><td><input type="number" name="columns_tablet" min="1" max="3" value="<?php echo esc_attr( $settings['columns_tablet'] ); ?>"><p class="description">মোবাইলে (৫৬০px এর নিচে) সবসময় ১টা কার্ড দেখাবে — ৩২০px পর্যন্ত সাপোর্টেড।</p></td></tr>
					<tr><th>অটোপ্লে (সেকেন্ড)</th><td><input type="number" name="autoplay_seconds" min="0" value="<?php echo esc_attr( $settings['autoplay_seconds'] ); ?>"><p class="description">০ দিলে অটোপ্লে বন্ধ থাকবে।</p></td></tr>
					<tr><th>ডিফল্ট ডেজিগনেশন টেক্সট</th><td><input type="text" name="verified_text" value="<?php echo esc_attr( $settings['verified_text'] ); ?>" class="regular-text"></td></tr>
					<tr>
						<th>কাস্টম CSS</th>
						<td><textarea name="custom_css" rows="8" class="large-text code"><?php echo esc_textarea( $settings['custom_css'] ); ?></textarea>
						<p class="description">ক্লাসসমূহ: <code>.crs-card, .crs-name, .crs-stars, .crs-text, .crs-quote, .crs-prev, .crs-next</code></p></td>
					</tr>
				</table>
			</div>

			<?php submit_button( 'সেভ করুন' ); ?>
		</form>
	</div>

	<script type="text/template" id="crs-row-template">
		<?php crs_render_review_row(); ?>
	</script>

	<script>
	jQuery(function($){
		$('.nav-tab-wrapper .nav-tab').on('click', function(e){
			e.preventDefault();
			$('.nav-tab-wrapper .nav-tab').removeClass('nav-tab-active');
			$(this).addClass('nav-tab-active');
			$('.crs-tab-panel').hide();
			$('#crs-tab-' + $(this).data('tab')).show();
		});

		$('.crs-color').wpColorPicker();

		// Prottek row er field gulo ke DOM-er bortoman order onujayi reviews[i][field] name dey,
		// jate PHP-te field gulo thik row er sathe mile (eita e age-r bug er main karon chhilo).
		function crsReindex(){
			$('#crs-review-list .crs-review-row').each(function(i){
				$(this).find('[data-field]').each(function(){
					$(this).attr('name', 'reviews[' + i + '][' + $(this).data('field') + ']');
				});
			});
		}
		crsReindex();

		$('#crs-review-list').sortable({ handle: '.crs-drag', update: crsReindex });

		$('#crs-add-row').on('click', function(){
			$('#crs-review-list').append( $('#crs-row-template').html() );
			crsReindex();
		});

		$('#crs-review-list').on('click', '.crs-remove-row', function(e){
			e.preventDefault();
			$(this).closest('.crs-review-row').remove();
			crsReindex();
		});

		$('form').on('submit', crsReindex);

		$('#crs-review-list').on('click', '.crs-choose-img', function(e){
			e.preventDefault();
			var row = $(this).closest('.crs-review-row');
			var frame = wp.media({ title: 'ছবি নির্বাচন করুন', multiple: false, library: { type: 'image' } });
			frame.on('select', function(){
				var att = frame.state().get('selection').first().toJSON();
				row.find('.crs-avatar-id').val(att.id);
				row.find('.crs-avatar-preview').attr('src', (att.sizes && att.sizes.thumbnail ? att.sizes.thumbnail.url : att.url)).show();
			});
			frame.open();
		});
	});
	</script>
	<?php
}

/* ----------------------------------------------------------
 * Shortcode
 * ---------------------------------------------------------- */
add_shortcode( 'crs_reviews', 'crs_shortcode_render' );

function crs_shortcode_render() {
	$settings = crs_get_settings();
	$reviews  = crs_get_reviews();
	if ( empty( $reviews ) ) return '';

	crs_enqueue_front_assets();

	$uid = 'crs-' . wp_rand( 1000, 9999 );

	ob_start();
	?>
	<div class="crs-wrap crs-layout-<?php echo esc_attr( $settings['layout'] ); ?><?php echo $settings['use_hind'] ? ' crs-hind' : ''; ?>" id="<?php echo esc_attr( $uid ); ?>" style="
		--crs-text: <?php echo esc_attr( $settings['text_color'] ); ?>;
		--crs-star: <?php echo esc_attr( $settings['star_color'] ); ?>;
		--crs-quote: <?php echo esc_attr( $settings['quote_color'] ); ?>;
		--crs-card-bg: <?php echo esc_attr( $settings['card_bg'] ); ?>;
		--crs-card-border: <?php echo esc_attr( $settings['card_border'] ); ?>;
		--crs-radius: <?php echo esc_attr( $settings['card_radius'] ); ?>px;
		--crs-arrow-bg: <?php echo esc_attr( $settings['arrow_bg'] ); ?>;
		--crs-arrow-color: <?php echo esc_attr( $settings['arrow_color'] ); ?>;
		--crs-cols-desktop: <?php echo esc_attr( $settings['columns_desktop'] ); ?>;
		--crs-cols-tablet: <?php echo esc_attr( $settings['columns_tablet'] ); ?>;
	" data-autoplay="<?php echo esc_attr( $settings['autoplay_seconds'] ); ?>">

		<?php if ( $settings['label_text'] !== '' ) : ?>
		<div class="crs-top-row">
			<span class="crs-label" style="color:<?php echo esc_attr( $settings['label_color'] ); ?>;"><?php echo esc_html( $settings['label_text'] ); ?></span>
		</div>
		<?php endif; ?>
		<?php if ( $settings['heading_text'] ) : ?>
			<h2 class="crs-heading" style="color:<?php echo esc_attr( $settings['heading_color'] ); ?>;"><?php echo esc_html( $settings['heading_text'] ); ?></h2>
		<?php endif; ?>

		<div class="crs-slider">
			<button type="button" class="crs-prev" aria-label="Previous">‹</button>
			<div class="crs-track-wrap">
				<div class="crs-track">
					<?php foreach ( $reviews as $r ) :
						$img = $r['avatar_id'] ? wp_get_attachment_image_url( $r['avatar_id'], array( 60, 60 ) ) : '';
						$designation = $r['designation'] ? $r['designation'] : $settings['verified_text'];
						?>
						<div class="crs-slide">
						<?php if ( $settings['layout'] === 'centered' ) :
							$img_big = $r['avatar_id'] ? wp_get_attachment_image_url( $r['avatar_id'], 'medium' ) : '';
							?>
							<div class="crs-card crs-card-c">
								<?php if ( $img_big ) : ?>
									<img class="crs-avatar-c" src="<?php echo esc_url( $img_big ); ?>" alt="<?php echo esc_attr( $r['name'] ); ?>" loading="lazy">
								<?php else : ?>
									<span class="crs-avatar-c crs-avatar-c-ph"><?php echo esc_html( mb_substr( $r['name'], 0, 1 ) ); ?></span>
								<?php endif; ?>
								<span class="crs-stars"><?php echo str_repeat( '★', intval( $r['rating'] ) ) . str_repeat( '☆', 5 - intval( $r['rating'] ) ); ?></span>
								<p class="crs-text"><?php echo esc_html( $r['text'] ); ?></p>
								<span class="crs-name"><?php echo esc_html( $r['name'] ); ?></span>
								<?php if ( $r['designation'] ) : ?><span class="crs-designation"><?php echo esc_html( $r['designation'] ); ?></span><?php endif; ?>
							</div>
						<?php else : ?>
							<div class="crs-card">
								<div class="crs-card-top">
									<span class="crs-stars"><?php echo str_repeat( '★', intval( $r['rating'] ) ) . str_repeat( '☆', 5 - intval( $r['rating'] ) ); ?></span>
									<span class="crs-quote">&#8221;&#8221;</span>
								</div>
								<p class="crs-text"><?php echo esc_html( $r['text'] ); ?></p>
								<div class="crs-person">
									<?php if ( $img ) : ?>
										<img class="crs-avatar" src="<?php echo esc_url( $img ); ?>" alt="<?php echo esc_attr( $r['name'] ); ?>">
									<?php else : ?>
										<span class="crs-avatar crs-avatar-placeholder"><?php echo esc_html( mb_substr( $r['name'], 0, 1 ) ); ?></span>
									<?php endif; ?>
									<span>
										<span class="crs-name"><?php echo esc_html( $r['name'] ); ?></span>
										<span class="crs-designation"><?php echo esc_html( $designation ); ?></span>
									</span>
								</div>
							</div>
						<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<button type="button" class="crs-next" aria-label="Next">›</button>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

/* ----------------------------------------------------------
 * Front assets
 * ---------------------------------------------------------- */
function crs_enqueue_front_assets() {
	static $done = false;
	if ( $done ) return;
	$done = true;

	wp_register_style( 'crs-front', false, array(), CRS_VERSION );
	wp_enqueue_style( 'crs-front' );
	wp_register_script( 'crs-front', false, array(), CRS_VERSION, true );
	wp_enqueue_script( 'crs-front' );

	$settings = crs_get_settings();

	$css = "
	.crs-wrap{max-width:1200px;margin:0 auto;padding:0 16px;box-sizing:border-box;text-align:center;}
	.crs-wrap *{box-sizing:border-box;}
	.crs-top-row{display:flex;align-items:center;gap:16px;margin-bottom:8px;}
	.crs-top-row:before,.crs-top-row:after{content:'';flex:1;height:1px;background:#ddd;}
	.crs-label{font-size:13px;font-weight:700;letter-spacing:1px;white-space:nowrap;}
	.crs-heading{font-weight:800;margin:4px 0 28px;font-size:clamp(20px,4vw,32px);}
	.crs-slider{position:relative;padding:0 46px;}
	.crs-track-wrap{overflow:hidden;}
	.crs-track{display:flex;gap:20px;overflow-x:auto;scroll-snap-type:x mandatory;scroll-behavior:smooth;-ms-overflow-style:none;scrollbar-width:none;padding:4px 2px 14px;}
	.crs-track::-webkit-scrollbar{display:none;}
	.crs-slide{flex:0 0 calc((100% - (var(--crs-cols-desktop) - 1) * 20px) / var(--crs-cols-desktop));scroll-snap-align:start;}
	@media (max-width:900px){.crs-slide{flex-basis:calc((100% - (var(--crs-cols-tablet) - 1) * 20px) / var(--crs-cols-tablet));}}
	@media (max-width:560px){.crs-slide{flex-basis:100%;}.crs-slider{padding:0 38px;}}
	.crs-card{height:100%;background:var(--crs-card-bg);border:1px solid var(--crs-card-border);border-radius:var(--crs-radius);padding:22px 18px;text-align:left;display:flex;flex-direction:column;}
	.crs-card-top{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px;}
	.crs-stars{color:var(--crs-star);font-size:18px;letter-spacing:2px;}
	.crs-quote{color:var(--crs-quote);font-size:38px;font-weight:800;line-height:1;font-family:Georgia,serif;}
	.crs-text{font-size:14.5px;color:#333;line-height:1.7;margin:0 0 16px;border-bottom:1px solid #eee;padding-bottom:16px;flex:1;}
	.crs-person{display:flex;align-items:center;gap:12px;}
	.crs-avatar{width:46px;height:46px;border-radius:50%;object-fit:cover;border:2px solid var(--crs-arrow-bg);flex-shrink:0;}
	.crs-avatar-placeholder{display:flex;align-items:center;justify-content:center;background:var(--crs-arrow-bg);color:#fff;font-weight:700;}
	.crs-name{display:block;font-weight:700;font-size:14.5px;color:#1a1a1a;}
	.crs-designation{display:block;font-size:12.5px;color:#777;}
	.crs-prev,.crs-next{position:absolute;top:40%;transform:translateY(-50%);width:40px;height:40px;border-radius:50%;background:var(--crs-arrow-bg);color:var(--crs-arrow-color);border:none;font-size:22px;line-height:1;cursor:pointer;z-index:2;}
	.crs-prev{left:0;}
	.crs-next{right:0;}
	@media (max-width:560px){.crs-prev,.crs-next{width:32px;height:32px;font-size:18px;}}
	@media (max-width:320px){.crs-card{padding:16px 12px;}.crs-slider{padding:0 32px;}}
	.crs-hind,.crs-hind *{font-family:'Hind Siliguri',sans-serif;}
	.crs-text{color:var(--crs-text);}
	.crs-layout-centered .crs-card-c{background:transparent;border:0;border-radius:0;padding:8px 6px;align-items:center;text-align:center;}
	.crs-avatar-c{width:100px;height:100px;border-radius:50%;object-fit:cover;display:block;margin:0 auto 14px;flex-shrink:0;}
	.crs-avatar-c-ph{display:flex;align-items:center;justify-content:center;background:var(--crs-arrow-bg);color:#fff;font-size:38px;font-weight:700;}
	.crs-layout-centered .crs-stars{font-size:16px;letter-spacing:3px;margin-bottom:10px;display:block;}
	.crs-layout-centered .crs-text{border:0;padding:0;margin:0 0 18px;font-size:15px;line-height:1.7;text-align:center;flex:1;}
	.crs-layout-centered .crs-name{font-size:14px;font-weight:700;color:#222;}
	.crs-layout-centered .crs-designation{margin-top:2px;}
	.crs-layout-centered .crs-prev,.crs-layout-centered .crs-next{top:35%;}
	@media (max-width:560px){.crs-avatar-c{width:84px;height:84px;}}
	@media (max-width:360px){.crs-avatar-c{width:72px;height:72px;}.crs-layout-centered .crs-text{font-size:14px;}.crs-wrap{padding:0 8px;}}
	";
	if ( ! empty( $settings['use_hind'] ) ) {
		wp_enqueue_style( 'crs-hind-font', 'https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap', array(), null );
	}
	wp_add_inline_style( 'crs-front', $css );
	if ( ! empty( $settings['custom_css'] ) ) {
		wp_add_inline_style( 'crs-front', $settings['custom_css'] );
	}

	$js = "
	document.addEventListener('DOMContentLoaded', function(){
		document.querySelectorAll('.crs-wrap').forEach(function(wrap){
			var track = wrap.querySelector('.crs-track');
			var prev = wrap.querySelector('.crs-prev');
			var next = wrap.querySelector('.crs-next');
			function slideWidth(){
				var slide = track.querySelector('.crs-slide');
				return slide ? slide.getBoundingClientRect().width + 20 : 300;
			}
			prev.addEventListener('click', function(){ track.scrollBy({ left: -slideWidth(), behavior: 'smooth' }); });
			next.addEventListener('click', function(){
				var atEnd = track.scrollLeft + track.clientWidth >= track.scrollWidth - 5;
				if ( atEnd ) { track.scrollTo({ left: 0, behavior: 'smooth' }); }
				else { track.scrollBy({ left: slideWidth(), behavior: 'smooth' }); }
			});
			var auto = parseInt(wrap.getAttribute('data-autoplay'), 10);
			if ( auto > 0 ) {
				setInterval(function(){ next.click(); }, auto * 1000);
			}
		});
	});
	";
	wp_add_inline_script( 'crs-front', $js );
}
