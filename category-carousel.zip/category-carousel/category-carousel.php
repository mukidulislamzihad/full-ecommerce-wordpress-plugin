<?php
/**
 * Plugin Name: Category Carousel
 * Description: WooCommerce category carousel. Shortcode: [category_carousel]. Admin settings + custom CSS.
 * Version: 1.0
 */
if (!defined('ABSPATH')) exit;

function ccw_def(){return [
 'title'=>'Shop by Category','show_title'=>1,'title_size'=>30,'title_color'=>'#000000','title_weight'=>700,'title_align'=>'left',
 'cats'=>[],'orderby'=>'name','order'=>'ASC','hide_empty'=>0,'parent_only'=>0,'limit'=>0,'show_count'=>0,
 'pv_d'=>8,'pv_t'=>4,'pv_m'=>2,'bp_t'=>1024,'bp_m'=>640,'gap'=>14,'max_w'=>1400,
 'card_bg'=>'#ffffff','card_border'=>'#eeeeee','card_radius'=>10,'card_pad'=>9,'img_radius'=>10,'img_ratio'=>'4/3','zoom'=>1,'shadow_hover'=>1,
 'name_size'=>16,'name_color'=>'#222222','name_hover'=>'#16a34a','name_weight'=>400,
 'arrows'=>1,'arr_bg'=>'#16a34a','arr_color'=>'#ffffff','arr_size'=>40,'arr_radius'=>3,'css'=>''];}
function ccw_opt(){return wp_parse_args(get_option('ccw_opts',[]),ccw_def());}

add_action('admin_menu',function(){add_menu_page('Category Carousel','Category Carousel','manage_options','ccw','ccw_page','dashicons-category',59);});
add_action('admin_enqueue_scripts',function($h){if($h==='toplevel_page_ccw'){wp_enqueue_style('wp-color-picker');wp_enqueue_script('wp-color-picker');}});

function ccw_page(){
 $d=ccw_def();
 if(!empty($_POST['ccw_go'])&&check_admin_referer('ccw_s')&&current_user_can('manage_options')){
  $p=wp_unslash($_POST);$n=[];
  foreach($d as $k=>$v){
   $x=$p[$k]??'';
   if($k==='cats')$n[$k]=array_map('absint',(array)$x);
   elseif($k==='css')$n[$k]=wp_strip_all_tags($x);
   elseif(in_array($k,['title','img_ratio']))$n[$k]=sanitize_text_field($x)?:$v;
   elseif(in_array($k,['orderby','order','title_align']))$n[$k]=sanitize_key($x)?:$v;
   elseif(strpos($k,'color')!==false||in_array($k,['card_bg','card_border','arr_bg','name_hover']))$n[$k]=sanitize_hex_color($x)?:$v;
   elseif(in_array($k,['show_title','hide_empty','parent_only','show_count','zoom','shadow_hover','arrows']))$n[$k]=empty($x)?0:1;
   else $n[$k]=max(0,(float)$x);
  }
  update_option('ccw_opts',$n);echo '<div class="updated"><p>Saved.</p></div>';
 }
 $o=ccw_opt();
 $t=function($k,$l,$type='text')use($o){$c=(strpos($k,'color')!==false||in_array($k,['card_bg','card_border','arr_bg','name_hover']))?'ccw-c':'';
  echo '<tr><th>'.esc_html($l).'</th><td><input type="'.($c?'text':$type).'" name="'.$k.'" value="'.esc_attr($o[$k]).'" class="'.$c.'"></td></tr>';};
 $ck=function($k,$l)use($o){echo '<tr><th>'.esc_html($l).'</th><td><input type="checkbox" name="'.$k.'" value="1" '.checked($o[$k],1,false).'></td></tr>';};
 $sel=function($k,$l,$opts)use($o){echo '<tr><th>'.esc_html($l).'</th><td><select name="'.$k.'">';foreach($opts as $v=>$lb)echo '<option value="'.$v.'" '.selected($o[$k],$v,false).'>'.$lb.'</option>';echo '</select></td></tr>';};
 echo '<div class="wrap"><h1>Category Carousel</h1><p>Shortcode: <code>[category_carousel]</code> (WooCommerce product categories)</p><form method="post">';
 wp_nonce_field('ccw_s');echo '<table class="form-table" style="max-width:720px">';
 $ck('show_title','Show heading');$t('title','Heading');$t('title_size','Heading size (px)','number');$t('title_color','Heading color');
 $t('title_weight','Heading weight','number');$sel('title_align','Heading align',['left'=>'Left','center'=>'Center','right'=>'Right']);
 echo '<tr><th>Categories<br><small>(কিছু select না করলে সব)</small></th><td style="max-height:200px;overflow:auto;display:block;border:1px solid #ddd;background:#fff;padding:6px;width:300px">';
 $terms=get_terms(['taxonomy'=>'product_cat','hide_empty'=>false]);
 if(!is_wp_error($terms))foreach($terms as $tm)echo '<label style="display:block"><input type="checkbox" name="cats[]" value="'.$tm->term_id.'" '.checked(in_array($tm->term_id,$o['cats']),true,false).'> '.esc_html($tm->name).'</label>';
 echo '</td></tr>';
 $sel('orderby','Order by',['name'=>'Name','count'=>'Product count','menu_order'=>'Custom order','id'=>'ID','include'=>'Selected order']);
 $sel('order','Order',['ASC'=>'ASC','DESC'=>'DESC']);
 $ck('hide_empty','Hide empty');$ck('parent_only','Parent categories only');$ck('show_count','Show product count');$t('limit','Limit (0 = all)','number');
 $t('pv_d','Items – desktop','number');$t('pv_t','Items – tablet','number');$t('pv_m','Items – mobile (320px+)','number');
 $t('bp_t','Tablet breakpoint (px)','number');$t('bp_m','Mobile breakpoint (px)','number');$t('gap','Gap (px)','number');$t('max_w','Max width (px, 0=full)','number');
 $t('card_bg','Card background');$t('card_border','Card border color');$t('card_radius','Card radius','number');$t('card_pad','Card padding','number');
 $t('img_radius','Image radius','number');$t('img_ratio','Image ratio (e.g. 4/3)');$ck('zoom','Hover zoom');$ck('shadow_hover','Hover shadow');
 $t('name_size','Name size (px)','number');$t('name_color','Name color');$t('name_hover','Name hover color');$t('name_weight','Name weight','number');
 $ck('arrows','Show arrows');$t('arr_bg','Arrow background');$t('arr_color','Arrow color');$t('arr_size','Arrow size (px)','number');$t('arr_radius','Arrow radius','number');
 echo '</table><h2>Custom CSS</h2><textarea name="css" rows="8" style="width:100%;max-width:720px;font-family:monospace" placeholder=".ccw-card{} .ccw-name{} .ccw-title{} .ccw-arr{}">'.esc_textarea($o['css']).'</textarea>';
 echo '<p><button class="button button-primary button-large" name="ccw_go" value="1">Save</button></p></form></div>';
 echo '<script>jQuery(function($){$(".ccw-c").wpColorPicker();});</script>';
}

add_shortcode('category_carousel',function(){
 if(!taxonomy_exists('product_cat'))return '';
 static $n=0;$n++;$o=ccw_opt();$id='ccw-'.$n;
 $a=['taxonomy'=>'product_cat','hide_empty'=>(bool)$o['hide_empty'],'orderby'=>$o['orderby'],'order'=>$o['order']];
 if($o['cats']){$a['include']=$o['cats'];}else{$a['exclude']=[get_option('default_product_cat')];}
 if($o['parent_only']&&!$o['cats'])$a['parent']=0;
 if($o['limit'])$a['number']=(int)$o['limit'];
 $terms=get_terms($a);if(is_wp_error($terms)||!$terms)return '';
 $sh=$o['shadow_hover']?"#$id .ccw-card:hover{box-shadow:0 4px 14px rgba(0,0,0,.1)}":'';
 $css="#$id{max-width:".($o['max_w']?$o['max_w'].'px':'none').";margin:0 auto;width:100%;box-sizing:border-box;--pv:{$o['pv_d']};--g:{$o['gap']}px}
#$id *{box-sizing:border-box}
#$id .ccw-title{margin:0 0 16px;font-size:{$o['title_size']}px;color:{$o['title_color']};font-weight:{$o['title_weight']};text-align:{$o['title_align']};line-height:1.2}
#$id .ccw-wrap{position:relative}
#$id .ccw-track{display:flex;gap:var(--g);overflow-x:auto;scroll-snap-type:x mandatory;scroll-behavior:smooth;scrollbar-width:none;-webkit-overflow-scrolling:touch;padding:2px}
#$id .ccw-track::-webkit-scrollbar{display:none}
#$id .ccw-card{flex:0 0 calc((100% - var(--g)*(var(--pv) - 1))/var(--pv));min-width:0;scroll-snap-align:start;display:block;text-decoration:none;background:{$o['card_bg']};border:1px solid {$o['card_border']};border-radius:{$o['card_radius']}px;padding:{$o['card_pad']}px;text-align:center;transition:box-shadow .3s}
#$id .ccw-img{display:block;overflow:hidden;border-radius:{$o['img_radius']}px;aspect-ratio:{$o['img_ratio']};background:#f3f3f3}
#$id .ccw-img img{width:100%;height:100%;object-fit:cover;display:block".($o['zoom']?";transition:transform .4s":"")."}
".($o['zoom']?"#$id .ccw-card:hover img{transform:scale(1.06)}":"")."
#$id .ccw-name{display:block;margin-top:10px;font-size:{$o['name_size']}px;color:{$o['name_color']};font-weight:{$o['name_weight']};line-height:1.3;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#$id .ccw-card:hover .ccw-name{color:{$o['name_hover']}}
#$id .ccw-arr{position:absolute;top:calc(50% - 20px);transform:translateY(-50%);width:{$o['arr_size']}px;height:{$o['arr_size']}px;background:{$o['arr_bg']};color:{$o['arr_color']};border:0;border-radius:{$o['arr_radius']}px;cursor:pointer;z-index:2;font-size:22px;line-height:1;padding:0;display:flex;align-items:center;justify-content:center}
#$id .ccw-prev{left:0}#$id .ccw-next{right:0}#$id .ccw-arr.off{display:none}
$sh
@media(max-width:{$o['bp_t']}px){#$id{--pv:{$o['pv_t']}}}
@media(max-width:{$o['bp_m']}px){#$id{--pv:{$o['pv_m']};--g:".min($o['gap'],10)."px}#$id .ccw-name{font-size:".max(12,$o['name_size']-2)."px}#$id .ccw-title{font-size:".max(18,$o['title_size']-8)."px}#$id .ccw-arr{width:32px;height:32px;font-size:18px}}
".$o['css'];
 ob_start();?>
<style><?php echo $css;?></style>
<div id="<?php echo $id;?>" class="ccw">
<?php if($o['show_title']&&$o['title'])echo '<h2 class="ccw-title">'.esc_html($o['title']).'</h2>';?>
<div class="ccw-wrap"><div class="ccw-track">
<?php foreach($terms as $t){
 $tid=get_term_meta($t->term_id,'thumbnail_id',true);
 $img=$tid?wp_get_attachment_image($tid,'medium',false,['alt'=>$t->name,'loading'=>'lazy','draggable'=>'false']):'<img src="'.esc_url(function_exists('wc_placeholder_img_src')?wc_placeholder_img_src():'').'" alt="">';
 echo '<a class="ccw-card" href="'.esc_url(get_term_link($t)).'"><span class="ccw-img">'.$img.'</span><span class="ccw-name">'.esc_html($t->name).($o['show_count']?' ('.(int)$t->count.')':'').'</span></a>';
}?>
</div>
<?php if($o['arrows'])echo '<button class="ccw-arr ccw-prev" aria-label="Prev">‹</button><button class="ccw-arr ccw-next" aria-label="Next">›</button>';?>
</div></div>
<?php if($n===1):?><script>
document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('.ccw').forEach(function(w){
var t=w.querySelector('.ccw-track'),p=w.querySelector('.ccw-prev'),x=w.querySelector('.ccw-next');if(!p)return;
function u(){p.classList.toggle('off',t.scrollLeft<5);x.classList.toggle('off',t.scrollLeft+t.clientWidth>=t.scrollWidth-5);}
function s(d){var c=t.querySelector('.ccw-card');t.scrollBy({left:d*(c.offsetWidth+parseFloat(getComputedStyle(t).columnGap||0))*Math.max(1,Math.floor(t.clientWidth/c.offsetWidth)-1||1)});}
p.onclick=function(){s(-1)};x.onclick=function(){s(1)};t.addEventListener('scroll',u);window.addEventListener('resize',u);u();});});
</script><?php endif;
 return ob_get_clean();});
