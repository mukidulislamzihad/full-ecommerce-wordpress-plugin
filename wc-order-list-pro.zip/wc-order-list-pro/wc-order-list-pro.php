<?php
/**
 * Plugin Name: WC Order List Pro
 * Description: Orders list-এ product image, WhatsApp আইকন, single Excel/CSV export এবং bulk custom CSV export।
 * Version: 1.0.0
 * Requires Plugins: woocommerce
 */
if (!defined('ABSPATH')) exit;

add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil'))
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
});

class WOLP {
    static function init() {
        // Columns (legacy + HPOS)
        add_filter('manage_edit-shop_order_columns', [__CLASS__, 'cols'], 20);
        add_filter('manage_woocommerce_page_wc-orders_columns', [__CLASS__, 'cols'], 20);
        add_action('manage_shop_order_posts_custom_column', [__CLASS__, 'col'], 20, 2);
        add_action('manage_woocommerce_page_wc-orders_custom_column', [__CLASS__, 'col'], 20, 2);
        // Bulk
        foreach (['edit-shop_order', 'woocommerce_page_wc-orders'] as $s) {
            add_filter("bulk_actions-$s", function ($a) { $a['wolp_export'] = 'Export Orders to Custom CSV'; return $a; });
            add_filter("handle_bulk_actions-$s", [__CLASS__, 'bulk'], 10, 3);
        }
        add_action('woocommerce_checkout_create_order', function ($o) { $o->update_meta_data('_wolp_ip', self::ip()); });
        add_action('woocommerce_store_api_checkout_update_order_meta', function ($o) { $o->update_meta_data('_wolp_ip', self::ip()); });
        add_action('admin_post_wolp_single', [__CLASS__, 'single']);
        add_action('admin_head', [__CLASS__, 'css']);
    }

    static function cols($c) {
        $n = [];
        foreach ($c as $k => $v) {
            if ($k === 'order_number') $n['wolp_img'] = 'Image';
            $n[$k] = $v;
        }
        $n['wolp_ip'] = 'IP';
        $n['wolp_wa'] = 'WhatsApp';
        $n['wolp_exp'] = 'Export';
        return $n;
    }

    static function col($col, $arg) {
        if (!in_array($col, ['wolp_img', 'wolp_wa', 'wolp_exp', 'wolp_ip'], true)) return;
        $o = is_object($arg) ? $arg : wc_get_order($arg);
        if (!$o) return;
        if ($col === 'wolp_img') {
            foreach ($o->get_items() as $i) {
                $p = $i->get_product();
                if ($p) { echo $p->get_image([50, 50], ['style' => 'border-radius:6px;display:block']); }
                break;
            }
        } elseif ($col === 'wolp_ip') {
            echo esc_html(self::get_ip($o));
        } elseif ($col === 'wolp_wa') {
            $ph = $o->get_billing_phone();
            if (!$ph) return;
            echo esc_html($ph) . ' <a href="' . esc_url('https://wa.me/' . self::wa($ph)) . '" target="_blank" title="WhatsApp" class="wolp-wa"><span class="wolp-ico">WA</span></a>';
        } else {
            $u = wp_nonce_url(admin_url('admin-post.php?action=wolp_single&id=' . $o->get_id()), 'wolp_' . $o->get_id());
            echo '<a href="' . esc_url($u) . '" title="Export CSV/Excel" class="wolp-x"><span class="dashicons dashicons-media-spreadsheet"></span></a>';
        }
    }

    static function ip() {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
            if (!empty($_SERVER[$k])) {
                $ip = trim(explode(',', $_SERVER[$k])[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
        }
        return '';
    }

    static function get_ip($o) {
        return $o->get_meta('_wolp_ip') ?: $o->get_customer_ip_address();
    }

    static function wa($p) {
        $d = preg_replace('/\D/', '', $p);
        if (strpos($d, '880') === 0) return $d;
        if (strpos($d, '0') === 0) return '88' . $d;
        return '880' . $d;
    }

    static function css() {
        echo '<style>.column-wolp_img{width:60px}.column-wolp_wa{width:150px}.column-wolp_exp{width:60px;text-align:center}.wolp-wa{text-decoration:none;margin-left:4px}.wolp-ico{display:inline-block;background:#25D366;color:#fff;font-weight:700;font-size:11px;padding:4px 7px;border-radius:50%;line-height:1}.wolp-x .dashicons{color:#1d7a46;font-size:26px;width:26px;height:26px}.wolp-x:hover .dashicons{color:#0b5d30}</style>';
    }

    static function bulk($redirect, $action, $ids) {
        if ($action !== 'wolp_export') return $redirect;
        if (!current_user_can('manage_woocommerce')) return $redirect;
        self::csv(array_map('absint', (array) $ids), 'orders-' . date('Y-m-d'));
    }

    static function single() {
        $id = absint($_GET['id'] ?? 0);
        if (!current_user_can('manage_woocommerce') || !wp_verify_nonce($_GET['_wpnonce'] ?? '', 'wolp_' . $id)) wp_die('Not allowed');
        self::csv([$id], 'order-' . $id);
    }

    static function csv($ids, $name) {
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $name . '.csv"');
        $f = fopen('php://output', 'w');
        fwrite($f, "\xEF\xBB\xBF"); // UTF-8 BOM (Bangla Excel-এ ঠিক দেখাবে)
        fputcsv($f, ['Order ID', 'Customer Name', 'Customer Phone', 'Billing Address', 'Order Total', 'Customer IP', 'Products', 'Product Links']);
        foreach ($ids as $id) {
            $o = wc_get_order($id);
            if (!$o) continue;
            $names = []; $links = [];
            foreach ($o->get_items() as $i) {
                $names[] = $i->get_name() . ' × ' . $i->get_quantity();
                $links[] = get_permalink($i->get_product_id());
            }
            $addr = trim(preg_replace('/\s+/', ' ', wp_strip_all_tags(str_replace(['<br/>', '<br>', '<br />'], ', ', $o->get_formatted_billing_address()))));
            fputcsv($f, [
                $o->get_order_number(),
                trim($o->get_billing_first_name() . ' ' . $o->get_billing_last_name()),
                $o->get_billing_phone(),
                $addr,
                html_entity_decode(wp_strip_all_tags($o->get_formatted_order_total())),
                self::get_ip($o),
                implode("\n", $names),
                implode("\n", $links),
            ]);
        }
        fclose($f);
        exit;
    }
}
add_action('plugins_loaded', ['WOLP', 'init']);
