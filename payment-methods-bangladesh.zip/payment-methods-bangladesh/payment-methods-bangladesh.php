<?php
/**
 * Plugin Name:       Payment Methods Bangladesh
 * Plugin URI:        https://borbila.com/
 * Description:       Simple manual Bkash, Nagad and Rocket payment methods for WooCommerce stores in Bangladesh.
 * Version:           1.0.5
 * Requires at least: 6.5
 * Requires PHP:      8.0
 * Author:            Borbila
 * Author URI:        https://borbila.com/
 * Text Domain:       payment-methods-bangladesh
 * Domain Path:       /languages
 * WC requires at least: 8.0
 * WC tested up to:   10.1
 *
 * @package PaymentMethodsBangladesh
 */

defined( 'ABSPATH' ) || exit;

define( 'PMB_VERSION', '1.0.5' );
define( 'PMB_PLUGIN_FILE', __FILE__ );
define( 'PMB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'PMB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Declare WooCommerce feature compatibility before WooCommerce initializes.
 */
function pmb_declare_woocommerce_compatibility() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
}
add_action( 'before_woocommerce_init', 'pmb_declare_woocommerce_compatibility' );

/**
 * Show a safe dependency notice instead of loading gateway classes too early.
 */
function pmb_woocommerce_missing_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	printf(
		'<div class="notice notice-error"><p>%s</p></div>',
		esc_html__( 'Payment Methods Bangladesh requires WooCommerce to be installed and activated.', 'payment-methods-bangladesh' )
	);
}

/**
 * Register all three independent gateways.
 *
 * @param array $gateways Existing WooCommerce gateway classes.
 * @return array
 */
function pmb_register_payment_gateways( $gateways ) {
	$gateways[] = 'PMB_Gateway_Bkash';
	$gateways[] = 'PMB_Gateway_Nagad';
	$gateways[] = 'PMB_Gateway_Rocket';

	return $gateways;
}

/**
 * Load the Checkout Block payment method integrations after Blocks is ready.
 */
function pmb_load_blocks_support() {
	if ( ! class_exists( '\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
		return;
	}

	require_once PMB_PLUGIN_DIR . 'includes/class-pmb-blocks-support.php';

	add_action(
		'woocommerce_blocks_payment_method_type_registration',
		static function ( $payment_method_registry ) {
			foreach ( array( 'pmb_bkash', 'pmb_nagad', 'pmb_rocket' ) as $gateway_id ) {
				$payment_method_registry->register( new PMB_Blocks_Payment_Method( $gateway_id ) );
			}
		}
	);
}
add_action( 'woocommerce_blocks_loaded', 'pmb_load_blocks_support' );

/**
 * Load plugin code only after all plugins, including WooCommerce, are available.
 */
function pmb_bootstrap() {
	load_plugin_textdomain( 'payment-methods-bangladesh', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	if ( ! class_exists( 'WooCommerce' ) || ! class_exists( 'WC_Payment_Gateway' ) ) {
		add_action( 'admin_notices', 'pmb_woocommerce_missing_notice' );
		return;
	}

	require_once PMB_PLUGIN_DIR . 'includes/class-pmb-transaction.php';
	require_once PMB_PLUGIN_DIR . 'includes/abstract-class-pmb-gateway.php';
	require_once PMB_PLUGIN_DIR . 'includes/class-pmb-gateway-bkash.php';
	require_once PMB_PLUGIN_DIR . 'includes/class-pmb-gateway-nagad.php';
	require_once PMB_PLUGIN_DIR . 'includes/class-pmb-gateway-rocket.php';
	require_once PMB_PLUGIN_DIR . 'includes/class-pmb-order-meta.php';
	require_once PMB_PLUGIN_DIR . 'includes/class-pmb-admin.php';

	add_filter( 'woocommerce_payment_gateways', 'pmb_register_payment_gateways' );
	PMB_Order_Meta::init();
	PMB_Admin::init();
}
add_action( 'plugins_loaded', 'pmb_bootstrap', 20 );

/**
 * Enqueue checkout/customer styles only where they are needed.
 */
function pmb_enqueue_frontend_assets() {
	if ( ! function_exists( 'is_checkout' ) || ( ! is_checkout() && ! is_account_page() ) ) {
		return;
	}

	wp_enqueue_style(
		'pmb-checkout',
		PMB_PLUGIN_URL . 'assets/css/checkout.css',
		array(),
		PMB_VERSION
	);

	if ( is_checkout() && ! is_order_received_page() ) {
		wp_enqueue_script(
			'pmb-checkout',
			PMB_PLUGIN_URL . 'assets/js/checkout.js',
			array( 'jquery' ),
			PMB_VERSION,
			true
		);

		wp_localize_script(
			'pmb-checkout',
			'pmbCheckoutL10n',
			array(
				'copyNumber' => __( 'Copy receiver number', 'payment-methods-bangladesh' ),
				'copied'     => __( 'Copied', 'payment-methods-bangladesh' ),
				'copyFailed' => __( 'Copy failed', 'payment-methods-bangladesh' ),
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'pmb_enqueue_frontend_assets' );
