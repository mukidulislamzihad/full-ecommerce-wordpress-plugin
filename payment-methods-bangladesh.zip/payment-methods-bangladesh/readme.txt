=== Payment Methods Bangladesh ===
Contributors: borbila
Tags: woocommerce, bkash, nagad, rocket, bangladesh, payment gateway
Requires at least: 6.5
Tested up to: 7.0
Requires PHP: 8.0
Stable tag: 1.0.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Simple manual Bkash, Nagad and Rocket payment methods for WooCommerce stores in Bangladesh.

== Description ==

Payment Methods Bangladesh adds three independent manual WooCommerce gateways:

* Bkash
* Nagad
* Rocket Pay

Every gateway has its own enable switch, checkout title, description, receiver number, account type, instructions, and submitted-order status. Customers must enter their sender number and Transaction ID. The plugin securely stores the submitted information on the order, displays it to the customer and administrator, and prevents reuse of a Transaction ID across orders.

The plugin supports WooCommerce High-Performance Order Storage (HPOS), Classic Checkout, and the WooCommerce Checkout Block.

== Installation ==

1. Upload the plugin ZIP through Plugins > Add New > Upload Plugin.
2. Activate Payment Methods Bangladesh.
3. Go to WooCommerce > Settings > Payments.
4. Configure and enable Bkash, Nagad, and/or Rocket Pay separately.
5. Enter a receiver number for every enabled method.

== Frequently Asked Questions ==

= Does this plugin contact an external payment API? =

No. These are manual payment methods. Store administrators verify submitted transaction details themselves.

= Can each gateway be enabled separately? =

Yes. Each gateway is a separate native WooCommerce payment method.

= Does it support HPOS and Checkout Block? =

Yes. Compatibility is declared for HPOS and Cart/Checkout Blocks, and each gateway registers a Checkout Block payment method integration.

== Changelog ==

= 1.0.5 =
* Removed the dark accent border from the payment instruction box.

= 1.0.4 =
* Limited the customer Payment Information section to a centered 1200px maximum width.
* Preserved full-width responsive behavior on smaller screens.

= 1.0.3 =
* Added a small accessible copy button beside each receiver number.
* Added secure Clipboard API handling with a non-HTTPS fallback.

= 1.0.2 =
* Fixed Classic Checkout submission when multiple Bangladesh gateways are enabled.
* Added gateway-specific field names for Classic and Block Checkout payloads.

= 1.0.1 =
* Refined the checkout payment panel with a compact classic design.
* Improved responsive payment summary and field spacing.

= 1.0.0 =
* Initial release.
* Added Bkash, Nagad, and Rocket Pay manual gateways.
* Added Classic and Block Checkout field validation.
* Added HPOS-safe order metadata and displays.
* Added case-insensitive duplicate Transaction ID protection.
