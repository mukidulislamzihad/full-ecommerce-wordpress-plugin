( function( $, document ) {
	'use strict';

	function refreshPaymentBoxState() {
		$( '.payment_methods .wc_payment_method' ).each( function() {
			var $method = $( this );
			var active = $method.find( 'input[name="payment_method"]' ).is( ':checked' );
			$method.toggleClass( 'pmb-is-selected', active );
			$method.find( '.pmb-payment-box' ).attr( 'aria-hidden', active ? 'false' : 'true' );
		} );
	}

	function fallbackCopy( value ) {
		var textarea = document.createElement( 'textarea' );
		var copied = false;
		textarea.value = value;
		textarea.setAttribute( 'readonly', 'readonly' );
		textarea.style.position = 'fixed';
		textarea.style.left = '-9999px';
		textarea.style.opacity = '0';
		document.body.appendChild( textarea );
		textarea.select();
		try {
			copied = document.execCommand( 'copy' );
		} catch ( error ) {
			copied = false;
		}
		document.body.removeChild( textarea );
		return copied;
	}

	function showCopyResult( $button, success ) {
		var labels = window.pmbCheckoutL10n || {};
		var defaultLabel = labels.copyNumber || 'Copy receiver number';
		var resultLabel = success ? ( labels.copied || 'Copied' ) : ( labels.copyFailed || 'Copy failed' );
		var previousTimer = $button.data( 'pmb-copy-timer' );

		if ( previousTimer ) {
			window.clearTimeout( previousTimer );
		}

		$button.toggleClass( 'is-copied', success ).toggleClass( 'has-copy-error', ! success );
		$button.attr( 'aria-label', resultLabel ).attr( 'title', resultLabel );
		$button.find( '.pmb-copy-status' ).text( resultLabel );

		$button.data( 'pmb-copy-timer', window.setTimeout( function() {
			$button.removeClass( 'is-copied has-copy-error' );
			$button.attr( 'aria-label', defaultLabel ).attr( 'title', defaultLabel );
			$button.find( '.pmb-copy-status' ).text( '' );
		}, 1800 ) );
	}

	$( document ).on( 'click', '.pmb-copy-number', function( event ) {
		var $button = $( this );
		var value = String( $button.attr( 'data-copy-value' ) || '' ).trim();

		event.preventDefault();
		event.stopPropagation();

		if ( ! value ) {
			showCopyResult( $button, false );
			return;
		}

		if ( navigator.clipboard && window.isSecureContext ) {
			navigator.clipboard.writeText( value ).then(
				function() { showCopyResult( $button, true ); },
				function() { showCopyResult( $button, fallbackCopy( value ) ); }
			);
			return;
		}

		showCopyResult( $button, fallbackCopy( value ) );
	} );

	$( document.body ).on( 'updated_checkout payment_method_selected', refreshPaymentBoxState );
	$( document ).on( 'change', 'input[name="payment_method"]', refreshPaymentBoxState );
	$( refreshPaymentBoxState );
}( jQuery, document ) );
