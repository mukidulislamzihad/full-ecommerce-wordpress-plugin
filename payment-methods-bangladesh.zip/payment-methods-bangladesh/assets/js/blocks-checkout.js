( function() {
	'use strict';

	var registry = window.wc && window.wc.wcBlocksRegistry;
	var settings = window.wc && window.wc.wcSettings;
	var element = window.wp && window.wp.element;
	var htmlEntities = window.wp && window.wp.htmlEntities;
	var i18n = window.wp && window.wp.i18n;

	if ( ! registry || ! settings || ! element ) {
		return;
	}

	var el = element.createElement;
	var useEffect = element.useEffect;
	var useState = element.useState;
	var decode = htmlEntities ? htmlEntities.decodeEntities : function( value ) { return value; };
	var __ = i18n ? i18n.__ : function( value ) { return value; };

	function textFromHtml( value ) {
		var temporary = document.createElement( 'div' );
		temporary.innerHTML = String( value || '' );
		return temporary.textContent || temporary.innerText || '';
	}

	function formatCurrency( total, currency ) {
		if ( ! total || typeof total.value === 'undefined' ) {
			return '';
		}

		currency = currency || {};
		var decimals = Number.isFinite( Number( currency.minorUnit ) ) ? Number( currency.minorUnit ) : 2;
		var value = Number( total.value ) / Math.pow( 10, decimals );
		var fixed = value.toFixed( decimals ).split( '.' );
		var thousands = currency.thousandSeparator || ',';
		var decimal = currency.decimalSeparator || '.';
		fixed[ 0 ] = fixed[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, thousands );
		var amount = fixed[ 0 ] + ( decimals ? decimal + fixed[ 1 ] : '' );
		var prefix = currency.prefix || currency.symbol || '';
		var suffix = currency.suffix || '';
		return decode( prefix ) + amount + decode( suffix );
	}

	function CopyButton( props ) {
		return el( 'button', {
			type: 'button',
			className: 'pmb-copy-number',
			'data-copy-value': props.value,
			'aria-label': props.label,
			title: props.label,
		},
			el( 'svg', { viewBox: '0 0 24 24', 'aria-hidden': 'true', focusable: 'false' },
				el( 'rect', { x: '8', y: '8', width: '11', height: '11', rx: '2' } ),
				el( 'path', { d: 'M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2' } )
			),
			el( 'span', { className: 'pmb-copy-status', 'aria-live': 'polite' } )
		);
	}

	function PaymentContent( props ) {
		var config = props.config;
		var eventRegistration = props.eventRegistration || {};
		var emitResponse = props.emitResponse || {};
		var billing = props.billing || {};
		var senderState = useState( '' );
		var sender = senderState[ 0 ];
		var setSender = senderState[ 1 ];
		var transactionState = useState( '' );
		var transactionId = transactionState[ 0 ];
		var setTransactionId = transactionState[ 1 ];

		useEffect( function() {
			if ( ! eventRegistration.onPaymentProcessing ) {
				return function() {};
			}

			return eventRegistration.onPaymentProcessing( function() {
				if ( ! sender.trim() || ! transactionId.trim() ) {
					return {
						type: emitResponse.responseTypes ? emitResponse.responseTypes.ERROR : 'error',
						message: config.required_message,
					};
				}

				var paymentMethodData = {};
				paymentMethodData[ config.id + '_sender_number' ] = sender.trim();
				paymentMethodData[ config.id + '_transaction_id' ] = transactionId.trim();

				return {
					type: emitResponse.responseTypes ? emitResponse.responseTypes.SUCCESS : 'success',
					meta: {
						paymentMethodData: paymentMethodData,
					},
				};
			} );
		}, [ sender, transactionId, eventRegistration.onPaymentProcessing, emitResponse.responseTypes ] );

		var amount = formatCurrency( billing.cartTotal, billing.currency );

		return el( 'div', { className: 'pmb-block-payment-box pmb-payment-box' },
			config.description ? el( 'p', { className: 'pmb-description' }, textFromHtml( config.description ) ) : null,
			el( 'dl', { className: 'pmb-payment-summary' },
				amount ? el( 'div', null, el( 'dt', null, config.amount_label ), el( 'dd', null, amount ) ) : null,
				el( 'div', null, el( 'dt', null, config.receiver_label ), el( 'dd', { className: 'pmb-receiver-value' }, config.receiver_number, el( CopyButton, { value: config.receiver_number, label: config.copy_label } ) ) ),
				el( 'div', null, el( 'dt', null, config.account_type_label ), el( 'dd', null, config.account_type ) )
			),
			config.instructions ? el( 'p', { className: 'pmb-instructions' }, textFromHtml( config.instructions ) ) : null,
			el( 'label', { className: 'pmb-block-field' },
				el( 'span', null, config.sender_label, ' ', el( 'abbr', { title: __( 'required', 'payment-methods-bangladesh' ) }, '*' ) ),
				el( 'input', {
					type: 'tel',
					value: sender,
					maxLength: 40,
					autoComplete: 'tel',
					required: true,
					onChange: function( event ) { setSender( event.target.value ); },
				} )
			),
			el( 'label', { className: 'pmb-block-field' },
				el( 'span', null, config.transaction_label, ' ', el( 'abbr', { title: __( 'required', 'payment-methods-bangladesh' ) }, '*' ) ),
				el( 'input', {
					type: 'text',
					value: transactionId,
					maxLength: 100,
					autoComplete: 'off',
					required: true,
					onChange: function( event ) { setTransactionId( event.target.value ); },
				} )
			)
		);
	}

	[ 'pmb_bkash', 'pmb_nagad', 'pmb_rocket' ].forEach( function( gatewayId ) {
		var config = settings.getSetting( gatewayId + '_data', null );
		if ( ! config || ! config.id ) {
			return;
		}

		registry.registerPaymentMethod( {
			name: gatewayId,
			label: el( 'span', { className: 'pmb-block-label' }, decode( config.title ) ),
			content: el( PaymentContent, { config: config } ),
			edit: el( 'div', { className: 'pmb-block-editor-preview' }, textFromHtml( config.description ) ),
			canMakePayment: function() { return true; },
			ariaLabel: decode( config.title ),
			supports: { features: config.supports || [ 'products' ] },
		} );
	} );
}() );
