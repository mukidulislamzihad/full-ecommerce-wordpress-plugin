<?php
/**
 * WooCommerce Checkout Block integration.
 *
 * @package PaymentMethodsBangladesh
 */

defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class PMB_Blocks_Payment_Method extends AbstractPaymentMethodType {
	/** @var string Gateway option name. */
	protected $name = '';

	/** @var array Gateway settings. */
	private $gateway_settings = array();

	/**
	 * Create an integration instance for one gateway.
	 *
	 * @param string $gateway_id Gateway ID.
	 */
	public function __construct( $gateway_id ) {
		$this->name = sanitize_key( $gateway_id );
	}

	/** Load gateway settings. */
	public function initialize() {
		$this->settings         = get_option( 'woocommerce_' . $this->name . '_settings', array() );
		$this->gateway_settings = is_array( $this->settings ) ? $this->settings : array();
	}

	/**
	 * Respect the individual native WooCommerce enable toggle and receiver number.
	 *
	 * @return bool
	 */
	public function is_active() {
		return 'yes' === ( $this->gateway_settings['enabled'] ?? 'no' ) && '' !== trim( (string) ( $this->gateway_settings['receiver_number'] ?? '' ) );
	}

	/**
	 * Shared browser script registered once for all gateways.
	 *
	 * @return string[]
	 */
	public function get_payment_method_script_handles() {
		$handle = 'pmb-blocks-checkout';
		if ( ! wp_script_is( $handle, 'registered' ) ) {
			wp_register_script(
				$handle,
				PMB_PLUGIN_URL . 'assets/js/blocks-checkout.js',
				array( 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities', 'wp-i18n' ),
				PMB_VERSION,
				true
			);
		}

		return array( $handle );
	}

	/**
	 * Data exposed to the registered Checkout Block payment method.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		$defaults = self::defaults( $this->name );
		$type     = $this->gateway_settings['account_type'] ?? 'personal';
		$types    = array(
			'personal' => __( 'Personal', 'payment-methods-bangladesh' ),
			'agent'    => __( 'Agent', 'payment-methods-bangladesh' ),
			'merchant' => __( 'Merchant', 'payment-methods-bangladesh' ),
		);

		return array(
			'id'                  => $this->name,
			'title'               => sanitize_text_field( $this->gateway_settings['title'] ?? $defaults['title'] ),
			'description'         => wp_kses_post( $this->gateway_settings['description'] ?? $defaults['description'] ),
			'receiver_number'     => sanitize_text_field( $this->gateway_settings['receiver_number'] ?? '' ),
			'account_type'        => $types[ $type ] ?? $types['personal'],
			'instructions'        => wp_kses_post( $this->gateway_settings['instructions'] ?? $defaults['instructions'] ),
			'sender_label'        => $defaults['sender_label'],
			'transaction_label'   => __( 'Transaction ID', 'payment-methods-bangladesh' ),
			'amount_label'        => __( 'Amount to pay', 'payment-methods-bangladesh' ),
			'receiver_label'      => __( 'Receiver number', 'payment-methods-bangladesh' ),
			'account_type_label'  => __( 'Account type', 'payment-methods-bangladesh' ),
			'copy_label'          => __( 'Copy receiver number', 'payment-methods-bangladesh' ),
			'required_message'    => __( 'Please enter your sender number and Transaction ID.', 'payment-methods-bangladesh' ),
			'supports'            => array( 'products' ),
		);
	}

	/**
	 * Default customer-facing labels and copy for each gateway.
	 *
	 * @param string $gateway_id Gateway ID.
	 * @return array
	 */
	private static function defaults( $gateway_id ) {
		$all = array(
			'pmb_bkash' => array(
				'title'        => 'Bkash',
				'description'  => __( 'Pay manually with Bkash.', 'payment-methods-bangladesh' ),
				'sender_label' => __( 'Your Bkash Number', 'payment-methods-bangladesh' ),
			),
			'pmb_nagad' => array(
				'title'        => 'Nagad',
				'description'  => __( 'Pay manually with Nagad.', 'payment-methods-bangladesh' ),
				'sender_label' => __( 'Your Nagad Number', 'payment-methods-bangladesh' ),
			),
			'pmb_rocket' => array(
				'title'        => 'Rocket Pay',
				'description'  => __( 'Pay manually with Rocket Pay.', 'payment-methods-bangladesh' ),
				'sender_label' => __( 'Your Rocket Number', 'payment-methods-bangladesh' ),
			),
		);

		$defaults                 = $all[ $gateway_id ] ?? $all['pmb_bkash'];
		$defaults['instructions'] = __( 'Send the exact order amount, then enter your sender number and Transaction ID below.', 'payment-methods-bangladesh' );

		return $defaults;
	}
}
