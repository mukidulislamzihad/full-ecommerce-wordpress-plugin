<?php
/**
 * Bkash gateway.
 *
 * @package PaymentMethodsBangladesh
 */

defined( 'ABSPATH' ) || exit;

final class PMB_Gateway_Bkash extends PMB_Abstract_Gateway {
	public function __construct() {
		$this->id                 = 'pmb_bkash';
		$this->brand_name         = 'Bkash';
		$this->sender_label       = __( 'Your Bkash Number', 'payment-methods-bangladesh' );
		$this->method_title       = __( 'Bkash', 'payment-methods-bangladesh' );
		$this->method_description = __( 'Accept manual Bkash payments with sender number and Transaction ID verification.', 'payment-methods-bangladesh' );
		$this->initialize_gateway();
	}
}

