<?php
/**
 * Transaction validation and duplicate protection.
 *
 * @package PaymentMethodsBangladesh
 */

defined( 'ABSPATH' ) || exit;

final class PMB_Transaction {
	/**
	 * Duplicate transaction error required by the product specification.
	 */
	const DUPLICATE_MESSAGE = 'This Transaction ID has already been used. Please check your payment information.';

	/**
	 * Sanitize a submitted sender number without changing legitimate prefixes.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_sender_number( $value ) {
		$value = is_scalar( $value ) ? sanitize_text_field( wp_unslash( (string) $value ) ) : '';
		return self::limit_length( trim( $value ), 40 );
	}

	/**
	 * Sanitize a transaction ID for display/storage.
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	public static function sanitize_transaction_id( $value ) {
		$value = is_scalar( $value ) ? sanitize_text_field( wp_unslash( (string) $value ) ) : '';
		return self::limit_length( trim( $value ), 100 );
	}

	/**
	 * Build a case-insensitive canonical value.
	 *
	 * Whitespace is ignored because customers commonly paste a transaction ID
	 * with an accidental leading, trailing, or internal space.
	 *
	 * @param string $transaction_id Transaction ID.
	 * @return string
	 */
	public static function normalize( $transaction_id ) {
		$normalized = preg_replace( '/\s+/u', '', trim( $transaction_id ) );
		$normalized = is_string( $normalized ) ? $normalized : '';

		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $normalized, 'UTF-8' ) : strtolower( $normalized );
	}

	/**
	 * Return a fixed-length lookup key that is safe for an indexed meta query.
	 *
	 * @param string $transaction_id Transaction ID.
	 * @return string
	 */
	public static function hash( $transaction_id ) {
		return hash( 'sha256', self::normalize( $transaction_id ) );
	}

	/**
	 * Read payment fields posted by either Classic or Checkout Block.
	 *
	 * @param string $gateway_id Selected gateway ID. Classic Checkout renders
	 *                           every gateway in one form, so each method must
	 *                           use unique field names.
	 * @return array{sender_number:string,transaction_id:string}
	 */
	public static function posted_fields( $gateway_id = '' ) {
		$gateway_id     = sanitize_key( $gateway_id );
		$sender_key     = $gateway_id ? $gateway_id . '_sender_number' : 'pmb_sender_number';
		$transaction_key = $gateway_id ? $gateway_id . '_transaction_id' : 'pmb_transaction_id';

		// The common names remain as a compatibility fallback for older Block payloads.
		$sender_value      = $_POST[ $sender_key ] ?? $_POST['pmb_sender_number'] ?? ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checkout nonce is verified by WooCommerce.
		$transaction_value = $_POST[ $transaction_key ] ?? $_POST['pmb_transaction_id'] ?? ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checkout nonce is verified by WooCommerce.

		return array(
			'sender_number'  => self::sanitize_sender_number( $sender_value ),
			'transaction_id' => self::sanitize_transaction_id( $transaction_value ),
		);
	}

	/**
	 * Check both the atomic transaction claim and HPOS-compatible order queries.
	 *
	 * @param string $transaction_id Transaction ID.
	 * @param int    $exclude_order_id Current order ID, if any.
	 * @return bool
	 */
	public static function exists( $transaction_id, $exclude_order_id = 0 ) {
		$hash = self::hash( $transaction_id );
		if ( '' === self::normalize( $transaction_id ) ) {
			return false;
		}

		$claimed_order_id = absint( get_option( self::claim_option_name( $hash ), 0 ) );
		if ( $claimed_order_id && $claimed_order_id !== absint( $exclude_order_id ) ) {
			return true;
		}

		if ( ! function_exists( 'wc_get_orders' ) ) {
			return false;
		}

		$args = array(
			'limit'      => 1,
			'return'     => 'ids',
			'type'       => 'shop_order',
			'status'     => array_keys( wc_get_order_statuses() ),
			'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Small exact hash lookup required for cross-order uniqueness.
				array(
					'key'     => '_pmb_transaction_id_hash',
					'value'   => $hash,
					'compare' => '=',
				),
			),
		);

		if ( $exclude_order_id ) {
			$args['exclude'] = array( absint( $exclude_order_id ) );
		}

		return ! empty( wc_get_orders( $args ) );
	}

	/**
	 * Atomically reserve a transaction ID to prevent concurrent duplicate use.
	 *
	 * @param string $transaction_id Transaction ID.
	 * @param int    $order_id Order ID.
	 * @return bool
	 */
	public static function claim( $transaction_id, $order_id ) {
		$option_name = self::claim_option_name( self::hash( $transaction_id ) );
		$existing    = absint( get_option( $option_name, 0 ) );

		if ( $existing ) {
			return $existing === absint( $order_id );
		}

		return add_option( $option_name, absint( $order_id ), '', false );
	}

	/**
	 * Create the private option name for an atomic claim.
	 *
	 * @param string $hash Normalized transaction hash.
	 * @return string
	 */
	private static function claim_option_name( $hash ) {
		return '_pmb_trx_' . $hash;
	}

	/**
	 * Limit input safely even when the optional mbstring extension is absent.
	 *
	 * @param string $value Input value.
	 * @param int    $length Maximum character count.
	 * @return string
	 */
	private static function limit_length( $value, $length ) {
		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, $length, 'UTF-8' ) : substr( $value, 0, $length );
	}
}
