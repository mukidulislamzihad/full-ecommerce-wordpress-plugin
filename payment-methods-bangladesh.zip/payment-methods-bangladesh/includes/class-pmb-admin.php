<?php
/**
 * Small native WooCommerce admin integrations.
 *
 * @package PaymentMethodsBangladesh
 */

defined( 'ABSPATH' ) || exit;

final class PMB_Admin {
	/** Register admin hooks. */
	public static function init() {
		add_filter( 'plugin_action_links_' . plugin_basename( PMB_PLUGIN_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Add a direct link to the WooCommerce payments page.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public static function action_links( $links ) {
		$url = admin_url( 'admin.php?page=wc-settings&tab=checkout' );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Payment settings', 'payment-methods-bangladesh' ) . '</a>' );
		return $links;
	}
}

