<?php
/**
 * Nagad gateway.
 *
 * @package PaymentMethodsBangladesh
 */

defined( 'ABSPATH' ) || exit;

final class PMB_Gateway_Nagad extends PMB_Abstract_Gateway {
	public function __construct() {
		$this->id                 = 'pmb_nagad';
		$this->brand_name         = 'Nagad';
		$this->sender_label       = __( 'Your Nagad Number', 'payment-methods-bangladesh' );
		$this->method_title       = __( 'Nagad', 'payment-methods-bangladesh' );
		$this->method_description = __( 'Accept manual Nagad payments with sender number and Transaction ID verification.', 'payment-methods-bangladesh' );
		$this->initialize_gateway();
	}
}

