<?php
/**
 * Shared manual gateway implementation.
 *
 * @package PaymentMethodsBangladesh
 */

defined( 'ABSPATH' ) || exit;

abstract class PMB_Abstract_Gateway extends WC_Payment_Gateway {
	/** @var string Customer field label. */
	protected $sender_label = '';

	/** @var string Short payment method name. */
	protected $brand_name = '';

	/** @var string Receiving account number. */
	protected $receiver_number = '';

	/** @var string Receiving account type. */
	protected $account_type = 'personal';

	/** @var string Customer payment instructions. */
	protected $instructions = '';

	/** @var string Order status selected by the merchant. */
	protected $order_status = 'on-hold';

	/**
	 * Complete shared setup after a child class sets its identifiers.
	 */
	protected function initialize_gateway() {
		$this->has_fields = true;
		$this->supports   = array( 'products' );

		$this->init_form_fields();
		$this->init_settings();

		$this->enabled         = $this->get_option( 'enabled', 'no' );
		$this->title           = $this->get_option( 'title', $this->brand_name );
		$this->description     = $this->get_option( 'description', '' );
		$this->receiver_number = $this->get_option( 'receiver_number', '' );
		$this->account_type    = $this->get_option( 'account_type', 'personal' );
		$this->instructions    = $this->get_option( 'instructions', '' );
		$this->order_status    = $this->get_option( 'order_status', 'on-hold' );

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	/**
	 * Admin gateway settings.
	 */
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'         => array(
				'title'   => __( 'Enable/Disable', 'payment-methods-bangladesh' ),
				'type'    => 'checkbox',
				'label'   => sprintf( /* translators: %s payment method name. */ __( 'Enable %s', 'payment-methods-bangladesh' ), $this->brand_name ),
				'default' => 'no',
			),
			'title'           => array(
				'title'       => __( 'Title', 'payment-methods-bangladesh' ),
				'type'        => 'text',
				'description' => __( 'The payment method title customers see at checkout.', 'payment-methods-bangladesh' ),
				'default'     => $this->brand_name,
				'desc_tip'    => true,
			),
			'description'     => array(
				'title'       => __( 'Description', 'payment-methods-bangladesh' ),
				'type'        => 'textarea',
				'description' => __( 'A short description shown when this method is selected.', 'payment-methods-bangladesh' ),
				'default'     => sprintf( /* translators: %s payment method name. */ __( 'Pay manually with %s.', 'payment-methods-bangladesh' ), $this->brand_name ),
			),
			'receiver_number' => array(
				'title'       => __( 'Receiver number', 'payment-methods-bangladesh' ),
				'type'        => 'text',
				'description' => __( 'The number where customers must send the payment.', 'payment-methods-bangladesh' ),
				'default'     => '',
				'desc_tip'    => true,
			),
			'account_type'    => array(
				'title'   => __( 'Account type', 'payment-methods-bangladesh' ),
				'type'    => 'select',
				'default' => 'personal',
				'options' => array(
					'personal' => __( 'Personal', 'payment-methods-bangladesh' ),
					'agent'    => __( 'Agent', 'payment-methods-bangladesh' ),
					'merchant' => __( 'Merchant', 'payment-methods-bangladesh' ),
				),
			),
			'instructions'    => array(
				'title'       => __( 'Payment instructions', 'payment-methods-bangladesh' ),
				'type'        => 'textarea',
				'description' => __( 'Step-by-step instructions displayed to the customer at checkout.', 'payment-methods-bangladesh' ),
				'default'     => __( 'Send the exact order amount, then enter your sender number and Transaction ID below.', 'payment-methods-bangladesh' ),
			),
			'order_status'    => array(
				'title'       => __( 'Order status after payment submission', 'payment-methods-bangladesh' ),
				'type'        => 'select',
				'description' => __( 'Status assigned after the customer submits the manual payment information.', 'payment-methods-bangladesh' ),
				'default'     => 'on-hold',
				'options'     => array(
					'on-hold'   => __( 'On Hold', 'payment-methods-bangladesh' ),
					'processing' => __( 'Processing', 'payment-methods-bangladesh' ),
				),
			),
		);
	}

	/**
	 * Only make a gateway available when its required receiving details exist.
	 *
	 * @return bool
	 */
	public function is_available() {
		return parent::is_available() && '' !== trim( (string) $this->receiver_number );
	}

	/**
	 * Render the selected gateway's customer input box.
	 */
	public function payment_fields() {
		$fields       = PMB_Transaction::posted_fields( $this->id );
		$amount_html  = WC()->cart ? WC()->cart->get_total() : wc_price( 0 );
		$account_type = $this->account_type_label();

		if ( $this->description ) {
			printf( '<div class="pmb-description">%s</div>', wp_kses_post( wpautop( $this->description ) ) );
		}

		echo '<div class="pmb-payment-box" data-pmb-gateway="' . esc_attr( $this->id ) . '">';
		echo '<dl class="pmb-payment-summary">';
		printf( '<div><dt>%s</dt><dd>%s</dd></div>', esc_html__( 'Amount to pay', 'payment-methods-bangladesh' ), wp_kses_post( $amount_html ) );
		printf(
			'<div><dt>%1$s</dt><dd class="pmb-receiver-value"><bdi>%2$s</bdi><button type="button" class="pmb-copy-number" data-copy-value="%3$s" aria-label="%4$s" title="%4$s"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="8" y="8" width="11" height="11" rx="2"></rect><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"></path></svg><span class="pmb-copy-status" aria-live="polite"></span></button></dd></div>',
			esc_html__( 'Receiver number', 'payment-methods-bangladesh' ),
			esc_html( $this->receiver_number ),
			esc_attr( $this->receiver_number ),
			esc_attr__( 'Copy receiver number', 'payment-methods-bangladesh' )
		);
		printf( '<div><dt>%s</dt><dd>%s</dd></div>', esc_html__( 'Account type', 'payment-methods-bangladesh' ), esc_html( $account_type ) );
		echo '</dl>';

		if ( $this->instructions ) {
			printf( '<div class="pmb-instructions">%s</div>', wp_kses_post( wpautop( $this->instructions ) ) );
		}

		woocommerce_form_field(
			$this->id . '_sender_number',
			array(
				'type'              => 'tel',
				'label'             => $this->sender_label,
				'required'          => true,
				'class'             => array( 'form-row-wide', 'pmb-field' ),
				'input_class'       => array( 'pmb-input' ),
				'custom_attributes' => array(
					'autocomplete' => 'tel',
					'maxlength'   => '40',
				),
			),
			$fields['sender_number']
		);

		woocommerce_form_field(
			$this->id . '_transaction_id',
			array(
				'type'              => 'text',
				'label'             => __( 'Transaction ID', 'payment-methods-bangladesh' ),
				'required'          => true,
				'class'             => array( 'form-row-wide', 'pmb-field' ),
				'input_class'       => array( 'pmb-input' ),
				'custom_attributes' => array(
					'autocomplete' => 'off',
					'maxlength'   => '100',
				),
			),
			$fields['transaction_id']
		);

		echo '</div>';
	}

	/**
	 * Validate the selected gateway before WooCommerce creates/processes an order.
	 *
	 * @return bool
	 */
	public function validate_fields() {
		$fields = PMB_Transaction::posted_fields( $this->id );
		$valid  = true;

		if ( '' === $fields['sender_number'] ) {
			wc_add_notice( sprintf( /* translators: %s sender number field label. */ __( '%s is required.', 'payment-methods-bangladesh' ), $this->sender_label ), 'error' );
			$valid = false;
		}

		if ( '' === $fields['transaction_id'] ) {
			wc_add_notice( __( 'Transaction ID is required.', 'payment-methods-bangladesh' ), 'error' );
			$valid = false;
		} elseif ( PMB_Transaction::exists( $fields['transaction_id'] ) ) {
			wc_add_notice( __( PMB_Transaction::DUPLICATE_MESSAGE, 'payment-methods-bangladesh' ), 'error' );
			$valid = false;
		}

		return $valid;
	}

	/**
	 * Store the submitted payment data and finish the WooCommerce checkout.
	 *
	 * @param int $order_id WooCommerce order ID.
	 * @return array
	 */
	public function process_payment( $order_id ) {
		$order  = wc_get_order( $order_id );
		$fields = PMB_Transaction::posted_fields( $this->id );

		if ( ! $order || '' === $fields['sender_number'] || '' === $fields['transaction_id'] ) {
			$message = __( 'Please enter complete payment information.', 'payment-methods-bangladesh' );
			wc_add_notice( $message, 'error' );
			return array(
				'result'  => 'failure',
				'message' => $message,
			);
		}

		if ( PMB_Transaction::exists( $fields['transaction_id'], $order_id ) || ! PMB_Transaction::claim( $fields['transaction_id'], $order_id ) ) {
			$message = __( PMB_Transaction::DUPLICATE_MESSAGE, 'payment-methods-bangladesh' );
			wc_add_notice( $message, 'error' );
			return array(
				'result'  => 'failure',
				'message' => $message,
			);
		}

		$amount = wc_format_decimal( $order->get_total( 'edit' ), false );
		$status = in_array( $this->order_status, array( 'on-hold', 'processing' ), true ) ? $this->order_status : 'on-hold';

		$order->update_meta_data( '_pmb_gateway_id', $this->id );
		$order->update_meta_data( '_pmb_payment_method', $this->brand_name );
		$order->update_meta_data( '_pmb_sender_number', $fields['sender_number'] );
		$order->update_meta_data( '_pmb_transaction_id', $fields['transaction_id'] );
		$order->update_meta_data( '_pmb_transaction_id_hash', PMB_Transaction::hash( $fields['transaction_id'] ) );
		$order->update_meta_data( '_pmb_payment_amount', $amount );
		$order->save();

		wc_reduce_stock_levels( $order_id );

		$order->update_status(
			$status,
			sprintf(
				/* translators: 1: payment method, 2: sender number, 3: transaction ID. */
				__( 'Manual %1$s payment submitted. Sender: %2$s; Transaction ID: %3$s. Verification required.', 'payment-methods-bangladesh' ),
				$this->brand_name,
				$fields['sender_number'],
				$fields['transaction_id']
			)
		);

		if ( WC()->cart ) {
			WC()->cart->empty_cart();
		}

		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}

	/**
	 * Sanitize text settings with stricter rules for public labels/numbers.
	 *
	 * @param string $key Setting key.
	 * @param mixed  $value Submitted value.
	 * @return string
	 */
	public function validate_text_field( $key, $value ) {
		if ( 'receiver_number' === $key ) {
			return PMB_Transaction::sanitize_sender_number( $value );
		}

		if ( 'title' === $key ) {
			return sanitize_text_field( is_scalar( $value ) ? wp_unslash( (string) $value ) : '' );
		}

		return parent::validate_text_field( $key, $value );
	}

	/**
	 * Enforce the supported values for both select settings.
	 *
	 * @param string $key Setting key.
	 * @param mixed  $value Submitted value.
	 * @return string
	 */
	public function validate_select_field( $key, $value ) {
		$value = sanitize_key( is_scalar( $value ) ? wp_unslash( (string) $value ) : '' );

		if ( 'account_type' === $key ) {
			return in_array( $value, array( 'personal', 'agent', 'merchant' ), true ) ? $value : 'personal';
		}

		if ( 'order_status' === $key ) {
			return in_array( $value, array( 'on-hold', 'processing' ), true ) ? $value : 'on-hold';
		}

		return parent::validate_select_field( $key, $value );
	}

	/**
	 * Account type translated label.
	 *
	 * @return string
	 */
	protected function account_type_label() {
		$labels = array(
			'personal' => __( 'Personal', 'payment-methods-bangladesh' ),
			'agent'    => __( 'Agent', 'payment-methods-bangladesh' ),
			'merchant' => __( 'Merchant', 'payment-methods-bangladesh' ),
		);

		return $labels[ $this->account_type ] ?? $labels['personal'];
	}
}
