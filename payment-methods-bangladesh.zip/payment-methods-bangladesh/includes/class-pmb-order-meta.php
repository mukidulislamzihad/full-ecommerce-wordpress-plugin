<?php
/**
 * Order metadata display for administrators and customers.
 *
 * @package PaymentMethodsBangladesh
 */

defined( 'ABSPATH' ) || exit;

final class PMB_Order_Meta {
	/** @var array<int,bool> Prevent duplicate customer sections on Thank You. */
	private static $rendered_orders = array();

	/**
	 * Register order screen, list table, Thank You, and My Account hooks.
	 */
	public static function init() {
		add_action( 'woocommerce_admin_order_data_after_order_details', array( __CLASS__, 'render_admin_information' ) );
		add_action( 'woocommerce_thankyou', array( __CLASS__, 'render_customer_information' ), 20 );
		add_action( 'woocommerce_order_details_after_order_table', array( __CLASS__, 'render_customer_information' ), 20 );

		// HPOS orders screen.
		add_filter( 'manage_woocommerce_page_wc-orders_columns', array( __CLASS__, 'add_hpos_column' ) );
		add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( __CLASS__, 'render_hpos_column' ), 10, 2 );

		// Legacy posts-based orders screen.
		add_filter( 'manage_edit-shop_order_columns', array( __CLASS__, 'add_legacy_column' ) );
		add_action( 'manage_shop_order_posts_custom_column', array( __CLASS__, 'render_legacy_column' ), 10, 2 );
	}

	/**
	 * Get protected payment details only for one of this plugin's gateways.
	 *
	 * @param WC_Order|int $order Order object or ID.
	 * @return array<string,string>|false
	 */
	private static function details( $order ) {
		$order = is_a( $order, 'WC_Order' ) ? $order : wc_get_order( $order );
		if ( ! $order ) {
			return false;
		}

		$gateway_id = (string) $order->get_meta( '_pmb_gateway_id', true );
		if ( ! in_array( $gateway_id, array( 'pmb_bkash', 'pmb_nagad', 'pmb_rocket' ), true ) ) {
			return false;
		}

		$amount = (string) $order->get_meta( '_pmb_payment_amount', true );

		return array(
			'method'         => (string) $order->get_meta( '_pmb_payment_method', true ),
			'sender_number'  => (string) $order->get_meta( '_pmb_sender_number', true ),
			'transaction_id' => (string) $order->get_meta( '_pmb_transaction_id', true ),
			'amount_html'    => wc_price( $amount, array( 'currency' => $order->get_currency() ) ),
		);
	}

	/**
	 * Show a clear section on the WooCommerce order edit screen.
	 *
	 * @param WC_Order $order Order object.
	 */
	public static function render_admin_information( $order ) {
		$details = self::details( $order );
		if ( ! $details ) {
			return;
		}

		echo '<div class="pmb-admin-payment-info" style="clear:both;padding-top:16px">';
		echo '<h3>' . esc_html__( 'Manual Payment Information', 'payment-methods-bangladesh' ) . '</h3>';
		echo '<table class="widefat striped" style="max-width:680px"><tbody>';
		self::render_row( __( 'Payment method', 'payment-methods-bangladesh' ), esc_html( $details['method'] ) );
		self::render_row( __( 'Sender number', 'payment-methods-bangladesh' ), '<bdi>' . esc_html( $details['sender_number'] ) . '</bdi>' );
		self::render_row( __( 'Transaction ID', 'payment-methods-bangladesh' ), '<code>' . esc_html( $details['transaction_id'] ) . '</code>' );
		self::render_row( __( 'Submitted amount', 'payment-methods-bangladesh' ), wp_kses_post( $details['amount_html'] ) );
		echo '</tbody></table></div>';
	}

	/**
	 * Render customer-safe payment data on Thank You and My Account order views.
	 *
	 * @param WC_Order|int $order Order object or ID.
	 */
	public static function render_customer_information( $order ) {
		$order = is_a( $order, 'WC_Order' ) ? $order : wc_get_order( $order );
		if ( ! $order || isset( self::$rendered_orders[ $order->get_id() ] ) ) {
			return;
		}

		$details = self::details( $order );
		if ( ! $details ) {
			return;
		}

		self::$rendered_orders[ $order->get_id() ] = true;

		echo '<section class="woocommerce-order-details pmb-customer-payment-info">';
		echo '<h2 class="woocommerce-order-details__title">' . esc_html__( 'Payment Information', 'payment-methods-bangladesh' ) . '</h2>';
		echo '<table class="woocommerce-table shop_table pmb-payment-info-table"><tbody>';
		self::render_row( __( 'Payment method', 'payment-methods-bangladesh' ), esc_html( $details['method'] ) );
		self::render_row( __( 'Sender number', 'payment-methods-bangladesh' ), '<bdi>' . esc_html( $details['sender_number'] ) . '</bdi>' );
		self::render_row( __( 'Transaction ID', 'payment-methods-bangladesh' ), '<code>' . esc_html( $details['transaction_id'] ) . '</code>' );
		self::render_row( __( 'Amount', 'payment-methods-bangladesh' ), wp_kses_post( $details['amount_html'] ) );
		echo '</tbody></table>';
		echo '<p class="pmb-verification-note">' . esc_html__( 'Your payment information has been submitted and is awaiting verification.', 'payment-methods-bangladesh' ) . '</p>';
		echo '</section>';
	}

	/**
	 * Add a compact Payment Info column to HPOS order list.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public static function add_hpos_column( $columns ) {
		return self::insert_column( $columns );
	}

	/**
	 * Render the HPOS column.
	 *
	 * @param string   $column Column key.
	 * @param WC_Order $order Order object.
	 */
	public static function render_hpos_column( $column, $order ) {
		if ( 'pmb_payment_info' === $column ) {
			self::render_list_value( $order );
		}
	}

	/**
	 * Add a compact Payment Info column to legacy order list.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public static function add_legacy_column( $columns ) {
		return self::insert_column( $columns );
	}

	/**
	 * Render the legacy order list column.
	 *
	 * @param string $column Column key.
	 * @param int    $post_id Order post ID.
	 */
	public static function render_legacy_column( $column, $post_id ) {
		if ( 'pmb_payment_info' === $column ) {
			self::render_list_value( $post_id );
		}
	}

	/**
	 * Insert the column immediately before order actions when possible.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	private static function insert_column( $columns ) {
		$result = array();
		foreach ( $columns as $key => $label ) {
			if ( 'wc_actions' === $key ) {
				$result['pmb_payment_info'] = __( 'Payment Info', 'payment-methods-bangladesh' );
			}
			$result[ $key ] = $label;
		}

		if ( ! isset( $result['pmb_payment_info'] ) ) {
			$result['pmb_payment_info'] = __( 'Payment Info', 'payment-methods-bangladesh' );
		}

		return $result;
	}

	/**
	 * Compact list output.
	 *
	 * @param WC_Order|int $order Order object or ID.
	 */
	private static function render_list_value( $order ) {
		$details = self::details( $order );
		if ( ! $details ) {
			echo '<span aria-hidden="true">&mdash;</span><span class="screen-reader-text">' . esc_html__( 'Not a manual Bangladesh payment', 'payment-methods-bangladesh' ) . '</span>';
			return;
		}

		printf(
			'<strong>%1$s</strong><br><span title="%2$s">%3$s</span>',
			esc_html( $details['method'] ),
			esc_attr__( 'Transaction ID', 'payment-methods-bangladesh' ),
			esc_html( $details['transaction_id'] )
		);
	}

	/**
	 * Reusable table row with pre-escaped content.
	 *
	 * @param string $label Row label.
	 * @param string $value Safe HTML value.
	 */
	private static function render_row( $label, $value ) {
		printf( '<tr><th scope="row">%1$s</th><td>%2$s</td></tr>', esc_html( $label ), $value ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Every caller passes escaped, intentionally formatted HTML.
	}
}

