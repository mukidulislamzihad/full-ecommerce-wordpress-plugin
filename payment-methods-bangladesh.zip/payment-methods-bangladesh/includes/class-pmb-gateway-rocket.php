<?php
/**
 * Rocket Pay gateway.
 *
 * @package PaymentMethodsBangladesh
 */

defined( 'ABSPATH' ) || exit;

final class PMB_Gateway_Rocket extends PMB_Abstract_Gateway {
	public function __construct() {
		$this->id                 = 'pmb_rocket';
		$this->brand_name         = 'Rocket Pay';
		$this->sender_label       = __( 'Your Rocket Number', 'payment-methods-bangladesh' );
		$this->method_title       = __( 'Rocket Pay', 'payment-methods-bangladesh' );
		$this->method_description = __( 'Accept manual Rocket payments with sender number and Transaction ID verification.', 'payment-methods-bangladesh' );
		$this->initialize_gateway();
	}
}
