(function ($) {
  'use strict';

  function activateTab(root, tabName) {
    var form = root.querySelector('[data-settings-form]');
    var preview = root.querySelector('[data-preview-column]');
    var activeInput = root.querySelector('.bbl-active-tab');

    root.querySelectorAll('.bbl-tab').forEach(function (tab) {
      var active = tab.getAttribute('data-tab') === tabName;
      tab.classList.toggle('is-active', active);
      tab.setAttribute('aria-selected', active ? 'true' : 'false');
    });

    root.querySelectorAll('.bbl-panel').forEach(function (panel) {
      var active = panel.getAttribute('data-panel') === tabName;
      panel.classList.toggle('is-active', active);
      panel.hidden = !active;
    });

    if (form) form.hidden = tabName === 'license';
    if (preview) preview.hidden = tabName === 'license';
    if (activeInput && tabName !== 'license') activeInput.value = tabName;

    try { window.localStorage.setItem('bblActiveTab', tabName); } catch (error) {}
  }

  function initTabs(root) {
    var page = root.closest('.bbl-admin-page');
    var requested = page ? String(page.getAttribute('data-default-tab') || '') : '';
    var input = root.querySelector('.bbl-active-tab');
    var initial = requested || (input ? input.value : 'general');
    var allowed = ['general', 'appearance', 'effects', 'behavior', 'license'];

    if (requested !== 'license') {
      try { initial = window.localStorage.getItem('bblActiveTab') || initial; } catch (error) {}
    }
    if (allowed.indexOf(initial) === -1) initial = 'general';

    root.querySelectorAll('.bbl-tab').forEach(function (tab) {
      tab.addEventListener('click', function () {
        activateTab(root, tab.getAttribute('data-tab'));
      });
    });

    root.querySelectorAll('[data-open-license]').forEach(function (button) {
      button.addEventListener('click', function (event) {
        event.preventDefault();
        activateTab(root, 'license');
        var license = root.querySelector('[data-tab="license"]');
        if (license) license.focus();
        if (window.history && window.history.replaceState) window.history.replaceState(null, '', '#bbl-license');
      });
    });

    activateTab(root, initial);
  }

  function value(root, selector, fallback) {
    var field = root.querySelector(selector);
    return field && field.value !== '' ? field.value : fallback;
  }

  function updateLogo(root, url) {
    var thumb = root.querySelector('#bbl-thumb');
    var preview = root.querySelector('[data-preview-logo]');
    var safeUrl = String(url || '').trim();

    if (thumb) {
      thumb.innerHTML = '';
      if (safeUrl) {
        var image = document.createElement('img');
        image.src = safeUrl;
        image.alt = '';
        thumb.appendChild(image);
      } else {
        var icon = document.createElement('span');
        icon.className = 'dashicons dashicons-format-image';
        var label = document.createElement('small');
        label.textContent = thumb.getAttribute('data-empty-text') || 'No logo selected';
        thumb.appendChild(icon);
        thumb.appendChild(label);
      }
    }

    if (preview) {
      preview.innerHTML = '';
      if (safeUrl) {
        var previewImage = document.createElement('img');
        previewImage.src = safeUrl;
        previewImage.alt = '';
        preview.appendChild(previewImage);
      } else {
        var fallback = document.createElement('b');
        fallback.textContent = 'B';
        preview.appendChild(fallback);
      }
    }
  }

  function updatePreview(root) {
    var column = root.querySelector('[data-preview-column]');
    var loader = root.querySelector('[data-preview-loader]');
    if (!column || !loader) return;

    var selected = root.querySelector('input[name$="[style]"]:checked');
    var style = selected ? selected.value : 'ring';
    ['ring', 'orbit', 'double', 'pulse', 'minimal'].forEach(function (name) {
      loader.classList.toggle('style-' + name, name === style);
    });

    var neon = root.querySelector('[data-preview-toggle="neon"]');
    var glow = root.querySelector('[data-preview-toggle="glow"]');
    loader.classList.toggle('is-neon', !!(neon && neon.checked));
    loader.classList.toggle('is-glow', !!(glow && glow.checked));

    column.style.setProperty('--preview-accent', value(root, '[data-color-key="accent"]', '#ff2b2b'));
    column.style.setProperty('--preview-bg', value(root, '[data-color-key="bg"]', '#0b0f19'));
    column.style.setProperty('--preview-text', value(root, '[data-color-key="text_color"]', '#ffffff'));
    column.style.setProperty('--preview-glow', value(root, '[data-range-output="glow"]', '70'));

    var message = root.querySelector('[data-preview-message]');
    if (message) message.textContent = value(root, '[data-preview-text]', 'Loading, please wait...');

    root.querySelectorAll('.bbl-style-card').forEach(function (card) {
      card.classList.toggle('is-selected', card.getAttribute('data-style-choice') === style);
    });
  }

  function initRanges(root) {
    root.querySelectorAll('[data-range-output]').forEach(function (range) {
      var output = range.parentElement ? range.parentElement.querySelector('output') : null;
      var refresh = function () {
        if (output) output.textContent = range.value + '%';
        updatePreview(root);
      };
      range.addEventListener('input', refresh);
      refresh();
    });
  }

  function initLogo(root) {
    var input = root.querySelector('#bbl-logo');
    var upload = root.querySelector('#bbl-upload');
    var remove = root.querySelector('#bbl-remove-logo');
    var frame = null;

    if (upload && window.wp && window.wp.media) {
      upload.addEventListener('click', function (event) {
        event.preventDefault();
        if (frame) { frame.open(); return; }
        frame = window.wp.media({
          title: (window.BBLAdmin && BBLAdmin.mediaTitle) || 'Choose loader logo',
          button: { text: (window.BBLAdmin && BBLAdmin.mediaButton) || 'Use this logo' },
          multiple: false
        });
        frame.on('select', function () {
          var item = frame.state().get('selection').first().toJSON();
          if (input) input.value = item.url || '';
          updateLogo(root, item.url || '');
        });
        frame.open();
      });
    }

    if (remove) {
      remove.addEventListener('click', function (event) {
        event.preventDefault();
        if (input) input.value = '';
        updateLogo(root, '');
      });
    }
    if (input) input.addEventListener('input', function () { updateLogo(root, input.value); });
  }

  function initEditor(root) {
    root.addEventListener('input', function (event) {
      if (event.target.matches('input, select')) updatePreview(root);
    });
    root.addEventListener('change', function (event) {
      if (event.target.matches('input, select')) updatePreview(root);
    });

    $('.bbl-color').wpColorPicker({
      change: function () { window.setTimeout(function () { updatePreview(root); }, 0); },
      clear: function () { window.setTimeout(function () { updatePreview(root); }, 0); }
    });

    initLogo(root);
    initRanges(root);
    updatePreview(root);
  }

  $(function () {
    var root = document.querySelector('.bbl-dashboard');
    if (!root) return;
    initTabs(root);
    if (root.getAttribute('data-license-active') === '1') initEditor(root);
  });
})(jQuery);
