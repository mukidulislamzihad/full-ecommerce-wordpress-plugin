
(function(){
  const loader = document.getElementById('bbl-loader');
  if(!loader) return;

  const percentEl = document.getElementById('bbl-percent');
  const bar = loader.querySelector('.bbl-ring__bar');

  const minDisplay = (window.BBL && typeof BBL.minDisplay === 'number') ? BBL.minDisplay : parseInt(BBL?.minDisplay || 350,10);
  const soundEnabled = !!(window.BBL && BBL.sound);
  const soundUrl = (window.BBL && BBL.soundUrl) ? BBL.soundUrl : '';
  const volume = (window.BBL && typeof BBL.volume !== 'undefined') ? (parseInt(BBL.volume,10)/100) : 0.35;

  let start = Date.now();
  let p = 0;
  const circumference = 302; // matches CSS dasharray
  function setProgress(val){
    const v = Math.max(0, Math.min(100, val));
    if (percentEl) percentEl.textContent = String(v);
    if (bar) {
      const offset = circumference - (circumference * (v/100));
      bar.style.strokeDashoffset = String(offset);
    }
  }

  // Smooth fake progress that reaches 90% before load, then 100% on load
  let timer = setInterval(function(){
    if (document.readyState === 'complete') return;
    p = Math.min(90, p + (p < 40 ? 3 : (p < 75 ? 2 : 1)));
    setProgress(p);
  }, 140);

  // Sound handling: browsers may block autoplay
  let audio;
  function tryPlay(){
    if(!soundEnabled || !soundUrl) return;
    try{
      audio = new Audio(soundUrl);
      audio.volume = isNaN(volume) ? 0.35 : Math.max(0, Math.min(1, volume));
      const playPromise = audio.play();
      if (playPromise && typeof playPromise.catch === 'function') {
        playPromise.catch(function(){
          // unlock on first interaction
          const unlock = function(){
            try{ audio.play(); }catch(e){}
            window.removeEventListener('pointerdown', unlock);
            window.removeEventListener('keydown', unlock);
          };
          window.addEventListener('pointerdown', unlock, {once:true});
          window.addEventListener('keydown', unlock, {once:true});
        });
      }
    }catch(e){}
  }
  tryPlay();

  function reveal(){
    document.documentElement.classList.remove('bbl-preload');
    document.body.style.visibility = 'visible';
    document.body.style.overflow = '';
  }

  window.addEventListener('load', function(){
    clearInterval(timer);
    setProgress(100);

    const elapsed = Date.now() - start;
    const wait = Math.max(0, minDisplay - elapsed);

    setTimeout(function(){
      loader.classList.add('is-hiding');
      reveal();
      setTimeout(function(){ loader.remove(); }, 280);
    }, wait);
  });

  // Safety: if load event never fires, reveal after 8s
  setTimeout(function(){
    if (document.documentElement.classList.contains('bbl-preload')) {
      reveal();
      loader.remove();
    }
  }, 8000);

})();
