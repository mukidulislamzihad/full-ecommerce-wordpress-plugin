=== Borbila Premium Loader Plugin ===
Contributors: borbila
Tags: loader, preloader, animation, branding, borbila
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 2.0.0
License: Proprietary

Create a premium branded loader with progress, glow and optional sound.

== Description ==

Borbila Premium Loader provides five responsive loading styles, editable branding, visual effects, timing controls and optional audio.

Version 2.0 includes a redesigned administration experience and Borbila license protection. When the license is inactive, settings remain read-only and no loader markup, styles, scripts or sound are loaded on the public website.

License template ID: `loader`

== Changelog ==

= 2.0.0 =

* Changed plugin author and branding to Borbila.
* Added Borbila server license activation, checking and deactivation.
* Added secure lifetime master-license support without storing the raw key.
* Added daily license validation with network-failure protection.
* Locked settings and disabled frontend loader assets while inactive.
* Added premium vertical navigation and live loader preview.
* Added responsive controls for logo, colors, effects, sound and timing.
* Added cache-friendly file-versioned admin and frontend assets.
