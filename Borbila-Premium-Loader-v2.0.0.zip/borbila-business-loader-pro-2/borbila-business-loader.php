<?php
/**
 * Plugin Name: Borbila Premium Loader Plugin
 * Description: Advanced business-style site loader with neon glow, progress ring and optional sound.
 * Version: 2.0.0
 * Author: Borbila
 * Author URI: https://www.borbila.com
 * Plugin URI: https://www.borbila.com
 * Text Domain: borbila-premium-loader
 */

if (!defined('ABSPATH')) exit;

define('BBL_VERSION', '2.0.0');
define('BBL_FILE', __FILE__);
define('BBL_URL', plugin_dir_url(__FILE__));
define('BBL_PATH', plugin_dir_path(__FILE__));
define('BBL_OPT', 'bbl_settings');

require_once BBL_PATH . 'includes/settings.php';
require_once BBL_PATH . 'includes/render.php';
require_once BBL_PATH . 'includes/class-bbl-license.php';

BBL_License::register_hooks();

add_action('plugins_loaded', function () {
    BBL_Settings::init();
    BBL_Render::init();
});

register_activation_hook(__FILE__, function(){
    if (!get_option(BBL_OPT)) {
        add_option(BBL_OPT, BBL_Settings::defaults());
    }
    BBL_License::install();
});

register_deactivation_hook(__FILE__, array('BBL_License', 'unschedule'));
