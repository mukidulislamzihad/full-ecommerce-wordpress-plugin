<?php
if (!defined('ABSPATH')) exit;

class BBL_Render {

    private static $printed = false;

    public static function init(){
        add_action('wp_enqueue_scripts',[__CLASS__,'assets']);
        add_action('wp_head',[__CLASS__,'head'], 0);
        add_action('wp_body_open',[__CLASS__,'html'],0);
        add_action('wp_footer',[__CLASS__,'fallback'],0);
    }

    private static function should_show($o){
        if (!BBL_License::is_active()) return false;
        if (is_admin()) return false;
        if (empty($o['enabled'])) return false;
        if (!empty($o['hide_for_admin']) && current_user_can('manage_options')) return false;
        return true;
    }

    public static function assets(){
        if(is_admin()) return;
        $o = BBL_Settings::get();
        if (!self::should_show($o)) return;

        $css = BBL_PATH . 'assets/front.css';
        $js  = BBL_PATH . 'assets/front.js';
        wp_enqueue_style('bbl-front', BBL_URL.'assets/front.css', [], file_exists($css) ? (string) filemtime($css) : BBL_VERSION);
        wp_enqueue_script('bbl-front', BBL_URL.'assets/front.js', [], file_exists($js) ? (string) filemtime($js) : BBL_VERSION, true);

        wp_localize_script('bbl-front', 'BBL', [
            'minDisplay' => intval($o['min_display_ms'] ?? 350),
            'sound' => !empty($o['sound']) ? 1 : 0,
            'soundUrl' => !empty($o['sound_url']) ? esc_url($o['sound_url']) : BBL_URL.'assets/beep.wav',
            'volume' => max(0, min(100, intval($o['sound_volume'] ?? 35))),
        ]);
    }

    public static function head(){
        $o = BBL_Settings::get();
        if (!self::should_show($o)) return;

        // Add class as early as possible so theme doesn't flash
        echo "<script>(function(){document.documentElement.classList.add('bbl-preload');})();</script>\n";
        echo "<style>
            html.bbl-preload body{visibility:hidden; overflow:hidden;}
            html.bbl-preload #bbl-loader{visibility:visible;}
        </style>\n";
    }

    public static function html(){
        $o = BBL_Settings::get();
        if (!self::should_show($o) || self::$printed) return;

        $vars = sprintf(
            '--bbl-accent:%s;--bbl-bg:%s;--bbl-text:%s;--bbl-glow:%s;',
            esc_attr($o['accent']),
            esc_attr($o['bg']),
            esc_attr($o['text_color']),
            esc_attr(intval($o['glow_intensity']))
        );

        $classes = 'bbl-loader style-' . esc_attr($o['style']);
        if (!empty($o['neon'])) $classes .= ' is-neon';
        if (!empty($o['glow'])) $classes .= ' is-glow';

        $logo = !empty($o['logo']) ? '<img src="'.esc_url($o['logo']).'" alt="Logo" />' : '<span class="bbl-fallback">B</span>';

        echo '<div id="bbl-loader" class="'.$classes.'" style="'.$vars.'" aria-hidden="true">
                <div class="bbl-bg"></div>
                <div class="bbl-center">
                    <div class="bbl-orbit" aria-hidden="true"></div>

                    <div class="bbl-ringwrap" aria-hidden="true">
                        <svg class="bbl-ring" viewBox="0 0 120 120">
                            <circle class="bbl-ring__track" cx="60" cy="60" r="48"></circle>
                            <circle class="bbl-ring__bar" cx="60" cy="60" r="48"></circle>
                        </svg>
                    </div>

                    <div class="bbl-logo">'.$logo.'</div>

                    <div class="bbl-percent"><span id="bbl-percent">0</span><span class="bbl-percent__sym">%</span></div>
                    <div class="bbl-text" id="bbl-text">'.esc_html($o['text']).'</div>

                    <div class="bbl-pulse" aria-hidden="true">
                        <i></i><i></i><i></i><i></i><i></i>
                    </div>

                    <div class="bbl-minimaldot" aria-hidden="true"></div>
                </div>
            </div>';

        self::$printed = true;
    }

    public static function fallback(){
        if (self::$printed) return;
        self::html();
    }
}
