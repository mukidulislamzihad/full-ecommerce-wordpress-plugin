<?php
if (!defined('ABSPATH')) {
    exit;
}

class BBL_Settings
{
    public static function defaults()
    {
        return array(
            'enabled'         => 1,
            'logo'            => '',
            'text'            => 'Loading, please wait...',
            'accent'          => '#ff2b2b',
            'bg'              => '#0b0f19',
            'text_color'      => '#ffffff',
            'style'           => 'ring',
            'neon'            => 1,
            'glow'            => 1,
            'glow_intensity'  => 70,
            'sound'           => 1,
            'sound_url'       => '',
            'sound_volume'    => 35,
            'min_display_ms'  => 350,
            'hide_for_admin'  => 0,
            'active_tab'      => 'general',
        );
    }

    public static function styles()
    {
        return array(
            'ring'    => array('label' => __('Business Ring', 'borbila-premium-loader'), 'description' => __('Clean circular progress around your logo.', 'borbila-premium-loader')),
            'orbit'   => array('label' => __('Orbit Dashed', 'borbila-premium-loader'), 'description' => __('Animated orbital detail with a modern feel.', 'borbila-premium-loader')),
            'double'  => array('label' => __('Double Glow', 'borbila-premium-loader'), 'description' => __('Layered glow for a bold premium entrance.', 'borbila-premium-loader')),
            'pulse'   => array('label' => __('Pulse Bars', 'borbila-premium-loader'), 'description' => __('A compact equalizer-inspired animation.', 'borbila-premium-loader')),
            'minimal' => array('label' => __('Minimal Dot', 'borbila-premium-loader'), 'description' => __('Quiet, lightweight loading indicator.', 'borbila-premium-loader')),
        );
    }

    public static function init()
    {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_init', array(__CLASS__, 'register'));
        add_filter('plugin_action_links_' . plugin_basename(BBL_FILE), array(__CLASS__, 'links'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'assets'));
    }

    public static function menu()
    {
        add_options_page(__('Borbila Premium Loader', 'borbila-premium-loader'), __('Premium Loader', 'borbila-premium-loader'), 'manage_options', 'bbl-loader', array(__CLASS__, 'page'));
    }

    public static function register()
    {
        register_setting('bbl-loader', BBL_OPT, array(__CLASS__, 'sanitize'));
    }

    public static function sanitize($input)
    {
        if (!BBL_License::is_active()) {
            add_settings_error(BBL_OPT, 'bbl_license_required', __('Settings were not changed. Activate your Borbila license first.', 'borbila-premium-loader'), 'error');
            return self::get();
        }

        $defaults = self::defaults();
        $input    = is_array($input) ? $input : array();
        $styles   = array_keys(self::styles());
        $style    = isset($input['style']) ? sanitize_key($input['style']) : $defaults['style'];
        $tab      = isset($input['active_tab']) ? sanitize_key($input['active_tab']) : $defaults['active_tab'];

        if (!in_array($style, $styles, true)) {
            $style = $defaults['style'];
        }
        if (!in_array($tab, array('general', 'appearance', 'effects', 'behavior'), true)) {
            $tab = $defaults['active_tab'];
        }

        return array(
            'enabled'         => !empty($input['enabled']) ? 1 : 0,
            'logo'            => isset($input['logo']) ? esc_url_raw($input['logo']) : '',
            'text'            => isset($input['text']) && '' !== trim((string) $input['text']) ? sanitize_text_field($input['text']) : $defaults['text'],
            'accent'          => self::color(isset($input['accent']) ? $input['accent'] : '', $defaults['accent']),
            'bg'              => self::color(isset($input['bg']) ? $input['bg'] : '', $defaults['bg']),
            'text_color'      => self::color(isset($input['text_color']) ? $input['text_color'] : '', $defaults['text_color']),
            'style'           => $style,
            'neon'            => !empty($input['neon']) ? 1 : 0,
            'glow'            => !empty($input['glow']) ? 1 : 0,
            'glow_intensity'  => max(0, min(100, absint(isset($input['glow_intensity']) ? $input['glow_intensity'] : $defaults['glow_intensity']))),
            'sound'           => !empty($input['sound']) ? 1 : 0,
            'sound_url'       => isset($input['sound_url']) ? esc_url_raw($input['sound_url']) : '',
            'sound_volume'    => max(0, min(100, absint(isset($input['sound_volume']) ? $input['sound_volume'] : $defaults['sound_volume']))),
            'min_display_ms'  => max(0, min(10000, absint(isset($input['min_display_ms']) ? $input['min_display_ms'] : $defaults['min_display_ms']))),
            'hide_for_admin'  => !empty($input['hide_for_admin']) ? 1 : 0,
            'active_tab'      => $tab,
        );
    }

    private static function color($color, $fallback)
    {
        $sanitized = sanitize_hex_color(trim((string) $color));
        return $sanitized ? $sanitized : $fallback;
    }

    public static function get()
    {
        $saved = get_option(BBL_OPT, array());
        return wp_parse_args(is_array($saved) ? $saved : array(), self::defaults());
    }

    public static function links($links)
    {
        $license  = '<a href="' . esc_url(admin_url('options-general.php?page=bbl-loader&tab=license#bbl-license')) . '">' . esc_html__('License', 'borbila-premium-loader') . '</a>';
        $settings = '<a href="' . esc_url(admin_url('options-general.php?page=bbl-loader')) . '">' . esc_html__('Settings', 'borbila-premium-loader') . '</a>';
        array_unshift($links, $license, $settings);
        return $links;
    }

    public static function assets($hook)
    {
        if ('settings_page_bbl-loader' !== $hook) {
            return;
        }
        wp_enqueue_media();
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        $css = BBL_PATH . 'assets/admin.css';
        $js  = BBL_PATH . 'assets/admin.js';
        wp_enqueue_style('bbl-admin', BBL_URL . 'assets/admin.css', array(), file_exists($css) ? (string) filemtime($css) : BBL_VERSION);
        wp_enqueue_script('bbl-admin', BBL_URL . 'assets/admin.js', array('jquery', 'wp-color-picker'), file_exists($js) ? (string) filemtime($js) : BBL_VERSION, true);
        wp_localize_script('bbl-admin', 'BBLAdmin', array(
            'licenseActive' => BBL_License::is_active(),
            'mediaTitle'    => __('Choose loader logo', 'borbila-premium-loader'),
            'mediaButton'   => __('Use this logo', 'borbila-premium-loader'),
            'emptyLogo'     => __('No logo selected', 'borbila-premium-loader'),
        ));
    }

    public static function page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $options        = self::get();
        $license_active = BBL_License::is_active();
        $initial_tab    = isset($_GET['tab']) && 'license' === sanitize_key(wp_unslash($_GET['tab'])) ? 'license' : $options['active_tab'];
        ?>
        <div class="wrap bbl-admin-page" data-default-tab="<?php echo esc_attr($initial_tab); ?>">
            <header class="bbl-admin-header">
                <div class="bbl-admin-brand"><span class="dashicons dashicons-update-alt"></span><div><span class="bbl-kicker"><?php esc_html_e('BORBILA PERFORMANCE TOOLS', 'borbila-premium-loader'); ?></span><h1><?php esc_html_e('Premium Loader', 'borbila-premium-loader'); ?></h1><p><?php esc_html_e('Create a polished branded loading experience for every visitor.', 'borbila-premium-loader'); ?></p></div></div>
                <span class="bbl-license-pill <?php echo $license_active ? 'is-active' : 'is-inactive'; ?>"><span class="dashicons <?php echo $license_active ? 'dashicons-shield-alt' : 'dashicons-lock'; ?>"></span><?php echo $license_active ? esc_html__('Licensed', 'borbila-premium-loader') : esc_html__('License required', 'borbila-premium-loader'); ?></span>
            </header>
            <?php settings_errors(BBL_OPT); ?>

            <div class="bbl-dashboard" data-license-active="<?php echo $license_active ? '1' : '0'; ?>">
                <nav class="bbl-tabs" role="tablist" aria-label="<?php esc_attr_e('Loader settings', 'borbila-premium-loader'); ?>">
                    <span class="bbl-tab-caption"><?php esc_html_e('Customize', 'borbila-premium-loader'); ?></span>
                    <?php self::tab_button('general', 'dashicons-admin-generic', __('General', 'borbila-premium-loader')); ?>
                    <?php self::tab_button('appearance', 'dashicons-art', __('Appearance', 'borbila-premium-loader')); ?>
                    <?php self::tab_button('effects', 'dashicons-superhero-alt', __('Effects', 'borbila-premium-loader')); ?>
                    <?php self::tab_button('behavior', 'dashicons-controls-volumeon', __('Sound & Timing', 'borbila-premium-loader')); ?>
                    <span class="bbl-tab-divider"></span>
                    <button type="button" class="bbl-tab bbl-license-tab" data-tab="license" role="tab" aria-selected="false"><span class="dashicons dashicons-lock"></span><?php esc_html_e('License', 'borbila-premium-loader'); ?><em><?php echo $license_active ? esc_html__('Active', 'borbila-premium-loader') : esc_html__('Required', 'borbila-premium-loader'); ?></em></button>
                    <div class="bbl-tab-help"><span class="dashicons dashicons-info-outline"></span><p><?php esc_html_e('Changes appear instantly in the preview and go live after saving.', 'borbila-premium-loader'); ?></p></div>
                </nav>

                <form method="post" action="options.php" class="bbl-settings-card <?php echo $license_active ? '' : 'is-license-locked'; ?>" data-settings-form>
                    <?php settings_fields('bbl-loader'); ?>
                    <input type="hidden" class="bbl-active-tab" name="<?php echo esc_attr(BBL_OPT); ?>[active_tab]" value="<?php echo esc_attr($options['active_tab']); ?>">
                    <?php if (!$license_active) : ?><div class="bbl-lock-banner"><span class="dashicons dashicons-lock"></span><div><strong><?php esc_html_e('Loader settings are locked', 'borbila-premium-loader'); ?></strong><small><?php esc_html_e('Activate your Borbila license to edit, preview and publish changes.', 'borbila-premium-loader'); ?></small></div><button type="button" class="button button-primary" data-open-license><?php esc_html_e('Activate License', 'borbila-premium-loader'); ?></button></div><?php endif; ?>

                    <fieldset class="bbl-settings-fieldset" <?php disabled(!$license_active); ?>>
                        <?php self::panel_general($options); ?>
                        <?php self::panel_appearance($options); ?>
                        <?php self::panel_effects($options); ?>
                        <?php self::panel_behavior($options); ?>
                        <div class="bbl-savebar"><span><span class="dashicons <?php echo $license_active ? 'dashicons-saved' : 'dashicons-lock'; ?>"></span><?php echo $license_active ? esc_html__('Ready to publish your loader settings.', 'borbila-premium-loader') : esc_html__('Activate the license before saving.', 'borbila-premium-loader'); ?></span><?php submit_button(__('Save Changes', 'borbila-premium-loader'), 'primary', 'submit', false, $license_active ? array() : array('disabled' => 'disabled')); ?></div>
                    </fieldset>
                </form>

                <?php self::preview($options, $license_active); ?>
                <section id="bbl-license" class="bbl-panel bbl-license-panel" data-panel="license" role="tabpanel" hidden><?php self::license_panel(); ?></section>
            </div>
        </div>
        <?php
    }

    private static function tab_button($tab, $icon, $label)
    {
        printf('<button type="button" class="bbl-tab" data-tab="%1$s" role="tab" aria-selected="false"><span class="dashicons %2$s"></span>%3$s</button>', esc_attr($tab), esc_attr($icon), esc_html($label));
    }

    private static function panel_heading($kicker, $title, $description)
    {
        echo '<header class="bbl-panel-heading"><span class="bbl-kicker">' . esc_html($kicker) . '</span><h2>' . esc_html($title) . '</h2><p>' . esc_html($description) . '</p></header>';
    }

    private static function panel_general($options)
    {
        ?>
        <section class="bbl-panel" data-panel="general" role="tabpanel" hidden>
            <?php self::panel_heading(__('CORE SETTINGS', 'borbila-premium-loader'), __('Loader & style', 'borbila-premium-loader'), __('Choose when the loader runs and its base animation.', 'borbila-premium-loader')); ?>
            <label class="bbl-feature-row"><span class="bbl-feature-icon"><span class="dashicons dashicons-visibility"></span></span><span><strong><?php esc_html_e('Enable premium loader', 'borbila-premium-loader'); ?></strong><small><?php esc_html_e('Display the branded loader on public pages.', 'borbila-premium-loader'); ?></small></span><span class="bbl-switch"><input type="checkbox" name="<?php echo esc_attr(BBL_OPT); ?>[enabled]" value="1" <?php checked(1, $options['enabled']); ?>><i></i></span></label>
            <div class="bbl-field-title"><?php esc_html_e('Loader style', 'borbila-premium-loader'); ?></div>
            <div class="bbl-style-grid">
                <?php foreach (self::styles() as $key => $style) : ?><label class="bbl-style-card <?php echo $key === $options['style'] ? 'is-selected' : ''; ?>" data-style-choice="<?php echo esc_attr($key); ?>"><input type="radio" name="<?php echo esc_attr(BBL_OPT); ?>[style]" value="<?php echo esc_attr($key); ?>" <?php checked($options['style'], $key); ?>><span class="bbl-style-visual style-<?php echo esc_attr($key); ?>"><i></i><b></b><em></em></span><strong><?php echo esc_html($style['label']); ?></strong><small><?php echo esc_html($style['description']); ?></small><span class="bbl-style-check dashicons dashicons-yes-alt"></span></label><?php endforeach; ?>
            </div>
        </section>
        <?php
    }

    private static function panel_appearance($options)
    {
        ?>
        <section class="bbl-panel" data-panel="appearance" role="tabpanel" hidden>
            <?php self::panel_heading(__('BRAND APPEARANCE', 'borbila-premium-loader'), __('Logo, message & colors', 'borbila-premium-loader'), __('Match the loader with your website identity.', 'borbila-premium-loader')); ?>
            <div class="bbl-logo-layout"><div class="bbl-thumb" id="bbl-thumb" data-empty-text="<?php esc_attr_e('No logo selected', 'borbila-premium-loader'); ?>"><?php if (!empty($options['logo'])) : ?><img src="<?php echo esc_url($options['logo']); ?>" alt=""><?php else : ?><span class="dashicons dashicons-format-image"></span><small><?php esc_html_e('No logo selected', 'borbila-premium-loader'); ?></small><?php endif; ?></div><div class="bbl-logo-controls"><label class="bbl-field"><span><?php esc_html_e('Logo URL', 'borbila-premium-loader'); ?></span><input type="url" id="bbl-logo" name="<?php echo esc_attr(BBL_OPT); ?>[logo]" value="<?php echo esc_attr($options['logo']); ?>" placeholder="https://example.com/logo.png"></label><div class="bbl-button-row"><button type="button" class="button button-primary" id="bbl-upload"><span class="dashicons dashicons-upload"></span><?php esc_html_e('Choose Logo', 'borbila-premium-loader'); ?></button><button type="button" class="button" id="bbl-remove-logo"><?php esc_html_e('Remove', 'borbila-premium-loader'); ?></button></div><p class="description"><?php esc_html_e('A square transparent PNG or WebP gives the cleanest result.', 'borbila-premium-loader'); ?></p></div></div>
            <label class="bbl-field bbl-field-full"><span><?php esc_html_e('Loading message', 'borbila-premium-loader'); ?></span><input type="text" name="<?php echo esc_attr(BBL_OPT); ?>[text]" value="<?php echo esc_attr($options['text']); ?>" data-preview-text></label>
            <div class="bbl-color-grid"><?php self::color_field('accent', __('Accent color', 'borbila-premium-loader'), $options['accent']); ?><?php self::color_field('bg', __('Background color', 'borbila-premium-loader'), $options['bg']); ?><?php self::color_field('text_color', __('Text color', 'borbila-premium-loader'), $options['text_color']); ?></div>
        </section>
        <?php
    }

    private static function color_field($key, $label, $value)
    {
        echo '<label class="bbl-field"><span>' . esc_html($label) . '</span><input class="bbl-color" data-color-key="' . esc_attr($key) . '" name="' . esc_attr(BBL_OPT) . '[' . esc_attr($key) . ']" value="' . esc_attr($value) . '"></label>';
    }

    private static function panel_effects($options)
    {
        ?>
        <section class="bbl-panel" data-panel="effects" role="tabpanel" hidden>
            <?php self::panel_heading(__('VISUAL EFFECTS', 'borbila-premium-loader'), __('Premium glow controls', 'borbila-premium-loader'), __('Add depth while keeping the loader smooth and focused.', 'borbila-premium-loader')); ?>
            <div class="bbl-toggle-grid"><label class="bbl-toggle-card"><span class="bbl-feature-icon"><span class="dashicons dashicons-lightbulb"></span></span><span><strong><?php esc_html_e('Neon mode', 'borbila-premium-loader'); ?></strong><small><?php esc_html_e('Creates a brighter animated ring highlight.', 'borbila-premium-loader'); ?></small></span><span class="bbl-switch"><input type="checkbox" name="<?php echo esc_attr(BBL_OPT); ?>[neon]" value="1" <?php checked(1, $options['neon']); ?> data-preview-toggle="neon"><i></i></span></label><label class="bbl-toggle-card"><span class="bbl-feature-icon"><span class="dashicons dashicons-star-filled"></span></span><span><strong><?php esc_html_e('Logo glow', 'borbila-premium-loader'); ?></strong><small><?php esc_html_e('Adds a premium aura around the brand mark.', 'borbila-premium-loader'); ?></small></span><span class="bbl-switch"><input type="checkbox" name="<?php echo esc_attr(BBL_OPT); ?>[glow]" value="1" <?php checked(1, $options['glow']); ?> data-preview-toggle="glow"><i></i></span></label></div>
            <label class="bbl-range-card"><span><strong><?php esc_html_e('Glow intensity', 'borbila-premium-loader'); ?></strong><small><?php esc_html_e('Control how strongly the logo and ring illuminate.', 'borbila-premium-loader'); ?></small></span><input type="range" min="0" max="100" name="<?php echo esc_attr(BBL_OPT); ?>[glow_intensity]" value="<?php echo esc_attr($options['glow_intensity']); ?>" data-range-output="glow"><output><?php echo esc_html($options['glow_intensity']); ?>%</output></label>
        </section>
        <?php
    }

    private static function panel_behavior($options)
    {
        ?>
        <section class="bbl-panel" data-panel="behavior" role="tabpanel" hidden>
            <?php self::panel_heading(__('SOUND & BEHAVIOR', 'borbila-premium-loader'), __('Timing and audio', 'borbila-premium-loader'), __('Fine-tune the loading experience without slowing the website.', 'borbila-premium-loader')); ?>
            <div class="bbl-toggle-grid"><label class="bbl-toggle-card"><span class="bbl-feature-icon"><span class="dashicons dashicons-controls-volumeon"></span></span><span><strong><?php esc_html_e('Enable sound', 'borbila-premium-loader'); ?></strong><small><?php esc_html_e('Play the default beep or your own short audio.', 'borbila-premium-loader'); ?></small></span><span class="bbl-switch"><input type="checkbox" name="<?php echo esc_attr(BBL_OPT); ?>[sound]" value="1" <?php checked(1, $options['sound']); ?>><i></i></span></label><label class="bbl-toggle-card"><span class="bbl-feature-icon"><span class="dashicons dashicons-admin-users"></span></span><span><strong><?php esc_html_e('Hide for administrators', 'borbila-premium-loader'); ?></strong><small><?php esc_html_e('Skip the loader for logged-in site managers.', 'borbila-premium-loader'); ?></small></span><span class="bbl-switch"><input type="checkbox" name="<?php echo esc_attr(BBL_OPT); ?>[hide_for_admin]" value="1" <?php checked(1, $options['hide_for_admin']); ?>><i></i></span></label></div>
            <div class="bbl-field-grid"><label class="bbl-field bbl-field-full"><span><?php esc_html_e('Custom sound URL (optional)', 'borbila-premium-loader'); ?></span><input type="url" name="<?php echo esc_attr(BBL_OPT); ?>[sound_url]" value="<?php echo esc_attr($options['sound_url']); ?>" placeholder="https://example.com/loading.mp3"><small><?php esc_html_e('Leave blank to use the bundled loader sound.', 'borbila-premium-loader'); ?></small></label><label class="bbl-range-card"><span><strong><?php esc_html_e('Sound volume', 'borbila-premium-loader'); ?></strong><small><?php esc_html_e('Recommended: 20–40%.', 'borbila-premium-loader'); ?></small></span><input type="range" min="0" max="100" name="<?php echo esc_attr(BBL_OPT); ?>[sound_volume]" value="<?php echo esc_attr($options['sound_volume']); ?>" data-range-output="volume"><output><?php echo esc_html($options['sound_volume']); ?>%</output></label><label class="bbl-field"><span><?php esc_html_e('Minimum display time', 'borbila-premium-loader'); ?></span><span class="bbl-input-suffix"><input type="number" min="0" max="10000" step="50" name="<?php echo esc_attr(BBL_OPT); ?>[min_display_ms]" value="<?php echo esc_attr($options['min_display_ms']); ?>"><i>ms</i></span><small><?php esc_html_e('0–10000 milliseconds. 350ms is recommended.', 'borbila-premium-loader'); ?></small></label></div>
            <div class="bbl-browser-note"><span class="dashicons dashicons-info-outline"></span><p><?php esc_html_e('Browsers may block autoplay audio. When blocked, sound starts after the visitor’s first click or tap.', 'borbila-premium-loader'); ?></p></div>
        </section>
        <?php
    }

    private static function preview($options, $license_active)
    {
        $classes = 'bbl-preview-loader style-' . sanitize_html_class($options['style']);
        $classes .= !empty($options['neon']) ? ' is-neon' : '';
        $classes .= !empty($options['glow']) ? ' is-glow' : '';
        ?>
        <aside class="bbl-live-preview" data-preview-column style="--preview-accent:<?php echo esc_attr($options['accent']); ?>;--preview-bg:<?php echo esc_attr($options['bg']); ?>;--preview-text:<?php echo esc_attr($options['text_color']); ?>;--preview-glow:<?php echo esc_attr($options['glow_intensity']); ?>;"><header><div><strong><?php esc_html_e('Live preview', 'borbila-premium-loader'); ?></strong><small><?php esc_html_e('Updates while you edit', 'borbila-premium-loader'); ?></small></div><span class="bbl-live-dot"><?php esc_html_e('LIVE', 'borbila-premium-loader'); ?></span></header><div class="bbl-preview-browser"><div class="bbl-browser-bar"><i></i><i></i><i></i><span></span></div><div class="<?php echo esc_attr($classes); ?>" data-preview-loader><span class="bbl-preview-orbit"></span><span class="bbl-preview-ring"></span><span class="bbl-preview-logo" data-preview-logo><?php if (!empty($options['logo'])) : ?><img src="<?php echo esc_url($options['logo']); ?>" alt=""><?php else : ?><b>B</b><?php endif; ?></span><span class="bbl-preview-percent">72%</span><span class="bbl-preview-message" data-preview-message><?php echo esc_html($options['text']); ?></span><span class="bbl-preview-bars"><i></i><i></i><i></i><i></i><i></i></span><span class="bbl-preview-dot"></span></div><?php if (!$license_active) : ?><div class="bbl-preview-lock"><span class="dashicons dashicons-lock"></span><strong><?php esc_html_e('Preview locked', 'borbila-premium-loader'); ?></strong><small><?php esc_html_e('Activate your license', 'borbila-premium-loader'); ?></small></div><?php endif; ?></div><p><span class="dashicons dashicons-smartphone"></span><?php esc_html_e('Responsive on desktop, tablet and mobile.', 'borbila-premium-loader'); ?></p></aside>
        <?php
    }

    private static function license_panel()
    {
        $license = BBL_License::get();
        $active  = BBL_License::is_active();
        $key     = 'bbl_loader_license_notice_' . get_current_user_id();
        $notice  = get_transient($key);
        if (false !== $notice) {
            delete_transient($key);
        }
        $checked = !empty($license['last_checked']) ? wp_date(get_option('date_format') . ' · ' . get_option('time_format'), strtotime($license['last_checked'])) : __('Never', 'borbila-premium-loader');
        ?>
        <?php if (is_array($notice)) : ?><div class="bbl-license-notice <?php echo !empty($notice['success']) ? 'is-success' : 'is-error'; ?>"><span class="dashicons <?php echo !empty($notice['success']) ? 'dashicons-yes-alt' : 'dashicons-warning'; ?>"></span><?php echo esc_html(isset($notice['message']) ? $notice['message'] : ''); ?></div><?php endif; ?>
        <section class="bbl-license-status <?php echo $active ? 'is-active' : 'is-inactive'; ?>"><span class="bbl-license-status-icon"><span class="dashicons <?php echo $active ? 'dashicons-shield-alt' : 'dashicons-lock'; ?>"></span></span><div><span class="bbl-kicker"><?php esc_html_e('BORBILA LICENSING', 'borbila-premium-loader'); ?></span><h2><?php echo $active ? esc_html__('Your loader license is active', 'borbila-premium-loader') : esc_html__('Activate Premium Loader', 'borbila-premium-loader'); ?></h2><p><?php echo $active ? esc_html__('All loader settings and public animations are unlocked.', 'borbila-premium-loader') : esc_html__('Settings and frontend loader remain disabled until activation.', 'borbila-premium-loader'); ?></p></div><strong><?php echo $active ? esc_html__('ACTIVE', 'borbila-premium-loader') : esc_html__('INACTIVE', 'borbila-premium-loader'); ?></strong></section>
        <div class="bbl-license-grid"><section class="bbl-license-card"><h2><?php esc_html_e('Manage License', 'borbila-premium-loader'); ?></h2><p><?php esc_html_e('Enter the license assigned to template ID “loader”.', 'borbila-premium-loader'); ?></p><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="bbl_loader_license_action"><?php wp_nonce_field('bbl_loader_license_action', 'bbl_loader_license_nonce'); ?><label for="bbl-license-key"><?php esc_html_e('License key', 'borbila-premium-loader'); ?></label><div class="bbl-license-key-row"><input id="bbl-license-key" name="license_key" type="text" value="<?php echo esc_attr(BBL_License::mask($license['license_key'])); ?>" placeholder="BRB-XXXX-XXXX-XXXX" autocomplete="off"><button class="button button-primary" name="license_operation" value="activate"><?php esc_html_e('Activate License', 'borbila-premium-loader'); ?></button></div><div class="bbl-license-actions"><?php if ($active) : ?><button class="button" name="license_operation" value="check"><?php esc_html_e('Check License', 'borbila-premium-loader'); ?></button><button class="button bbl-danger" name="license_operation" value="deactivate"><?php esc_html_e('Deactivate', 'borbila-premium-loader'); ?></button><?php endif; ?><a class="button" href="https://borbila.com/my-account/licenses/" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Get License', 'borbila-premium-loader'); ?></a></div></form></section><div class="bbl-license-meta"><div><span><?php esc_html_e('Website', 'borbila-premium-loader'); ?></span><strong><?php echo esc_html(BBL_License::domain()); ?></strong></div><div><span><?php esc_html_e('Template ID', 'borbila-premium-loader'); ?></span><strong><?php echo esc_html(BBL_License::TEMPLATE_ID); ?></strong></div><div><span><?php esc_html_e('Validity', 'borbila-premium-loader'); ?></span><strong><?php echo $active ? esc_html__('Lifetime', 'borbila-premium-loader') : '—'; ?></strong></div><div><span><?php esc_html_e('Last checked', 'borbila-premium-loader'); ?></span><strong><?php echo esc_html($checked); ?></strong></div></div></div>
        <?php
    }
}
